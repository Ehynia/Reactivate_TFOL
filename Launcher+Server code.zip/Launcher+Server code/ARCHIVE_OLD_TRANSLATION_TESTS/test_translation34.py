"""Full preparation, verified streaming, cancellation and launch-gating regressions."""
import hashlib,importlib.util,io,json,struct,tempfile,unittest,zlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,Mock
import launcher_entry
ROOT=Path(__file__).parent;LANG=ROOT.parent/'ClientLanguages'
def load(name):
    spec=importlib.util.spec_from_file_location('test34_'+name,LANG/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
full=load('full_preparation');scan=full.scan;ui=scan.ui
def ftext(source,key='A'*32):
    def string(s):b=s.encode()+b'\0';return struct.pack('<i',len(b))+b
    return struct.pack('<IB',8,0)+string('')+string(key)+string(source)

class CompletePreparation34(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name);self.game=self.path/'TFOL';self.cache=self.path/'cache'
        (self.game/'Binaries/Win32').mkdir(parents=True);(self.game/'Content/Paks').mkdir(parents=True)
        self.pak=self.game/'Content/Paks/TFOL-WindowsNoEditor_1.pak'
        self.pak.write_bytes(ui.locres.build_pak({'Blueprints/Missions/Test.uasset':b'x'*131060+ftext('系统设置'),'Other/Test.uexp':ftext('未知测试文本','B'*32)}))
        self.original=self.pak.read_bytes()
    def tearDown(self):self.tmp.cleanup()
    def state(self):return scan.gather(self.game,self.cache)
    def prepare(self,provider=lambda *a:'Тестовый текст',**kwargs):
        # Isolate the full scanner/translation flow from unrelated missing-table catalogue entries.
        raw=(LANG/'translation_candidates.json').read_bytes();real=json.loads
        def loads(data,*a,**kw):return {'entries':[]} if data==raw else real(data,*a,**kw)
        with patch.object(full.json,'loads',side_effect=loads):
            return full.prepare(self.game,'ru',self.cache,provider=provider,**kwargs)
    def test_streaming_finds_non_umg_and_boundary_ftext_and_never_edits_original(self):
        state=self.state();self.assertTrue(state['complete']);self.assertEqual(state['eligible_assets'],2)
        self.assertEqual({r['source'] for r in state['rows']},{'系统设置','未知测试文本'})
        self.assertEqual(self.pak.read_bytes(),self.original)
        with patch.object(ui.pak,'index',side_effect=AssertionError('complete scan should be cached')):
            self.assertTrue(scan.gather(self.game,self.cache)['complete'])
    def test_cancelled_scan_resumes_and_does_not_mark_complete(self):
        calls=[]
        def cancel():calls.append(1);return len(calls)>3
        with self.assertRaises(InterruptedError):scan.gather(self.game,self.cache,cancelled=cancel)
        state=json.loads((self.cache/'full_catalog_v2.json').read_text());self.assertFalse(state['complete'])
        self.assertTrue(self.state()['complete'])
    def test_corrupt_asset_is_not_committed_and_does_not_fake_completion(self):
        data=bytearray(self.original);data[60]^=1;self.pak.write_bytes(data)
        state=self.state();self.assertFalse(state['complete']);self.assertTrue(state['errors'])
        self.assertNotIn('系统设置',{r['source'] for r in state['rows']})
    def test_prepare_checks_all_rows_offline_before_provider_and_install_is_explicit(self):
        progress=[];calls=[]
        result=self.prepare(provider=lambda s,*a:calls.append(s) or 'Тестовый текст',progress=lambda **p:progress.append(p))
        self.assertTrue(result['ready']);self.assertEqual(calls,['未知测试文本'])
        self.assertFalse((self.game/'Content/Paks'/ui.UI_PAK).exists())
        full.apply(result);self.assertTrue((self.game/'Content/Paks'/ui.UI_PAK).exists())
        with patch.object(scan.ui.pak,'index',side_effect=AssertionError('rescan')):
            again=self.prepare(provider=lambda *a:self.fail('cached text requested online'))
        self.assertTrue(again['ready']);self.assertTrue(any(p['stage']=='translate' for p in progress))
    def test_service_failure_is_blocked_and_never_installs_resources_silently(self):
        def offline(*a):raise OSError('offline')
        result=self.prepare(provider=offline);self.assertFalse(result['ready'])
        self.assertEqual(result['status'],'offline_or_service_limit');self.assertGreater(result['summary']['remaining'],0)
        self.assertFalse((self.game/'Content/Paks'/ui.UI_PAK).exists())
    def test_daily_limit_is_preserved_and_does_not_send_a_request(self):
        self.cache.mkdir();full.auto.access.write_text(self.cache/'translations_v1.json',json.dumps(dict(version=1,values={},used=full.max_daily_chars(),day=full.datetime.datetime.now(full.datetime.timezone.utc).date().isoformat())))
        result=self.prepare(provider=lambda *a:self.fail('quota bypass'))
        self.assertEqual(result['status'],'client_daily_budget');self.assertFalse(result['ready'])
    def test_conflicting_ftext_identity_never_claims_complete(self):
        self.pak.write_bytes(ui.locres.build_pak({'a.uasset':ftext('系统设置'),'b.uasset':ftext('退出游戏')}))
        result=self.prepare(provider=lambda *a:self.fail('offline labels called online'))
        self.assertFalse(result['ready']);self.assertEqual(result['status'],'identity_conflicts')
        self.assertEqual(result['summary']['identity_conflicts'],1)
    def test_scan_errors_do_not_spend_translation_quota(self):
        data=bytearray(self.original);data[60]^=1;self.pak.write_bytes(data)
        result=self.prepare(provider=lambda *a:self.fail('unverified scan must not spend quota'))
        self.assertFalse(result['ready']);self.assertEqual(result['status'],'scan_errors')
    def test_long_text_segments_preserve_tokens_and_use_bounded_queries(self):
        source='测试文本'*400+'<b>{0}</b>\\n结束'
        parts=full.segments(source);self.assertEqual(''.join(parts),source)
        self.assertTrue(all(len(p.encode())<=380 for p in parts))
        for token in full.auto.PARAMS.findall(source):self.assertTrue(any(token in p for p in parts))
    def test_original_language_does_not_scan_or_call_provider(self):
        with patch.object(scan,'gather',side_effect=AssertionError('unnecessary scan')):
            result=full.prepare(self.game,'zh',self.cache,provider=lambda *a:self.fail('network'))
        self.assertTrue(result['ready']);full.apply(result);self.assertEqual(ui.pak.index(self.game/'Content/Paks'/ui.UI_PAK)[1],[])
    def test_stream_reader_checks_compressed_and_uncompressed_hashes(self):
        _,entries,_=ui.pak.index(self.pak)
        for entry in entries:
            self.assertEqual(b''.join(ui.pak.asset_chunks(self.pak,entry,chunk_size=91)),ui.pak.asset(self.pak,entry))
        raw=b'compression-test '*40000;encoded=zlib.compress(raw);file=self.path/'compressed';file.write_bytes(encoded)
        e=dict(flags=0,expanded=len(raw),size=len(encoded),compression=1,blocks=[(0,len(encoded))],sha1=hashlib.sha1(raw).digest())
        self.assertEqual(b''.join(ui.pak.asset_chunks(file,e,chunk_size=64)),raw)

class LaunchGate34(unittest.TestCase):
    def result(self,ready=False):return dict(ready=ready,status='client_daily_budget',summary=dict(done=3,total=5,remaining=2))
    def test_blocked_cancel_never_applies_or_reports_complete(self):
        events=[];prep=SimpleNamespace(prepare=Mock(return_value=self.result()),apply=Mock())
        ctl=SimpleNamespace(cancelled=lambda:False,wait=lambda:'translation_cancel')
        with self.assertRaises(InterruptedError):launcher_entry.prepare_complete(dict(game_path='x',language='ru'),events.append,ctl,prep)
        prep.apply.assert_not_called();self.assertEqual(events[-1]['event'],'translation_blocked')
    def test_partial_requires_explicit_choice(self):
        prep=SimpleNamespace(prepare=Mock(return_value=self.result()),apply=Mock());events=[]
        ctl=SimpleNamespace(cancelled=lambda:False,wait=lambda:'translation_partial')
        launcher_entry.prepare_complete(dict(game_path='x',language='ru'),events.append,ctl,prep)
        prep.apply.assert_called_once();self.assertEqual(events[-1]['status'],'partial')
    def test_retry_reprepares_then_applies_once(self):
        prep=SimpleNamespace(prepare=Mock(side_effect=[self.result(),self.result(True)]),apply=Mock());events=[]
        ctl=SimpleNamespace(cancelled=lambda:False,wait=lambda:'translation_retry')
        launcher_entry.prepare_complete(dict(game_path='x',language='ru'),events.append,ctl,prep)
        self.assertEqual(prep.prepare.call_count,2);prep.apply.assert_called_once();self.assertEqual(events[-1]['status'],'complete')
    def test_pipe_eof_and_explicit_cancel_are_cancellation(self):
        for data in [b'',b'{"command":"translation_cancel"}\n',b'x'*514]:
            ctl=launcher_entry.PreparationControl(io.TextIOWrapper(io.BytesIO(data)));self.assertEqual(ctl.wait(),'translation_cancel')
    def test_shipped_launcher_keeps_pipe_open_and_has_localized_progress(self):
        cs=(ROOT/'LauncherSource/ReactivateStandalone.cs').read_text('utf-8-sig')
        self.assertIn('TranslationMode = "complete"',cs);self.assertIn('ShowTranslationProgress(state)',cs)
        self.assertNotIn('if (_authAction != "register") _bridgeProcess.StandardInput.Close()',cs)
        self.assertIn('Запустить с неполным',cs);self.assertIn('Play with partial translation',cs);self.assertIn('使用部分翻译启动',cs)
        self.assertEqual((ROOT/'LauncherSource/ReactivateStandalone.cs').read_bytes(),(ROOT.parents[1]/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs').read_bytes())

if __name__=='__main__':unittest.main()
