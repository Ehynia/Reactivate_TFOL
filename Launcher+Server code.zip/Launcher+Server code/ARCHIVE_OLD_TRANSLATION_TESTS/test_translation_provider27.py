import importlib.util,io,json,os,unittest
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
L=HERE.parent/'ClientLanguages'
spec=importlib.util.spec_from_file_location('translate27',L/'prepare_translation.py')
auto=importlib.util.module_from_spec(spec);spec.loader.exec_module(auto)
class Response:
    def __init__(self,data,uri):self.data=io.BytesIO(json.dumps(data).encode());self.uri=uri
    def geturl(self):return self.uri
    def read(self,n):return self.data.read(n)
    def __enter__(self):return self
    def __exit__(self,*a):pass
class ProviderTests(unittest.TestCase):
    def test_public_google_free_and_format_token_preserved(self):
        def fetch(req,timeout):
            self.assertIn('translate.googleapis.com',req.full_url)
            self.assertIn('ZXQ0000QXZ',req.full_url)
            return Response([[['Точка ZXQ0000QXZ','系统设置 {0}']]],req.full_url)
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'google_public'}),patch.object(auto.urllib.request,'urlopen',side_effect=fetch):
            self.assertEqual(auto.translate('系统设置 {0}','ru',3),'Точка {0}')
    def test_optional_libretranslate_uses_post_and_key(self):
        def fetch(req,timeout):
            self.assertEqual(req.get_method(),'POST')
            self.assertEqual(json.loads(req.data)['api_key'],'test-key')
            return Response({'translatedText':'Параметры'},req.full_url)
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'libretranslate','REACTIVATE_LIBRETRANSLATE_URL':'https://translate.example.org/translate','REACTIVATE_LIBRETRANSLATE_KEY':'test-key'}),patch.object(auto.urllib.request,'urlopen',side_effect=fetch):
            self.assertEqual(auto.translate('设置','ru',3),'Параметры')
    def test_rejects_unsafe_url_and_unknown_provider(self):
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'libretranslate','REACTIVATE_LIBRETRANSLATE_URL':'http://unsafe/translate'}):
            with self.assertRaises(ValueError):auto.translate('设置','ru',3)
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'fake'}):
            with self.assertRaises(ValueError):auto.translate('设置','ru',3)
    def test_original_chinese_does_not_need_provider(self):
        spec=importlib.util.spec_from_file_location('full27',L/'full_preparation.py');full=importlib.util.module_from_spec(spec);spec.loader.exec_module(full)
        self.assertEqual(full.max_daily_chars(),100000)
        self.assertIs(full.auto.translate,auto.translate) if False else None

if __name__=='__main__':unittest.main()
