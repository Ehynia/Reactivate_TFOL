"""v36: original private tutorial dispatch and offline translator selection."""
import os,struct,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from database import Database
import accounts,garage,native_bots, tutorial_mission36
from tdr_codec import packets
import sys
sys.path.insert(0,str(Path(__file__).parent.parent/'ClientLanguages'))
import importlib.util
prep_path=Path(__file__).parent.parent/'ClientLanguages'/'prepare_translation.py'
spec=importlib.util.spec_from_file_location('translation_v36',prep_path)
auto=importlib.util.module_from_spec(spec);spec.loader.exec_module(auto)

class MegatronMission36(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.db=Database(Path(self.temp.name)/'v36.db', progression_enabled=True)
        garage.install(self.db)
        self.uid=accounts.register(self.db,'MissionPlayer')['user_id']
        garage.provision(self.db,self.uid)
        self.ctx=dict(native_bots=True,logged_in=True,allow_local_rewards=True)
    def tearDown(self):self.db.close();self.temp.cleanup()
    def test_first_login_starts_original_private_mission_not_pve_defense(self):
        # v41: the ORIGINAL native LoginDataRes handler, not an OB27 job,
        # must create the private one-time onboarding scene before lobby.
        self.assertTrue(tutorial_mission36.tutorial_due(self.db,self.uid))
        self.assertTrue(tutorial_mission36.login_state(self.db,self.uid,self.ctx))
        self.assertEqual(self.ctx['original_tutorial_login41']['hero'],15)
        self.assertEqual(self.ctx['original_tutorial_login41']['map'],1009)
        for t in (100,108,300):
            self.assertEqual(native_bots.poll(self.db,self.uid,self.ctx,now=t),b'')
        self.assertNotIn('engine_match',self.ctx)
        self.assertTrue(tutorial_mission36.tutorial_due(self.db,self.uid))
    def test_existing_match_not_interrupted_and_public_vps_never_starts_tutorial(self):
        self.ctx['engine_match']=dict(state='selecting',sequence=4,selection_deadline=100)
        self.assertEqual(native_bots.poll(self.db,self.uid,self.ctx,now=1),b'')
        self.assertEqual(native_bots.poll(self.db,self.uid,self.ctx,now=10),b'')
        self.assertEqual(self.ctx['engine_match']['state'],'selecting')
        self.ctx['engine_match']['state']='travel_dispatched'
        self.assertEqual(native_bots.poll(self.db,self.uid,self.ctx,now=15),b'')
        self.assertEqual(self.ctx['engine_match']['state'],'travel_dispatched')
        other=dict(native_bots=True,logged_in=True,allow_local_rewards=False)
        self.assertEqual(native_bots.poll(self.db,self.uid,other,now=100),b'')
        self.assertNotIn('megatron_tutorial36',other)
    def test_trusted_tutorial_completion_disables_first_login_entry(self):
        accounts.confirm_tutorial(self.db,self.uid,'test-trusted-worker','Megatron_Tutorial_1009')
        self.assertFalse(tutorial_mission36.tutorial_due(self.db,self.uid))
        self.assertEqual(native_bots.poll(self.db,self.uid,self.ctx,now=5),b'')
        self.assertNotIn('original_tutorial_login41',self.ctx)
    def test_legacy_guest_does_not_crash_on_identity_lookup(self):
        guest=self.db.player('Guest36');garage.provision(self.db,guest)
        ctx=dict(native_bots=True,logged_in=True,allow_local_rewards=True)
        self.assertEqual(native_bots.poll(self.db,guest,ctx,now=33),b'')

class ArgosProvider36(unittest.TestCase):
    def test_argos_opt_in_or_auto_only_when_installed(self):
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'auto','REACTIVATE_TRANSLATE_ORDER':'argos,google_public,mymemory'},clear=False):
            with patch.object(auto._argos_local(),'ready',return_value=False):
                self.assertEqual(auto.provider_order(),['google_public','mymemory'])
            with patch.object(auto._argos_local(),'ready',return_value=True):
                self.assertEqual(auto.provider_order(),['argos','google_public','mymemory'])
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'argos'},clear=False):
            self.assertEqual(auto.provider_order(),['argos'])
    def test_offline_argos_preserves_formatting_placeholders(self):
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'argos'},clear=False):
            with patch.object(auto._argos_local(),'translate',return_value='Урон ZXQ0000QXZ') as mock:
                self.assertEqual(auto.translate('伤害 {value}','ru',7),'Урон {value}')
                mock.assert_called_once_with('伤害 ZXQ0000QXZ','ru',unittest.mock.ANY)
    def test_invalid_offline_result_not_installed(self):
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'argos'},clear=False):
            with patch.object(auto._argos_local(),'translate',return_value='ZXQ0000QXZ ZXQ0000QXZ'):
                with self.assertRaises(ValueError):auto.translate('变形 {id}','ru',7)
    def test_argos_failure_falls_back_to_google_without_token_loss(self):
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'auto','REACTIVATE_TRANSLATE_ORDER':'argos,google_public'},clear=False):
            with patch.object(auto._argos_local(),'ready',return_value=True):
                def upstream(provider,*args):
                    if provider=='argos':raise OSError('model unavailable')
                    return 'Миссия ZXQ0000QXZ'
                with patch.object(auto,'_translate_one',side_effect=upstream) as calls:
                    self.assertEqual(auto.translate('任务 {id}','ru',7),'Миссия {id}')
                    self.assertEqual([c.args[0] for c in calls.call_args_list],['argos','google_public'])

    def test_provider_order_existing_google_still_works(self):
        with patch.dict(os.environ,{'REACTIVATE_TRANSLATE_PROVIDER':'google_public'},clear=False):
            self.assertEqual(auto.provider_order(),['google_public'])

if __name__=='__main__':unittest.main()
