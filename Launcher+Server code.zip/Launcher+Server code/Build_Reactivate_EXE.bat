﻿@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title Reactivate EXE Builder - Transformers Online

echo =============================================================
echo  Reactivate - native Windows Forms EXE (C#)
echo =============================================================
if not exist "Release" mkdir "Release"
if not exist "Release\Assets" mkdir "Release\Assets"
xcopy /Y /Q "Reactivate\Assets\*.*" "Release\Assets\" >nul 2>&1
set "CSC_PATH="
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set "CSC_PATH=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not defined CSC_PATH if exist "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" set "CSC_PATH=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not defined CSC_PATH (
  echo [ERROR] System csc.exe compiler missing. Use Build_Reactivate_NET8.bat with .NET 8 SDK.
  pause
  exit /b 1
)
if exist "Release\Reactivate.UI.v21.building.exe" del /F /Q "Release\Reactivate.UI.v21.building.exe"
echo [1/2] Compiling C# source with Windows .NET Framework compiler...
"!CSC_PATH!" /nologo /target:winexe /optimize+ /platform:x64 /out:"Release\Reactivate.UI.v21.building.exe" /win32icon:"Reactivate\Assets\app_icon.ico" /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll "Reactivate\NativeDesktopBuilder\ReactivateStandalone.cs"
if errorlevel 1 (
    echo [ERROR] Compilation failed. See errors above.
    pause
    exit /b 1
)
if not exist "Release\Reactivate.UI.v21.building.exe" (
    echo [ERROR] EXE not produced.
    pause
    exit /b 1
)
move /Y "Release\Reactivate.UI.v21.building.exe" "Release\Reactivate.UI.v21.exe" >nul
if errorlevel 1 (
  echo [ERROR] Close the running interface and retry. Previous launcher preserved.
  pause
  exit /b 1
)
echo [2/2] Windows launcher ready: Release\Reactivate.exe
for %%F in ("Release\Reactivate.exe") do echo Size: %%~zF bytes
start "" "Release\Reactivate.UI.v21.exe"
pause
