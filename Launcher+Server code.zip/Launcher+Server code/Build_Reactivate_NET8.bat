@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
  echo [ERROR] .NET 8 SDK not installed. Get the SDK from dotnet.microsoft.com.
  pause
  exit /b 1
)
if not exist "Release" mkdir "Release"
dotnet publish "Reactivate\Reactivate.csproj" -c Release -r win-x64 --self-contained true -o "%~dp0Release"
if errorlevel 1 (
  echo [ERROR] dotnet publish failed. See errors above.
  pause
  exit /b 1
)
if not exist "Release\Reactivate.exe" (
  echo [ERROR] EXE not produced.
  pause
  exit /b 1
)
start "" "Release\Reactivate.exe"
pause
