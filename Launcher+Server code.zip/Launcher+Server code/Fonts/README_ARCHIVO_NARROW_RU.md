# Archivo Narrow для Transformers Online — подготовка, не активный игровой шрифт

Оригинальный UE4.14 хранит ссылки на Font/FontFace в UMG-активах. Установка `.ttf` в Windows не меняет cooked UI игрового клиента. Простая подмена стандартных TTF в PAK без контроля Unicode fallback может уничтожить кириллицу и китайские иероглифы. Поэтому **в v48 основной шрифт игры ещё не заменён**.

Скрипт `Setup-ArchivoNarrow.ps1` **по инициативе пользователя** скачивает Archivo Narrow и OFL-лицензию из оригинального Google Fonts в `%LOCALAPPDATA%\Reactivate\Fonts`. Шрифт **не распространяется в составе архива**. Он поставляется по SIL Open Font License 1.1: https://github.com/google/fonts/tree/main/ofl/archivonarrow .

Следующий шаг: в совместимом редакторе UE4 импортировать TTF как Font Face, создать Composite Font с Archivo Narrow для латиницы и отдельными шрифтами, включающими **кириллицу и CJK**. Затем собрать только новый override для реально найденных UMG Fonts, с резервными копиями и проверкой шрифтов в RU/EN/ZH. В уже cooked игре без UE4-редактора это нельзя честно считать выполненной заменой шрифта.
