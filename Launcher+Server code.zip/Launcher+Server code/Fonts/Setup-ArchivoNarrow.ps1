# User-invoked font stage for a future Unreal Engine 4.14 Composite Font asset.
# Does NOT modify original PAKs, register Windows fonts, or claim to alter the live game HUD.
param([string]$Staging = "$env:LOCALAPPDATA\Reactivate\Fonts")
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force $Staging | Out-Null
$font = Join-Path $Staging 'ArchivoNarrow-Variable.ttf'
$license = Join-Path $Staging 'OFL.txt'
$source = 'https://raw.githubusercontent.com/google/fonts/main/ofl/archivonarrow/'
Invoke-WebRequest -UseBasicParsing -Uri ($source+'ArchivoNarrow%5Bwght%5D.ttf') -OutFile $font -TimeoutSec 60
Invoke-WebRequest -UseBasicParsing -Uri ($source+'OFL.txt') -OutFile $license -TimeoutSec 30
$stream = [IO.File]::OpenRead($font)
try {
    if ($stream.Length -lt 8192) { throw 'Invalid or truncated font' }
    $bytes = New-Object byte[] 4
    [void]$stream.Read($bytes,0,4)
    $valid = (($bytes[0] -eq 0 -and $bytes[1] -eq 1 -and $bytes[2] -eq 0 -and $bytes[3] -eq 0) -or
              ([Text.Encoding]::ASCII.GetString($bytes) -eq 'OTTO'))
    if (-not $valid) { throw 'Not a TrueType/OpenType font' }
} finally { $stream.Dispose() }
Write-Host "Archivo Narrow staged (not installed into TFOL): $font"
Write-Host 'For real in-game UMG rendering an UE4.14-compatible Font Face/Composite Font asset and explicit Cyrillic/CJK fallback must be built and tested.'
