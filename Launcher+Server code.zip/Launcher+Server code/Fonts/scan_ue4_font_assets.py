"""Read PAK indices to locate native Unreal Font / FontFace assets, no extraction."""
from pathlib import Path
import json,argparse,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'Release/ClientLanguages'))
import ue_pak_reader as pak

def scan(project):
    root=Path(project)
    if (root/'TFOL/Content/Paks').is_dir():root=root/'TFOL'
    paks=sorted((root/'Content/Paks').glob('TFOL-WindowsNoEditor_*.pak'))
    found=[];errors=[]
    for file in paks:
        try:mount,rows,_=pak.index(file)
        except Exception as ex:errors.append(dict(pak=file.name,error=type(ex).__name__));continue
        for row in rows:
            name=row['name'].replace('\\','/')
            if any(x in name.lower() for x in ('/font/', '/fonts/', 'fontface', 'font_')) and name.lower().endswith(('.uasset','.uexp')):
                found.append(dict(pak=file.name,asset=mount+name))
    return dict(original_paks_scanned=len(paks),candidate_font_assets=found,errors=errors,
      game_font_modified=False,requires_matching_cooked_ue4_uasset=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('game_path');p.add_argument('--output',default='TFOL_Font_Asset_Audit.json');opts=p.parse_args()
    result=scan(opts.game_path)
    Path(opts.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
    print('Fonts referenced:',len(result['candidate_font_assets']),'of',result['original_paks_scanned'],'PAKs, errors:',len(result['errors']))
