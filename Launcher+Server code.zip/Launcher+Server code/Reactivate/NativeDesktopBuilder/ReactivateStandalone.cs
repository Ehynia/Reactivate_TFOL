﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reactivate
{
    internal static class Program
    {
        internal static string LauncherRoot = AppDomain.CurrentDomain.BaseDirectory;
        internal static string Language = "ru";
        internal static string Localize(string ru, string en, string zh)
        { return Language == "ru" ? ru : Language == "zh" ? zh : en; }
        internal static string LogFailure(Exception error)
        {
            LauncherDiagnostics.Log("ui_exception", "error", error.ToString());
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Reactivate", "Logs", "Reactivate_UI_error.log");
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.AppendAllText(path, DateTime.UtcNow.ToString("o") + "\r\n" + LauncherDiagnostics.Scrub(error.ToString()) + "\r\n", Encoding.UTF8);
            }
            catch { return "Log could not be written / Не удалось записать лог"; }
            return path;
        }
        [DllImport("user32.dll", EntryPoint = "SetProcessDpiAwarenessContext")]
        private static extern bool SetDpiAwarenessContext(IntPtr awarenessContext);
        [DllImport("user32.dll", EntryPoint = "SetProcessDPIAware")]
        private static extern bool SetLegacyDpiAwareness();

        private static void EnableNativeDpi()
        {
            // Per-monitor V2 on Windows 10/11; system DPI on older Windows.
            // Must be done before Application.EnableVisualStyles or opening a window.
            try { if (SetDpiAwarenessContext(new IntPtr(-4))) return; }
            catch (EntryPointNotFoundException) { }
            catch (DllNotFoundException) { }
            try { SetLegacyDpiAwareness(); }
            catch (EntryPointNotFoundException) { }
        }

        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                if (args.Length == 2 && args[0] == "--root")
                {
                    string root = Path.GetFullPath(args[1]);
                    if (!Directory.Exists(Path.Combine(root, "Server")) || !Directory.Exists(Path.Combine(root, "Assets")))
                        throw new DirectoryNotFoundException("Incomplete Release folder / Неполная папка Release: " + root);
                    LauncherRoot = root;
                }
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException);
                AppDomain.CurrentDomain.UnhandledException += (sender, e) => {
                    Exception error = e.ExceptionObject as Exception;
                    if (error != null) LogFailure(error);
                };
                EnableNativeDpi();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                LauncherDiagnostics.Start();
                Application.Run(new ReactivateMainWindow());
            }
            catch (Exception error)
            {
                string log = LogFailure(error);
                DiagnosticDialogs.Show(error.Message + "\r\n\r\nLog / Лог: " + log,
                    "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.ExitCode = 1;
            }
        }
    }

    public sealed class ReactivateMainWindow : Form
    {
[DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("winmm.dll", CharSet = CharSet.Auto)]
        private static extern int mciSendString(string command, StringBuilder buffer, int bufferSize, IntPtr hwndCallback);

        // Standard Windows drop shadow for a borderless window (depends on OS composition).
        private const int CsDropShadow = 0x00020000;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                parameters.ClassStyle |= CsDropShadow;
                return parameters;
            }
        }

        private readonly string _baseDir = Program.LauncherRoot;
        private string _gamePath = "";
        private bool _selectingGame;
        private bool _launching;
        private Image _backgroundVignette;
        private Image _bgSharp;
        private Image _bgBlur;
        private Image _logoUniv;
        private Image _logoZh;
        private bool _useBlurBg = false;
        private bool _soundEnabled = true;
        private bool _collectDiagnostics = true; // enabled for this diagnostic build
                private bool _isReady;
        private string _gameResolution = "1920X1080";
        private string _gameWindowMode = "fullscreen";
        private string _gameGraphicsApi = "dx11";
        private string _currentLang = "ru";
        private string _currentTab = "home";
        private string _currentRegion = "pts";
        private string _accountName = "";
        private string _accountKey;
        private string _authAction = "login";
        private Label _launchAccountHint;
        private Label _heroHeading;
        private Label _heroDescription;
        private Label _heroBadge;
        private Label _heroDetail;
        private Label _launchCardHeading;
        private Button _chooseGameBtn;
        private const string ClientVersion = "TFOL_1.0.0.59";
        private readonly string[] _serverCodes = { "eu1", "eu2", "asia1", "pts" };
        private readonly Dictionary<string, string> _serverIps = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> _serverPorts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, TextBox> _serverIpEdits = new Dictionary<string, TextBox>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, NumericUpDown> _serverPortEdits = new Dictionary<string, NumericUpDown>(StringComparer.OrdinalIgnoreCase);
        private string _serverIniPath;
        private Process _bridgeProcess;
        private bool _gameRunning;
        private bool _restoreAfterGame;
        private ThemePanel _settingsOverlay;
        private Button _settingsBack;
        private Button _settingsAppTab;
        private Button _settingsGameTab;
        private Label _settingsPageTitle;
        private Label _serverStatusLabel;

        // UI Controls
        private ThemePanel _titleBar;
        private ThemePanel _sideBar;
        private ThemePanel _mainStage;
        private ComboBox _regionCombo;
        private Label _pingLabel;
        private Button _accountBtn;
        private Button[] _langBtns;
        private Button[] _navBtns;

        // Home Page Controls
        private ThemePanel _homePage;
        private Label _newsHeaderLabel;
        private Label[] _newsItemLabels;
        private NewsEntry[] _newsEntries = new NewsEntry[0];
        private bool _newsRefreshing;
        private System.Windows.Forms.Timer _newsTimer;
        private Label _statusMainLabel;
        private Label _statusVerLabel;
        private Button _startGameBtn;

        // SubPage Controls
        private ThemePanel _subPage;
        private ThemePanel _gameSettingsCard;
        private ThemePanel _appSettingsCard;
        private TextBox _pathBox;
        private CheckBox _blurCheckbox;
        private CheckBox _soundCheckbox;
        private CheckBox _reportsCheckbox;
        private Label _subTitleLabel;
        private Label _subDescLabel;
        private ComboBox _resCombo;
        private ComboBox _winModeCombo;
        private ComboBox _dxCombo;

        // C# 5.0 compatible Dictionary collection initializer (for system csc.exe v4.0.30319)
        private readonly Dictionary<string, Dictionary<string, string>> _i18n = new Dictionary<string, Dictionary<string, string>>
        {
            {
                "ru", new Dictionary<string, string>
                {
                    { "back", "← На главную" },
                    { "settingsapp", "Лаунчер" },
                    { "adminpanel", "Админская панель" },
                    { "settingsgame", "Игра" },
                    { "serverhead", "АДРЕСА СЕРВЕРОВ  •  SERVERS.INI" },
                    { "serverhelp", "Настройте IP и порт каждого сервера. Незаполненные адреса разрешены." },
                    { "servernote", "Пустой IP и порт 0: локальный OBT. Удалённый игровой сервер пока не поддерживается." },
                    { "srv_eu1", "Восточный сектор #1 (EU/CIS)" },
                    { "srv_eu2", "Западный сектор #2 (EU)" },
                    { "srv_asia1", "Азиатский сектор #1 (CN/ASIA)" },
                    { "srv_pts", "Test Node (локальный сервер)" },
                    { "nav_home", "Главная" },
                    { "nav_gamesettings", "Параметры игры" },
                    { "nav_appsettings", "Настройки" },
                    { "sub_badge", "REACTIVATE • СЕРВЕР 2016 ГОДА" },
                    { "news_hdr", "REDDIT  •  TRANSFORMERS" },
                    { "st_ver", "Reactivate v26.3 · OBT33 · TFOL_1.0.0.59" },
                    { "btn_start", "Запустить игру" },
                    { "gs_t", "Параметры игры" },
                    { "gs_d", "Настройка TCLS/config/system.ini без замены файлов клиента" },
                    { "as_t", "Настройки лаунчера Reactivate" },
                    { "as_d", "Фон, звуки, расположение клиента и Python Portable" },
                    { "look", "ВНЕШНИЙ ВИД" },
                    { "blur", "Размытый фон" },
                    { "sound", "Звуки интерфейса" },
                    { "gamepath", "РАСПОЛОЖЕНИЕ КЛИЕНТА" },
                    { "chooseexe", "Выбрать EXE…" }, { "choosefolder", "Найти в папке…" },
                    { "pathhelp", "Выберите EXE или папку игры. Расположение запоминается." },
                    { "pythonhead", "PYTHON PORTABLE 3.13 (x64)" },
                    { "install", "Установить Python" },
                    { "pycheck", "Проверить Python" },
                    { "pynote", "Python 3.13 включён: сервер и сессия запускаются автоматически." },
                    { "save", "Сохранить настройки" },
                    { "syshead", "Конфигурация клиента [system] (TCLS/config/system.ini):" },
                    { "gamesave", "✔ Сохранить параметры игры" },
                    { "gameinfo", "Файл TCLS/config/system.ini сохраняется только по команде.\r\nЛокальный сервер и клиент запускаются автоматически." },
                }
            },
            {
                "en", new Dictionary<string, string>
                {
                    { "back", "← Home" },
                    { "settingsapp", "Launcher" },
                    { "adminpanel", "Admin panel" },
                    { "settingsgame", "Game" },
                    { "serverhead", "SERVER ADDRESSES  •  SERVERS.INI" },
                    { "serverhelp", "Set real server IPs and ports. Empty entries are allowed." },
                    { "servernote", "Empty IP and port 0 use local OBT. Remote game hosting is not implemented yet." },
                    { "srv_eu1", "Eastern Sector #1 (EU/CIS)" },
                    { "srv_eu2", "Western Sector #2 (EU)" },
                    { "srv_asia1", "Asia Pacific #1 (CN/ASIA)" },
                    { "srv_pts", "Test Node (local server)" },
                    { "nav_home", "Home" },
                    { "nav_gamesettings", "Game Settings" },
                    { "nav_appsettings", "App Settings" },
                    { "sub_badge", "REACTIVATE • 2016 REVIVAL SERVER" },
                    { "news_hdr", "REDDIT  •  TRANSFORMERS" },
                    { "st_ver", "Reactivate v26.3 · OBT33 · TFOL_1.0.0.59" },
                    { "btn_start", "Start Game" },
                    { "gs_t", "Game Settings" },
                    { "gs_d", "Update TCLS/config/system.ini while preserving other game files" },
                    { "as_t", "Reactivate Settings" },
                    { "as_d", "Background, sounds, game location, and Python Portable" },
                    { "look", "APPEARANCE" },
                    { "blur", "Blurred background" },
                    { "sound", "Interface sounds" },
                    { "gamepath", "GAME LOCATION" },
                    { "chooseexe", "Choose EXE…" }, { "choosefolder", "Search folder…" },
                    { "pathhelp", "Choose a game EXE or folder. The location is remembered." },
                    { "pythonhead", "PYTHON PORTABLE 3.13 (x64)" },
                    { "install", "Install Python" },
                    { "pycheck", "Check Python" },
                    { "pynote", "Python 3.13 is bundled for local server and session startup." },
                    { "save", "Save settings" },
                    { "syshead", "Client configuration [system] (TCLS/config/system.ini):" },
                    { "gamesave", "✔ Save game settings" },
                    { "gameinfo", "TCLS/config/system.ini is saved only on demand.\r\nThe local server and client start automatically." },
                }
            },
            {
                "zh", new Dictionary<string, string>
                {
                    { "back", "← 返回主页" },
                    { "settingsapp", "启动器" },
                    { "adminpanel", "管理面板" },
                    { "settingsgame", "游戏" },
                    { "serverhead", "服务器地址  •  SERVERS.INI" },
                    { "serverhelp", "输入实际服务器 IP 与端口，未填写的地址可以留空。" },
                    { "servernote", "IP 留空、端口设为 0 即使用本地 OBT。尚不支持远程游戏服务器。" },
                    { "srv_eu1", "欧洲与独联体 #1 (EU/CIS)" },
                    { "srv_eu2", "欧洲西部 #2 (EU)" },
                    { "srv_asia1", "亚太区节点 #1 (CN/ASIA)" },
                    { "srv_pts", "Test Node（本地服务器）" },
                    { "nav_home", "主页" },
                    { "nav_gamesettings", "游戏设置" },
                    { "nav_appsettings", "启动器设置" },
                    { "sub_badge", "REACTIVATE • 2016 怀旧服务器" },
                    { "news_hdr", "REDDIT  •  TRANSFORMERS" },
                    { "st_ver", "Reactivate v26.3 · OBT33 · TFOL_1.0.0.59" },
                    { "btn_start", "启动游戏" },
                    { "gs_t", "游戏设置 (Game Settings)" },
                    { "gs_d", "保存到 TCLS/config/system.ini，不修改其他游戏文件" },
                    { "as_t", "Reactivate 启动器设置" },
                    { "as_d", "背景、声音、游戏目录及便携式 Python" },
                    { "look", "外观" },
                    { "blur", "模糊背景" },
                    { "sound", "界面音效" },
                    { "gamepath", "游戏客户端目录" },
                    { "chooseexe", "选择 EXE…" }, { "choosefolder", "搜索文件夹…" },
                    { "pathhelp", "选择游戏 EXE 或文件夹。位置将被保存。" },
                    { "pythonhead", "便携 Python 3.13 (x64)" },
                    { "install", "安装 Python" },
                    { "pycheck", "检测 Python" },
                    { "pynote", "已包含 Python 3.13，用于启动本地服务器和会话。" },
                    { "save", "保存设置" },
                    { "syshead", "客户端配置 [system] (TCLS/config/system.ini)：" },
                    { "gamesave", "✔ 保存游戏设置" },
                    { "gameinfo", "仅点击保存时写入 TCLS/config/system.ini。\r\n自动启动本地服务器和客户端。" },
                }
            }
        };

        public ReactivateMainWindow()
        {
            Text = "Reactivate — Transformers Online";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1280, 720);
            BackColor = Color.FromArgb(11, 17, 29);
            ForeColor = Color.FromArgb(242, 245, 248);
            Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;
            MinimumSize = new Size(1280, 720);
            MaximumSize = new Size(1280, 720);
            Resize += (sender, args) => UpdateWindowShape();

            MigrateLegacySettings();
            LoadSettings();
            LoadServerConfig();
            LoadAssets();
            ExtendLauncherTranslations();
            BuildLayout();
            SetLanguage(_currentLang);
            ApplyNativePixelScale();
            _isReady = true;
            Shown += async (sender, args) => { await RefreshNewsAsync(); };
            _newsTimer = new System.Windows.Forms.Timer { Interval = 900000 };
            _newsTimer.Tick += async (sender, args) => { await RefreshNewsAsync(); };
            _newsTimer.Start();
            FormClosed += (sender, args) => { _newsTimer.Stop(); _newsTimer.Dispose(); };
        }

        private static void MigrateLegacySettings()
        {
            try
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string oldDir = Path.Combine(appData, "CollapseLauncher");
                if (!Directory.Exists(oldDir)) return;
                string newDir = Path.Combine(appData, "Reactivate");
                foreach (string fileName in new[] { "LauncherSettings.ini", "Servers.ini" })
                {
                    string from = Path.Combine(oldDir, fileName);
                    string to = Path.Combine(newDir, fileName);
                    if (File.Exists(from) && !File.Exists(to))
                    {
                        Directory.CreateDirectory(newDir);
                        File.Copy(from, to, false);
                    }
                }
            }
            catch (IOException) { /* Old settings are optional and must not prevent startup. */ }
            catch (UnauthorizedAccessException) { /* Read-only profile: use fresh settings. */ }
        }

        private void LoadAssets()
        {
            string assetsDir = Path.Combine(_baseDir, "Assets");
            if (!Directory.Exists(assetsDir))
                assetsDir = Path.Combine(_baseDir, "..", "Reactivate", "Assets");

            string icoPath = Path.Combine(assetsDir, "app_icon.ico");
            if (File.Exists(icoPath)) Icon = new Icon(icoPath);

            string vignettePath = Path.Combine(assetsDir, "background_vignette.png");
            if (File.Exists(vignettePath)) _backgroundVignette = Image.FromFile(vignettePath);
            string sharpPath = Path.Combine(assetsDir, "bg_sharp.png");
            string blurPath = Path.Combine(assetsDir, "bg_blur.png");
            string univPath = Path.Combine(assetsDir, "logo_universal.png");
            string zhPath = Path.Combine(assetsDir, "logo_zh.png");

            if (File.Exists(sharpPath)) _bgSharp = Image.FromFile(sharpPath);
            if (File.Exists(blurPath)) _bgBlur = Image.FromFile(blurPath);
            if (File.Exists(univPath)) _logoUniv = Image.FromFile(univPath);
            if (File.Exists(zhPath)) _logoZh = Image.FromFile(zhPath);
        }

        private void PlayUiSound()
        {
            if (!_soundEnabled) return;
            try
            {
                string mp3 = Path.Combine(_baseDir, "Assets", "startgame_01.mp3");
                if (File.Exists(mp3))
                {
                    mciSendString("close uisnd", null, 0, IntPtr.Zero);
                    mciSendString("open \"" + mp3 + "\" type mpegvideo alias uisnd", null, 0, IntPtr.Zero);
                    mciSendString("play uisnd", null, 0, IntPtr.Zero);
                }
            }
            catch { }
        }

        // One-pass compositing: draw a cropped scene, then a mild tint once.
        // Never redraw sibling controls or labels (previous versions duplicated text).
        internal void DrawSurface(Graphics g, Control panel, Color tint, bool solid, int radius)
        {
            DrawScene(g, ClientOrigin(panel), panel.ClientSize);
            if (solid)
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                using (var shape = RoundRect(new Rectangle(0, 0,
                    Math.Max(2, panel.ClientSize.Width - 1),
                    Math.Max(2, panel.ClientSize.Height - 1)), (int)(radius * _uiScale)))
                using (var fill = new SolidBrush(tint))
                using (var edge = new Pen(Color.FromArgb(70, 118, 148, 175), 1f))
                {
                    g.FillPath(fill, shape);
                    if (radius > 0) g.DrawPath(edge, shape);
                }
            }
        }

        internal static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int d = Math.Max(2, Math.Min(radius * 2, Math.Min(r.Width, r.Height)));
            if (radius <= 0) { path.AddRectangle(r); return path; }
            path.AddArc(r.Left, r.Top, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        [DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
        [DllImport("user32.dll", EntryPoint = "GetDpiForWindow")]
        private static extern uint NativeGetDpiForWindow(IntPtr hwnd);

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            // DWMWA_WINDOW_CORNER_PREFERENCE = 33, DWMWCP_ROUND = 2.
            // On Windows 10 unsupported/frameless windows stay rectangular (but clean).
            try { int preference = 2; DwmSetWindowAttribute(Handle, 33, ref preference, sizeof(int)); }
            catch (DllNotFoundException) { }
            catch (EntryPointNotFoundException) { }
        }

        private void UpdateWindowShape()
        {
            // Intentionally do NOT set Form.Region. GDI Regions are 1-bit pixel masks:
            // they create the visibly jagged staircase around rounded frameless windows.
            // DWM owns the outermost edge; we only paint an anti-aliased inset stroke.
            if (Region != null) { Region old = Region; Region = null; old.Dispose(); }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            Rectangle r = new Rectangle(1, 1, Math.Max(2, ClientSize.Width - 3),
                Math.Max(2, ClientSize.Height - 3));
            using (GraphicsPath edge = RoundRect(r, Math.Max(12, (int)(16 * _uiScale))))
            using (Pen border = new Pen(Color.FromArgb(125, 91, 146, 178), Math.Max(1f, _uiScale)))
                e.Graphics.DrawPath(border, edge);
        }

        // Scale once in actual display pixels. Never allow Windows bitmap-stretch
        // an unaware 1280x720 surface to 125%, 150% or 200%.
        private float _uiScale = 1f;
        private void ApplyNativePixelScale()
        {
            float dpi = 96f;
            try { uint measured = NativeGetDpiForWindow(Handle); if (measured >= 96 && measured <= 768) dpi = measured; }
            catch (EntryPointNotFoundException)
            {
                using (Graphics g = CreateGraphics()) dpi = g.DpiX;
            }
            Rectangle work = Screen.FromControl(this).WorkingArea;
            float available = Math.Min((work.Width - 28f) / 1280f, (work.Height - 28f) / 720f);
            float targetScale = Math.Max(0.70f, Math.Min(dpi / 96f, available));
            float ratio = targetScale / _uiScale;
            if (Math.Abs(ratio - 1f) < .015f) { UpdateWindowShape(); return; }
            var originals = new List<KeyValuePair<Control, Font>>();
            GatherFonts(this, originals);
            SuspendLayout();
            MinimumSize = Size.Empty; MaximumSize = Size.Empty;
            Scale(new SizeF(ratio, ratio));
            ClientSize = new Size((int)Math.Round(1280f * targetScale), (int)Math.Round(720f * targetScale));
            foreach (KeyValuePair<Control, Font> entry in originals)
            {
                Control c = entry.Key; Font f = entry.Value;
                if (!c.IsDisposed && f != null)
                    c.Font = new Font(f.FontFamily, Math.Max(6f, f.Size * ratio), f.Style, f.Unit);
                VectorButton vb = c as VectorButton;
                if (vb != null) vb.UiScale = targetScale;
            }
            _uiScale = targetScale;
            FitHeroHeading();
            MinimumSize = Size;
            MaximumSize = Size;
            ResumeLayout(true);
            UpdateWindowShape();
        }

        protected override void WndProc(ref Message message)
        {
            const int WM_DPICHANGED = 0x02E0;
            base.WndProc(ref message);
            if (message.Msg == WM_DPICHANGED && _isReady && IsHandleCreated && !IsDisposed)
                BeginInvoke((MethodInvoker)(() => { if (!IsDisposed) ApplyNativePixelScale(); }));
        }

        private static void GatherFonts(Control parent, List<KeyValuePair<Control, Font>> fonts)
        {
            foreach (Control c in parent.Controls)
            {
                fonts.Add(new KeyValuePair<Control, Font>(c, c.Font));
                GatherFonts(c, fonts);
            }
        }

        private Point ClientOrigin(Control control)
        {
            int x = 0, y = 0;
            while (control != null && control != this)
            {
                x += control.Left;
                y += control.Top;
                control = control.Parent;
            }
            return new Point(x, y);
        }

        private void DrawScene(Graphics g, Point origin, Size viewport)
        {
            Image current = (_useBlurBg ? _bgBlur : _bgSharp) ?? _bgSharp ?? _bgBlur;
            var sceneRect = new Rectangle(-origin.X, -origin.Y, ClientSize.Width, ClientSize.Height);
            g.Clear(Color.FromArgb(10, 16, 28));
            if (current != null)
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(current, sceneRect);
                if (_backgroundVignette != null) g.DrawImage(_backgroundVignette, sceneRect);
            }
            // Readable left-edge gradient without replacing the original Transformers art.
            using (var overlay = new LinearGradientBrush(sceneRect,
                Color.FromArgb(209, 8, 16, 31), Color.FromArgb(37, 5, 11, 24),
                LinearGradientMode.Horizontal))
                g.FillRectangle(overlay, sceneRect);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Original SWF background + subtle dark edge falloff; no blur/glass.
            DrawScene(e.Graphics, Point.Empty, ClientSize);
        }

        private void RefreshBackground()
        {
            Invalidate(true);
        }

        private void BuildLayout()
        {
            // Title bar: compact controls, low-contrast glass, and intact region/account controls.
            _titleBar = new ThemePanel(this, Color.FromArgb(242, 14, 24, 41), true, 18)
            {
                Location = new Point(18, 16), Size = new Size(1244, 62)
            };
            _titleBar.MouseDown += (sender, e) => {
                if (e.Button == MouseButtons.Left) { ReleaseCapture(); SendMessage(Handle, 0xA1, 0x2, 0); }
            };
            var mark = new BrandBadge {
                Location = new Point(18, 12), Size = new Size(38, 38)
            };
            _titleBar.Controls.Add(mark);
            _titleBar.Controls.Add(new Label {
                Text = "REACTIVATE", Location = new Point(68, 13), Size = new Size(216, 23),
                Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold),
                ForeColor = Color.FromArgb(246, 249, 255)
            });
            _titleBar.Controls.Add(new Label {
                Text = "TRANSFORMERS ONLINE  /  OBT33", Location = new Point(69, 37),
                Size = new Size(242, 18), Font = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(141, 175, 198)
            });
            _regionCombo = new ComboBox {
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(26, 43, 62), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Location = new Point(362, 19), Width = 242
            };
            _regionCombo.SelectedIndexChanged += (sender, e) => {
                int idx = _regionCombo.SelectedIndex;
                string[] codes = { "eu1", "eu2", "asia1", "pts" };
                if (idx >= 0 && idx < codes.Length) {
                    _currentRegion = codes[idx]; UpdateServerInfoLabel();
                    if (_isReady) SaveSettings();
                }
            };
            _titleBar.Controls.Add(_regionCombo);
            _pingLabel = new Label {
                Text = "● IP: —", Location = new Point(612, 21), Size = new Size(118, 22),
                ForeColor = Color.FromArgb(113, 215, 174), AutoEllipsis = true
            };
            _titleBar.Controls.Add(_pingLabel);
            _accountBtn = new VectorButton("account") { CenterText = false,
                Text = Ui("Вход", "Sign in", "登录"), Location = new Point(737, 14), Size = new Size(180, 35),
                FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(32, 51, 74),
                ForeColor = Color.FromArgb(239, 244, 251), Cursor = Cursors.Hand,
                AutoEllipsis = true, Font = new Font("Segoe UI Semibold", 9f)
            };
            _accountBtn.FlatAppearance.BorderSize = 0;
            _accountBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(44, 75, 105);
            _accountBtn.Click += (sender, e) => { if (_bridgeProcess == null) LaunchGameClient(); };
            _titleBar.Controls.Add(_accountBtn);
            string[] langs = { "zh", "en", "ru" };
            string[] langLabels = { "中", "EN", "RU" };
            _langBtns = new Button[langs.Length];
            for (int i = 0; i < langs.Length; i++) {
                string lc = langs[i];
                var b = new VectorButton("") {
                    Text = langLabels[i], Tag = lc, FlatStyle = FlatStyle.Flat,
                    Size = new Size(40, 34), Location = new Point(931 + i * 43, 14),
                    Cursor = Cursors.Hand, Font = new Font("Segoe UI", 9f, FontStyle.Bold)
                };
                b.FlatAppearance.BorderSize = 0;
                b.FlatAppearance.MouseOverBackColor = Color.FromArgb(49, 82, 108);
                b.Click += (sender, e) => { PlayUiSound(); SetLanguage(lc); };
                _langBtns[i] = b; _titleBar.Controls.Add(b);
                var tip = new ToolTip();
                tip.SetToolTip(b, lc == "ru" ? "Русский" : lc == "en" ? "English" : "中文");
            }
            var minBtn = new VectorButton("min") {
                Text = "", FlatStyle = FlatStyle.Flat, Location = new Point(1070, 15),
                Size = new Size(39, 34), BackColor = Color.FromArgb(26, 41, 61),
                ForeColor = Color.FromArgb(215, 232, 244), Cursor = Cursors.Hand
            };
            minBtn.FlatAppearance.BorderSize = 0;
            minBtn.Click += (sender, e) => WindowState = FormWindowState.Minimized;
            _titleBar.Controls.Add(minBtn);
            var closeBtn = new VectorButton("close") {
                Text = "", FlatStyle = FlatStyle.Flat, Location = new Point(1118, 15),
                Size = new Size(39, 34), BackColor = Color.FromArgb(99, 38, 50),
                ForeColor = Color.White, Cursor = Cursors.Hand
            };
            closeBtn.FlatAppearance.BorderSize = 0;
            closeBtn.Click += (sender, e) => Close();
            _titleBar.Controls.Add(closeBtn);
            Controls.Add(_titleBar);

            // Side rail – modern navigation, actual settings pages reused unchanged.
            _sideBar = new ThemePanel(this, Color.FromArgb(232, 11, 23, 39), true, 20) {
                Location = new Point(20, 91), Size = new Size(206, 602)
            };
            _sideBar.Controls.Add(new Label {
                Text = "PLAY HUB", Tag = "i18n:playhub", Location = new Point(22, 26), Size = new Size(164, 24),
                ForeColor = Color.FromArgb(105, 214, 241),
                Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold)
            });
            string[] navKeys = { "home", "gamesettings", "appsettings" };
            _navBtns = new Button[navKeys.Length];
            for (int i = 0; i < navKeys.Length; i++) {
                string nk = navKeys[i];
                var nb = new VectorButton(nk == "home" ? "home" : nk == "gamesettings" ? "game" : "settings") { CenterText = false,
                    Tag = nk, FlatStyle = FlatStyle.Flat,
                    TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(0),
                    Size = new Size(182, 50), Location = new Point(12, 70 + i * 62),
                    Cursor = Cursors.Hand, Font = new Font("Segoe UI Semibold", 9f)
                };
                nb.FlatAppearance.BorderSize = 0;
                nb.Click += (sender, e) => { PlayUiSound(); SwitchTab(nk); };
                _navBtns[i] = nb; _sideBar.Controls.Add(nb);
            }
            var sideLine = new Panel { Location = new Point(22, 500), Size = new Size(160, 1),
                BackColor = Color.FromArgb(51, 76, 99) };
            _sideBar.Controls.Add(sideLine);
            _sideBar.Controls.Add(new Label {
                Text = "●  OBT33  ·  1.0.0.59", Location = new Point(21, 519),
                Size = new Size(176, 27), ForeColor = Color.FromArgb(120, 213, 183),
                Font = new Font("Segoe UI", 8.5f)
            });
            _sideBar.Controls.Add(new Label {
                Text = "COMMUNITY RESTORATION", Tag = "i18n:community", Location = new Point(21, 552),
                Size = new Size(180, 27), ForeColor = Color.FromArgb(143, 162, 184),
                Font = new Font("Segoe UI", 7.5f)
            });
            Controls.Add(_sideBar);
            _mainStage = new ThemePanel(this, Color.Transparent, false, 0) {
                Location = new Point(236, 91), Size = new Size(1026, 602)
            };
            Controls.Add(_mainStage);
            _sideBar.BringToFront(); _titleBar.BringToFront();
            BuildHomePage(); BuildSubPage(); BuildSettingsOverlay(); SwitchTab("home");
        }

        private static Label ModernText(string text, int x, int y, int width, int height,
            float size, Color color, bool bold)
        {
            return new Label {
                Text = text, Location = new Point(x, y), Size = new Size(width, height),
                Font = new Font(bold ? "Segoe UI Semibold" : "Segoe UI", size,
                    bold ? FontStyle.Bold : FontStyle.Regular),
                ForeColor = color, BackColor = Color.Transparent
            };
        }

        // Use real GDI measurements, not a hard-coded two-line label. The
        // measured font is expressed in points and Windows scales it to the
        // active monitor's DPI. Geometry is scaled separately in pixels.
        private void FitHeroHeading()
        {
            if (_heroHeading == null || _heroHeading.IsDisposed || !_heroHeading.IsHandleCreated)
                return;
            const string title = "TRANSFORMERS ONLINE";
            int availableWidth = Math.Max(20, _heroHeading.ClientSize.Width - 12);
            int availableHeight = Math.Max(20, _heroHeading.ClientSize.Height - 5);
            const TextFormatFlags flags = TextFormatFlags.SingleLine | TextFormatFlags.NoPadding;
            using (Graphics graphics = _heroHeading.CreateGraphics())
            {
                for (float points = 25f; points >= 13f; points -= .5f)
                {
                    using (Font trial = new Font("Segoe UI Semibold", points, FontStyle.Bold))
                    {
                        Size needed = TextRenderer.MeasureText(graphics, title, trial,
                            new Size(8192, 512), flags);
                        if (needed.Width > availableWidth || needed.Height > availableHeight)
                            continue;
                        _heroHeading.Font = new Font("Segoe UI Semibold", points, FontStyle.Bold);
                        return;
                    }
                }
            }
            // Extremely small screens: shrink safely rather than wrap the title.
            _heroHeading.Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold);
        }

        private void BuildHomePage()
        {
            _homePage = new ThemePanel(this, Color.Transparent, false, 0) {
                Dock = DockStyle.Fill
            };
            var hero = new ThemePanel(this, Color.Transparent, false, 0) {
                Location = new Point(19, 22), Size = new Size(540, 326)
            };
            _heroBadge = ModernText("ORIGINAL CLIENT  ·  REACTIVATED", 28, 26, 482, 23,
                9f, Color.FromArgb(112, 217, 242), true);
            hero.Controls.Add(_heroBadge);
            // One-line title with a measured font: no wrapping, clipping or collisions
            // at 100–200% Windows DPI and when the launcher changes monitors.
            _heroHeading = ModernText("TRANSFORMERS ONLINE", 28, 85, 500, 64,
                25f, Color.FromArgb(249, 250, 253), true);
            _heroHeading.TextAlign = ContentAlignment.MiddleLeft;
            _heroHeading.AutoEllipsis = false;
            hero.Controls.Add(_heroHeading);
            // On first show the child gets its real Windows DPI/handle.
            _heroHeading.HandleCreated += (sender, e) => FitHeroHeading();
            FitHeroHeading();
            var stripe = new Panel { Location = new Point(30, 168), Size = new Size(54, 4),
                BackColor = Color.FromArgb(241, 154, 78) };
            hero.Controls.Add(stripe);
            _heroDescription = ModernText("Легендарная игра возвращается. Оригинальный клиент, свой сервер и весь мир Трансформеров.",
                30, 191, 480, 65, 10f, Color.FromArgb(200, 217, 232), false);
            hero.Controls.Add(_heroDescription);
            _heroDetail = ModernText("TFOL 1.0.0.59   /   OBT33", 30, 271, 450, 23,
                8.5f, Color.FromArgb(142, 168, 192), true);
            hero.Controls.Add(_heroDetail);
            _homePage.Controls.Add(hero);

            var newsCard = new ThemePanel(this, Color.FromArgb(239, 12, 25, 43), true, 20) {
                Location = new Point(19, 368), Size = new Size(535, 212)
            };
            _newsHeaderLabel = ModernText("COMMUNITY  /  NEWS", 22, 17, 486, 28,
                11f, Color.FromArgb(115, 211, 235), true);
            newsCard.Controls.Add(_newsHeaderLabel);
            _newsItemLabels = new Label[4];
            for (int i = 0; i < 4; i++) {
                var nl = ModernText("", 22, 56 + i * 36, 485, 29, 9f,
                    Color.FromArgb(219, 231, 242), false);
                nl.AutoEllipsis = true; nl.Cursor = Cursors.Hand;
                nl.Click += (sender, e) => OpenNews(((Label)sender).Tag as string);
                _newsItemLabels[i] = nl; newsCard.Controls.Add(nl);
            }
            _homePage.Controls.Add(newsCard);

            var launchCard = new ThemePanel(this, Color.FromArgb(240, 12, 26, 45), true, 22) {
                Location = new Point(591, 312), Size = new Size(414, 268)
            };
            _launchCardHeading = ModernText("ГОТОВ К ЗАПУСКУ", 23, 19, 369, 29,
                12f, Color.FromArgb(246, 249, 253), true);
            launchCard.Controls.Add(_launchCardHeading);
            _statusMainLabel = ModernText("", 23, 54, 367, 26,
                9.5f, Color.FromArgb(215, 229, 241), true);
            _statusMainLabel.Name = "LaunchStatus";
            _statusMainLabel.TextChanged += (sender, args) => LauncherDiagnostics.Log("ui_status", "text", _statusMainLabel.Text);
            _statusMainLabel.AutoEllipsis = true;
            launchCard.Controls.Add(_statusMainLabel);
            _statusVerLabel = ModernText("", 23, 82, 366, 24,
                8.3f, Color.FromArgb(140, 164, 186), false);
            launchCard.Controls.Add(_statusVerLabel);
            _chooseGameBtn = CardButton("Выбрать игру…", 22, 117, 369, 34, false);
            ((VectorButton)_chooseGameBtn).IconKind = "choose";
            _chooseGameBtn.Click += async (sender, e) => { await SelectGameAsync(null); };
            launchCard.Controls.Add(_chooseGameBtn);
            _startGameBtn = CardButton("Запустить игру", 22, 162, 369, 53, true);
            ((VectorButton)_startGameBtn).IconKind = "play";
            _startGameBtn.BackColor = Color.FromArgb(29, 188, 229);
            _startGameBtn.Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold);
            _startGameBtn.Click += (sender, e) => LaunchGameClient();
            launchCard.Controls.Add(_startGameBtn);
            _launchAccountHint = ModernText("", 22, 226, 366, 25,
                8.3f, Color.FromArgb(159, 189, 207), false);
            _launchAccountHint.TextAlign = ContentAlignment.MiddleCenter;
            _launchAccountHint.AutoEllipsis = true;
            launchCard.Controls.Add(_launchAccountHint);
            _homePage.Controls.Add(launchCard);
            _mainStage.Controls.Add(_homePage);
        }

        private void BuildSubPage()
        {
            _subPage = new ThemePanel(this, Color.FromArgb(232, 12, 24, 42), true, 0)
            {
                Dock = DockStyle.Fill,
                Visible = false
            };

            _subTitleLabel = new Label
            {
                Location = new Point(28, 24),
                AutoSize = true,
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI Semibold", 15f, FontStyle.Bold),
                ForeColor = Color.White
            };
            _subDescLabel = new Label
            {
                Location = new Point(28, 56),
                Size = new Size(700, 24),
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.FromArgb(162, 176, 194)
            };
            _subPage.Controls.Add(_subTitleLabel);
            _subDescLabel.Visible = false;

            // Game Settings Card ([system] config writer)
            _gameSettingsCard = new ThemePanel(this, Color.FromArgb(234, 16, 30, 48), true, 19)
            {
                Location = new Point(28, 130),
                Size = new Size(1000, 245)
            };
            var gsCard = _gameSettingsCard;
            var gsHeader = new Label
            {
                Text = "Конфигурация клиента [system] (TCLS/config/system.ini):",
                Location = new Point(18, 16),
                AutoSize = true,
                Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(242, 149, 70)
            };
            gsHeader.Tag = "i18n:syshead";
            gsCard.Controls.Add(gsHeader);

            var lblRes = new Label { Text = "Resolution:", Tag = "i18n:resolution", Location = new Point(18, 56), AutoSize = true, ForeColor = Color.LightGray };
            _resCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(130, 52),
                Width = 180,
                BackColor = Color.FromArgb(30, 37, 50),
                ForeColor = Color.White
            };
            _resCombo.Items.AddRange(new object[] { "1920X1080", "2560X1440", "1440X850", "1280X720" });
            _resCombo.SelectedIndex = Math.Max(0, _resCombo.Items.IndexOf(_gameResolution));

            var lblWm = new Label { Text = "Window Mode:", Tag = "i18n:windowmode", Location = new Point(340, 56), AutoSize = true, ForeColor = Color.LightGray };
            _winModeCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(450, 52),
                Width = 160,
                BackColor = Color.FromArgb(30, 37, 50),
                ForeColor = Color.White
            };
            _winModeCombo.Items.AddRange(new object[] { "fullscreen", "borderless", "windowed" });
            _winModeCombo.SelectedIndex = Math.Max(0, _winModeCombo.Items.IndexOf(_gameWindowMode));

            var lblDx = new Label { Text = "Graphics API:", Tag = "i18n:graphicsapi", Location = new Point(640, 56), AutoSize = true, ForeColor = Color.LightGray };
            _dxCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(745, 52),
                Width = 220,
                BackColor = Color.FromArgb(30, 37, 50),
                ForeColor = Color.White
            };
            _winModeCombo.FormattingEnabled = true;
            _winModeCombo.Format += (s, e) => {
                string mode = e.ListItem as string;
                e.Value = mode == "fullscreen" ? Ui("Во весь экран", "Fullscreen", "全屏") :
                    mode == "borderless" ? Ui("Без рамки", "Borderless", "无边框") : Ui("В окне", "Windowed", "窗口");
            };
            _dxCombo.FormattingEnabled = true;
            _dxCombo.Format += (s, e) => {
                string value = e.ListItem as string;
                e.Value = value != null && value.StartsWith("dx12") ? Ui("DirectX 12 (экспер.)", "DirectX 12 (experimental)", "DirectX 12（实验）") :
                    value != null && value.StartsWith("dx9") ? "DirectX 9" : "DirectX 11";
            };
            _dxCombo.Items.AddRange(new object[] { "dx11 (DirectX 11 FL 11.0)", "dx9 (2016 Native)", "dx12 (Experimental)" });
            _dxCombo.SelectedIndex = _gameGraphicsApi == "dx9" ? 1 : (_gameGraphicsApi == "dx12" ? 2 : 0);

            var saveCfgBtn = new Button
            {
                Text = "✔ Сохранить параметры игры",
                Location = new Point(18, 105),
                Size = new Size(235, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(45, 135, 75),
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            saveCfgBtn.Tag = "i18n:gamesave";
            saveCfgBtn.FlatAppearance.BorderSize = 0;
            RoundControl(saveCfgBtn, 9);
            saveCfgBtn.Click += (s, e) =>
            {
                if (WriteGameConfigFiles())
                    DiagnosticDialogs.Show(Ui("Сохранён TCLS\\config\\system.ini (резервная копия .bak при наличии исходного файла).","Saved TCLS\\config\\system.ini (.bak backup created if an original exists).","已保存 TCLS\\config\\system.ini（若有原文件，则创建 .bak 备份）。"),
                        "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            var infoBox = new Label
            {
                Location = new Point(18, 155),
                Size = new Size(950, 60),
                ForeColor = Color.FromArgb(150, 165, 185),
                Text = "Параметры игры сохраняются вручную в TCLS\\config\\system.ini.\r\n" +
                       "При запуске локальный сервер и клиент подготавливаются автоматически."
            };

            _resCombo.SelectedIndexChanged += (sender, args) => { if (_isReady) SaveSettings(); };
            _winModeCombo.SelectedIndexChanged += (sender, args) => { if (_isReady) SaveSettings(); };
            _dxCombo.SelectedIndexChanged += (sender, args) => { if (_isReady) SaveSettings(); };
            infoBox.Tag = "i18n:gameinfo";
            gsCard.Controls.AddRange(new Control[] { lblRes, _resCombo, lblWm, _winModeCombo, lblDx, _dxCombo, saveCfgBtn, infoBox });
            _subPage.Controls.Add(gsCard);
            BuildAppSettingsCard();

            _mainStage.Controls.Add(_subPage);
        }

        private static Label CardLabel(string text, int x, int y, int width, int height, float fontSize)
        {
            return new Label
            {
                Text = text, Location = new Point(x, y), Size = new Size(width, height),
                BackColor = Color.Transparent, ForeColor = Color.FromArgb(222, 231, 243),
                Font = new Font("Segoe UI", fontSize)
            };
        }

        private static void RoundControl(Control control, int radius)
        {
            // Intentionally empty. Only the outer Form has the original SWF shape.
            // Applying a Region to child controls caused repaint artifacts.
        }

        private static Button CardButton(string text, int x, int y, int width, int height, bool accent)
        {
            var b = new VectorButton("")
            {
                Text = text, Location = new Point(x, y), Size = new Size(width, height),
                BackColor = accent ? Color.FromArgb(29, 177, 219) : Color.FromArgb(27, 46, 67),
                ForeColor = accent ? Color.FromArgb(7, 24, 37) : Color.White, FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand,
                Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold)
            };
            b.FlatAppearance.BorderSize = 0;
            RoundControl(b, 9);
            return b;
        }

        private T Translate<T>(T control, string key) where T : Control
        {
            control.Tag = "i18n:" + key;
            return control;
        }

        private void UpdateSettingsTranslations()
        {
            if (_appSettingsCard != null) UpdateTranslationTree(_appSettingsCard);
            if (_gameSettingsCard != null) UpdateTranslationTree(_gameSettingsCard);
        }

        private void UpdateTranslationTree(Control root)
        {
            var d = _i18n[_currentLang];
            foreach (Control control in root.Controls)
            {
                string tag = control.Tag as string;
                if (tag != null && tag.StartsWith("i18n:", StringComparison.Ordinal))
                {
                    string key = tag.Substring(5);
                    if (d.ContainsKey(key)) control.Text = d[key];
                }
                if (control.HasChildren) UpdateTranslationTree(control);
            }
        }


        [DataContract]
        private sealed class GithubRelease
        {
            [DataMember(Name = "tag_name")] public string Tag;
            [DataMember(Name = "draft")] public bool Draft;
            [DataMember(Name = "assets")] public GithubAsset[] Assets;
        }

        [DataContract]
        private sealed class GithubAsset
        {
            [DataMember(Name = "name")] public string Name;
        }

        private async Task CheckGithubUpdateAsync()
        {
            // Official release channel only: do not execute remotely downloaded code.
            const string endpoint = "https://api.github.com/repos/Ehynia/Reactivate_TFOL/releases?per_page=10";
            try
            {
                // Older .NET Framework installations may otherwise negotiate TLS 1.0;
                // GitHub API requires TLS 1.2+. Keep OS certificate verification ON.
                ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072; // TLS 1.2
                string json;
                using (var client = new WebClient())
                {
                    client.Headers[HttpRequestHeader.UserAgent] = "Reactivate-TFOL-WinForms/31";
                    client.Headers[HttpRequestHeader.Accept] = "application/vnd.github+json";
                    json = await client.DownloadStringTaskAsync(new Uri(endpoint));
                }
                var releases = FromJson<GithubRelease[]>(json);
                var release = releases == null ? null : releases.FirstOrDefault(r => r != null && !r.Draft &&
                    !string.IsNullOrEmpty(r.Tag) && System.Text.RegularExpressions.Regex.IsMatch(r.Tag, @"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$"));
                if (release == null) {
                    DiagnosticDialogs.Show(Ui("Пока нет опубликованных версий GitHub Releases.", "No GitHub Releases have been published yet.", "尚未发布 GitHub 版本。"), "Reactivate");
                    return;
                }
                string tag = release.Tag;
                // A source-only preview is not an installable launcher update.
                var assets = release.Assets ?? new GithubAsset[0];
                string archiveName = assets.Where(a => a != null && a.Name != null &&
                    (a.Name == "launcher-update.zip" || System.Text.RegularExpressions.Regex.IsMatch(a.Name, @"^Reactivate_TFOL_[A-Za-z0-9._-]+\.zip$")))
                    .Select(a => a.Name).FirstOrDefault(name => assets.Any(a => a != null && a.Name == name + ".sha256"));
                bool hasLauncherZip = archiveName != null;
                bool hasChecksum = archiveName != null;
                if (!hasLauncherZip || !hasChecksum)
                {
                    DiagnosticDialogs.Show(Ui("GitHub опубликовал " + tag + ", но проверенного обновления лаунчера ещё нет.",
                        "GitHub has " + tag + ", but no verified launcher update assets yet.",
                        "GitHub 已发布 " + tag + "，但尚无已验证的启动器更新包。"), "Reactivate");
                    return;
                }

                if (DiagnosticDialogs.Show(Ui("Найден релиз " + tag + ". Скачать обновление и проверить SHA-256?", "Release " + tag + " is available. Download and verify SHA-256?", "发现版本 " + tag + "。下载并验证 SHA-256？"),
                    "Reactivate GitHub", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                string script = Path.Combine(_baseDir, "Tools", "Install-ReactivateUpdate.ps1");
                if (!File.Exists(script)) throw new FileNotFoundException("Update script missing", script);
                var process = new ProcessStartInfo("powershell.exe") {
                    Arguments = "-NoProfile -ExecutionPolicy Bypass -File " + QuoteArg(script) + " -Tag " + QuoteArg(tag) + " -ArchiveName " + QuoteArg(archiveName),
                    UseShellExecute = true
                };
                Process.Start(process);
            }
            catch (WebException error)
            {
                var http = error.Response as HttpWebResponse;
                if (http != null && http.StatusCode == HttpStatusCode.NotFound) {
                    DiagnosticDialogs.Show(Ui("Пока нет опубликованных версий GitHub Releases.","No GitHub Releases have been published yet.","尚未发布 GitHub 版本。"), "Reactivate");
                    return;
                }
                string hint = error.Status == WebExceptionStatus.SecureChannelFailure || error.Status == WebExceptionStatus.TrustFailure
                    ? Ui("Не удалось установить TLS 1.2 соединение с GitHub. Проверьте дату Windows, обновления корневых сертификатов, TLS 1.2 и прокси. Проверка сертификата НЕ отключена.",
                         "GitHub TLS 1.2 failed. Check Windows clock, root certificates, TLS 1.2 and proxy. Certificate validation is still enforced.",
                         "GitHub TLS 1.2 连接失败；请检查系统时间、根证书、TLS 1.2 和代理。证书验证仍已启用。")
                    : error.Message;
                DiagnosticDialogs.Show("GitHub: " + hint, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception error) { DiagnosticDialogs.Show("GitHub: " + error.Message, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void BuildAppSettingsCard()
        {
            _appSettingsCard = new ThemePanel(this, Color.FromArgb(229, 12, 25, 43), true, 0)
            {
                Location = new Point(22, 100), Size = new Size(1198, 512)
            };
            var card = _appSettingsCard;
            card.Controls.Add(Translate(CardLabel("ВНЕШНИЙ ВИД", 26, 22, 670, 30, 11f), "look"));
            _blurCheckbox = new CheckBox
            {
                Text = "Размытый фон", Tag = "i18n:blur", Checked = _useBlurBg,
                Location = new Point(26, 62), Size = new Size(240, 32),
                ForeColor = Color.White, BackColor = Color.Transparent
            };
            _blurCheckbox.CheckedChanged += (sender, args) =>
            {
                _useBlurBg = _blurCheckbox.Checked;
                RefreshBackground();
                if (_isReady) SaveSettings();
            };
            _soundCheckbox = new CheckBox
            {
                Text = "Звуки интерфейса", Tag = "i18n:sound", Checked = _soundEnabled,
                Location = new Point(294, 62), Size = new Size(240, 32),
                ForeColor = Color.White, BackColor = Color.Transparent
            };
            _soundCheckbox.CheckedChanged += (sender, args) =>
            {
                _soundEnabled = _soundCheckbox.Checked;
                if (_isReady) SaveSettings();
            };
            card.Controls.Add(_blurCheckbox);
            card.Controls.Add(_soundCheckbox);
            _reportsCheckbox = new CheckBox
            {
                Text = Ui("Диагностика игры и снимки её окна", "Game diagnostics and window snapshots", "游戏诊断与窗口截图"),
                Checked = _collectDiagnostics, Location = new Point(26, 96), Size = new Size(390, 27),
                ForeColor = Color.White, BackColor = Color.Transparent
            };
            _reportsCheckbox.CheckedChanged += (sender, args) =>
            {
                _collectDiagnostics = _reportsCheckbox.Checked;
                if (_isReady) SaveSettings();
            };
            _reportsCheckbox.Tag = "i18n:reports";
            card.Controls.Add(_reportsCheckbox);
            var diagnostics = CardButton(Ui("Собрать отчёт · F12", "Collect report · F12", "收集报告 · F12"), 420, 94, 276, 29, false);
            diagnostics.Name = "ExportDiagnostics";
            diagnostics.Click += async (sender, args) => { await ExportDiagnosticsAsync(); };
            card.Controls.Add(diagnostics);

            card.Controls.Add(Translate(CardLabel("РАСПОЛОЖЕНИЕ КЛИЕНТА", 26, 125, 680, 28, 11f), "gamepath"));
            card.Controls.Add(Translate(CardLabel("Выберите EXE или папку игры:", 26, 156, 690, 26, 9f), "pathhelp"));
            _pathBox = new TextBox
            {
                Text = _gamePath,
                Location = new Point(26, 190), Size = new Size(670, 28),
                BackColor = Color.FromArgb(32, 43, 60), ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle, ReadOnly = true
            };
            card.Controls.Add(_pathBox);
            var chooseExe = Translate(CardButton(Ui("Выбрать EXE…","Choose EXE…","选择程序…"), 26, 224, 205, 29, true), "chooseexe");
            chooseExe.Tag = "i18n:chooseexe";
            chooseExe.Click += async (sender, args) => { await SelectGameAsync("exe"); };
            card.Controls.Add(chooseExe);
            var chooseFolder = Translate(CardButton(Ui("Найти в папке…","Search folder…","搜索文件夹…"), 240, 224, 205, 29, false), "choosefolder");
            chooseFolder.Tag = "i18n:choosefolder";
            chooseFolder.Click += async (sender, args) => { await SelectGameAsync("folder"); };
            card.Controls.Add(chooseFolder);
            var downloadGame = Translate(CardButton(Ui("Скачать игру с Диска…", "Download game from Drive…", "从云端硬盘下载游戏…"),
                456, 224, 240, 29, false), "downloadgame");
            downloadGame.Click += async (sender, args) => { await DownloadGameAsync(); };
            card.Controls.Add(downloadGame);

            card.Controls.Add(Translate(CardLabel("", 26, 282, 670, 36, 10f), "prepare_note"));
            card.Controls.Add(Translate(CardLabel("", 26, 325, 670, 48, 9f), "location_note"));
            var openGame = Translate(CardButton("", 26, 376, 250, 36, false), "openfolder");
            openGame.Click += (sender, args) =>
            {
                if (!string.IsNullOrEmpty(_gamePath) && Directory.Exists(_gamePath))
                    Process.Start(new ProcessStartInfo { FileName = _gamePath, UseShellExecute = true });
                else DiagnosticDialogs.Show(Ui("Сначала выберите игру.","Select the game first.","请先选择游戏。"), "Reactivate");
            };
            card.Controls.Add(openGame);

            card.Controls.Add(Translate(CardLabel("СЕРВЕРЫ — SERVERS.INI", 735, 22, 410, 31, 11f), "serverhead"));
            card.Controls.Add(Translate(CardLabel("Укажи настоящий IP и порт. Пустые поля допустимы.",
                735, 55, 435, 52, 9f), "serverhelp"));
            string[] serverNames = { "EU/CIS #1", "EU #2", "CN/ASIA #1", "PTS 2016" };
            for (int i = 0; i < _serverCodes.Length; i++)
            {
                string code = _serverCodes[i];
                int y = 115 + 47 * i;
                card.Controls.Add(CardLabel(serverNames[i], 735, y + 5, 116, 31, 9.5f));
                var ip = new TextBox
                {
                    Text = _serverIps[code], Location = new Point(860, y), Width = 213,
                    BackColor = Color.FromArgb(32, 43, 60), ForeColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 10f)
                };
                var port = new NumericUpDown
                {
                    Minimum = 0, Maximum = 65535, Value = _serverPorts[code],
                    Location = new Point(1080, y), Width = 91,
                    BackColor = Color.FromArgb(32, 43, 60), ForeColor = Color.White,
                    Font = new Font("Consolas", 10f)
                };
                _serverIpEdits[code] = ip;
                _serverPortEdits[code] = port;
                card.Controls.Add(ip);
                card.Controls.Add(port);
            }
            _serverStatusLabel = Translate(CardLabel("Адреса записываются отдельно в Servers.ini рядом с EXE.",
                735, 320, 437, 57, 9f), "servernote");
            card.Controls.Add(_serverStatusLabel);
            var admin = Translate(CardButton(Ui("Админская панель", "Admin panel", "管理面板"), 735, 376, 230, 36, false), "adminpanel");
            admin.Click += (sender, args) => OpenLocalAdmin();
            card.Controls.Add(admin);
            var githubUpdate = Translate(CardButton(Ui("Проверить обновления GitHub…", "Check GitHub updates…", "检查 GitHub 更新…"), 290, 376, 405, 36, false), "githubupdates");
            githubUpdate.Click += async (sender, args) => { await CheckGithubUpdateAsync(); };
            card.Controls.Add(githubUpdate);
            // v55: reviewed labels + local user CSV draft; no network translation.
            // Resources install at the next game launch, never during an active match.
            card.Controls.Add(Translate(CardLabel(Ui("ЛОКАЛИЗАЦИЯ: RU / EN / 中文", "LOCALIZATION: RU / EN / 中文", "本地化：俄语／英语／中文"), 26, 421, 615, 24, 11f), "manuallocalization"));
            card.Controls.Add(Translate(CardLabel(Ui("CSV-перевод применяется при запуске игры. Машинные строки — черновик.",
                "CSV translation applies on game launch. Machine-translated lines are drafts.",
                "游戏启动时应用 CSV 翻译；机翻文本尚未校对。"), 26, 449, 660, 36, 9f), "manualnote"));
            var openTable = Translate(CardButton(Ui("Таблица переводов…", "Translation table…", "翻译表…"), 735, 422, 240, 36, false), "translationtable");
            openTable.Click += (sender, args) => {
                try {
                    var path = Path.Combine(_baseDir, "ClientLanguages", "TFOL_partial_native_GoogleTranslate_source_v55.csv");
                    if (!File.Exists(path)) throw new FileNotFoundException("Missing bundled CSV translation table", path);
                    Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
                } catch (Exception ex) { DiagnosticDialogs.Show(ex.Message, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };
            card.Controls.Add(openTable);
            var scanTexts = Translate(CardButton(Ui("Экспортировать строки из PAK…", "Export original PAK strings…", "导出原始 PAK 文本…"), 735, 468, 438, 35, false), "exportpaktexts");
            scanTexts.Click += (sender, args) => {
                try {
                    string python = Path.Combine(_baseDir, "Server", "python", "python.exe");
                    string script = Path.Combine(_baseDir, "Server", "launcher_tools.py");
                    if (!File.Exists(python) || !File.Exists(script)) throw new FileNotFoundException("Missing offline text extractor");
                    // Explicit opt-in: scans the user's own PAK resources; does not send any text online.
                    // Do NOT wrap this in cmd.exe /k: Windows cmd parses a leading
                    // quoted executable + quoted Cyrillic path as a different command.
                    // CreateProcess parses FileName separately; QuoteArg is for arguments only.
                    Process.Start(new ProcessStartInfo {
                        FileName = python,
                        Arguments = QuoteArg(script) + " translations --launcher-root " + QuoteArg(_baseDir),
                        WorkingDirectory = _baseDir,
                        UseShellExecute = false,
                        CreateNoWindow = false
                    });
                } catch (Exception ex) { DiagnosticDialogs.Show(ex.Message, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            };
            card.Controls.Add(scanTexts);

            var saveButton = Translate(CardButton(Ui("Сохранить настройки", "Save settings", "保存设置"), 985, 422, 188, 36, true), "savesettings");
            saveButton.Click += (sender, args) =>
            {
                if (!SaveServerConfig(true)) return;
                SaveSettings();
                DiagnosticDialogs.Show(Ui("Настройки и адреса серверов сохранены.","Settings and server addresses saved.","已保存设置和服务器地址。"), "Reactivate",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            card.Controls.Add(saveButton);
            _subPage.Controls.Add(card);
        }

        private void SwitchTab(string tabKey)
        {
            LauncherDiagnostics.Screen = tabKey;
            LauncherDiagnostics.Log("ui_tab_changed", "tab", tabKey);
            _currentTab = tabKey;
            bool settings = tabKey == "appsettings" || tabKey == "gamesettings";
            _sideBar.Visible = !settings;
            _mainStage.Visible = !settings;
            _settingsOverlay.Visible = settings;
            _homePage.Visible = tabKey == "home";
            _subPage.Visible = false;
            _gameSettingsCard.Visible = tabKey == "gamesettings";
            _appSettingsCard.Visible = tabKey == "appsettings";
            foreach (Button b in _navBtns)
            {
                bool active = (b.Tag as string) == tabKey;
                b.BackColor = active ? Color.FromArgb(35, 95, 126) : Color.FromArgb(25, 43, 65);
                b.ForeColor = active ? Color.White : Color.FromArgb(205, 218, 232);
                b.FlatAppearance.MouseOverBackColor = Color.FromArgb(58, 78, 102);
            }
            if (_settingsAppTab != null)
            {
                _settingsAppTab.BackColor = tabKey == "appsettings" ? Color.FromArgb(46, 129, 158) : Color.FromArgb(36, 56, 78);
                _settingsGameTab.BackColor = tabKey == "gamesettings" ? Color.FromArgb(46, 129, 158) : Color.FromArgb(36, 56, 78);
            }
            _titleBar.BringToFront();
            if (settings) { _settingsOverlay.BringToFront(); _titleBar.BringToFront(); }
            UpdateSubPageText();
            RefreshBackground();
        }

        private void BuildSettingsOverlay()
        {
            _settingsOverlay = new ThemePanel(this, Color.FromArgb(234, 11, 24, 41), true, 0)
            {
                Location = new Point(19, 81),
                Size = new Size(1242, 622),
                Visible = false
            };
            _settingsBack = CardButton("← Назад", 22, 19, 138, 40, false);
            _settingsBack.Click += (s, e) => { if (SaveServerConfig(true)) SwitchTab("home"); };
            _settingsOverlay.Controls.Add(_settingsBack);
            _settingsAppTab = CardButton("Лаунчер", 178, 19, 185, 40, false);
            _settingsAppTab.Click += (s, e) => SwitchTab("appsettings");
            _settingsOverlay.Controls.Add(_settingsAppTab);
            _settingsGameTab = CardButton("Игра", 373, 19, 185, 40, false);
            _settingsGameTab.Click += (s, e) => { if (SaveServerConfig(true)) SwitchTab("gamesettings"); };
            _settingsOverlay.Controls.Add(_settingsGameTab);
            _settingsPageTitle = new Label
            {
                Location = new Point(575, 21), Size = new Size(600, 36),
                TextAlign = ContentAlignment.MiddleRight, BackColor = Color.Transparent,
                ForeColor = Color.FromArgb(223, 235, 248),
                Font = new Font("Segoe UI Semibold", 15f, FontStyle.Bold)
            };
            _settingsOverlay.Controls.Add(_settingsPageTitle);
            // Parent transfer is deliberate: settings replace the full interior,
            // not a card squeezed beside the navigation bar.
            _gameSettingsCard.Location = new Point(22, 84);
            _gameSettingsCard.Size = new Size(1198, 512);
            _appSettingsCard.Location = new Point(22, 84);
            _appSettingsCard.Size = new Size(1198, 512);
            _settingsOverlay.Controls.Add(_gameSettingsCard);
            _settingsOverlay.Controls.Add(_appSettingsCard);
            Controls.Add(_settingsOverlay);
        }

        private void ExtendLauncherTranslations()
        {
            // V48: language switching must refresh controls, not just rebuild the title.
            string[,] text = new string[,] {
                {"manuallocalization", "ЛОКАЛИЗАЦИЯ: RU / EN / 中文", "LOCALIZATION: RU / EN / 中文", "本地化：俄语／英语／中文"},
                {"manualnote", "CSV-перевод применяется при запуске игры. Машинные строки — черновик.", "CSV translation applies on game launch. Machine-translated lines are drafts.", "游戏启动时应用 CSV 翻译；机翻文本尚未校对。"},
                {"translationtable", "Таблица переводов…", "Translation table…", "翻译表…"},
                {"exportpaktexts", "Экспортировать строки из PAK…", "Export original PAK strings…", "导出原始 PAK 文本…"},
                {"savesettings", "Сохранить", "Save settings", "保存设置"},
                {"adminpanel", "Админская панель", "Admin panel", "管理面板"},
                {"githubupdates", "Проверить обновления GitHub…", "Check GitHub updates…", "检查 GitHub 更新…"},
                {"reports", "Диагностика игры и снимки её окна", "Game diagnostics and window snapshots", "游戏诊断与窗口截图"},
                {"chooseexe", "Выбрать EXE…", "Choose EXE…", "选择程序…"},
                {"choosefolder", "Найти в папке…", "Search folder…", "搜索文件夹…"},
                {"downloadgame", "Скачать игру с Диска…", "Download game from Drive…", "从云端硬盘下载游戏…"}
            };
            for (int i=0; i<text.GetLength(0); i++) {
                _i18n["ru"][text[i,0]]=text[i,1];
                _i18n["en"][text[i,0]]=text[i,2];
                _i18n["zh"][text[i,0]]=text[i,3];
            }
            _i18n["ru"]["resolution"] = "Разрешение";
            _i18n["en"]["resolution"] = "Resolution";
            _i18n["zh"]["resolution"] = "分辨率";
            _i18n["ru"]["windowmode"] = "Режим окна";
            _i18n["en"]["windowmode"] = "Window mode";
            _i18n["zh"]["windowmode"] = "窗口模式";
            _i18n["ru"]["graphicsapi"] = "Графика";
            _i18n["en"]["graphicsapi"] = "Graphics API";
            _i18n["zh"]["graphicsapi"] = "图形接口";
            _i18n["ru"]["prepare_note"] = "Игра запускается после проверки локальных языковых ресурсов.";
            _i18n["en"]["prepare_note"] = "The game starts after checking local language resources.";
            _i18n["zh"]["prepare_note"] = "游戏在检查本地语言资源后启动。";
            _i18n["ru"]["location_note"] = "Игра может находиться на любом диске. Выбранный путь сохраняется.";
            _i18n["en"]["location_note"] = "The game can be on any drive. Your chosen location is saved.";
            _i18n["zh"]["location_note"] = "游戏可位于任意磁盘，所选位置将保存。";
            _i18n["ru"]["openfolder"] = "Открыть папку игры";
            _i18n["en"]["openfolder"] = "Open game folder";
            _i18n["zh"]["openfolder"] = "打开游戏文件夹";
            _i18n["ru"]["playhub"] = "ИГРОВОЙ ЦЕНТР";
            _i18n["en"]["playhub"] = "PLAY HUB";
            _i18n["zh"]["playhub"] = "游戏中心";
            _i18n["ru"]["community"] = "ПРОЕКТ СООБЩЕСТВА";
            _i18n["en"]["community"] = "COMMUNITY RESTORATION";
            _i18n["zh"]["community"] = "社区重启计划";
        }

        private void SetLanguage(string lang)
        {
            if (!_i18n.ContainsKey(lang)) lang = "ru";
            bool gameLanguagePending = _gameRunning && _currentLang != lang;
            _currentLang = lang;
            Program.Language = lang;
            var d = _i18n[lang];

            string[] codes = { "eu1", "eu2", "asia1", "pts" };
            int selReg = Array.IndexOf(codes, _currentRegion);
            _regionCombo.Items.Clear();
            _regionCombo.Items.AddRange(new object[] { d["srv_eu1"], d["srv_eu2"], d["srv_asia1"], d["srv_pts"] });
            _regionCombo.SelectedIndex = Math.Max(0, selReg);
            UpdateServerInfoLabel();

            string[] navKeys = { "nav_home", "nav_gamesettings", "nav_appsettings" };
            for (int i = 0; i < _navBtns.Length; i++)
                _navBtns[i].Text = d[navKeys[i]];

            foreach (Button lb in _langBtns)
            {
                bool active = (lb.Tag as string) == lang;
                lb.BackColor = active ? Color.FromArgb(231, 141, 63) : Color.FromArgb(31, 52, 73);
                lb.ForeColor = Color.White;
                lb.FlatAppearance.MouseOverBackColor = Color.FromArgb(58, 78, 102);
                lb.Invalidate();
            }

            if (_heroBadge != null) _heroBadge.Text = Ui("ОРИГИНАЛЬНАЯ ИГРА  •  ВОССТАНОВЛЕНИЕ", "ORIGINAL GAME  •  REACTIVATED", "原版游戏  •  重启计划");
            if (_heroHeading != null) { _heroHeading.Text = "TRANSFORMERS ONLINE"; FitHeroHeading(); }
            if (_heroDescription != null) _heroDescription.Text = Ui(
                "Оригинальный клиент, собственный сервер и вселенная Трансформеров. Проект восстановления TFOL.",
                "The original client, independent server and Transformers universe. A TFOL restoration project.",
                "原版客户端、独立服务器与变形金刚宇宙。TFOL 游戏重建计划。");
            if (_launchCardHeading != null) _launchCardHeading.Text = Ui("ИГРА ГОТОВА", "READY TO PLAY", "准备启动游戏");
            if (_chooseGameBtn != null) _chooseGameBtn.Text = Ui("Выбрать клиент TFOL", "Select TFOL client", "选择游戏客户端");
            _newsHeaderLabel.Text = Ui("СООБЩЕСТВО  /  НОВОСТИ", "COMMUNITY  /  NEWS", "社区  /  资讯");
            RenderNews();
            _statusMainLabel.Text = gameLanguagePending ?
                (lang == "ru" ? "Язык игры изменится при следующем запуске" : lang == "en" ? "Game language changes on the next launch" : "游戏语言将在下次启动时更改") :
                (string.IsNullOrEmpty(_gamePath) ?
                    (lang == "ru" ? "Нажмите «Играть» и выберите игру" : lang == "en" ? "Click Play and select the game" : "点击开始并选择游戏") :
                    (lang == "ru" ? Ui("Игра выбрана · готов к запуску","Game selected · ready to launch","已选择游戏，可以启动") : lang == "en" ? "Game selected · ready to launch" : "已选择游戏 · 可以启动"));
            _statusVerLabel.Text = d["st_ver"];
            _startGameBtn.Text = d["btn_start"];
            _accountBtn.Text = string.IsNullOrEmpty(_accountName) ? Ui("Вход", "Sign in", "登录") : _accountName;
            if (_launchAccountHint != null) _launchAccountHint.Text = Ui("Вход или регистрация перед запуском", "Sign in or create an account to play", "启动前登录或注册账户");
            UpdateSubPageText();
            UpdateSettingsTranslations();
            UpdateTranslationTree(this);
            _winModeCombo.Refresh(); _dxCombo.Refresh();
            if (_settingsAppTab != null)
            {
                _settingsBack.Text = d["back"];
                _settingsAppTab.Text = d["settingsapp"];
                _settingsGameTab.Text = d["settingsgame"];
                _settingsPageTitle.Text = _currentTab == "gamesettings" ? d["gs_t"] : d["as_t"];
            }
            if (_isReady) SaveSettings();
            RefreshBackground();
        }


        private void UpdateSubPageText()
        {
            var d = _i18n[_currentLang];
            if (_settingsPageTitle != null && _currentTab == "appsettings") _settingsPageTitle.Text = d["as_t"];
            else if (_settingsPageTitle != null && _currentTab == "gamesettings") _settingsPageTitle.Text = d["gs_t"];
            if (_currentTab == "gamesettings") { _subTitleLabel.Text = d["gs_t"]; _subDescLabel.Text = d["gs_d"]; }
            else if (_currentTab == "appsettings") { _subTitleLabel.Text = d["as_t"]; _subDescLabel.Text = d["as_d"]; }
        }

        private bool WriteGameConfigFiles()
        {
            string gameRoot = GetGameDirectory(true);
            if (gameRoot == null) return false;
            string path = Path.Combine(gameRoot, "TCLS", "config", "system.ini");
            try
            {
                SaveSettings();
                string cfgDir = Path.Combine(gameRoot, "TCLS", "config");
                Directory.CreateDirectory(cfgDir);
                var changes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                changes["resolution"] = _gameResolution;
                changes["windowmode"] = _gameWindowMode;
                changes["graphicsapi"] = _gameGraphicsApi;
                changes["region"] = _currentRegion;
                changes["lang"] = _currentLang;
                List<string> lines = File.Exists(path) ? new List<string>(File.ReadAllLines(path)) : new List<string>();
                if (File.Exists(path) && !File.Exists(path + ".bak")) File.Copy(path, path + ".bak");
                int sectionStart = -1, sectionEnd = lines.Count;
                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Equals("[system]", StringComparison.OrdinalIgnoreCase))
                    { sectionStart = i; continue; }
                    if (sectionStart >= 0 && line.StartsWith("[") && line.EndsWith("]"))
                    { sectionEnd = i; break; }
                }
                if (sectionStart < 0)
                {
                    if (lines.Count > 0) lines.Add("");
                    sectionStart = lines.Count;
                    lines.Add("[system]");
                    sectionEnd = lines.Count;
                }
                for (int i = sectionStart + 1; i < sectionEnd; i++)
                {
                    string trimmed = lines[i].Trim();
                    if (trimmed.StartsWith("#") || trimmed.StartsWith(";")) continue;
                    int equals = lines[i].IndexOf('=');
                    if (equals < 0) continue;
                    string key = lines[i].Substring(0, equals).Trim();
                    if (changes.ContainsKey(key))
                    {
                        lines[i] = key + "=" + changes[key];
                        changes.Remove(key);
                    }
                }
                foreach (var pair in changes)
                    lines.Insert(sectionEnd++, pair.Key + "=" + pair.Value);
                WriteManagedLines(path, lines);
                return true;
            }
            catch (Exception ex)
            {
                Program.LogFailure(ex);
                DiagnosticDialogs.Show(Ui("Не удалось сохранить конфигурацию / Cannot save config:\r\n","Could not save configuration:\r\n","无法保存配置：\r\n") + path + "\r\n" + ex.Message, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        private string Ui(string ru, string en, string zh)
        {
            return _currentLang == "ru" ? ru : _currentLang == "zh" ? zh : en;
        }

        private Button AuthButton(string text, int x, int y, int width, bool accent)
        {
            var button = new Button { Text = text, Location = new Point(x, y), Size = new Size(width, 38),
                FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand,
                BackColor = accent ? Color.FromArgb(242, 149, 70) : Color.FromArgb(36, 51, 69), ForeColor = Color.White };
            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private bool PromptAccountDialog()
        {
            PlayUiSound();
            using (var dlg = new Form())
            {
                dlg.Text = Ui("Доступ к игре", "Game access", "游戏账户") + " — Reactivate";
                dlg.ClientSize = new Size(500, 440);
                dlg.Font = new Font("Segoe UI", 10f);
                dlg.AutoScaleMode = AutoScaleMode.Dpi;
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false;
                dlg.MinimizeBox = false;
                dlg.BackColor = Color.FromArgb(24, 30, 42);
                dlg.ForeColor = Color.White;

                var title = new Label { Text = "REACTIVATE  /  TEST NODE", Location = new Point(28, 24), Size = new Size(444, 28),
                    ForeColor = Color.FromArgb(242, 163, 104), Font = new Font("Segoe UI Semibold", 13f) };
                var signIn = AuthButton(Ui("Вход", "Sign in", "登录"), 28, 70, 216, true);
                var signUp = AuthButton(Ui("Регистрация", "Register", "注册"), 254, 70, 218, false);
                var lbl = new Label { Text = Ui("Логин аккаунта (не игровой ник)", "Account login (not your in-game name)", "账户登录名（不是游戏昵称）"), Location = new Point(28, 132), Size = new Size(444, 24) };
                var box = new TextBox { Text = _accountName, Location = new Point(28, 160), Width = 444, MaxLength = 31 };
                var keyLabel = new Label { Text = Ui("Пароль", "Password", "密码"), Location = new Point(28, 204), Size = new Size(444, 24) };
                var keyBox = new TextBox { Location = new Point(28, 232), Width = 444, MaxLength = 256, UseSystemPasswordChar = true };
                var note = new Label { Location = new Point(28, 282), Size = new Size(444, 80), ForeColor = Color.FromArgb(182, 200, 218) };
                var cancel = AuthButton(Ui("Отмена", "Cancel", "取消"), 28, 374, 124, false);
                cancel.DialogResult = DialogResult.Cancel;
                var ok = AuthButton("", 166, 374, 306, true);
                bool registering = false;
                Action<bool> choose = mode => {
                    registering = mode;
                    keyLabel.Visible = keyBox.Visible = !mode;
                    signIn.BackColor = mode ? Color.FromArgb(36, 51, 69) : Color.FromArgb(242, 149, 70);
                    signUp.BackColor = mode ? Color.FromArgb(242, 149, 70) : Color.FromArgb(36, 51, 69);
                    note.Text = mode ? Ui("Введите только логин. Сервер выдаст уникальный пароль. Пока в игре будет временное имя: цепочка обучения с Мегатроном и выбора ника ещё подключается.",
                        "Enter a login only. The server generates your password. A temporary in-game name is used for now; Megatron tutorial and name-selection integration is still in progress.", "只输入登录名，服务器会生成密码。游戏暂时使用临时昵称，威震天教程结束后的命名流程仍在接入中。") :
                        Ui("В OBT29 старые тестовые аккаунты сброшены: сначала зарегистрируйтесь. Затем используйте логин и выданный пароль. Лаунчер пароль не хранит.",
                        "OBT29 resets old test accounts: register first. After that, use your login and issued password. The launcher does not save passwords.", "OBT29会重置旧测试账户，请先注册。之后使用登录名和已获得的密码登录。启动器不保存密码。");
                    ok.Text = mode ? Ui("Создать аккаунт", "Create account", "创建账户") : Ui("Войти и запустить", "Sign in and play", "登录并启动");
                };
                signIn.Click += (s, e) => choose(false);
                signUp.Click += (s, e) => choose(true);
                choose(string.IsNullOrEmpty(_accountName));
                ok.Click += (s, e) =>
                {
                    string login = box.Text.Trim();
                    if (string.IsNullOrEmpty(login) || Encoding.UTF8.GetByteCount(login) > 31 ||
                        login.Any(c => char.IsControl(c) || "?&#=\\/".IndexOf(c) >= 0))
                    {
                        DiagnosticDialogs.Show(dlg, Ui("Логин: от 1 до 31 байта UTF-8, без управляющих символов и ? & # = / \\",
                            "Login: 1–31 UTF-8 bytes; no control characters or ? & # = / \\", "登录名必须为1至31个UTF-8字节，不得包含控制字符或特殊分隔符。"), "Reactivate");
                        return;
                    }
                    if (!registering && keyBox.Text.Length == 0) { keyBox.Focus(); return; }
                    _accountName = login;
                    _accountKey = registering ? null : keyBox.Text;
                    _authAction = registering ? "register" : "login";
                    _accountBtn.Text = _accountName;
                    SaveSettings(); // Login only. Password never enters an INI.
                    dlg.DialogResult = DialogResult.OK;
                };
                dlg.AcceptButton = ok; dlg.CancelButton = cancel;
                dlg.Controls.AddRange(new Control[] { title, signIn, signUp, lbl, box, keyLabel, keyBox, note, cancel, ok });
                return dlg.ShowDialog(this) == DialogResult.OK;
            }
        }

        private bool ConfirmGeneratedPassword(string login, string password)
        {
            if (string.IsNullOrEmpty(password) || password.Length > 256) throw new InvalidOperationException("Invalid registration response");
            using (var dlg = new Form { Text = Ui("Сохраните пароль", "Save your password", "保存密码"), ClientSize = new Size(560, 380),
                Font = new Font("Segoe UI", 10f), AutoScaleMode = AutoScaleMode.Dpi,
                BackColor = Color.FromArgb(24, 30, 42), ForeColor = Color.White, StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, ControlBox = false })
            {
                var title = new Label { Text = Ui("АККАУНТ СОЗДАН", "ACCOUNT CREATED", "账户已创建"), Location = new Point(28, 26), Size = new Size(504, 30), ForeColor = Color.FromArgb(242, 163, 104), Font = new Font("Segoe UI Semibold", 15f) };
                var name = new Label { Text = Ui("Логин: ", "Login: ", "登录名：") + login, Location = new Point(28, 76), Size = new Size(504, 28), AutoEllipsis = true };
                var secret = new TextBox { Text = password, ReadOnly = true, Location = new Point(28, 116), Width = 504 };
                var copy = AuthButton(Ui("Копировать пароль", "Copy password", "复制密码"), 28, 158, 220, false);
                copy.Click += (s, e) => { try { Clipboard.SetText(password); copy.Text = Ui("Скопировано", "Copied", "已复制"); }
                    catch (ExternalException) { DiagnosticDialogs.Show(dlg, Ui("Не удалось скопировать. Сохраните пароль вручную.", "Copy failed. Save the password manually.", "复制失败，请手动保存密码。")); } };
                var note = new Label { Text = Ui("Пароль показывается только сейчас. Сохраните его в менеджер паролей. Без него повторный вход невозможен.",
                    "This is the only password display. Save it in a password manager. You need it to sign in again.", "密码仅显示一次。请保存到密码管理器，以便下次登录。"), Location = new Point(28, 212), Size = new Size(504, 56), ForeColor = Color.FromArgb(182, 200, 218) };
                var saved = new CheckBox { Text = Ui("Я сохранил логин и пароль", "I saved my login and password", "我已保存登录名和密码"), Location = new Point(28, 278), Size = new Size(504, 30) };
                var later = AuthButton(Ui("Не запускать", "Not now", "暂不启动"), 28, 324, 164, false);
                later.Click += (s, e) => dlg.DialogResult = DialogResult.Cancel;
                var go = AuthButton(Ui("Продолжить и запустить", "Continue and play", "继续并启动"), 204, 324, 328, true); go.Enabled = false;
                saved.CheckedChanged += (s, e) => go.Enabled = saved.Checked;
                go.Click += (s, e) => dlg.DialogResult = DialogResult.OK;
                dlg.FormClosing += (s, e) => {
                    if (!saved.Checked && e.CloseReason == CloseReason.UserClosing && DiagnosticDialogs.Show(dlg,
                        Ui("Аккаунт уже создан. Если закрыть окно без сохранённого пароля, повторный вход будет невозможен. Закрыть?",
                        "The account already exists. If you close without saving the password, you cannot sign in again. Close?",
                        "账户已创建。未保存密码将无法再次登录。确定关闭？"), "Reactivate", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                        e.Cancel = true;
                };
                dlg.Controls.AddRange(new Control[] { title, name, secret, copy, note, saved, later, go });
                bool accepted = dlg.ShowDialog(this) == DialogResult.OK;
                secret.Clear(); return accepted;
            }
        }

        [DataContract]
        private sealed class NewsCache
        {
            [DataMember(Name = "items")] public NewsEntry[] Items;
        }
        [DataContract]
        private sealed class NewsEntry
        {
            [DataMember(Name = "title")] public string Title;
            [DataMember(Name = "url")] public string Url;
            [DataMember(Name = "subreddit")] public string Community;
        }
        private static bool IsRedditPost(string value)
        {
            Uri uri;
            return Uri.TryCreate(value, UriKind.Absolute, out uri) && uri.Scheme == "https" &&
                (uri.Host == "www.reddit.com" || uri.Host == "reddit.com" || uri.Host == "old.reddit.com") &&
                uri.IsDefaultPort && string.IsNullOrEmpty(uri.UserInfo) &&
                uri.AbsolutePath.StartsWith("/r/", StringComparison.Ordinal) && uri.AbsolutePath.Contains("/comments/");
        }
        private void OpenNews(string url)
        {
            if (!IsRedditPost(url)) return;
            try { Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true }); }
            catch (Exception error) { DiagnosticDialogs.Show(error.Message, "Reddit"); }
        }
        private void RenderNews()
        {
            if (_newsItemLabels == null) return;
            _newsHeaderLabel.Text = "REDDIT  •  TRANSFORMERS";
            for (int i = 0; i < _newsItemLabels.Length; i++)
            {
                NewsEntry row = i < _newsEntries.Length ? _newsEntries[i] : null;
                _newsItemLabels[i].Tag = row == null ? null : row.Url;
                _newsItemLabels[i].Cursor = row == null ? Cursors.Default : Cursors.Hand;
                _newsItemLabels[i].Text = row == null ? "" : "r/" + row.Community + ": " + row.Title;
            }
            if (_newsEntries.Length == 0)
                _newsItemLabels[0].Text = _currentLang == "ru" ? "Новости пока недоступны. Повторим позже." :
                    (_currentLang == "zh" ? "新闻暂时不可用，稍后重试。" : "News unavailable. Will retry later.");
        }
        private async Task RefreshNewsAsync()
        {
            if (_newsRefreshing || IsDisposed) return;
            _newsRefreshing = true;
            try
            {
                string python = Path.Combine(_baseDir, "Server", "python", "python.exe");
                string script = Path.Combine(_baseDir, "Server", "news_feed.py");
                if (!File.Exists(python) || !File.Exists(script)) return;
                string cache = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "reddit_news_cache.json");
                using (var process = new Process { StartInfo = new ProcessStartInfo { FileName = python,
                    Arguments = QuoteArg(script) + " --cache " + QuoteArg(cache), WorkingDirectory = _baseDir,
                    UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
                    RedirectStandardError = true, StandardOutputEncoding = Encoding.UTF8,
                    StandardErrorEncoding = Encoding.UTF8 } })
                {
                    StartChecked(process);
                    Task<string> output = process.StandardOutput.ReadToEndAsync();
                    Task<string> errors = process.StandardError.ReadToEndAsync();
                    if (!await Task.Run(() => process.WaitForExit(20000)))
                    {
                        try { process.Kill(); } catch (InvalidOperationException) { }
                        return;
                    }
                    string text = await output;
                    await errors;
                    if (IsDisposed || process.ExitCode != 0 || text.Length > 1048576) return;
                    NewsCache value = FromJson<NewsCache>(text);
                    _newsEntries = (value.Items ?? new NewsEntry[0]).Where(row => row != null &&
                        !string.IsNullOrWhiteSpace(row.Title) && IsRedditPost(row.Url) &&
                        (row.Community == "transformers" || row.Community == "TransformersReactivate")).Take(4).ToArray();
                }
            }
            catch (Exception) { /* Keep the last cached news; startup and Play stay independent. */ }
            finally { _newsRefreshing = false; if (!IsDisposed) RenderNews(); }
        }

        [DataContract]
        private sealed class GameDownloadRequest
        {
            [DataMember(Name = "destination")] public string Destination;
            [DataMember(Name = "archive_dir")] public string ArchiveDir;
            [DataMember(Name = "launcher_root")] public string LauncherRoot;
        }

        [DataContract]
        private sealed class GameDownloadEvent
        {
            [DataMember(Name = "event")] public string Event;
            [DataMember(Name = "message")] public string Message;
            [DataMember(Name = "file")] public string File;
            [DataMember(Name = "game_path")] public string GamePath;
            [DataMember(Name = "bytes")] public long Bytes;
            [DataMember(Name = "total")] public long Total;
            [DataMember(Name = "index")] public int Index;
            [DataMember(Name = "count")] public int Count;
        }

        private async Task<bool> DownloadGameAsync()
        {
            if (_launching || _selectingGame || _bridgeProcess != null) return false;
            string python = Path.Combine(_baseDir, "Server", "python", "python.exe");
            string script = Path.Combine(_baseDir, "Server", "download_game.py");
            if (!File.Exists(python) || !File.Exists(script))
            {
                DiagnosticDialogs.Show(Ui("Распакуйте лаунчер полностью, включая папку Server.",
                    "Extract the launcher including the Server folder.", "请完整解压启动器及 Server 目录。"), "Reactivate");
                return false;
            }
            string folder = Path.Combine(_baseDir, "GameFiles", "Installed");
            // Automatically default to a dedicated folder inside Release.
            // If Release is read-only, use a per-user install folder instead.
            try { Directory.CreateDirectory(folder); }
            catch (UnauthorizedAccessException) {
                folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "GameFiles", "Installed");
                Directory.CreateDirectory(folder);
            }
            // Never silently reuse/overwrite an arbitrary user folder. Advanced users can choose a location.
            using (var chooser = new FolderBrowserDialog {
                Description = Ui("Выберите папку установки. Нужно около 6 ГБ для загрузки плюс место для распаковки.",
                    "Choose an install folder. Around 6 GB for downloads plus extracted space is needed.",
                    "选择安装目录，下载需约 6 GB 空间，解压还需额外空间。"),
                SelectedPath = Directory.Exists(folder) ? folder : _baseDir, ShowNewFolderButton = true })
            {
                if (chooser.ShowDialog(this) != DialogResult.OK) return false;
                folder = chooser.SelectedPath;
                if (String.Equals(Path.GetFullPath(folder).TrimEnd('\\'), Path.GetFullPath(_baseDir).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
                {
                    DiagnosticDialogs.Show(Ui("Выберите отдельную папку для игры, не корень лаунчера.",
                        "Choose a dedicated game folder, not the launcher root.", "请选择独立游戏目录，不要使用启动器根目录。"));
                    return false;
                }
            }
            string archiveCache = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Reactivate", "Downloads", "TFOL");
            if (DiagnosticDialogs.Show(Ui("Загрузить 37 частей TFOL (~5,8 ГБ) с Google Drive? 7-Zip уже включён в лаунчер. Уже скачанные части будут повторно использованы.\r\n\r\n" + folder,
                "Download 37 TFOL volumes (~5.8 GB) from Google Drive? 7-Zip is bundled with the launcher. Existing parts will be reused.\r\n\r\n" + folder,
                "从 Google Drive 下载 37 个 TFOL 分卷（约 5.8 GB）？启动器已内置 7-Zip，已下载的分卷可复用。\r\n\r\n" + folder),
                "Reactivate", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return false;
            _selectingGame = true;
            _startGameBtn.Enabled = false;
            Process process = null;
            bool completed = false;
            string resultPath = null;
            string installError = null;
            using (var progress = new Form { Text = Ui("Установка TFOL", "Installing TFOL", "安装 TFOL"),
                ClientSize = new Size(600, 180), StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false })
            {
                var status = new Label { Text = Ui("Подготовка…", "Preparing…", "准备中…"), AutoEllipsis = true,
                    Location = new Point(22, 20), Size = new Size(554, 56) };
                var bar = new ProgressBar { Location = new Point(22, 83), Size = new Size(554, 24), Minimum = 0, Maximum = 100 };
                var cancel = new Button { Text = Ui("Отмена", "Cancel", "取消"), Location = new Point(450, 126), Size = new Size(126, 33) };
                cancel.Click += (sender, e) => progress.Close();
                progress.Controls.AddRange(new Control[] { status, bar, cancel });
                progress.FormClosing += (sender, e) => {
                    if (!completed) try { if (process != null && !process.HasExited) process.Kill(); } catch { }
                };
                progress.Show(this);
                try
                {
                    process = new Process { StartInfo = new ProcessStartInfo { FileName = python,
                        Arguments = QuoteArg(script) + " --json-stdin", WorkingDirectory = _baseDir,
                        UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true,
                        RedirectStandardOutput = true, RedirectStandardError = true,
                        StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 } };
                    StartChecked(process);
                    Task<string> errorStream = process.StandardError.ReadToEndAsync();
                    var request = new GameDownloadRequest { Destination = folder, ArchiveDir = archiveCache, LauncherRoot = _baseDir };
                    byte[] payload = new UTF8Encoding(false).GetBytes(ToJson(request) + "\n");
                    await process.StandardInput.BaseStream.WriteAsync(payload, 0, payload.Length);
                    process.StandardInput.Close();
                    string line;
                    while ((line = await process.StandardOutput.ReadLineAsync()) != null)
                    {
                        if (progress.IsDisposed) continue;
                        GameDownloadEvent item;
                        try { item = FromJson<GameDownloadEvent>(line); } catch { continue; }
                        if (item == null) continue;
                        if (item.Event == "download") {
                            status.Text = Ui("Скачивание: ", "Downloading: ", "下载中：") + (item.File ?? "") +
                                "  " + (item.Bytes / 1048576L) + "/" + (item.Total / 1048576L) + " MB";
                            if (item.Total > 0) bar.Value = (int)Math.Min(100, item.Bytes * 100L / item.Total);
                        }
                        else if (item.Event == "part") {
                            status.Text = Ui("Часть ", "Part ", "分卷 ") + item.Index + "/" + item.Count + "  " + item.File;
                            bar.Value = 0;
                        }
                        else if (item.Event == "extract") {status.Text = Ui("Распаковка и проверка файлов…", "Extracting and validating game…", "解压并验证游戏文件…"); bar.Style = ProgressBarStyle.Marquee;}
                        else if (item.Event == "complete") resultPath = item.GamePath;
                        else if (item.Event == "error") installError = item.Message;
                    }
                    await Task.Run(() => process.WaitForExit());
                    string stderr = await errorStream;
                    if (!progress.IsDisposed && process.ExitCode == 0 && !String.IsNullOrEmpty(resultPath) && Directory.Exists(resultPath))
                    {
                        _gamePath = resultPath;
                        if (_pathBox != null) _pathBox.Text = _gamePath;
                        SaveSettings();
                        _statusMainLabel.Text = Ui("Игра установлена · готов к запуску", "Game installed · ready to launch", "游戏安装完成，可以启动");
                        completed = true;
                        progress.Close();
                        return true;
                    }
                    if (!progress.IsDisposed) DiagnosticDialogs.Show(installError ?? stderr ?? Ui("Установка не завершена.", "Installation did not finish.", "安装未完成。"),
                        "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                catch (Exception error)
                {
                    if (!progress.IsDisposed) DiagnosticDialogs.Show(error.Message, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                finally
                {
                    completed = true;
                    if (!progress.IsDisposed) progress.Close();
                    if (process != null) process.Dispose();
                    _selectingGame = false;
                    if (!IsDisposed) _startGameBtn.Enabled = true;
                }
            }
        }

        private async Task<bool> SelectGameAsync(string mode)
        {
            if (_launching || _bridgeProcess != null) return false;
            if (_selectingGame || (_bridgeProcess != null)) return false;
            string selected = null;
            if (mode == null)
            {
                using (var choice = new Form { Text = Ui("Где установлена игра?","Where is the game installed?","游戏安装在哪里？"), ClientSize = new Size(560, 210),
                    StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog,
                    MaximizeBox = false, MinimizeBox = false })
                {
                    choice.Controls.Add(new Label { Text = Ui("Укажите EXE игры или папку, в которой её нужно найти.","Select the game EXE or the folder to search.","选择游戏程序或要搜索的文件夹。"),
                        Location = new Point(20, 20), Size = new Size(520, 40) });
                    var download = new Button { Text = Ui("Скачать и установить TFOL с Google Drive", "Download and install TFOL from Google Drive", "从 Google Drive 下载并安装 TFOL"),
                        Location = new Point(20, 143), Size = new Size(510, 39) };
                    download.Click += (sender, args) => { mode = "download"; choice.DialogResult = DialogResult.OK; };
                    var exe = new Button { Text = Ui("Выбрать EXE…","Choose EXE…","选择程序…"), Location = new Point(20, 82), Size = new Size(245, 40) };
                    var folder = new Button { Text = Ui("Найти в папке…","Search folder…","搜索文件夹…"), Location = new Point(285, 82), Size = new Size(245, 40) };
                    exe.Click += (sender, args) => { mode = "exe"; choice.DialogResult = DialogResult.OK; };
                    folder.Click += (sender, args) => { mode = "folder"; choice.DialogResult = DialogResult.OK; };
                    choice.Controls.AddRange(new Control[] { exe, folder, download });
                    if (choice.ShowDialog(this) != DialogResult.OK) return false;
                }
            }
            if (mode == "download") return await DownloadGameAsync();
            if (mode == "exe")
            {
                using (var picker = new OpenFileDialog { Title = Ui("Выберите EXE игры","Select the game EXE","选择游戏程序"), Filter = "Исполняемые файлы (*.exe)|*.exe",
                    CheckFileExists = true, Multiselect = false })
                {
                    if (Directory.Exists(_gamePath)) picker.InitialDirectory = _gamePath;
                    if (picker.ShowDialog(this) != DialogResult.OK) return false;
                    selected = picker.FileName;
                }
            }
            else
            {
                using (var picker = new FolderBrowserDialog { Description = Ui("Выберите папку с распакованной игрой. Поиск выполняется только внутри неё.","Select the extracted game folder. Only this folder will be searched.","选择已解压的游戏文件夹，仅搜索所选文件夹。"),
                    ShowNewFolderButton = false, SelectedPath = Directory.Exists(_gamePath) ? _gamePath : _baseDir })
                {
                    if (picker.ShowDialog(this) != DialogResult.OK) return false;
                    selected = picker.SelectedPath;
                }
            }
            string python = Path.Combine(_baseDir, "Server", "python", "python.exe");
            string script = Path.Combine(_baseDir, "Server", "game_discovery.py");
            if (!File.Exists(python) || !File.Exists(script))
            { DiagnosticDialogs.Show(Ui("Распакуйте обновление целиком: рядом с Reactivate.exe нужна папка Server.","Extract the whole update: Reactivate.exe needs the Server folder beside it.","请完整解压更新，Reactivate.exe 旁需要有 Server 文件夹。"), "Reactivate"); return false; }
            _selectingGame = true;
            _startGameBtn.Enabled = false;
            bool cancelled = false;
            bool completed = false;
            Process process = null;
            using (var progress = new Form { Text = Ui("Поиск игры","Finding the game","查找游戏"), ClientSize = new Size(580, 145),
                StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false, MinimizeBox = false })
            {
                progress.Controls.Add(new Label { Text = Ui("Ищу Binaries/Win32, Content/Paks и Engine…\r\n","Looking for Binaries/Win32, Content/Paks and Engine…\r\n","正在查找 Binaries/Win32、Content/Paks 和 Engine…\r\n") + selected,
                    AutoEllipsis = true, Location = new Point(20, 20), Size = new Size(540, 60) });
                var cancel = new Button { Text = Ui("Отмена","Cancel","取消"), Location = new Point(435, 95), Size = new Size(125, 32) };
                cancel.Click += (sender, args) => progress.Close();
                progress.Controls.Add(cancel);
                progress.FormClosing += (sender, args) =>
                {
                    if (!completed)
                    {
                        cancelled = true;
                        try { if (process != null && !process.HasExited) process.Kill(); } catch { }
                    }
                };
                progress.Show(this);
                try
                {
                    process = new Process { StartInfo = new ProcessStartInfo { FileName = python,
                        Arguments = QuoteArg(script) + " --json-stdin", WorkingDirectory = _baseDir,
                        UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true,
                        RedirectStandardOutput = true, RedirectStandardError = true,
                        StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 } };
                    StartChecked(process);
                    Task<string> output = process.StandardOutput.ReadToEndAsync();
                    Task<string> errors = process.StandardError.ReadToEndAsync();
                    byte[] payload = new UTF8Encoding(false).GetBytes(ToJson(new DiscoveryRequest { Path = selected }));
                    process.StandardInput.BaseStream.Write(payload, 0, payload.Length);
                    process.StandardInput.BaseStream.Flush();
                    process.StandardInput.Close();
                    await Task.Run(() => process.WaitForExit());
                    string text = await output;
                    string stderr = await errors;
                    if (cancelled || IsDisposed) return false;
                    DiscoveryResult result;
                    try { result = FromJson<DiscoveryResult>(text); }
                    catch { throw new IOException(Ui("Не удалось прочитать результат поиска. ","Could not read the discovery result. ","无法读取搜索结果。") + stderr); }
                    if (!string.IsNullOrEmpty(result.Error)) throw new IOException(result.Error);
                    if (result.Games == null || result.Games.Length == 0)
                        throw new IOException(Ui("Клиент OBT не найден. Выберите EXE из Binaries/Win32 или папку распакованной игры с Engine и Content/Paks.","OBT client not found. Select an EXE in Binaries/Win32 or the extracted game folder with Engine and Content/Paks.","未找到 OBT 客户端。请选择 Binaries/Win32 中的程序或包含 Engine 和 Content/Paks 的游戏文件夹。") +
                            (result.Truncated ? Ui(" Поиск ограничен: выберите папку ближе к игре."," Search limit reached: choose a folder closer to the game."," 搜索已达上限，请选择更接近游戏的文件夹。") : ""));
                    completed = true;
                    progress.Close();
                    GameMatch game = result.Games[0];
                    if (result.Games.Length > 1 || result.Truncated)
                    {
                        using (var choose = new Form { Text = result.Truncated ? Ui("Поиск ограничен — выберите найденный клиент","Search limit reached — select a found client","搜索已达上限，请选择已找到的客户端") : Ui("Выберите клиент OBT", "Select the OBT client", "选择 OBT 客户端"),
                            ClientSize = new Size(760, 295), StartPosition = FormStartPosition.CenterParent,
                            FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false })
                        {
                            var list = new ListBox { Location = new Point(15, 15), Size = new Size(730, 210), HorizontalScrollbar = true };
                            foreach (GameMatch item in result.Games) list.Items.Add(item.Win32);
                            list.SelectedIndex = 0;
                            var ok = new Button { Text = Ui("Выбрать","Select","选择"), DialogResult = DialogResult.OK, Location = new Point(610, 245), Size = new Size(135, 35) };
                            choose.Controls.AddRange(new Control[] { list, ok });
                            choose.AcceptButton = ok;
                            list.DoubleClick += (sender, args) => { if (list.SelectedIndex >= 0) choose.DialogResult = DialogResult.OK; };
                            if (choose.ShowDialog(this) != DialogResult.OK || list.SelectedIndex < 0) return false;
                            game = result.Games[list.SelectedIndex];
                        }
                    }
                    _gamePath = game.Win32;
                    _pathBox.Text = _gamePath;
                    SaveSettings();
                    _statusMainLabel.Text = Ui("Игра выбрана · готов к запуску","Game selected · ready to launch","已选择游戏，可以启动");
                    return true;
                }
                catch (Exception ex)
                {
                    if (!cancelled && !IsDisposed) DiagnosticDialogs.Show(ex.Message, Ui("Поиск игры","Finding the game","查找游戏"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                finally
                {
                    completed = true;
                    if (!progress.IsDisposed) progress.Close();
                    if (process != null) process.Dispose();
                    _selectingGame = false;
                    if (!IsDisposed) _startGameBtn.Enabled = true;
                }
            }
        }

        [DataContract]
        private sealed class DiscoveryRequest
        {
            [DataMember(Name = "path")] public string Path;
        }
        [DataContract]
        private sealed class GameMatch
        {
            [DataMember(Name = "win32")] public string Win32;
        }
        [DataContract]
        private sealed class DiscoveryResult
        {
            [DataMember(Name = "games")] public GameMatch[] Games;
            [DataMember(Name = "error")] public string Error;
            [DataMember(Name = "truncated")] public bool Truncated;
        }

        private Form _translationWindow;
        private Label _translationStage, _translationCount, _translationReason;
        private ProgressBar _translationBar;
        private Button _translationRetry, _translationPartial, _translationCancel;
        private bool _closingTranslation;

        private void SendTranslationCommand(string command)
        {
            try
            {
                if (_bridgeProcess == null || _bridgeProcess.HasExited) return;
                _bridgeProcess.StandardInput.WriteLine("{\"command\":\"" + command + "\"}");
                _bridgeProcess.StandardInput.Flush();
                _translationRetry.Visible = _translationPartial.Visible = false;
                _translationCancel.Enabled = command != "translation_cancel";
                _translationStage.Text = command == "translation_cancel" ? Ui("Сохраняю прогресс…", "Saving progress…", "正在保存进度…") : Ui("Продолжаю подготовку…", "Continuing preparation…", "正在继续准备…");
            }
            catch (InvalidOperationException) { }
            catch (IOException) { }
        }

        private void ShowTranslationProgress(BridgeEvent state)
        {
            if (_translationWindow == null || _translationWindow.IsDisposed)
            {
                _translationWindow = new Form { Text = Ui("Подготовка языка игры", "Preparing game language", "准备游戏语言"),
                    ClientSize = new Size(680, 300), StartPosition = FormStartPosition.CenterParent,
                    FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false,
                    AutoScaleMode = AutoScaleMode.Dpi, Font = new Font("Segoe UI", 10f),
                    BackColor = Color.FromArgb(15, 22, 32), ForeColor = Color.White };
                _translationStage = new Label { Location = new Point(24, 22), Size = new Size(632, 32), Font = new Font("Segoe UI", 13f, FontStyle.Bold) };
                _translationBar = new ProgressBar { Location = new Point(24, 72), Size = new Size(632, 14), Minimum = 0, Maximum = 100 };
                _translationCount = new Label { Location = new Point(24, 101), Size = new Size(632, 28) };
                _translationReason = new Label { Location = new Point(24, 139), Size = new Size(632, 72), ForeColor = Color.FromArgb(170, 193, 213),
                    Text = Ui("Игра откроется после подготовки. Прогресс сохраняется; повторный запуск продолжит работу.",
                        "The game opens after preparation. Progress is saved and the next launch resumes it.", "准备完成后才会启动游戏。进度会保存，下次启动时将继续。") };
                _translationRetry = AuthButton(Ui("Повторить", "Retry", "重试"), 24, 240, 150, false);
                _translationRetry.Visible = false; _translationRetry.Click += (s, e) => SendTranslationCommand("translation_retry");
                _translationPartial = AuthButton(Ui("Запустить с неполным", "Play with partial translation", "使用部分翻译启动"), 186, 240, 278, false);
                _translationPartial.Visible = false; _translationPartial.Click += (s, e) => SendTranslationCommand("translation_partial");
                _translationCancel = AuthButton(Ui("Отмена", "Cancel", "取消"), 476, 240, 180, true);
                _translationCancel.Click += (s, e) => SendTranslationCommand("translation_cancel");
                _translationWindow.FormClosing += (s, e) => { if (!_closingTranslation) { e.Cancel = true; SendTranslationCommand("translation_cancel"); } };
                _translationWindow.Controls.AddRange(new Control[] { _translationStage, _translationBar, _translationCount, _translationReason, _translationRetry, _translationPartial, _translationCancel });
                _translationWindow.Show(this);
            }
            string stage = state.Stage ?? "";
            _translationStage.Text = stage == "waiting" ? Ui("Ожидаю другую подготовку", "Waiting for another preparation", "等待其他准备任务") :
                stage == "index" ? Ui("Читаю архивы игры", "Reading game archives", "读取游戏资源包") :
                stage == "scan" ? Ui("Нахожу строки игры", "Finding game strings", "查找游戏文本") :
                stage == "pack" ? Ui("Собираю языковые ресурсы", "Building language resources", "生成语言资源") :
                stage == "apply" ? Ui("Устанавливаю перевод", "Installing translations", "安装翻译") :
                Ui("Подготавливаю перевод", "Preparing translations", "准备翻译");
            int total = Math.Max(0, state.Total), done = Math.Max(0, Math.Min(state.Done, total));
            _translationBar.Style = total > 0 ? ProgressBarStyle.Continuous : ProgressBarStyle.Marquee;
            if (total > 0) _translationBar.Value = (int)Math.Min(100, 100L * done / total);
            _translationCount.Text = total > 0 ? string.Format(Ui("{0:N0} из {1:N0}", "{0:N0} of {1:N0}", "{0:N0} / {1:N0}"), done, total) : Ui("Пожалуйста, подождите…", "Please wait…", "请稍候…");
            if (stage == "translate") _translationCount.Text += string.Format(Ui(" · Осталось строк: {0:N0}", " · Strings remaining: {0:N0}", " · 剩余文本：{0:N0}"), Math.Max(0, state.Remaining));
            if (state.Kind == "translation_blocked")
            {
                _translationStage.Text = Ui("Подготовка не завершена", "Preparation incomplete", "准备尚未完成");
                _translationCount.Text = string.Format(Ui("Готово {0:N0} из {1:N0} · Осталось {2:N0}", "Ready: {0:N0} of {1:N0} · Remaining: {2:N0}", "已完成 {0:N0} / {1:N0} · 剩余 {2:N0}"), done, total, Math.Max(0, state.Remaining));
                _translationReason.Text = state.Status == "client_daily_budget" || state.Status == "service_limit" ?
                    Ui("Достигнут лимит бесплатного перевода. Прогресс сохранён. Можно отменить и продолжить позже или явно запустить игру с неполным переводом.",
                        "The free translation limit was reached. Progress is saved. Resume later, or choose to play with partial translation.", "已达到免费翻译限额，进度已保存。可稍后继续，或选择使用部分翻译启动。") :
                    state.Status == "identity_conflicts" ? Ui("В архивах есть разные тексты с одним идентификатором. Автоматический выбор не подтверждён. Повторите проверку после обновления файлов или явно выберите неполный перевод.",
                        "Archives contain different texts with the same identifier. Automatic selection is unconfirmed. Retry after updating the files, or explicitly choose partial translation.", "资源包中存在标识相同但内容不同的文本，尚不能确认自动选择。更新文件后请重试，或明确选择部分翻译。") :
                    state.Status == "scan_errors" ? Ui("Некоторые ассеты не удалось прочитать. Полная подготовка не подтверждена. Повторите проверку или запустите с доступным переводом.",
                        "Some assets could not be read. Full preparation is unconfirmed. Retry, or play with the available translations.", "部分资源无法读取，尚不能确认准备完成。请重试或使用已有翻译启动。") :
                    Ui("Остались непереведённые строки: сервис недоступен либо текст требует проверки. Прогресс сохранён. Повторите позже или явно выберите неполный перевод.",
                        "Strings remain untranslated: the service is unavailable or the text needs review. Progress is saved. Retry later, or explicitly choose partial translation.", "仍有未翻译文本：服务不可用或文本需要检查。进度已保存，请稍后重试或选择部分翻译。");
                _translationRetry.Visible = _translationPartial.Visible = true;
                _translationBar.Style = ProgressBarStyle.Continuous;
            }
        }

        private void CloseTranslationProgress()
        {
            if (_translationWindow == null) return;
            _closingTranslation = true;
            _translationWindow.Close(); _translationWindow.Dispose(); _translationWindow = null;
            _closingTranslation = false;
        }

        private string FriendlyLauncherError(string error)
        {
            string text = error ?? "";
            if (text.IndexOf("Invalid nickname or account key", StringComparison.OrdinalIgnoreCase) >= 0)
                return Ui("Неверный логин или пароль.", "Incorrect login or password.", "登录名或密码不正确。");
            if (text.IndexOf("Login already exists", StringComparison.OrdinalIgnoreCase) >= 0 || text.Contains("Логин занят"))
                return Ui("Логин уже занят. Используйте вход в существующий аккаунт.", "That login already exists. Sign in to the existing account.", "该登录名已存在，请登录已有账户。");
            if (text.IndexOf("permanent account login", StringComparison.OrdinalIgnoreCase) >= 0)
                return Ui("Укажите логин аккаунта, полученный при регистрации.", "Use your permanent account login.", "请使用注册时的账户登录名。");
            if (text.IndexOf("Unknown existing", StringComparison.OrdinalIgnoreCase) >= 0)
                return Ui("Установленный языковой файл отличается от проверенной версии. Файл сохранён. Подробности:\r\n", "An installed language file differs from the verified version. It was preserved. Details:\r\n", "已安装的语言文件与已验证版本不同，文件已保留。详细信息：\r\n") + text;
            return Ui("Не удалось завершить подготовку или запуск. Подробности:\r\n", "Preparation or launch could not finish. Details:\r\n", "无法完成准备或启动。详细信息：\r\n") + text;
        }

        private bool _exportingDiagnostics;
        [DataContract] private sealed class DiagnosticExport
        { [DataMember(Name="file")] public string File; }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F12) { var pending = ExportDiagnosticsAsync(); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private async Task ExportDiagnosticsAsync()
        {
            if (_exportingDiagnostics) return;
            _exportingDiagnostics = true;
            LauncherDiagnostics.Log("ui_report_requested");
            try
            {
                var start = new ProcessStartInfo { FileName=Path.Combine(_baseDir,"Server","python","python.exe"),
                    Arguments=QuoteArg(Path.Combine(_baseDir,"Server","diagnostics59.py"))+" --root "+QuoteArg(_baseDir)+" --run-id "+LauncherDiagnostics.RunId+
                        (string.IsNullOrEmpty(_gamePath)?"":" --game "+QuoteArg(_gamePath)),
                    WorkingDirectory=_baseDir,UseShellExecute=false,CreateNoWindow=true,
                    RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8 };
                using(var process = new Process { StartInfo=start })
                {
                    StartChecked(process);
                    Task<string> errors=process.StandardError.ReadToEndAsync();
                    string output=await process.StandardOutput.ReadToEndAsync();
                    await Task.Run(()=>process.WaitForExit());
                    string error=await errors;
                    if(process.ExitCode!=0) throw new IOException(error);
                    var report=FromJson<DiagnosticExport>(output);
                    LauncherDiagnostics.Log("ui_report_created","file",report.File);
                    DiagnosticDialogs.Show(this,Ui("Отчёт сохранён:\r\n","Report saved:\r\n","报告已保存：\r\n")+report.File,"Reactivate");
                    Process.Start(new ProcessStartInfo { FileName="explorer.exe",Arguments="/select,"+QuoteArg(report.File),UseShellExecute=true });
                }
            }
            catch(Exception error) { Program.LogFailure(error);DiagnosticDialogs.Show(this,error.Message,"Reactivate",MessageBoxButtons.OK,MessageBoxIcon.Error); }
            finally { _exportingDiagnostics=false; }
        }

        private async void LaunchGameClient()
        {
            LauncherDiagnostics.Log("ui_launch_attempt", "busy", (_selectingGame || _launching || _bridgeProcess != null).ToString());
            if (_selectingGame || _launching || (_bridgeProcess != null)) return;
            if (_currentRegion != "pts")
            {
                string nodeMessage = _currentLang == "ru" ? "Локальный сервер запускается только для Test Node. Выберите Test Node в списке серверов. Другие узлы пока не подключены." :
                    _currentLang == "zh" ? "本地服务器仅在选择 Test Node 时启动。其他节点尚未连接。" : "The local server starts only for Test Node. Select Test Node in the server list. Other nodes are not connected yet.";
                DiagnosticDialogs.Show(nodeMessage, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (string.IsNullOrEmpty(_gamePath) || !Directory.Exists(_gamePath))
                if (!await SelectGameAsync(null)) return;
            if (!PromptAccountDialog()) return;
            PlayUiSound();
            string python = Path.Combine(_baseDir, "Server", "python", "python.exe");
            string entry = Path.Combine(_baseDir, "Server", "launcher_entry.py");
            if (!File.Exists(python) || !File.Exists(entry))
            {
                DiagnosticDialogs.Show(Ui("Нет папки Server с локальным сервером. Распакуйте обновление Reactivate целиком.","The Server folder is missing. Extract the whole Reactivate update.","缺少 Server 文件夹，请完整解压 Reactivate 更新。"), "Reactivate");
                return;
            }
            LauncherDiagnostics.BeginLaunch();
            LauncherDiagnostics.RememberSecret(_accountKey);
            _startGameBtn.Enabled = false;
            _launching = true;
            _regionCombo.Enabled = false; _accountBtn.Enabled = false;
            foreach (var button in _langBtns) button.Enabled = false;
            _statusMainLabel.Text = Ui("Подготовка локального сервера…","Preparing the local server…","正在准备本地服务器…");
            string launchError = null;
            try
            {
                var start = new ProcessStartInfo
                {
                    FileName = python,
                    Arguments = QuoteArg(entry) + " --json-stdin",
                    WorkingDirectory = _baseDir,
                    UseShellExecute = false, CreateNoWindow = true,
                    RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8,
                    StandardErrorEncoding = Encoding.UTF8
                };
                _bridgeProcess = new Process { StartInfo = start };
                StartChecked(_bridgeProcess);
                Task<string> errors = _bridgeProcess.StandardError.ReadToEndAsync();
                string ip; int port;
                _serverIps.TryGetValue(_currentRegion, out ip);
                _serverPorts.TryGetValue(_currentRegion, out port);
                var request = new LaunchRequest { Protocol = 2, LauncherRoot = _baseDir, GamePath = _gamePath, Nickname = _accountName,
                    DiagnosticRunId = LauncherDiagnostics.RunId, DiagnosticLaunchId = LauncherDiagnostics.LaunchId, AccountKey = _accountKey, AuthAction = _authAction, Language = _currentLang, TranslationMode = null, CollectDiagnostics = _collectDiagnostics, ServerCode = _currentRegion, ServerIp = ip ?? "", ServerPort = port };
                byte[] payload = new UTF8Encoding(false).GetBytes(ToJson(request) + "\n");
                _bridgeProcess.StandardInput.BaseStream.Write(payload, 0, payload.Length);
                _bridgeProcess.StandardInput.BaseStream.Flush();
                Array.Clear(payload, 0, payload.Length);
                request.AccountKey = null; _accountKey = null;
                // Keep the control pipe open for preparation cancellation/retry/partial acceptance.
                string line;
                while ((line = await _bridgeProcess.StandardOutput.ReadLineAsync()) != null)
                {
                    BridgeEvent state;
                    try { state = FromJson<BridgeEvent>(line); }
                    catch { LauncherDiagnostics.Log("ui_bridge_parse_error"); continue; }
                    LauncherDiagnostics.RememberSecret(state.Password);
                    LauncherDiagnostics.Bridge(state.Kind, state.Error, state.Phase);
                    if (state.Kind == "diagnostic_report" && !string.IsNullOrEmpty(state.ReportArchive)) _statusMainLabel.Tag = state.ReportArchive;
                    if (IsDisposed || Disposing) continue;
                    if (state.Kind == "registration_created")
                    {
                        bool saved = ConfirmGeneratedPassword(state.Login, state.Password);
                        state.Password = null;
                        _bridgeProcess.StandardInput.WriteLine(saved ? "{\"command\":\"password_saved\"}" : "{\"command\":\"cancel\"}");
                        _bridgeProcess.StandardInput.Flush();
                        _authAction = "login";
                    }
                    if (state.Kind == "translation_progress" || state.Kind == "translation_blocked") ShowTranslationProgress(state);
                    if (state.Kind == "translation_complete" || state.Kind == "launch_cancelled") CloseTranslationProgress();
                    if (state.Kind == "client_preparing") _statusMainLabel.Text = Ui("Подготовка клиента…","Preparing the client…","正在准备客户端…");
                    if (state.Kind == "server_ready") _statusMainLabel.Text = Ui("Локальный сервер готов","Local server ready","本地服务器已就绪");
                    if (state.Kind == "game_started")
                    {
                        CloseTranslationProgress();
                        _bridgeProcess.StandardInput.Close();
                        _gameRunning = true; _statusMainLabel.Text = Ui("Игра запущена","Game started","游戏已启动");
                        _restoreAfterGame = WindowState != FormWindowState.Minimized;
                        WindowState = FormWindowState.Minimized;
                    }
                    if (state.Kind == "launch_error") launchError = FriendlyLauncherError(state.Error);
                    if (state.Kind == "game_exited")
                    {
                        _gameRunning = false;
                        launchError = state.Error;
                        if (!string.IsNullOrEmpty(launchError) && !string.IsNullOrEmpty(state.ReportArchive))
                            launchError += Ui("\r\n\r\nОтчёт: ","\r\n\r\nReport: ","\r\n\r\n报告：") + state.ReportArchive;
                        _statusMainLabel.Text = string.IsNullOrEmpty(launchError) ? Ui("Игра завершена","Game closed","游戏已退出") : Ui("Ошибка клиента", "Client error", "客户端错误");
                        if (!string.IsNullOrEmpty(state.ReportArchive)) _statusMainLabel.Tag = state.ReportArchive;
                    }
                }
                await Task.Run(() => _bridgeProcess.WaitForExit());
                string stderr = await errors;
                if (_bridgeProcess.ExitCode != 0 && string.IsNullOrEmpty(launchError))
                    launchError = string.IsNullOrWhiteSpace(stderr) ? Ui("Не удалось запустить сессию. Распакуйте обновление целиком и повторно выберите игру.","Session could not start. Extract the whole update and select the game again.","无法启动会话。请完整解压更新并重新选择游戏。") :
                        (stderr.Length > 2000 ? stderr.Substring(stderr.Length - 2000) : stderr);
                if (!string.IsNullOrEmpty(launchError) && !IsDisposed)
                    DiagnosticDialogs.Show(launchError, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                string errorLog = Program.LogFailure(ex);
                if (!IsDisposed) DiagnosticDialogs.Show(Ui("Ошибка запуска локальной сессии: ","Local session launch failed: ","本地会话启动失败：") + ex.Message,
                    "Reactivate · " + errorLog, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                LauncherDiagnostics.EndLaunch();
                CloseTranslationProgress();
                if (_bridgeProcess != null) { _bridgeProcess.Dispose(); _bridgeProcess = null; }
                _accountKey = null;
                _launching = false;
                _gameRunning = false;
                if (!IsDisposed)
                {
                    _startGameBtn.Enabled = true; _statusMainLabel.Text = Ui("Готов к запуску","Ready to launch","可以启动");
                    _regionCombo.Enabled = true; _accountBtn.Enabled = true;
                    foreach (var button in _langBtns) button.Enabled = true;
                    if (_restoreAfterGame && WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                    _restoreAfterGame = false;
                }
            }
        }

        private static void StartChecked(Process process)
        {
            try { process.Start(); }
            catch (System.ComponentModel.Win32Exception error)
            {
                throw new IOException(Program.Localize("Не удалось запустить:\r\n", "Cannot execute:\r\n", "无法执行：\r\n") + process.StartInfo.FileName +
                    "\r\nWindows: " + error.NativeErrorCode + "\r\n" + error.Message +
                    Program.Localize("\r\nПроверьте журнал защиты Windows.", "\r\nCheck Windows protection history.", "\r\n请检查 Windows 保护历史记录。"), error);
            }
        }

        private static string ToJson<T>(T value)
        {
            using (var stream = new MemoryStream())
            {
                new DataContractJsonSerializer(typeof(T)).WriteObject(stream, value);
                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        private static T FromJson<T>(string value)
        {
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(value)))
                return (T)new DataContractJsonSerializer(typeof(T)).ReadObject(stream);
        }

        private void OpenLocalAdmin()
        {
            if (string.IsNullOrEmpty(_gamePath)) { DiagnosticDialogs.Show(Ui("Сначала выберите и запустите игру.","Select and launch the game first.","请先选择并启动游戏。"), "Reactivate"); return; }
            string data = Path.Combine(_gamePath, "OBT_SERVER_DATA");
            if (!File.Exists(Path.Combine(data, "server.ready.json")))
            { DiagnosticDialogs.Show(Ui("Сначала запустите игру или локальный сервер.","Start the game or local server first.","请先启动游戏或本地服务器。"), "Reactivate"); return; }
            string python = Path.Combine(_baseDir, "Server", "python", "python.exe");
            string script = Path.Combine(_baseDir, "Server", "open_admin.py");
            try { Process.Start(new ProcessStartInfo { FileName = python, WorkingDirectory = _baseDir,
                Arguments = QuoteArg(script) + " --data " + QuoteArg(data),
                UseShellExecute = false, CreateNoWindow = true }); }
            catch (Exception ex) { DiagnosticDialogs.Show(Ui("Сначала запустите локальный сервер: ","Start the local server first: ","请先启动本地服务器：") + ex.Message, "Reactivate"); }
        }

        [DataContract]
        private sealed class LaunchRequest
        {
            [DataMember(Name = "protocol")] public int Protocol;
            [DataMember(Name = "launcher_root")] public string LauncherRoot;
            [DataMember(Name = "game_path")] public string GamePath;
            [DataMember(Name = "language")] public string Language;
            [DataMember(Name = "translation_mode")] public string TranslationMode;
            [DataMember(Name = "collect_diagnostics")] public bool CollectDiagnostics;
            [DataMember(Name = "diagnostic_run_id")] public string DiagnosticRunId;
            [DataMember(Name = "diagnostic_launch_id")] public string DiagnosticLaunchId;
            [DataMember(Name = "nickname")] public string Nickname;
            [DataMember(Name = "account_key", EmitDefaultValue = false)] public string AccountKey;
            [DataMember(Name = "auth_action")] public string AuthAction;
            [DataMember(Name = "server_code")] public string ServerCode;
            [DataMember(Name = "server_ip")] public string ServerIp;
            [DataMember(Name = "server_port")] public int ServerPort;
        }

        [DataContract]
        private sealed class BridgeEvent
        {
            [DataMember(Name = "event")] public string Kind;
            [DataMember(Name = "stage")] public string Stage;
            [DataMember(Name = "phase")] public string Phase;
            [DataMember(Name = "status")] public string Status;
            [DataMember(Name = "done")] public int Done;
            [DataMember(Name = "total")] public int Total;
            [DataMember(Name = "remaining")] public int Remaining;
            [DataMember(Name = "error")] public string Error;
            [DataMember(Name = "report_archive")] public string ReportArchive;
            [DataMember(Name = "login")] public string Login;
            [DataMember(Name = "password")] public string Password;
        }

        private string ServerFile
        {
            get
            {
                string local = Path.Combine(_baseDir, "Servers.ini");
                string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "Servers.ini");
                if (File.Exists(fallback) && (!File.Exists(local) || File.GetLastWriteTimeUtc(fallback) > File.GetLastWriteTimeUtc(local))) return fallback;
                if (File.Exists(local)) return local;
                return File.Exists(fallback) ? fallback : local;
            }
        }

        private void UpdateServerInfoLabel()
        {
            if (_pingLabel == null) return;
            string ip;
            if (_serverIps.TryGetValue(_currentRegion, out ip) && !string.IsNullOrWhiteSpace(ip))
            {
                _pingLabel.Text = "● " + ip;
            }
            else _pingLabel.Text = _currentLang == "en" ? "● Local OBT" :
                (_currentLang == "zh" ? "● 本地 OBT" : "● Локальный OBT");
        }

        private void LoadServerConfig()
        {
            foreach (string code in _serverCodes) { _serverIps[code] = ""; _serverPorts[code] = 0; }
            _serverIniPath = ServerFile;
            // Create at first run; no made-up IPs. On protected media fall back to LocalAppData.
            try
            {
                if (!File.Exists(_serverIniPath))
                {
                    try { WriteDefaultServerConfig(_serverIniPath); }
                    catch (UnauthorizedAccessException)
                    {
                        _serverIniPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "Reactivate", "Servers.ini");
                        if (!File.Exists(_serverIniPath)) WriteDefaultServerConfig(_serverIniPath);
                    }
                }
                bool inServers = false;
                foreach (string line in File.ReadAllLines(_serverIniPath))
                {
                    string trimmed = line.Trim();
                    if (trimmed.StartsWith("[") && trimmed.EndsWith("]"))
                    {
                        inServers = trimmed.Equals("[servers]", StringComparison.OrdinalIgnoreCase);
                        continue;
                    }
                    if (!inServers || trimmed.StartsWith(";") || trimmed.StartsWith("#")) continue;
                    int equal = trimmed.IndexOf('=');
                    if (equal < 1) continue;
                    string key = trimmed.Substring(0, equal).Trim().ToLowerInvariant();
                    string value = trimmed.Substring(equal + 1).Trim();
                    foreach (string code in _serverCodes)
                    {
                        if (key == code + "_ip")
                        {
                            IPAddress parsed;
                            if (value.Length == 0 || IPAddress.TryParse(value, out parsed)) _serverIps[code] = value;
                        }
                        else if (key == code + "_port")
                        {
                            int port;
                            if (int.TryParse(value, out port) && port >= 0 && port <= 65535)
                                _serverPorts[code] = port;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Do not break the launcher on read-only drives / invalid user INI.
                Debug.WriteLine("Cannot read Servers.ini: " + ex.Message);
            }
        }

        private void WriteDefaultServerConfig(string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var lines = new List<string>();
            lines.Add("; TFOL_1.0.0.59 - Server endpoints. Add real IP addresses and ports.");
            lines.Add("; Empty IP and port=0 mean unconfigured; no addresses are assumed.");
            lines.Add("[servers]");
            foreach (string code in _serverCodes)
            {
                lines.Add(code + "_ip=");
                lines.Add(code + "_port=0");
            }
            WriteManagedLines(path, lines);
        }

        private bool SaveServerConfig(bool showErrors)
        {
            var newIps = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var newPorts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string code in _serverCodes)
            {
                string ip = _serverIpEdits.ContainsKey(code) ? _serverIpEdits[code].Text.Trim() : _serverIps[code];
                int port = _serverPortEdits.ContainsKey(code) ? (int)_serverPortEdits[code].Value : _serverPorts[code];
                IPAddress parsed;
                if ((ip.Length > 0 && !IPAddress.TryParse(ip, out parsed)) || (ip.Length > 0 && port == 0))
                {
                    if (showErrors) DiagnosticDialogs.Show(string.Format(Ui("Для {0} введите IP и порт (1–65535), либо оставьте IP пустым.", "Enter an IP and port (1–65535) for {0}, or leave the IP empty.", "请为 {0} 输入 IP 和端口（1–65535），或将 IP 留空。"), code),
                        "Servers.ini", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                newIps[code] = ip;
                newPorts[code] = ip.Length == 0 ? 0 : port;
                if (ip.Length == 0 && _serverPortEdits.ContainsKey(code)) _serverPortEdits[code].Value = 0;
            }
            try
            {
                // Update only our section. Preserve comments, unrelated keys and sections.
                List<string> lines = File.Exists(_serverIniPath) ?
                    new List<string>(File.ReadAllLines(_serverIniPath)) : new List<string>();
                int section = -1, end = lines.Count;
                for (int i = 0; i < lines.Count; i++)
                {
                    string t = lines[i].Trim();
                    if (t.Equals("[servers]", StringComparison.OrdinalIgnoreCase)) section = i;
                    else if (section >= 0 && t.StartsWith("[") && t.EndsWith("]")) { end = i; break; }
                }
                if (section < 0) { if (lines.Count > 0) lines.Add(""); section = lines.Count; lines.Add("[servers]"); end = lines.Count; }
                var updates = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string code in _serverCodes)
                {
                    updates[code + "_ip"] = newIps[code];
                    updates[code + "_port"] = newPorts[code].ToString();
                }
                for (int i = section + 1; i < end; i++)
                {
                    int equal = lines[i].IndexOf('=');
                    if (equal < 0) continue;
                    string key = lines[i].Substring(0, equal).Trim();
                    if (updates.ContainsKey(key)) { lines[i] = key + "=" + updates[key]; updates.Remove(key); }
                }
                foreach (KeyValuePair<string, string> pair in updates) lines.Insert(end++, pair.Key + "=" + pair.Value);
                Directory.CreateDirectory(Path.GetDirectoryName(_serverIniPath));
                WriteManagedLines(_serverIniPath, lines);
                foreach (string code in _serverCodes) { _serverIps[code] = newIps[code]; _serverPorts[code] = newPorts[code]; }
                UpdateServerInfoLabel();
                return true;
            }
            catch (UnauthorizedAccessException)
            {
                string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "Servers.ini");
                if (string.Equals(_serverIniPath, fallback, StringComparison.OrdinalIgnoreCase))
                {
                    if (showErrors) DiagnosticDialogs.Show(Ui("Не хватает прав на сохранение Servers.ini.","Permission denied while saving Servers.ini.","没有权限保存 Servers.ini。"),
                        "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                _serverIniPath = fallback;
                return SaveServerConfig(showErrors);
            }
            catch (Exception ex)
            {
                if (showErrors) DiagnosticDialogs.Show(Ui("Не удалось сохранить Servers.ini: ","Could not save Servers.ini: ","无法保存 Servers.ini：") + ex.Message,
                    "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private string SettingsFile
        {
            get
            {
                string local = Path.Combine(_baseDir, "LauncherSettings.ini");
                string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "LauncherSettings.ini");
                if (!File.Exists(local)) return File.Exists(fallback) ? fallback : local;
                if (File.Exists(fallback) && File.GetLastWriteTimeUtc(fallback) > File.GetLastWriteTimeUtc(local))
                    return fallback;
                return local;
            }
        }

        private void LoadSettings()
        {
            try
            {
                string file = SettingsFile;
                if (File.Exists(file))
                {
                    bool currentDiagnostics = File.ReadAllLines(file).Contains("diagnostics_schema=59");
                    foreach (string row in File.ReadAllLines(file))
                    {
                        int index = row.IndexOf('=');
                        if (index < 1) continue;
                        string key = row.Substring(0, index).Trim();
                        string val = row.Substring(index + 1).Trim();
                        switch (key.ToLowerInvariant())
                        {
                            case "blur": _useBlurBg = val == "1"; break;
                            case "sound": _soundEnabled = val != "0"; break;
                            case "diagnostics": if (currentDiagnostics) _collectDiagnostics = val == "1"; break;
                            case "lang": if (_i18n.ContainsKey(val)) _currentLang = val; break;
                            case "region": if (new[] { "eu1", "eu2", "asia1", "pts" }.Contains(val)) _currentRegion = val; break;
                            case "user": _accountName = val; break;
                            case "gamepath": _gamePath = val; break;
                            case "resolution": _gameResolution = val; break;
                            case "windowmode": _gameWindowMode = val; break;
                            case "graphicsapi": _gameGraphicsApi = val; break;
                        }
                    }
                }
            }
            catch { /* Invalid or read-only setting files must not block the launcher. */ }
        }

        private static string FlatValue(string value)
        {
            return (value ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
        }

        // Only launcher-owned INIs and the explicitly selected TCLS config use this.
        // Do not change ACLs or recursively clear attributes on a game directory.
        private static void WriteManagedLines(string path, IEnumerable<string> lines)
        {
            path = Path.GetFullPath(path);
            string temporary = Path.Combine(Path.GetDirectoryName(path), ".reactivate-" + Guid.NewGuid().ToString("N") + ".tmp");
            FileAttributes oldAttributes = 0;
            bool adjusted = false;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                if (File.Exists(path))
                {
                    oldAttributes = File.GetAttributes(path);
                    if ((oldAttributes & FileAttributes.ReparsePoint) != 0)
                        throw new IOException(Program.Localize("Символическая ссылка: ", "Symbolic link: ", "符号链接：") + path);
                }
                File.WriteAllLines(temporary, lines, new UTF8Encoding(false));
                if (File.Exists(path))
                {
                    if ((oldAttributes & FileAttributes.ReadOnly) != 0)
                    {
                        File.SetAttributes(path, oldAttributes & ~FileAttributes.ReadOnly);
                        adjusted = true;
                    }
                    File.Replace(temporary, path, null);
                }
                else File.Move(temporary, path);
            }
            catch (Exception error)
            {
                if (adjusted && File.Exists(path))
                    try { File.SetAttributes(path, oldAttributes); } catch { }
                int code = error.HResult & 0xFFFF;
                string hint = code == 32 || code == 33 ?
                    Program.Localize("Закройте игру и другие лаунчеры.", "Close the game and other launchers.", "请关闭游戏和其他启动器。") :
                    Program.Localize("Проверьте доступ к папке и журнал защиты Windows.", "Use a writable folder and check Windows protection history.", "请检查文件夹写入权限和 Windows 保护历史记录。");
                string message = Program.Localize("Файл: ", "File: ", "文件：") + path + "\r\nWindows: " + code + "\r\n" + hint;
                if (error is UnauthorizedAccessException) throw new UnauthorizedAccessException(message, error);
                throw new IOException(message, error);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); } catch { }
            }
        }

        private void SaveSettings()
        {
            if (!_isReady) return;
            if (_resCombo != null && _resCombo.SelectedItem != null) _gameResolution = _resCombo.SelectedItem.ToString();
            if (_winModeCombo != null && _winModeCombo.SelectedItem != null) _gameWindowMode = _winModeCombo.SelectedItem.ToString();
            if (_dxCombo != null && _dxCombo.SelectedItem != null) _gameGraphicsApi = _dxCombo.SelectedItem.ToString().Split(' ')[0];
            string[] rows = {
                "blur=" + (_useBlurBg ? "1" : "0"),
                "diagnostics_schema=59", "sound=" + (_soundEnabled ? "1" : "0"), "diagnostics=" + (_collectDiagnostics ? "1" : "0"), "lang=" + _currentLang,
                "region=" + _currentRegion, "user=" + FlatValue(_accountName),
                "gamepath=" + FlatValue(_gamePath),
                "resolution=" + FlatValue(_gameResolution),
                "windowmode=" + FlatValue(_gameWindowMode), "graphicsapi=" + FlatValue(_gameGraphicsApi)
            };
            try
            {
                string path = SettingsFile;
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    WriteManagedLines(path, rows);
                }
                catch (UnauthorizedAccessException)
                {
                    path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "Reactivate", "LauncherSettings.ini");
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    WriteManagedLines(path, rows);
                }
            }
            catch { /* Launcher should keep working when portable media is read-only. */ }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_launching && !_gameRunning && _translationWindow != null) SendTranslationCommand("translation_cancel");
            if (_gameRunning && DiagnosticDialogs.Show(Ui("Игра продолжит работать с локальным сервером. Закрыть только лаунчер?","The game and local server will keep running. Close the launcher?","游戏和本地服务器将继续运行。要关闭启动器吗？"),
                "Reactivate", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            { e.Cancel = true; return; }
            SaveServerConfig(false);
            SaveSettings();
            base.OnFormClosing(e);
        }

        private string GetGameDirectory(bool showError)
        {
            if (!string.IsNullOrEmpty(_gamePath) && Directory.Exists(_gamePath))
            {
                var folder = new DirectoryInfo(_gamePath);
                if (folder.Name.Equals("Win32", StringComparison.OrdinalIgnoreCase) && folder.Parent != null &&
                    folder.Parent.Parent != null) return folder.Parent.Parent.FullName;
            }
            if (showError) DiagnosticDialogs.Show(Ui("Сначала выберите игру в настройках лаунчера или нажмите «Играть».","Select the game in launcher settings or click Play.","请在启动器设置中选择游戏，或点击开始游戏。"),
                "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return null;
        }

        private static string QuoteArg(string arg)
        {
            // Windows CreateProcess quoting rules, including spaces and embedded quotes.
            var builder = new StringBuilder("\"");
            int slashes = 0;
            foreach (char c in arg ?? "")
            {
                if (c == '\\') { slashes++; continue; }
                if (c == '"')
                {
                    builder.Append('\\', slashes * 2 + 1);
                    builder.Append('"');
                    slashes = 0;
                    continue;
                }
                builder.Append('\\', slashes);
                slashes = 0;
                builder.Append(c);
            }
            builder.Append('\\', slashes * 2);
            builder.Append('"');
            return builder.ToString();
        }
    }

    // Native GDI+ vector geometry, not font glyphs and not pre-rendered AI artwork.
    // All icon strokes and rounded edges are recalculated at display resolution.
    internal sealed class BrandBadge : Control
    {
        public BrandBadge()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Font = new Font("Segoe UI", 12f, FontStyle.Bold);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            e.Graphics.Clear(Parent == null ? Color.FromArgb(14,24,41) : Parent.BackColor);
            using (GraphicsPath shape = ReactivateMainWindow.RoundRect(new Rectangle(1, 1,
                Math.Max(2, Width - 3), Math.Max(2, Height - 3)), Math.Max(3, Width / 6)))
            using (Brush fill = new SolidBrush(Color.FromArgb(58, 210, 236)))
                e.Graphics.FillPath(fill, shape);
            TextRenderer.DrawText(e.Graphics, "TF", Font, ClientRectangle,
                Color.FromArgb(9, 26, 43), TextFormatFlags.HorizontalCenter |
                TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }

    internal sealed class VectorButton : Button
    {
        private string _iconKind;
        private bool _hover;
        public float UiScale { get; set; }
        public bool CenterText { get; set; }
        public string IconKind { get { return _iconKind; } set { _iconKind = value ?? ""; Invalidate(); } }
        public VectorButton(string icon)
        {
            _iconKind = icon; UiScale = 1f; CenterText = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat;
            Cursor = Cursors.Hand;
            TabStop = true;
        }
        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            Color background = Parent == null ? Color.FromArgb(11,23,39) : Parent.BackColor;
            g.Clear(background);
            Rectangle r = new Rectangle(1, 1, Math.Max(2, Width - 3), Math.Max(2, Height - 3));
            float scale = Math.Max(.70f, UiScale);
            using (GraphicsPath shape = ReactivateMainWindow.RoundRect(r, Math.Max(4, (int)(9f * scale))))
            using (Brush fill = new SolidBrush(_hover && Enabled ? ControlPaint.Light(BackColor, .12f) : BackColor))
            using (Pen border = new Pen(_hover && Enabled ? Color.FromArgb(170, 66, 206, 240) :
                Color.FromArgb(48, 107, 162, 194), Math.Max(.9f, scale)))
            {
                g.FillPath(fill, shape);
                g.DrawPath(border, shape);
            }
            if (Focused)
            {
                using (GraphicsPath focus = ReactivateMainWindow.RoundRect(
                    new Rectangle(3, 3, Math.Max(2, Width - 7), Math.Max(2, Height - 7)),
                    Math.Max(3, (int)(7f * scale))))
                using (Pen focusPen = new Pen(Color.FromArgb(155, 124, 220, 251), 1f))
                    g.DrawPath(focusPen, focus);
            }
            bool hasIcon = !string.IsNullOrEmpty(_iconKind);
            bool iconOnly = _iconKind == "close" || _iconKind == "min";
            float sz = Math.Min(22f * scale, Height * .54f);
            float x = iconOnly ? (Width - sz) * .5f : 14f * scale;
            float y = (Height - sz) * .5f;
            Color color = Enabled ? ForeColor : Color.FromArgb(120, ForeColor);
            if (hasIcon) DrawVectorIcon(g, _iconKind, new RectangleF(x, y, sz, sz), color);
            if (!iconOnly)
            {
                int textX = hasIcon ? (int)(x + sz + 12 * scale) : (int)(15 * scale);
                Rectangle textR = CenterText ? new Rectangle(hasIcon ? textX : 0, 0,
                    Math.Max(0, Width - (hasIcon ? textX : 0) - (int)(8 * scale)), Height) :
                    new Rectangle(textX, 0, Math.Max(0, Width - textX - (int)(8 * scale)), Height);
                TextRenderer.DrawText(g, Text, Font, textR, color,
                    TextFormatFlags.VerticalCenter | (CenterText ? TextFormatFlags.HorizontalCenter : TextFormatFlags.Left) |
                    TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine |
                    TextFormatFlags.NoPadding);
            }
        }
        private static void DrawVectorIcon(Graphics g, string type, RectangleF r, Color color)
        {
            GraphicsState state = g.Save();
            g.TranslateTransform(r.X, r.Y);
            g.ScaleTransform(r.Width / 24f, r.Height / 24f);
            using (Pen p = new Pen(color, 1.9f))
            {
                p.StartCap = LineCap.Round; p.EndCap = LineCap.Round;
                p.LineJoin = LineJoin.Round;
                if (type == "home")
                {
                    g.DrawLines(p, new[] {new PointF(3,11),new PointF(12,3.5f),new PointF(21,11)});
                    g.DrawLines(p, new[] {new PointF(5.5f,10.6f),new PointF(5.5f,21),new PointF(18.5f,21),new PointF(18.5f,10.6f)});
                    g.DrawLines(p, new[] {new PointF(10,21),new PointF(10,14.2f),new PointF(14,14.2f),new PointF(14,21)});
                }
                else if (type == "game" || type == "settings")
                {
                    if (type == "game")
                    {
                        g.DrawEllipse(p, 6, 6, 12, 12);
                        for (int i = 0; i < 8; ++i)
                        {
                            double a = i * Math.PI / 4;
                            g.DrawLine(p, 12f + 7.8f*(float)Math.Cos(a), 12f + 7.8f*(float)Math.Sin(a),
                                12f + 10.5f*(float)Math.Cos(a), 12f + 10.5f*(float)Math.Sin(a));
                        }
                        g.DrawEllipse(p, 10, 10, 4, 4);
                    }
                    else
                    {
                        g.DrawLine(p, 3, 5, 21, 5); g.DrawLine(p, 3, 12, 21, 12);
                        g.DrawLine(p, 3, 19, 21, 19);
                        using (Brush b = new SolidBrush(Color.FromArgb(21,42,62)))
                        {
                            g.FillEllipse(b, 7, 2, 6, 6); g.FillEllipse(b, 14, 9, 6, 6);
                            g.FillEllipse(b, 5, 16, 6, 6);
                        }
                        g.DrawEllipse(p, 7, 2, 6, 6); g.DrawEllipse(p, 14, 9, 6, 6);
                        g.DrawEllipse(p, 5, 16, 6, 6);
                    }
                }
                else if (type == "account")
                {
                    g.DrawEllipse(p, 8, 3, 8, 8);
                    g.DrawArc(p, 4.5f, 11.5f, 15, 12, 195, 150);
                }
                else if (type == "choose")
                {
                    g.DrawLines(p, new[] {new PointF(3,8),new PointF(3,19),new PointF(21,19),new PointF(21,8)});
                    g.DrawLines(p, new[] {new PointF(3,8),new PointF(8,8),new PointF(10,5),new PointF(21,5)});
                }
                else if (type == "play")
                {
                    using (Brush b = new SolidBrush(color))
                        g.FillPolygon(b, new[] {new PointF(8,4),new PointF(19,12),new PointF(8,20)});
                }
                else if (type == "close")
                {
                    g.DrawLine(p, 5, 5, 19, 19); g.DrawLine(p, 19, 5, 5, 19);
                }
                else if (type == "min") g.DrawLine(p, 5, 13, 19, 13);
            }
            g.Restore(state);
        }
    }

    // Opaque parent panels are safe in WinForms. Their background is either
    // a solid color or a correctly cropped portion of the single SWF backdrop.
    // The only shaped control in this process is the Form itself.
    internal sealed class ThemePanel : Panel
    {
        private readonly ReactivateMainWindow _window;
        private readonly Color _tint;
        private readonly bool _solid;
        private readonly int _radius;

        public ThemePanel(ReactivateMainWindow window, Color tint, bool solid, int radius)
        {
            _window = window;
            _tint = tint;
            _solid = solid;
            _radius = radius;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            SetStyle(ControlStyles.SupportsTransparentBackColor, false);
            BackColor = tint.A == 0 ? Color.FromArgb(14, 19, 29) : Color.FromArgb(tint.R, tint.G, tint.B);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            _window.DrawSurface(e.Graphics, this, _tint, _solid, _radius);
        }
    }
}

// Appended to ReactivateStandalone.cs so the existing single-source compiler works.
namespace Reactivate
{
    internal sealed class LauncherDiagnostics : IMessageFilter
    {
        [DataContract] private sealed class Entry
        {
            [DataMember(Name="utc")] public string Utc;
            [DataMember(Name="run_id")] public string Run;
            [DataMember(Name="launch_id")] public string Launch;
            [DataMember(Name="source")] public string Source="ui";
            [DataMember(Name="event")] public string Event;
            [DataMember(Name="sequence")] public long Sequence;
            [DataMember(Name="fields")] public Dictionary<string,string> Fields;
        }
        internal static readonly string RunId=Guid.NewGuid().ToString("N");
        internal static string LaunchId="";
        internal static string Folder;
        internal static string Screen="startup";
        internal static string LastError;
        private static string Phase="idle", LastAction="";
        private static long LastUi, LastBridge, Sequence, Dropped;
        private static readonly object Gate=new object();
        private static readonly List<string> Secrets=new List<string>();
        private static readonly System.Collections.Concurrent.BlockingCollection<Entry> Queue=
            new System.Collections.Concurrent.BlockingCollection<Entry>(4096);
        private static System.Threading.Thread Writer, Watcher;
        private static volatile bool Stopping;
        private static System.Windows.Forms.Timer UiTimer;
        private static readonly HashSet<Control> Hooked=new HashSet<Control>();
        private static readonly Stopwatch Clock=Stopwatch.StartNew();
        private static long Millis { get { return Clock.ElapsedMilliseconds; } }

        internal static void Start()
        {
            try
            {
                Folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Reactivate","Diagnostics",RunId);
                Directory.CreateDirectory(Folder);
                LastUi=LastBridge=Millis;
                Writer=new System.Threading.Thread(WriteLoop) { IsBackground=true, Name="TFOL UI journal" }; Writer.Start();
                Watcher=new System.Threading.Thread(WatchLoop) { IsBackground=true, Name="TFOL UI watchdog" }; Watcher.Start();
                Application.AddMessageFilter(new LauncherDiagnostics());
                UiTimer=new System.Windows.Forms.Timer { Interval=250 };
                UiTimer.Tick+=(s,e)=> {
                    System.Threading.Interlocked.Exchange(ref LastUi,Millis);
                    foreach (Form form in Application.OpenForms) Hook(form);
                };
                UiTimer.Start();
                Application.ApplicationExit+=(s,e)=>Stop();
                Log("ui_session_started","os",Environment.OSVersion.ToString(),"clr",Environment.Version.ToString(),"process_bits",IntPtr.Size.ToString());
            }
            catch(Exception error) { LastError=error.GetType().Name+": "+error.Message; }
        }
        internal static void RememberSecret(string secret)
        { if(!string.IsNullOrEmpty(secret)) lock(Gate) { if(!Secrets.Contains(secret)) Secrets.Add(secret); } }
        internal static string Scrub(string text)
        {
            if(text==null) return "";
            lock(Gate) foreach(string secret in Secrets) text=text.Replace(secret,"[REDACTED]");
            text=System.Text.RegularExpressions.Regex.Replace(text,@"(?i)(Bearer\s+)[A-Za-z0-9._~-]+","$1[REDACTED]");
            return text.Length>12000 ? text.Substring(0,12000) : text;
        }
        internal static void Log(string kind,params string[] pairs)
        {
            if(Writer==null || Stopping) return;
            var fields=new Dictionary<string,string>();
            for(int i=0;i+1<pairs.Length;i+=2) fields[pairs[i]]=Scrub(pairs[i+1]);
            fields["screen"]=Screen;
            var entry=new Entry { Utc=DateTime.UtcNow.ToString("o"),Run=RunId,Launch=LaunchId,Event=kind,
                Sequence=System.Threading.Interlocked.Increment(ref Sequence),Fields=fields };
            try { if(!Queue.TryAdd(entry)) System.Threading.Interlocked.Increment(ref Dropped); }
            catch(InvalidOperationException) { /* Session writer is closing. */ }
        }
        private static void WriteLoop()
        {
            foreach(Entry item in Queue.GetConsumingEnumerable())
            {
                try
                {
                    string path=Path.Combine(Folder,"ui.jsonl");
                    if(File.Exists(path) && new FileInfo(path).Length>=4*1024*1024)
                    {
                        if(File.Exists(path+".3")) File.Delete(path+".3");
                        for(int i=2;i>=1;--i) if(File.Exists(path+"."+i)) File.Move(path+"."+i,path+"."+(i+1));
                        File.Move(path,path+".1");
                    }
                    using(var buffer=new MemoryStream())
                    {
                        var serializer=new DataContractJsonSerializer(typeof(Entry),new DataContractJsonSerializerSettings { UseSimpleDictionaryFormat=true });
                        serializer.WriteObject(buffer,item);
                        using(var stream=new FileStream(path,FileMode.Append,FileAccess.Write,FileShare.ReadWrite|FileShare.Delete))
                        { var raw=buffer.ToArray();stream.Write(raw,0,raw.Length);stream.WriteByte(10); }
                    }
                }
                catch(Exception error) { LastError=error.GetType().Name; }
            }
        }
        private static void WatchLoop()
        {
            bool hung=false;long lastWait=0;
            while(!Stopping)
            {
                System.Threading.Thread.Sleep(1000);
                long now=Millis,age=now-System.Threading.Interlocked.Read(ref LastUi);
                if(age>=3000 && !hung) { hung=true;Log("ui_unresponsive","age_ms",age.ToString(),"last_action",LastAction,"phase",Phase); }
                if(age<1000 && hung) { hung=false;Log("ui_resumed","last_action",LastAction); }
                long bridgeAge=now-System.Threading.Interlocked.Read(ref LastBridge);
                if(Phase!="idle" && Phase!="game_run" && Phase!="password_confirmation" && bridgeAge>=15000 && now-lastWait>=15000)
                { lastWait=now;Log("ui_operation_waiting","phase",Phase,"no_bridge_event_ms",bridgeAge.ToString(),"observation","No completion observed; not proof of a deadlock"); }
                long dropped=System.Threading.Interlocked.Exchange(ref Dropped,0);
                if(dropped>0) Log("ui_diagnostic_dropped","count",dropped.ToString());
            }
        }
        internal static void BeginLaunch()
        { LaunchId=Guid.NewGuid().ToString("N");Phase="launch";System.Threading.Interlocked.Exchange(ref LastBridge,Millis);Log("ui_operation_begin","operation_id",LaunchId,"phase",Phase); }
        internal static void Bridge(string kind,string error,string phase)
        {
            System.Threading.Interlocked.Exchange(ref LastBridge,Millis);
            if(!string.IsNullOrEmpty(phase)) Phase=phase;
            if(kind=="registration_created") Phase="password_confirmation";
            if(kind=="game_started") { Phase="game_run";Log("ui_operation_end","operation_id",LaunchId,"result","game_started"); }
            if(kind=="game_exited" || kind=="launch_error" || kind=="launch_cancelled") Phase="idle";
            Log("ui_bridge_event","kind",kind,"phase",Phase,"error",error);
        }
        internal static void EndLaunch()
        { Log("ui_operation_end","operation_id",LaunchId,"phase",Phase);Phase="idle"; }
        private static string Target(Control c)
        {
            var path=new List<string>();
            for(int depth=0;c!=null && depth<16;c=c.Parent,++depth)
            { string name=string.IsNullOrEmpty(c.Name) ? c.GetType().Name+"["+(c.Parent==null?0:c.Parent.Controls.IndexOf(c))+ "]" : c.Name;path.Insert(0,name); }
            return string.Join("/",path.ToArray());
        }
        private static void Hook(Control c)
        {
            if(!Hooked.Add(c)) return;
            c.Disposed+=(s,e)=>Hooked.Remove(c);
            c.ControlAdded+=(s,e)=>Hook(e.Control);
            c.Enter+=(s,e)=>Log("ui_focus","target",Target(c),"type",c.GetType().Name);
            c.VisibleChanged+=(s,e)=>Log("ui_visibility","target",Target(c),"visible",c.Visible.ToString());
            c.EnabledChanged+=(s,e)=>Log("ui_enabled","target",Target(c),"enabled",c.Enabled.ToString());
            var button=c as ButtonBase;
            if(button!=null) button.Click+=(s,e)=>Log("ui_action","target",Target(c),"caption",button.Text,"enabled",c.Enabled.ToString());
            var combo=c as ComboBox;
            if(combo!=null) combo.SelectedIndexChanged+=(s,e)=>Log("ui_selection","target",Target(c),"selected_index",combo.SelectedIndex.ToString());
            var form=c as Form;
            if(form!=null) { Log("ui_window_observed","target",Target(c),"caption",form.Text);form.FormClosed+=(s,e)=>Log("ui_window_closed","target",Target(c),"reason",e.CloseReason.ToString()); }
            foreach(Control child in c.Controls) Hook(child);
        }
        public bool PreFilterMessage(ref Message m)
        {
            if(m.Msg!=0x201 && m.Msg!=0x204 && m.Msg!=0x100) return false;
            int key=(int)m.WParam;
            if(m.Msg==0x100 && key!=9 && key!=13 && key!=27 && key!=32 && (key<37 || key>40)) return false;
            Control control=Control.FromHandle(m.HWnd);
            if(control!=null && m.Msg!=0x100)
            {
                try { Control child=control.GetChildAtPoint(control.PointToClient(Cursor.Position),GetChildAtPointSkip.None);if(child!=null) control=child; } catch(InvalidOperationException) { }
            }
            string target=control==null?"native-dialog-window":Target(control);
            LastAction=target;
            var point=control==null ? Cursor.Position : control.PointToClient(Cursor.Position);
            Log(m.Msg==0x100?"ui_navigation_key":"ui_mouse_down","target",target,"type",control==null?"native":control.GetType().Name,
                "enabled",control==null?"unknown":control.Enabled.ToString(),"x",point.X.ToString(),"y",point.Y.ToString(),
                "button",m.Msg==0x201?"left":m.Msg==0x204?"right":"navigation","key",m.Msg==0x100?key.ToString():"");
            return false;
        }
        private static void Stop()
        {
            Log("ui_session_closed");Stopping=true;if(UiTimer!=null) UiTimer.Stop();Queue.CompleteAdding();
            if(Writer!=null) Writer.Join(2000);
        }
    }

    internal static class DiagnosticDialogs
    {
        internal static DialogResult Show(string text) { return Show(null,text,"",MessageBoxButtons.OK,MessageBoxIcon.None); }
        internal static DialogResult Show(string text,string caption) { return Show(null,text,caption,MessageBoxButtons.OK,MessageBoxIcon.None); }
        internal static DialogResult Show(string text,string caption,MessageBoxButtons buttons) { return Show(null,text,caption,buttons,MessageBoxIcon.None); }
        internal static DialogResult Show(string text,string caption,MessageBoxButtons buttons,MessageBoxIcon icon) { return Show(null,text,caption,buttons,icon); }
        internal static DialogResult Show(IWin32Window owner,string text) { return Show(owner,text,"",MessageBoxButtons.OK,MessageBoxIcon.None); }
        internal static DialogResult Show(IWin32Window owner,string text,string caption) { return Show(owner,text,caption,MessageBoxButtons.OK,MessageBoxIcon.None); }
        internal static DialogResult Show(IWin32Window owner,string text,string caption,MessageBoxButtons buttons) { return Show(owner,text,caption,buttons,MessageBoxIcon.None); }
        internal static DialogResult Show(IWin32Window owner,string text,string caption,MessageBoxButtons buttons,MessageBoxIcon icon)
        {
            string id=Guid.NewGuid().ToString("N");
            LauncherDiagnostics.Log("ui_dialog_shown","dialog_id",id,"caption",caption,"message",text,"buttons",buttons.ToString(),"icon",icon.ToString());
            var watch=Stopwatch.StartNew();
            var result=System.Windows.Forms.MessageBox.Show(owner,text,caption,buttons,icon);
            LauncherDiagnostics.Log("ui_dialog_closed","dialog_id",id,"result",result.ToString(),"elapsed_ms",watch.ElapsedMilliseconds.ToString());
            return result;
        }
    }
}
