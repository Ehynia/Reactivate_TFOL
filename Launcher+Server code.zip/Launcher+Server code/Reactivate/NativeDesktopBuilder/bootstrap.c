/* Versioned UI cache, no-install bootstrap for the provided WinForms source. */
typedef unsigned int U;
typedef unsigned short W;
typedef void *P;
#define WINAPI __attribute__((stdcall))
#ifdef BOOT_HOST_TEST
static P host_api[12];
#define API(i,ret,args) ((ret (*)args)host_api[i])
#else
#define API(i,ret,args) (*(ret (WINAPI **)args)(0x00430100u+4u*(i)))
#endif
#define ModuleName API(0,U,(P,W*,U))
#define Attributes API(1,U,(const W*))
#define WindowsDir API(2,U,(W*,U))
#define CreateProcess API(3,int,(const W*,W*,P,P,int,U,P,const W*,P,P))
#define Wait API(4,U,(P,U))
#define ExitCode API(5,int,(P,U*))
#define Close API(6,int,(P))
#define CreateFile API(7,P,(const W*,U,U,P,U,U,P))
#define Exit API(8,void,(U))
#define Message API(9,int,(P,const W*,const W*,U))
#define GetAttributesEx API(10,int,(const W*,U,P))
#define MoveFile API(11,int,(const W*,const W*,U))

static W base[2048],compiler[2048],source[2048],output[2048],temporary[2048],command_line[8192],logpath[2048],icon[2048];
static const W title[]=L"Reactivate";
typedef struct {U cb;P reserved,desktop,title;U x,y,sx,sy,cx,cy,fill,flags;W show,reserved_size;P reserved_data,input,output,error;} START;
typedef struct {P process,thread;U pid,tid;} PROCESS;
typedef struct {U size;P descriptor;int inherit;} SECURITY;
typedef struct {U attributes,created_low,created_high,access_low,access_high,write_low,write_high,size_high,size_low;} FILEDATA;

static U length(const W*s){U n=0;while(s[n])n++;return n;}
static void copy(W*d,const W*s){U i=0;do{d[i]=s[i];}while(s[i++]);}
static int append(W*d,U capacity,const W*s){U n=length(d),m=length(s);if(n+m>=capacity)return 0;copy(d+n,s);return 1;}
static int path(W*d,const W*s){copy(d,base);return append(d,2048,s);}
static int exists(const W*s){U a=Attributes(s);return a!=0xffffffffu&&!(a&16);}
static int quote(W*d,const W*s){return append(d,8192,L"\"")&&append(d,8192,s)&&append(d,8192,L"\"");}
static U fail(const W*message,U code){Message(0,message,title,0x10);return code;}

static U run_bootstrap(void){
    U n=ModuleName(0,base,2048),code=0;START start={0};PROCESS pi={0};FILEDATA src={0},exe={0};
    if(!n||n>=2048)return fail(L"The launcher path is too long.",2);
    while(n&&base[n-1]!='\\'&&base[n-1]!='/')n--;
    if(!n)return fail(L"Cannot resolve the launcher folder.",2);
    base[n]=0;
    if(!path(source,L"Server\\LauncherSource\\ReactivateStandalone.cs")||
       !path(output,L"Reactivate.UI.v32.exe")||!path(temporary,L"Reactivate.UI.v32.building.exe")||
       !path(logpath,L"Reactivate_build.log")||!path(icon,L"Assets\\app_icon.ico"))return fail(L"The launcher path is too long.",2);
    if(!exists(source)||!exists(icon))return fail(L"Extract the WHOLE Release folder, including Server and Assets.",3);
    U cached=GetAttributesEx(source,0,&src)&&GetAttributesEx(output,0,&exe)&&
        (exe.write_high>src.write_high||(exe.write_high==src.write_high&&exe.write_low>=src.write_low));
    if(!cached){
        n=WindowsDir(compiler,2048);if(!n||n>1800)return fail(L"Cannot locate the Windows compiler.",4);
        append(compiler,2048,L"\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe");
        if(!exists(compiler)){
            WindowsDir(compiler,2048);append(compiler,2048,L"\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe");
        }
        if(!exists(compiler))return fail(L"Windows .NET Framework compiler is unavailable. Use Build_Reactivate_NET8.bat or install .NET Framework 4.8.",4);
        command_line[0]=0;
        if(!quote(command_line,compiler)||!append(command_line,8192,L" /nologo /target:winexe /optimize+ /platform:x64 /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll /out:")||
           !quote(command_line,temporary)||!append(command_line,8192,L" /win32icon:")||!quote(command_line,icon)||!append(command_line,8192,L" ")||!quote(command_line,source))return fail(L"The compiler command is too long.",5);
        SECURITY security={sizeof(SECURITY),0,1};
        P log=CreateFile(logpath,0x40000000u,1,&security,2,0x80,0);
        if(log==(P)-1)return fail(L"Cannot write Reactivate_build.log. Move the launcher to a writable folder.",6);
        start.cb=sizeof(start);start.flags=0x100;start.output=start.error=log;
        if(!CreateProcess(compiler,command_line,0,0,1,0x08000000u,0,base,&start,&pi)){Close(log);return fail(L"Could not start the Windows compiler.",7);}
        Wait(pi.process,0xffffffffu);
        if(!ExitCode(pi.process,&code))code=8;
        Close(pi.thread);Close(pi.process);Close(log);
        if(code||!exists(temporary))return fail(L"Interface compilation failed. See Release\\Reactivate_build.log. Existing UI was not replaced.",8);
        if(!MoveFile(temporary,output,1|8))return fail(L"Could not install the compiled UI. Close another Reactivate window and retry.",9);
    }
    command_line[0]=0;quote(command_line,output);
    START ui={0};PROCESS game={0};ui.cb=sizeof(ui);
    if(!CreateProcess(output,command_line,0,0,0,0,0,base,&ui,&game))return fail(L"Could not start Reactivate.UI.v32.exe.",10);
    Close(game.thread);Close(game.process);return 0;
}

#ifndef BOOT_HOST_TEST
void entry(void){Exit(run_bootstrap());for(;;){}}
#endif
