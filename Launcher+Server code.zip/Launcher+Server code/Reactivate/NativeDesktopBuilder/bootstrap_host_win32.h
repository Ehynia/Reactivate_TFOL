/* Host-only API fixture, not part of the Windows executable. */
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include <assert.h>
typedef uint32_t DWORD;
typedef void *HANDLE,*HINSTANCE;
typedef wchar_t *LPWSTR;
typedef struct {DWORD cb,dwFlags;HANDLE hStdOutput,hStdError;} STARTUPINFOW;
typedef struct {HANDLE hProcess,hThread;DWORD dwProcessId;} PROCESS_INFORMATION;
typedef struct {DWORD nLength;void *lpSecurityDescriptor;int bInheritHandle;} SECURITY_ATTRIBUTES;
#define WINAPI
#define TRUE 1
#define FALSE 0
#define INVALID_FILE_ATTRIBUTES 0xffffffffu
#define INVALID_HANDLE_VALUE ((HANDLE)-1)
#define FILE_ATTRIBUTE_DIRECTORY 16
#define FILE_ATTRIBUTE_READONLY 1
#define ERROR_PATH_NOT_FOUND 3
#define ERROR_FILE_NOT_FOUND 2
#define ERROR_BUFFER_OVERFLOW 111
#define ERROR_ALREADY_EXISTS 183
#define GENERIC_WRITE 0x40000000u
#define OPEN_ALWAYS 4
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_TEMPORARY 256
#define FILE_FLAG_DELETE_ON_CLOSE 0x04000000u
#define FILE_SHARE_READ 1
#define FILE_ATTRIBUTE_NORMAL 128
#define STARTF_USESTDHANDLES 256
#define CREATE_NO_WINDOW 0x08000000u
#define WAIT_OBJECT_0 0
#define WAIT_TIMEOUT 258
#define MOVEFILE_WRITE_THROUGH 8
#define MB_OK 0
#define MB_ICONERROR 16
#define _snwprintf swprintf
static int scenario,compile_calls,ui_calls,terminated,messages,installed;
static wchar_t last_message[12288];
static FILE *_wfopen(const wchar_t *p,const wchar_t *m){(void)p;(void)m;return NULL;}
static DWORD GetLastError(void){return scenario==2?32:5;}
static DWORD GetCurrentProcessId(void){return 123;}
static DWORD GetModuleFileNameW(void *m,wchar_t *p,DWORD n){(void)m;if(scenario==8)return n;wcscpy(p,L"C:\\ReadOnly Release\\Reactivate.exe");return wcslen(p);}
static DWORD GetEnvironmentVariableW(const wchar_t *k,wchar_t *p,DWORD n){(void)k;(void)n;if(scenario==7)return 0;wcscpy(p,L"C:\\UserCache");return wcslen(p);}
static DWORD GetWindowsDirectoryW(wchar_t *p,DWORD n){(void)n;wcscpy(p,L"C:\\Windows");return wcslen(p);}
static DWORD GetFileAttributesW(const wchar_t *p){
 if(wcsstr(p,L"Reactivate.UI.v60.exe"))return scenario==0||scenario==5||scenario==6||installed?128:INVALID_FILE_ATTRIBUTES;
 if(wcsstr(p,L".cs")&&(scenario==0||scenario==9))return INVALID_FILE_ATTRIBUTES;
 if(wcsstr(p,L"building.exe"))return compile_calls?128:INVALID_FILE_ATTRIBUTES;
 return 128;
}
static int CreateDirectoryW(const wchar_t *p,void *s){(void)s;assert(!wcsstr(p,L"ReadOnly Release"));return 1;}
static int MessageBoxW(void *w,const wchar_t *m,const wchar_t *t,unsigned flags){(void)w;(void)t;(void)flags;messages++;wcscpy(last_message,m);return 1;}
static HANDLE CreateFileW(const wchar_t *p,DWORD a,DWORD b,SECURITY_ATTRIBUTES *s,DWORD c,DWORD d,HANDLE e){
 (void)a;(void)b;(void)s;(void)c;(void)d;(void)e;assert(!wcsstr(p,L"ReadOnly Release"));
 if(scenario==2&&wcsstr(p,L"build.lock"))return INVALID_HANDLE_VALUE;
 if(scenario==3&&wcsstr(p,L"build.log"))return INVALID_HANDLE_VALUE;
 return (HANDLE)1;
}
static int CloseHandle(HANDLE h){(void)h;return 1;}
static int DeleteFileW(const wchar_t *p){(void)p;return 1;}
static int SetFileAttributesW(const wchar_t *p,DWORD flags){(void)p;(void)flags;return 1;}
static int CreateProcessW(const wchar_t *app,wchar_t *cmd,void *a,void *b,int inherit,DWORD flags,void *env,const wchar_t *cwd,STARTUPINFOW *si,PROCESS_INFORMATION *pi){
 (void)a;(void)b;(void)inherit;(void)flags;(void)env;
 assert(si->cb==sizeof(*si));assert(wcsstr(cwd,L"ReadOnly Release"));
 if(wcsstr(app,L"csc.exe")){compile_calls++;pi->hProcess=(HANDLE)10;assert(wcsstr(cmd,L"C:\\UserCache"));}
 else{ui_calls++;pi->hProcess=(HANDLE)20;assert(wcsstr(cmd,L"--root \"C:\\ReadOnly Release\""));if(scenario==5)return 0;}
 pi->hThread=(HANDLE)30;pi->dwProcessId=77;return 1;
}
static DWORD WaitForSingleObject(HANDLE h,DWORD ms){(void)ms;if(h==(HANDLE)10)return scenario==4?WAIT_TIMEOUT:WAIT_OBJECT_0;return scenario==6?WAIT_OBJECT_0:WAIT_TIMEOUT;}
static int GetExitCodeProcess(HANDLE h,DWORD *p){(void)h;*p=scenario==6?17:0;return 1;}
static int TerminateProcess(HANDLE h,DWORD code){(void)h;(void)code;terminated++;return 1;}
static int MoveFileExW(const wchar_t *a,const wchar_t *b,DWORD flags){(void)a;(void)b;(void)flags;installed=1;return 1;}
