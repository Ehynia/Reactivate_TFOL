/* Normal Windows GUI bootstrap. User cache avoids writing to protected Release folders. */
#define UNICODE
#define _UNICODE
#ifdef BOOT_HOST_TEST
#include "bootstrap_host_win32.h"
#else
#include <windows.h>
#endif
#include <stdio.h>
#include <wchar.h>

#define CAP 4096
static wchar_t root[CAP],cache[CAP],logpath[CAP];
static FILE *trace;
static void note(const wchar_t *stage,DWORD code){if(trace){fwprintf(trace,L"%ls: %lu\n",stage,(unsigned long)code);fflush(trace);}}
static int fail(const wchar_t *stage,const wchar_t *path,DWORD code){
    wchar_t text[CAP*3];
    note(stage,code);
    _snwprintf(text,CAP*3,L"%ls\nFile / Path: %ls\nWindows: %lu\n\nLog: %ls\n\n5 = access denied; 32/33 = file in use; 19 = write-protected drive.\nNo administrator permissions or antivirus changes are required by this launcher.",stage,path,(unsigned long)code,logpath);
    text[CAP*3-1]=0;MessageBoxW(NULL,text,L"Reactivate - launch diagnostics",MB_OK|MB_ICONERROR);return 1;
}
static int join(wchar_t *out,const wchar_t *base,const wchar_t *leaf){
    int n=_snwprintf(out,CAP,L"%ls\\%ls",base,leaf);return n>0&&n<CAP;
}
static int exists(const wchar_t *p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES&&!(a&FILE_ATTRIBUTE_DIRECTORY);}
static int directory(const wchar_t *path){
    if(CreateDirectoryW(path,NULL))return 1;
    DWORD error=GetLastError(),a=GetFileAttributesW(path);
    return error==ERROR_ALREADY_EXISTS&&a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_DIRECTORY);
}
static int setup(void){
    DWORD n=GetModuleFileNameW(NULL,root,CAP);
    if(!n||n>=CAP)return fail(L"Cannot resolve launcher path",L"Reactivate.exe",GetLastError());
    while(n&&root[n-1]!=L'\\'&&root[n-1]!=L'/')--n;
    if(!n)return fail(L"Cannot resolve launcher folder",root,ERROR_PATH_NOT_FOUND);
    root[n-1]=0;
    if(n==3){root[2]=L'\\';root[3]=L'.';root[4]=0;} /* C:\\ must not escape a closing command-line quote. */
    n=GetEnvironmentVariableW(L"LOCALAPPDATA",cache,CAP);
    if(!n||n>=CAP-120)return fail(L"LOCALAPPDATA is unavailable",L"LOCALAPPDATA",ERROR_PATH_NOT_FOUND);
    wchar_t next[CAP];
    const wchar_t *parts[]={L"Reactivate",L"Launcher",L"v36argos1"};
    for(unsigned i=0;i<3;++i){
        if(!join(next,cache,parts[i]))return fail(L"Cache path is too long",cache,ERROR_BUFFER_OVERFLOW);
        wcscpy(cache,next);if(!directory(cache))return fail(L"Cannot create user cache",cache,GetLastError());
    }
    unsigned long long hash=1469598103934665603ULL;
    for(const wchar_t *p=root;*p;++p){hash^=(unsigned)*p;hash*=1099511628211ULL;}
    wchar_t id[32];_snwprintf(id,32,L"%08lx%08lx",(unsigned long)(hash>>32),(unsigned long)(hash&0xffffffffULL));
    if(!join(next,cache,id))return fail(L"Cache path is too long",cache,ERROR_BUFFER_OVERFLOW);
    wcscpy(cache,next);if(!directory(cache))return fail(L"Cannot create isolated user cache",cache,GetLastError());
    wchar_t leaf[80];_snwprintf(leaf,80,L"Reactivate_startup_%lu.log",(unsigned long)GetCurrentProcessId());
    if(!join(logpath,cache,leaf))return fail(L"Log path is too long",cache,ERROR_BUFFER_OVERFLOW);
    trace=_wfopen(logpath,L"w, ccs=UTF-8");note(L"OBT33 / v36argos1",0);
    return 0;
}
static int launch(void){
    if(setup())return 1;
    wchar_t source[CAP],icon[CAP],output[CAP],temporary[CAP],compiler[CAP],buildlog[CAP],lockpath[CAP],command[CAP*4];
    if(!join(source,root,L"Server\\LauncherSource\\ReactivateStandalone.cs")||!join(icon,root,L"Assets\\app_icon.ico")||
       !join(output,cache,L"Reactivate.UI.v60.exe")||!join(temporary,cache,L"Reactivate.UI.v60.building.exe")||
       !join(buildlog,cache,L"Reactivate_build.log")||!join(lockpath,cache,L"build.lock"))return fail(L"Launcher path is too long",root,ERROR_BUFFER_OVERFLOW);
    if(!exists(output)){
        HANDLE lock=CreateFileW(lockpath,GENERIC_WRITE,0,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_TEMPORARY|FILE_FLAG_DELETE_ON_CLOSE,NULL);
        if(lock==INVALID_HANDLE_VALUE)return fail(L"Another launcher may be building the UI; wait and retry",lockpath,GetLastError());
        DWORD code=0;int result=1;
        if(!exists(source)){fail(L"Missing source. Extract the whole Release folder",source,ERROR_FILE_NOT_FOUND);goto release_lock;}
        if(!exists(icon)){fail(L"Missing icon. Extract the whole Release folder",icon,ERROR_FILE_NOT_FOUND);goto release_lock;}
        DWORD n=GetWindowsDirectoryW(compiler,CAP);
        if(!n||n>=CAP-80){fail(L"Cannot locate .NET Framework",compiler,ERROR_PATH_NOT_FOUND);goto release_lock;}
        wcscat(compiler,L"\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe");
        if(!exists(compiler)){
            n=GetWindowsDirectoryW(compiler,CAP);
            if(!n||n>=CAP-80){fail(L"Cannot locate .NET Framework",compiler,ERROR_PATH_NOT_FOUND);goto release_lock;}
            wcscat(compiler,L"\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe");
        }
        if(!exists(compiler)){fail(L"Install .NET Framework 4.8 or use the NET8 build",compiler,ERROR_FILE_NOT_FOUND);goto release_lock;}
        int written=_snwprintf(command,CAP*4,L"\"%ls\" /nologo /target:winexe /optimize+ /platform:x64 /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll /out:\"%ls\" /win32icon:\"%ls\" \"%ls\"",compiler,temporary,icon,source);
        if(written<0||written>=CAP*4){fail(L"Compiler command is too long",source,ERROR_BUFFER_OVERFLOW);goto release_lock;}
        SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};
        HANDLE log=CreateFileW(buildlog,GENERIC_WRITE,FILE_SHARE_READ,&sa,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
        if(log==INVALID_HANDLE_VALUE){fail(L"Cannot write compiler log",buildlog,GetLastError());goto release_lock;}
        /* This is our stale managed staging file, never an original game EXE. */
        if(exists(temporary)){DWORD a=GetFileAttributesW(temporary);if(a&FILE_ATTRIBUTE_READONLY)SetFileAttributesW(temporary,a&~FILE_ATTRIBUTE_READONLY);DeleteFileW(temporary);}
        STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=si.hStdError=log;
        note(L"Compiling UI; 120 second timeout",0);
        if(!CreateProcessW(compiler,command,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,root,&si,&pi)){
            code=GetLastError();CloseHandle(log);fail(L"Cannot start compiler",compiler,code);goto release_lock;
        }
        DWORD wait=WaitForSingleObject(pi.hProcess,120000);
        if(wait!=WAIT_OBJECT_0){code=wait==WAIT_TIMEOUT?WAIT_TIMEOUT:GetLastError();TerminateProcess(pi.hProcess,code);WaitForSingleObject(pi.hProcess,5000);}
        else if(!GetExitCodeProcess(pi.hProcess,&code))code=GetLastError();
        CloseHandle(pi.hThread);CloseHandle(pi.hProcess);CloseHandle(log);note(L"Compiler exit",code);
        if(code||!exists(temporary)){fail(L"UI build failed or timed out; see compiler log",buildlog,code?code:ERROR_FILE_NOT_FOUND);goto release_lock;}
        if(!MoveFileExW(temporary,output,MOVEFILE_WRITE_THROUGH)){fail(L"Cannot install compiled interface",output,GetLastError());goto release_lock;}
        result=0;
release_lock:
        CloseHandle(lock);if(result)return result;
    }else note(L"Using versioned user cache",0);
    int written=_snwprintf(command,CAP*4,L"\"%ls\" --root \"%ls\"",output,root);
    if(written<0||written>=CAP*4)return fail(L"UI command is too long",output,ERROR_BUFFER_OVERFLOW);
    STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
    if(!CreateProcessW(output,command,NULL,NULL,FALSE,0,NULL,root,&si,&pi))return fail(L"Cannot start interface",output,GetLastError());
    note(L"UI process started",pi.dwProcessId);
    DWORD code=0,wait=WaitForSingleObject(pi.hProcess,1500);
    if(wait==WAIT_OBJECT_0&&GetExitCodeProcess(pi.hProcess,&code))note(L"UI early exit",code);
    CloseHandle(pi.hThread);CloseHandle(pi.hProcess);
    if(wait==WAIT_OBJECT_0&&code)return fail(L"UI exited early; see LOCALAPPDATA/Reactivate/Logs/Reactivate_UI_error.log",output,code);
    return 0;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,LPWSTR command,int show){
    (void)instance;(void)previous;(void)command;(void)show;
    int result=launch();if(trace)fclose(trace);return result;
}
