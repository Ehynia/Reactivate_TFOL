"""Compatibility entry point for the standard Windows bootstrap builder."""
import argparse,os
from build_windows import build
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--zig',default=os.environ.get('ZIG','zig'));build(p.parse_args().zig)
