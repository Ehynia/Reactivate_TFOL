"""Build the relocatable Windows GUI bootstrap with Zig 0.13 (no Windows runtime needed)."""
import argparse,os,struct,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def icon_object(ico):
    assert ico[:4]==b'\0\0\1\0';count=struct.unpack_from('<H',ico,4)[0]
    data=bytearray(32);struct.pack_into('<HH',data,12,0,2);leaves=[]
    def directory(ids):
        at=len(data);data.extend(bytes(16+8*len(ids)));struct.pack_into('<H',data,at+14,len(ids));return at
    icons=directory(list(range(1,count+1)));groups=directory([1])
    struct.pack_into('<IIII',data,16,3,icons|0x80000000,14,groups|0x80000000)
    for i in range(count+1):
        parent=icons if i<count else groups;slot=i if i<count else 0
        lang=directory([1033]);struct.pack_into('<II',data,parent+16+8*slot,i+1 if i<count else 1,lang|0x80000000)
        leaf=len(data);data.extend(bytes(16));struct.pack_into('<II',data,lang+16,1033,leaf);leaves.append(leaf)
    group=bytearray(struct.pack('<HHH',0,1,count));payloads=[]
    for i in range(count):
        w,h,col,res,planes,bpp,size,offset=struct.unpack_from('<BBBBHHII',ico,6+16*i)
        payload=ico[offset:offset+size];assert len(payload)==size;payloads.append(payload)
        group.extend(struct.pack('<BBBBHHIH',w,h,col,res,planes,bpp,size,i+1))
    payloads.append(bytes(group))
    for leaf,payload in zip(leaves,payloads):
        data.extend(bytes((-len(data))%4));at=len(data);data.extend(payload);struct.pack_into('<IIII',data,leaf,at,len(payload),0,0)
    reloc=b''.join(struct.pack('<IIH',at,0,7) for at in leaves) # IMAGE_REL_I386_DIR32NB
    rawptr=60;relptr=rawptr+len(data);symptr=relptr+len(reloc)
    header=struct.pack('<HHIIIHH',0x14c,1,0,symptr,1,0,0)
    section=struct.pack('<8sIIIIIIHHI',b'.rsrc\0\0\0',0,0,len(data),rawptr,relptr,0,len(leaves),0,0x40000040)
    symbol=struct.pack('<8sIhHBB',b'.rsrc\0\0\0',0,1,0,3,0)
    return header+section+data+reloc+symbol+struct.pack('<I',4)

def build(zig):
    obj=ROOT/'launcher_icon.o';obj.write_bytes(icon_object((ROOT.parent/'Assets/app_icon.ico').read_bytes()))
    out=ROOT.parents[1]/'Release/Reactivate.exe'
    subprocess.run([zig,'cc','-target','x86-windows-gnu','-municode','-Wl,--subsystem,windows','-O2','-s','-Wall','-Wextra',
                    str(ROOT/'bootstrap_windows.c'),str(obj),'-o',str(out),'-luser32'],check=True)
    print(out)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--zig',default=os.environ.get('ZIG','zig'));build(p.parse_args().zig)
