#define BOOT_HOST_TEST
#include <stdio.h>
#include <string.h>
#include "bootstrap.c"
static U scenario,processes,moves,failures;
static void ascii(W*out,const char*s){U i=0;do{out[i]=(W)(unsigned char)s[i];}while(s[i++]);}
static int has(const W*text,const char*needle){char temp[16384];U i=0;while(text[i]&&i<sizeof(temp)-1){temp[i]=(char)text[i];i++;}temp[i]=0;return strstr(temp,needle)!=0;}
static U module(P m,W*out,U n){(void)m;(void)n;ascii(out,"C:\\Launcher\\Release\\Reactivate.exe");return length(out);}
static U attrs(const W*name){if(scenario==2&&has(name,".cs"))return 0xffffffffu;return 0x80;}
static U windows(W*out,U n){(void)n;ascii(out,"C:\\Windows");return length(out);}
static int create(const W*app,W*cmd,P a,P b,int inherit,U flags,P env,const W*cwd,P si,P pi){
    (void)a;(void)b;(void)env;(void)cwd;(void)si;processes++;
    if(has(app,"csc.exe")){
        if(!inherit||flags!=0x08000000u||!has(cmd,"/r:System.Runtime.Serialization.dll")||!has(cmd,"ReactivateStandalone.cs")||!has(cmd,"Reactivate.UI.v17.building.exe"))return 0;
    }else if(!has(app,"Reactivate.UI.v17.exe")||inherit||flags)return 0;
    ((PROCESS*)pi)->process=(P)1;((PROCESS*)pi)->thread=(P)2;return 1;
}
static U wait_(P p,U n){(void)p;(void)n;return 0;}
static int exit_(P p,U*code){(void)p;*code=scenario==3?1:0;return 1;}
static int close_(P p){(void)p;return 1;}
static P file_(const W*p,U a,U b,P c,U d,U e,P f){(void)p;(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;return(P)3;}
static void end_(U n){(void)n;}
static int message(P p,const W*a,const W*b,U c){(void)p;(void)a;(void)b;(void)c;failures++;return 0;}
static int attributes_(const W*name,U level,P out){(void)level;FILEDATA*p=out;p->write_high=0;p->write_low=has(name,".cs")?20:(scenario==1?30:10);return 1;}
static int move_(const W*a,const W*b,U flags){(void)a;(void)b;if(flags!=9)return 0;moves++;return 1;}
int main(void){
    host_api[0]=(P)module;host_api[1]=(P)attrs;host_api[2]=(P)windows;host_api[3]=(P)create;host_api[4]=(P)wait_;host_api[5]=(P)exit_;host_api[6]=(P)close_;host_api[7]=(P)file_;host_api[8]=(P)end_;host_api[9]=(P)message;host_api[10]=(P)attributes_;host_api[11]=(P)move_;
    for(scenario=0;scenario<4;scenario++){
        processes=moves=failures=0;U result=run_bootstrap();
        if(scenario==0&&(result||processes!=2||moves!=1||failures))return 1;
        if(scenario==1&&(result||processes!=1||moves||failures))return 2;
        if(scenario==2&&(result!=3||processes||moves||failures!=1))return 3;
        if(scenario==3&&(result!=8||processes!=1||moves||failures!=1))return 4;
    }
    puts("BOOTSTRAP_4_SCENARIOS_OK (synthetic WinAPI; no Windows GUI execution)");return 0;
}
