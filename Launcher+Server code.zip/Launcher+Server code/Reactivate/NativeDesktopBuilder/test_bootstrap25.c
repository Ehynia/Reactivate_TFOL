#define BOOT_HOST_TEST
#include "bootstrap_windows.c"
int main(void){
 for(scenario=0;scenario<=9;++scenario){
  compile_calls=ui_calls=terminated=messages=installed=0;logpath[0]=last_message[0]=0;
  int code=launch();
  if(scenario==0){assert(!code&&!compile_calls&&ui_calls==1);}
  if(scenario==1){assert(!code&&compile_calls==1&&ui_calls==1&&installed);}
  if(scenario==2||scenario==3||scenario==7||scenario==8||scenario==9){assert(code==1&&!compile_calls&&!ui_calls);}
  if(scenario==4){assert(code==1&&compile_calls==1&&!ui_calls&&terminated==1);}
  if(scenario==5||scenario==6){assert(code==1&&!compile_calls&&ui_calls==1);}
  if(code)assert(messages==1);
  if(scenario==2)assert(wcsstr(last_message,L"build.lock")&&wcsstr(last_message,L"Windows: 32"));
  if(scenario==3)assert(wcsstr(last_message,L"Reactivate_build.log")&&wcsstr(last_message,L"Windows: 5"));
 }
 puts("BOOTSTRAP_10_USER_CACHE_AND_ACCESS_CASES_OK");return 0;
}
