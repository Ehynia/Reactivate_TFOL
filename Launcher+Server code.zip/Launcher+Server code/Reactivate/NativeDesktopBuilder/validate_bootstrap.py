"""Compatibility entry point for standard PE and host-fixture validation."""
from validate_windows import main
if __name__=='__main__':main()
