"""Standard PE checks and host C API-fixture checks, not Windows execution."""
import hashlib,json,struct,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'Release/Server'))
from pe_read import PE

def main():
    image=PE(ROOT.parents[1]/'Release/Reactivate.exe');checks=[]
    pe=struct.unpack_from('<I',image.b,0x3c)[0];opt=pe+24
    assert image.machine==0x14c and struct.unpack_from('<H',image.b,opt+68)[0]==2
    checks.append('Standard x86 Windows GUI PE32')
    assert image.directories[5][1]>0 and struct.unpack_from('<H',image.b,opt+70)[0]&0x140==0x140
    checks.append('ASLR, NX and relocations enabled')
    names={row['name'] for descriptor in image.imports() for row in descriptor['entries']}
    assert {'GetEnvironmentVariableW','CreateProcessW','WaitForSingleObject','TerminateProcess','GetLastError','MessageBoxW','MoveFileExW'}<=names
    checks.append('Standard Windows import table includes user-cache and diagnostic APIs')
    assert image.directories[2][1]>0
    resource=image.read(image.base+image.directories[2][0],image.directories[2][1]);ico=(ROOT.parent/'Assets/app_icon.ico').read_bytes()
    for i in range(struct.unpack_from('<H',ico,4)[0]):
        size,offset=struct.unpack_from('<II',ico,6+16*i+8);assert ico[offset:offset+size] in resource
    checks.append('All original icon payloads embedded')
    prior=0
    for s in image.sections.values():
        assert s['rawptr']%512==0 and s['rawptr']+s['rawsize']<=len(image.b)
        assert s['va']>=prior;prior=s['va']+((max(s['vsize'],s['rawsize'])+4095)//4096)*4096
    text=image.sections['.text'];assert text['va']<=image.entry<text['va']+text['vsize']
    checks.append('Entry point and section bounds verified')
    with tempfile.TemporaryDirectory(dir=ROOT) as temp:
        output=Path(temp)/'bootstrap_test'
        subprocess.run(['gcc','-O1','-Wall','-Wextra',str(ROOT/'test_bootstrap25.c'),'-o',str(output)],check=True,capture_output=True)
        run=subprocess.run([str(output)],check=True,capture_output=True,text=True,timeout=5);checks.append(run.stdout.strip())
    result=dict(passed=len(checks),checks=checks,bootstrap_sha256=hashlib.sha256(image.b).hexdigest(),windows_executed=False,managed_ui_compiled_here=False)
    top=ROOT.parents[1];(top/'BOOTSTRAP_VALIDATION.json').write_text(json.dumps(result,indent=2))
    (top/'BOOTSTRAP_BUILD.json').write_text(json.dumps(dict(file='Release/Reactivate.exe',bytes=len(image.b),sha256=result['bootstrap_sha256'],type='Standard relocatable PE32; user-cache C# bootstrap',windows_execution_verified=False),indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
