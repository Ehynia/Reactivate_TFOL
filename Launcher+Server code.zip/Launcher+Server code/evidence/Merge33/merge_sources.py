"""Repeatable reviewed merge. Input archives remain immutable."""
from pathlib import Path
import datetime,hashlib,json,shutil
ROOT=Path(__file__).parent
BASE=ROOT/'launcher';PATCH=ROOT/'gemini';OUT=ROOT/'result'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def log(action,**values):
    with (ROOT/'ACTIONS.jsonl').open('a') as f:
        f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),action=action,**values),ensure_ascii=False)+'\n')
def main():
    report=json.loads((ROOT/'INPUT_COMPARISON.json').read_text());decisions=[]
    for name in report['changed']+report['added']:
        if name.startswith('Release/Server/') and not Path(name).suffix=='.json' and not name.endswith('.txt') and '/LauncherSource/' not in name:
            target=OUT/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PATCH/name,target)
            log('merge_file',source='gemini',file=name,sha256=sha(target));decisions.append((name,'Gemini source, subject to review corrections'))
        elif name in ('LocalizationSource/localization_catalog.json','Release/ClientLanguages/ui_dictionary.json'):
            shutil.copyfile(PATCH/name,OUT/name);log('merge_file',source='gemini',file=name,sha256=sha(OUT/name))
        else:decisions.append((name,'launcher baseline retained; executable/manifest/resources rebuilt together'))
    # Preserve the user's v26.1 title-fit and DPI code, not the older launcher in Gemini's patch.
    a='Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs';b='Release/Server/LauncherSource/ReactivateStandalone.cs'
    assert (OUT/a).read_bytes()==(OUT/b).read_bytes()
    native=OUT/'Release/Server'
    shutil.copyfile(BASE/'Release/Server/base_exe_manifest.json',native/'fixtures/obt30_manifest.json')
    # Extract source using the exact release-30 manifest BEFORE any output manifest is changed.
    import sys
    sys.path.insert(0,str(native));from pe_read import PE
    im=PE(BASE/'Release/Server/ClientUpdate/TFOL_OBT.exe');m=json.loads((BASE/'Release/Server/base_exe_manifest.json').read_text())
    assert hashlib.sha256(im.b).hexdigest()==m['exe_sha256']
    code=bytearray(im.read(0x401000,32436224))
    for p in m['patches']:
        at=int(p['va'],16)-0x401000;after=bytes.fromhex(p['after']);before=bytes.fromhex(p['before'])
        assert code[at:at+len(after)]==after;code[at:at+len(before)]=before
    assert hashlib.sha256(code).hexdigest()==m['original_code_sha256']
    tvm=im.read(0x2d3b000,24576);assert hashlib.sha256(tvm).hexdigest()==m['recovered_tvm_sha256']
    for name,data in [('obt_current_recovered.exe',im.b),('OBT_original_code_rva_00001000.bin',code),('OBT_original_tvm_rva_0293b000.bin',tvm)]:
        target=OUT/'Release'/name;target.write_bytes(data);log('recover_pinned_build_input',file=name,sha256=sha(target))
    (ROOT/'MERGE_DECISIONS.json').write_text(json.dumps(decisions,ensure_ascii=False,indent=2)+'\n')
    log('launcher_preserved',file=a,sha256=sha(OUT/a))
    print('Reviewed merge staged; native release30 inputs reconstructed with exact hashes.')
if __name__=='__main__':main()
