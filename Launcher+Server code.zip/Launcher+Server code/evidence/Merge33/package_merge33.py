"""Package only the runnable full project, with independent hashes and input provenance."""
from pathlib import Path
import datetime,hashlib,json,shutil,zipfile
from merge_sources import ROOT,BASE,OUT,log,sha

def excluded(path):
    rel=path.relative_to(OUT);name=rel.name
    return ('__pycache__' in rel.parts or name.endswith(('.pyc','.sqlite3','.sqlite3-wal','.sqlite3-shm','.o','.elf'))
        or name in {'runtime.bin','obt_current_recovered.exe','OBT_original_code_rva_00001000.bin','OBT_original_tvm_rva_0293b000.bin','TFOL_OBT_TEST_33.exe'}
        or any(part.startswith('tmp') for part in rel.parts))

def main():
    server=OUT/'Release/Server';evidence=OUT/'evidence/Merge33'
    summary=json.loads((server/'SERVICE_VALIDATION.json').read_text())
    native=json.loads((server/'NATIVE_VALIDATION.json').read_text())
    assert summary['passed'] and summary['tests_run']==238 and native['passed']==12
    manifest=json.loads((server/'base_exe_manifest.json').read_text())
    assert sha(server/'ClientUpdate/TFOL_OBT.exe')==manifest['exe_sha256']
    readme=(OUT/'MERGE33_README_RU.md').read_text()
    (OUT/'README_RU.md').write_text(readme)
    (OUT/'Release/START_HERE_RU.txt').write_text('Reactivate OBT33 / лаунчер v26.2\n\nРаспакуйте полный архив в новую папку и откройте Release\\Reactivate.exe.\nВыберите Test Node и папку установленной полной игры.\nИспользуйте существующий логин и пароль: новое поколение аккаунтов не создаётся.\n\nПодробности и ограничения — MERGE33_README_RU.md в корне архива.\nОтчёт после теста: OBT_LOCAL_33_REPORT_*.zip.\n',encoding='utf-8-sig')
    checkpoint=dict(release='OBT33/v26.2',native_manifest_version=manifest['version'],native_sha256=manifest['exe_sha256'],
        native_bytes=manifest['exe_bytes'],native_patches=len(manifest['patches']),launcher_cache='v26merge1',
        launcher_base='OBT31A_v26_1_HERO_TITLE_FIX',service_tests=summary,native_checks=native['passed'],
        windows_engine_executed=False,windows_gui_executed=False,listen_server_verified=False,late_join_bot_replacement_implemented=False,
        account_generation='20261016-obt29-fresh-accounts-v1',translation_source='user workbook / Gemini catalogue',
        input_hashes={f.name:sha(f) for f in (ROOT.parent/'upload').iterdir()})
    (OUT/'CHECKPOINT_OBT33.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
    boot=OUT/'Release/Reactivate.exe';baseline=BASE/'Release/Reactivate.exe'
    bootversion=dict(file='Release/Reactivate.exe',sha256=sha(boot),baseline_sha256=sha(baseline),
        method='same-length UTF-16 cache and release literals only',cache='v26merge1',windows_executed=False)
    for name in ['BOOTSTRAP_VERSION33.json','BOOTSTRAP_BUILD.json']:(OUT/name).write_text(json.dumps(bootversion,indent=2)+'\n')
    (OUT/'BOOTSTRAP_VALIDATION.json').write_text((OUT/'MERGE33_FILE_CHECKS.json').read_text())
    for f in OUT.rglob('*'):
        if f.is_file() and not excluded(f):
            old=BASE/f.relative_to(OUT)
            if not old.exists() or sha(old)!=sha(f):log('final_file',file=str(f.relative_to(OUT)),sha256=sha(f),bytes=f.stat().st_size)
    log('tests_passed',tests=238,native_checks=12,bootstrap_scenarios=10,windows_executed=False)
    shutil.copyfile(ROOT/'ACTIONS.jsonl',evidence/'ACTIONS.jsonl')
    for name in ['review_fixes.py','merge_sources.py','package_merge33.py']:shutil.copyfile(ROOT/name,evidence/name)
    for name in ['REGRESSION_RUN_FINAL.txt','NATIVE_VALIDATION_LOG.txt']:shutil.copyfile(ROOT/name,evidence/name)
    files=[f for f in sorted(OUT.rglob('*')) if f.is_file() and not excluded(f) and f.name not in {'FILE_MANIFEST.json','SOURCE_MANIFEST.json'}]
    index={str(f.relative_to(OUT)):dict(bytes=f.stat().st_size,sha256=sha(f)) for f in files}
    (OUT/'FILE_MANIFEST.json').write_text(json.dumps(dict(release='OBT33/v26.2',files=index),ensure_ascii=False,indent=2)+'\n')
    sources={name:row for name,row in index.items() if Path(name).suffix in ('.py','.c','.h','.cs','.ld','.cmd','.bat')}
    (OUT/'SOURCE_MANIFEST.json').write_text(json.dumps(dict(release='OBT33/v26.2',files=sources),indent=2)+'\n')
    files += [OUT/'FILE_MANIFEST.json',OUT/'SOURCE_MANIFEST.json']
    output=ROOT.parent/'Reactivate_TFOL_OBT33_v26_2_MERGED_FULL.zip'
    prefix='Reactivate_TFOL_OBT33_v26_2'
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in files:z.write(f,prefix+'/'+str(f.relative_to(OUT)))
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        for name,row in index.items():assert hashlib.sha256(z.read(prefix+'/'+name)).hexdigest()==row['sha256']
        assert not any(n.endswith(('.sqlite3','.sqlite3-wal','.sqlite3-shm')) for n in z.namelist())
    receipt=dict(file=str(output.resolve()),bytes=output.stat().st_size,sha256=sha(output),files=len(files),crc_and_file_hashes_verified=True,service_tests=summary,native_checks=12)
    (ROOT/'PACKAGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
