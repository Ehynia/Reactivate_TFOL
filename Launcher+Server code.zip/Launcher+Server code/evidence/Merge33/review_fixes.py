"""Corrections applied after the staged source merge; journal every changed file."""
from pathlib import Path
import json,shutil,sys
sys.path.insert(0,str(Path(__file__).parent))
from merge_sources import ROOT,BASE,OUT,log,sha
S=OUT/'Release/Server'
def edit(path,fn):
    old=path.read_text(encoding='utf-8-sig');new=fn(old)
    if old==new:return
    path.write_text(new,encoding='utf-8-sig' if path.suffix=='.cs' else 'utf-8')
    log('review_correction',file=str(path.relative_to(OUT)),sha256=sha(path))
def main():
    shutil.copyfile(BASE/'Release/Server/ai_repair.h',S/'ai_repair.h')
    log('restore_scoped_ai_repair',file='Release/Server/ai_repair.h',sha256=sha(S/'ai_repair.h'))
    edit(S/'local_bridge.c',lambda t:t.replace('#include "ai_repair.h"','#include "ai_repair.h"\n#include "battle_repair33.h"'))
    edit(S/'native_bots.h',lambda t:t.replace('static EngineJob engine_job;','static EngineJob engine_job;\nstatic EngineJob engine_active_job;')
        .replace('     * OBT InitGame parses BotFill directly as target population; Bots adds one.\n     * Include the human in BotFill, otherwise a 6v6 match targets 11 players.','     * Native BotFill is the target NumBots, excluding the human player.')
        .replace('"?listen?dsport=1"','"?dsport=1"')
        .replace('if(j->action==2){((void(*)(void))0x7cdf60)();return 1;}','if(j->action==2){engine_active_job=(EngineJob){0};((void(*)(void))0x7cdf60)();return 1;}')
        .replace('    ((Console)fn)(pc,&output,&input,1);','    engine_active_job=*j;\n    ((Console)fn)(pc,&output,&input,1);'))
    def build(t):
        a=t.index('    # OBT32 repairs:');b=t.index('    # Client resource localization:',a)
        return t[:a]+'''    # Missing DS-side pawn metadata must not produce team 255 for the local human.
    site=0x6a7a72;at=site-0x401000
    before=bytes.fromhex('bfff00000085c074068bb8e80100008b068bce6a005753ff9048050000')
    if patched[at:at+len(before)]!=before:raise ValueError('Local Login team guard mismatch')
    after=b'\\xe9'+struct.pack('<i',sym['team_login_repaired']-site-5)+b'\\x90'*(len(before)-5)
    patched[at:at+len(before)]=after
    patches.append(dict(va=hex(site),before=before.hex(),after=after.hex(),purpose='scoped_local_login_team_fallback'))
    # Original null-safe primary ranged-weapon call. No APawn or bot-controller offsets.
    site=0x585254;at=site-0x401000;before=bytes.fromhex('e8e7751500')
    if patched[at:at+5]!=before:raise ValueError('Primary ranged spawn guard mismatch')
    after=b'\\xe8'+struct.pack('<i',sym['spawn_ranged_weapon_repaired']-site-5)
    patched[at:at+5]=after
    patches.append(dict(va=hex(site),before=before.hex(),after=after.hex(),purpose='scoped_primary_ranged_mode_filter'))
''' + t[b:]
    edit(S/'build_test.py',build)
    # Current release identifiers, diagnostics and paired file names.
    for path in S.glob('*.py'):
        edit(path,lambda t:t.replace("'OBT32'","'OBT33'").replace('OBT_RUNTIME_TEST_32','OBT_RUNTIME_TEST_33')
             .replace('TFOL_OBT_TEST_30.exe','TFOL_OBT_TEST_33.exe').replace('OBT_TEST_30.log','OBT_TEST_33.log').replace('OBT_TEST_30.dmp','OBT_TEST_33.dmp')
             .replace('OBT_LOCAL_32','OBT_LOCAL_33').replace('base_exe_version=30','base_exe_version=33'))
    edit(S/'build_test.py',lambda t:t.replace('TFOL OBT TEST 30','TFOL OBT TEST 33'))
    edit(S/'runtime.c',lambda t:t.replace('OBT_TEST_30','OBT_TEST_33').replace('TFOL OBT TEST 30','TFOL OBT TEST 33'))
    edit(S/'host_engine_test.c',lambda t:t.replace('?listen?dsport=1','?dsport=1'))
    edit(S/'validate_native.py',lambda t:t.replace("len(manifest['patches'])==15","len(manifest['patches'])==11")
         .replace(",('team_change_repaired',12)","").replace(",('jumppad_overlap_repaired',4)","")
         .replace('8 recovery patches plus 1 scoped AI-controller repair','8 recovery patches, scoped AI repair, local Login repair and ranged mode filter'))
    # Live clock governs production countdown. Tests supply now explicitly.
    edit(S/'native_bots.py',lambda t:t.replace("if match['state'] in ('selecting','ready'):\n            countdown=", "if match['state']=='selecting':\n            countdown=")
         .replace("base_now=now if now is not None else (match.get('last_poll_now') if match.get('last_poll_now') is not None else time.monotonic())", "base_now=time.monotonic() if now is None else now")
         .replace("        # Client UI countdown timer completed and requested LoadMapDataReq: release countdown gate if already Ready.","        # A client request cannot shorten the server's countdown.")
         .replace("        match['ready_deadline']=0\n", ""))
    # Refresh all client tables from the submitted catalogue; no stale .bytes vs PAK hashes.
    previous=[]
    for base in (BASE,ROOT/'gemini'):
        m=json.loads((base/'Release/ClientLanguages/manifest.json').read_text())
        previous+=m.get('previous_pak_sha256',[])+[v['pak_sha256'] for v in m['languages'].values()]
    (ROOT/'previous_paks.json').write_text(json.dumps(sorted(set(previous))))
    # Preserve the exact v26.1 launcher source except release labels. New cache isolates compiled UI.
    for name in ['Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs','Release/Server/LauncherSource/ReactivateStandalone.cs']:
        edit(OUT/name,lambda t:t.replace('Reactivate v24.1 · OBT31A','Reactivate v26.2 · OBT33').replace('OBT31A','OBT33'))
    source=OUT/'Reactivate/NativeDesktopBuilder/bootstrap_windows.c'
    edit(source,lambda t:t.replace('v26titfix','v26merge1').replace('OBT31 /','OBT33 /'))
    binary=OUT/'Release/Reactivate.exe';raw=binary.read_bytes()
    old='v26titfix'.encode('utf-16le');new='v26merge1'.encode('utf-16le');assert len(old)==len(new) and raw.count(old)==2
    raw=raw.replace(old,new);old='OBT31 /'.encode('utf-16le');assert raw.count(old)==1
    binary.write_bytes(raw.replace(old,'OBT33 /'.encode('utf-16le')))
    log('launcher_cache_bumped',file='Release/Reactivate.exe',sha256=sha(binary))
    edit(S/'test_hotfix29.py',lambda t:t.replace('v25-auth1','v26merge1').replace('Reactivate v25 · OBT32','Reactivate v26.2 · OBT33'))
    edit(S/'test_battle_init30.py',lambda t:t.replace("len(build['patches']),15","len(build['patches']),11"))
    edit(S/'test_pak_hotfix31a.py',lambda t:t.replace('def test_combat_changes_are_not_included(self):','def test_merged_native_matches_published_manifest(self):')
         .replace("'72d178a27e3bde738fb21bae475c371f7353c70001f0c56475240092f4eb0a93'", "json.loads((ROOT/'base_exe_manifest.json').read_text())['exe_sha256']"))
    # Old patch asserted two unsafe global modifications as successes. Check their preservation instead.
    edit(S/'test_obt32.py',lambda t:t.replace("bytes.fromhex('909090909090')","bytes.fromhex('89bb78060000')")
         .replace("bytes.fromhex('9090')","bytes.fromhex('7409')").replace("bytes.fromhex('85f67e3731f6eb36')","bytes.fromhex('837c242000a19489')"))
    edit(S/'run_tests.py',lambda t:t.replace("'test_obt32'","'test_obt32','test_merge33'").replace('TEST_RESULTS_32','TEST_RESULTS_33'))
    print('Reviewed native guards, countdown, launcher merge, release and migration fixes applied.')
if __name__=='__main__':main()
