"""Reproducible OBT29 packaging edits; no game-image changes or downloads."""
from pathlib import Path
import hashlib,json,struct

ROOT=Path(__file__).parent/'work_obt29/Reactivate_TFOL_OBT28_v21'

def replace_text(path,old,new,count=1):
    raw=path.read_bytes();bom=raw.startswith(b'\xef\xbb\xbf')
    text=raw.decode('utf-8-sig')
    if text.count(old)!=count:raise ValueError(f'Unexpected source {path}: {old[:60]}')
    text=text.replace(old,new)
    path.write_bytes((b'\xef\xbb\xbf' if bom else b'')+text.encode())

def main():
    source=ROOT/'Release/Server/LauncherSource/ReactivateStandalone.cs'
    mirror=ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs'
    if source.read_bytes()!=mirror.read_bytes():raise ValueError('Different launcher mirrors')
    for path in (source,mirror):
        replace_text(path,'Reactivate v21 HF29 · OBT28','Reactivate v22 · OBT29',3)
        replace_text(path,'                choose(false);','                choose(string.IsNullOrEmpty(_accountName));')
        start=path.read_text('utf-8-sig').index('        private async Task PrepareClientResources')
        end=path.read_text('utf-8-sig').index('        private static void StartChecked',start)
        old=path.read_text('utf-8-sig')[start:end]
        replace_text(path,old,'')
    native=ROOT/'Reactivate/NativeDesktopBuilder/bootstrap_windows.c'
    replace_text(native,'v21-auth1','v22-auth1',2)
    replace_text(native,'OBT28 / v22-auth1','OBT29 / v22-auth1')
    exe=ROOT/'Release/Reactivate.exe';before=exe.read_bytes()
    expected='b11a153e11b992bdb6e0d228f8e18045abeed2727d3eb758da178affb2ee1e25'
    if hashlib.sha256(before).hexdigest()!=expected:raise ValueError('Wrong bootstrap baseline')
    pe=struct.unpack_from('<I',before,0x3c)[0]
    optional=pe+24
    if before[pe:pe+4]!=b'PE\0\0' or struct.unpack_from('<H',before,optional)[0]!=0x10b:raise ValueError('Expected PE32')
    cert=struct.unpack_from('<II',before,optional+96+4*8)
    if cert!=(0,0):raise ValueError('Signed bootstrap must be rebuilt, not edited')
    data=before;edits=[]
    for old,new,count in [('v21-auth1','v22-auth1',2),('OBT28 / v22-auth1','OBT29 / v22-auth1',1)]:
        a,b=old.encode('utf-16le'),new.encode('utf-16le')
        if len(a)!=len(b) or data.count(a)!=count:raise ValueError('Unexpected bootstrap literals')
        edits.append(dict(old=old,new=new,count=count));data=data.replace(a,b)
    # The linker emitted no checksum; preserve that value and every other byte.
    if struct.unpack_from('<I',data,optional+64)[0]:raise ValueError('Expected zero PE checksum')
    exe.write_bytes(data)
    proof=dict(method='Exact equal-length UTF-16 version/cache literals only; not recompiled',
               baseline_sha256=expected,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),
               byte_differences=sum(a!=b for a,b in zip(before,data)),edits=edits,
               windows_executed=False,game_exe_changed=False)
    (ROOT/'BOOTSTRAP_VERSION29.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(proof))

if __name__=='__main__':main()
