"""Build the complete OBT29 update, with no databases, caches or test fixtures."""
import ast,hashlib,json
from pathlib import Path
import zipfile

BASE=Path(__file__).resolve().parent
ROOT=BASE/'work_obt29/Reactivate_TFOL_OBT28_v21'
OUTPUT=BASE/'Reactivate_TFOL_OBT29_v22_FULL.zip'
PREFIX='Reactivate_TFOL_OBT29_v22'

def sha(b):return hashlib.sha256(b).hexdigest()
def excluded(relative):
    return any(p in {'__pycache__','OBT_SERVER_DATA','OBT_LOCAL_STATE','.pytest_cache'}
               or p.startswith(('tmp','HF29_SOURCE_BACKUP_','OBT_ACCOUNT_BACKUP_'))
               for p in relative.parts) or relative.name=='HOTFIX29_APPLIED.json'
def write_json(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    tests=json.loads((ROOT/'Release/Server/SERVICE_VALIDATION.json').read_text())
    if not tests['passed'] or tests['tests_run']!=202 or tests['errors'] or tests['failures']:
        raise ValueError('Full OBT29 test run is required')
    raw=(ROOT/'Release/Server/ClientUpdate/TFOL_OBT.exe').read_bytes()
    if sha(raw)!='5451365a90b80d22b37fd9aa5791bcc124de83b48ccd74b160149b694763a29b':raise ValueError('Game EXE changed')
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and not excluded(p.relative_to(ROOT)))
    syntax=[]
    for p in files:
        if p.suffix=='.py':ast.parse(p.read_text('utf-8-sig'),filename=str(p));syntax.append(p.relative_to(ROOT).as_posix())
    source=ROOT/'Release/Server/LauncherSource/ReactivateStandalone.cs'
    mirror=ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs'
    if source.read_bytes()!=mirror.read_bytes():raise ValueError('Launcher mirrors differ')
    bootstrap=json.loads((ROOT/'BOOTSTRAP_VERSION29.json').read_text())
    if sha((ROOT/'Release/Reactivate.exe').read_bytes())!=bootstrap['sha256']:raise ValueError('Bootstrap differs')
    checkpoint=dict(release='OBT29/v22-auth1',baseline='OBT28/v21-auth1',
        baseline_archive_sha256='4ece38259ca4c1e039dd8a423a6836e87905abe3b802fc307d76a51a42a751de',
        service_tests=tests,python_ast_files=len(syntax),python_ast_passed=True,
        launcher_mirrors_identical=True,launcher_source_sha256=sha(source.read_bytes()),
        csharp_compiled=False,csharp_parser_available=False,windows_gui_executed=False,
        bootstrap_host_cases=10,bootstrap_host_cases_passed=True,bootstrap=bootstrap,
        game_exe_sha256=sha(raw),game_exe_changed=False,gameplay_runtime_verified=False,
        account_generation='20261016-obt29-fresh-accounts-v1',account_database_included=False,
        account_policy='Retire old test data once under InstanceLock; recoverable local backup, no import; keep OBT29 accounts.',
        fixes=['Password acknowledged before any resource install','Single prelaunch translation phase',
               'Read-denial diagnostics preserve path and Windows code','Busy UI controls and launch guard',
               'New bootstrap version/cache; normal Release/Reactivate.exe entry point',
               'Explicit one-time retirement of pre-OBT29 test accounts'],
        remaining=['Native Megatron victory observer and original nickname-popup integration incomplete',
                   'Windows GUI/compiler, real PvP/PvE bots, ally teams and damage need client testing',
                   'No new native combat hooks; game image identical to OBT28',
                   'Real sharing/ACL/security denial must be resolved on the test PC; no protection bypass'])
    write_json(ROOT/'CHECKPOINT_OBT29.json',checkpoint)
    write_json(ROOT/'SOURCE_AUDIT29.json',dict(python_ast_passed=True,python_files=syntax,
        pyflakes_executed=False,csharp_compilation_executed=False,csharp_syntax_parser_executed=False))
    # Historical evidence is retained explicitly as history, not current verification.
    history={'BOOTSTRAP_BUILD.json','BOOTSTRAP_VALIDATION.json','CSHARP_SYNTAX_CHECK.json','HOTFIX29_APPLIED.json'}
    payloads={}
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if not p.is_file() or excluded(rel) or rel.as_posix()=='FILE_MANIFEST.json':continue
        if p.suffix.lower() in {'.db','.sqlite3','.sqlite','.db3'}:raise ValueError('Database in release: '+str(rel))
        arc=rel.as_posix()
        if arc in history:arc='evidence/OBT28/'+arc
        payloads[arc]=p.read_bytes()
    # Keep the baseline manifest as historical provenance, with a current manifest at root.
    with zipfile.ZipFile(BASE/'upload/Reactivate_TFOL_OBT28_v21_AUTH_CHECKPOINT(1).zip') as archive:
        baseline=json.loads(archive.read('Reactivate_TFOL_OBT28_v21/FILE_MANIFEST.json'))
    payloads['evidence/OBT28/FILE_MANIFEST.json']=(json.dumps(baseline,indent=2)+'\n').encode()
    payloads['evidence/OBT29/finish_obt29.py']=(BASE/'finish_obt29.py').read_bytes()
    payloads['evidence/OBT29/package_obt29.py']=Path(__file__).read_bytes()
    manifest=dict(release='OBT29/v22-auth1',files={p:dict(bytes=len(b),sha256=sha(b)) for p,b in sorted(payloads.items())})
    payloads['FILE_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,b in sorted(payloads.items()):z.writestr(PREFIX+'/'+name,b)
    with zipfile.ZipFile(OUTPUT) as z:
        if z.testzip() is not None:raise ValueError('Archive CRC verification failed')
        for name,info in manifest['files'].items():
            b=z.read(PREFIX+'/'+name)
            if len(b)!=info['bytes'] or sha(b)!=info['sha256']:raise ValueError('Archive manifest mismatch: '+name)
        for required in ['Release/Reactivate.exe','Release/Server/python/python.exe',
                         'Release/Server/ClientUpdate/TFOL_OBT.exe','Release/START_HERE_RU.txt']:
            if PREFIX+'/'+required not in z.namelist():raise ValueError('Missing complete release component: '+required)
    receipt=dict(file=str(OUTPUT),bytes=OUTPUT.stat().st_size,sha256=sha(OUTPUT.read_bytes()),files=len(payloads),validation=checkpoint)
    write_json(BASE/'OBT29_PACKAGE_RECEIPT.json',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k!='validation'}))

if __name__=='__main__':main()
