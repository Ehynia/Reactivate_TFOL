"""Package the full targeted OBT30 test update, without user data/build inputs."""
from pathlib import Path
import ast,hashlib,json,zipfile
BASE=Path(__file__).resolve().parent
ROOT=BASE/'work_obt30/Reactivate_TFOL_OBT29_v22'
SERVER=ROOT/'Release/Server'
PREFIX='Reactivate_TFOL_OBT30_v23'
OUTPUT=BASE/'Reactivate_TFOL_OBT30_v23_BATTLE_INIT_TEST_FULL.zip'
EXPECTED='b560833e8006e9575d365dee47bbf94eca959e4e03530be0a808cb3a18b41eef'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def raw_json(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def excluded(rel):
    if any(p=='__pycache__' or p.startswith('tmp') or p in {'OBT_SERVER_DATA','OBT_LOCAL_STATE'} for p in rel.parts):return True
    if rel.as_posix() in {'Release/obt27_recovered.exe','Release/obt_current_recovered.exe',
        'Release/OBT_original_code_rva_00001000.bin','Release/OBT_original_tvm_rva_0293b000.bin',
        'Release/Server/TFOL_OBT_TEST_30.exe','Release/Server/runtime.bin'}:return True
    return rel.suffix in {'.o','.elf','.pyc'}

def main():
    service=json.loads((SERVER/'SERVICE_VALIDATION.json').read_text())
    if service['tests_run']!=211 or not service['passed'] or service['errors'] or service['failures']:raise ValueError('Full passing tests required')
    native=json.loads((SERVER/'NATIVE_VALIDATION.json').read_text())
    if native['passed']!=11 or native['exe_sha256']!=EXPECTED:raise ValueError('Native validation missing')
    build=json.loads((SERVER/'build_manifest.json').read_text())
    if json.loads((SERVER/'base_exe_manifest.json').read_text())!=build:raise ValueError('Published manifest differs')
    if sha((SERVER/'ClientUpdate/TFOL_OBT.exe').read_bytes())!=EXPECTED:raise ValueError('Wrong client')
    source=SERVER/'LauncherSource/ReactivateStandalone.cs'
    if source.read_bytes()!=(ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs').read_bytes():raise ValueError('Launcher mirrors differ')
    bootstrap=json.loads((ROOT/'BOOTSTRAP_VERSION30.json').read_text())
    if sha((ROOT/'Release/Reactivate.exe').read_bytes())!=bootstrap['sha256']:raise ValueError('Wrong bootstrap')
    proof=dict(release='OBT30/v23-auth1',report_sha256=sha((BASE/'upload/OBT_LOCAL_27_REPORT_20261016_224449_503295.zip').read_bytes()),
        confirmed_bug='Both manual battle URLs omit mapid; original InitGame independently reads mapid into +0x5a8.',
        misleading_error='Zero mapid logs invalid SubGameMode using the nonzero submode argument.',
        instructions=[dict(va='0x5db961',bytes='68dc213302',meaning='push UTF16 mapid at 0x23321dc'),
                      dict(va='0x5db980',bytes='8983a8050000',meaning='Store parsed mapid at GameMode+0x5a8'),
                      dict(va='0x5db99a',bytes='83bba805000000',meaning='Check mapid for zero'),
                      dict(va='0x5db9a3',bytes='ffb39c050000',meaning='Print submode (+0x59c), not mapid, on failure')],
        old_urls=['open /Game/Maps/PVEWRoom?Game=PVEDEFEND?submode=1007?BotFill=5?MaxPlayers=5?StartPawnID=9?dsport=1',
                  'open /Game/Maps/LittleTown?Game=TRW?submode=1005?BotFill=12?MaxPlayers=12?StartPawnID=14?dsport=1'],
        fixed_map_ids=dict(PVEWRoom=2001,LittleTown=201),rule_ids_changed=False,
        report_ds_send_failures=6,report_missing_animation_array_warnings=355,
        pve_team_root_cause_fully_proven=False,pvp_spawn_root_cause_fully_proven=False,
        gameplay_executed_here=False,team_or_damage_overrides_added=False,teleport_fallback_added=False)
    (ROOT/'BATTLE_INIT_PROOF30.json').write_bytes(raw_json(proof))
    paths=sorted(p for p in ROOT.rglob('*') if p.is_file() and not excluded(p.relative_to(ROOT)))
    python=[]
    for p in paths:
        if p.suffix=='.py':ast.parse(p.read_text('utf-8-sig'),filename=str(p));python.append(p.relative_to(ROOT).as_posix())
    checkpoint=dict(release='OBT30/v23-auth1',purpose='Targeted battle-init test; not a fully working PvP/PvE release',
        baseline_archive_sha256=sha((BASE/'Reactivate_TFOL_OBT29_v22_FULL.zip').read_bytes()),
        service_tests=service,native_validation=native,bootstrap_host_cases_passed=10,
        python_ast_files=len(python),python_ast_passed=True,csharp_compilation_executed=False,windows_gui_executed=False,
        game_exe_changed=True,game_exe_sha256=EXPECTED,original_text_hash=build['original_code_sha256'],
        text_patch_count=len(build['patches']),native_rebuild_reproduced_from_current_image=True,
        account_generation='20261016-obt29-fresh-accounts-v1',accounts_reset_again=False,databases_included=False,
        status=dict(mapid_added_to_every_manual_route=True,team_membership_verified=False,spawn_position_verified=False,
                    pve_wave_behavior_verified=False,gameplay_verified=False),
        remaining=['Client test needed for map initialization, teams and spawn','DS game-channel errors still unresolved',
                   'Missing animation data warnings still unresolved','Megatron completion/nickname-popup integration incomplete'])
    (ROOT/'CHECKPOINT_OBT30.json').write_bytes(raw_json(checkpoint))
    (ROOT/'SOURCE_AUDIT30.json').write_bytes(raw_json(dict(python_ast_files=python,passed=True,pyflakes_executed=False,
         csharp_syntax_parser_executed=False,csharp_compilation_executed=False)))
    payloads={}
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if not p.is_file() or excluded(rel) or rel.as_posix()=='FILE_MANIFEST.json':continue
        if p.suffix.lower() in {'.db','.sqlite3','.sqlite','.dmp'}:raise ValueError('Unexpected user data: '+str(rel))
        payloads[rel.as_posix()]=p.read_bytes()
    payloads['evidence/OBT29/FILE_MANIFEST.json']=(ROOT/'FILE_MANIFEST.json').read_bytes()
    for name in ['recover_build30.py','prepare_version30.py','package_obt30.py']:
        payloads['evidence/OBT30/'+name]=(BASE/name).read_bytes()
    manifest=dict(release='OBT30/v23-auth1',files={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(payloads.items())})
    payloads['FILE_MANIFEST.json']=raw_json(manifest)
    with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,raw in sorted(payloads.items()):archive.writestr(PREFIX+'/'+name,raw)
    with zipfile.ZipFile(OUTPUT) as archive:
        if archive.testzip():raise ValueError('Archive CRC failed')
        for name,row in manifest['files'].items():
            raw=archive.read(PREFIX+'/'+name)
            if len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:raise ValueError('Archive hash mismatch')
        for name in ['Release/Reactivate.exe','Release/Server/python/python.exe','Release/Server/ClientUpdate/TFOL_OBT.exe',
                     'Release/START_HERE_RU.txt','Release/Server/test_battle_init30.py']:
            archive.getinfo(PREFIX+'/'+name)
    receipt=dict(file=str(OUTPUT),bytes=OUTPUT.stat().st_size,sha256=sha(OUTPUT.read_bytes()),files=len(payloads),checkpoint=checkpoint)
    (BASE/'OBT30_PACKAGE_RECEIPT.json').write_bytes(raw_json(receipt))
    print(json.dumps({k:v for k,v in receipt.items() if k!='checkpoint'}))

if __name__=='__main__':main()
