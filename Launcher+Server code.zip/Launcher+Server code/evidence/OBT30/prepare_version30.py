"""Version-only mechanical edits for the new native test build."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).parent/'work_obt30/Reactivate_TFOL_OBT29_v22'
SERVER=ROOT/'Release/Server'

def edit(path,pairs):
    raw=path.read_bytes();bom=b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b''
    text=raw.decode('utf-8-sig')
    for old,new in pairs:
        if old not in text:raise ValueError('Missing version token: '+str(path)+' '+old)
        text=text.replace(old,new)
    path.write_bytes(bom+text.encode())

def main():
    for name in ['server.py','server_main.py','launcher_entry.py','capabilities.py','test_launcher_integration.py']:
        edit(SERVER/name,[("'OBT29'","'OBT30'")])
    edit(SERVER/'open_admin.py',[("'OBT28','OBT29'","'OBT28','OBT29','OBT30'")])
    for name in ['build_test.py','runtime.c']:
        edit(SERVER/name,[('TEST_27','TEST_30'),('TEST 27','TEST 30')])
    edit(SERVER/'client_runner.py',[('TEST_27','TEST_30'),('LOCAL_27','LOCAL_30'),('base_exe_version=27','base_exe_version=30')])
    for name in ['validate_native.py','capabilities.py','test_bot_modes26.py']:
        edit(SERVER/name,[('TEST_27','TEST_30')])
    edit(SERVER/'launch_contract.py',[("'TFOL_OBT_TEST_27.exe',","'TFOL_OBT_TEST_27.exe','TFOL_OBT_TEST_30.exe',")])
    for path in [SERVER/'LauncherSource/ReactivateStandalone.cs',ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs']:
        edit(path,[('Reactivate v22 · OBT29','Reactivate v23 · OBT30')])
    edit(SERVER/'test_hotfix29.py',[('v22-auth1','v23-auth1'),('OBT29 / v23-auth1','OBT30 / v23-auth1'),('Reactivate v22 · OBT29','Reactivate v23 · OBT30')])
    edit(ROOT/'Reactivate/NativeDesktopBuilder/bootstrap_windows.c',[('v22-auth1','v23-auth1'),('OBT29 / v23-auth1','OBT30 / v23-auth1')])
    exe=ROOT/'Release/Reactivate.exe';before=exe.read_bytes()
    if hashlib.sha256(before).hexdigest()!='7027063112025a3a2f3fde954974bdafa616fb662e6ebb6828a753cf7cf840e4':raise ValueError('Wrong OBT29 bootstrap')
    data=before
    for old,new,count in [('v22-auth1','v23-auth1',2),('OBT29 / v23-auth1','OBT30 / v23-auth1',1)]:
        a,b=old.encode('utf-16le'),new.encode('utf-16le')
        if len(a)!=len(b) or data.count(a)!=count:raise ValueError('Unexpected version literal')
        data=data.replace(a,b)
    exe.write_bytes(data)
    (ROOT/'BOOTSTRAP_VERSION30.json').write_text(json.dumps(dict(baseline_sha256=hashlib.sha256(before).hexdigest(),
        sha256=hashlib.sha256(data).hexdigest(),method='equal-length version/cache literals only; not recompiled',
        byte_differences=sum(a!=b for a,b in zip(before,data)),windows_executed=False),indent=2)+'\n')
    print('VERSION30_READY; ACCOUNT GENERATION UNCHANGED')

if __name__=='__main__':main()
