"""Restore verified plaintext build inputs from the supplied OBT27/29 image."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).parent/'work_obt30/Reactivate_TFOL_OBT29_v22/Release'
sys.path.insert(0,str(ROOT/'Server'))
from pe_read import PE

def main():
    image=PE(ROOT/'Server/ClientUpdate/TFOL_OBT.exe')
    manifest=json.loads((ROOT/'Server/base_exe_manifest.json').read_text())
    if hashlib.sha256(image.b).hexdigest()!='5451365a90b80d22b37fd9aa5791bcc124de83b48ccd74b160149b694763a29b':raise ValueError('Wrong pinned image')
    code=bytearray(image.read(0x401000,32436224))
    if len(manifest['patches'])!=9:raise ValueError('Expected nine baseline patches')
    for patch in manifest['patches']:
        pos=int(patch['va'],16)-0x401000
        before,after=bytes.fromhex(patch['before']),bytes.fromhex(patch['after'])
        if code[pos:pos+len(after)]!=after:raise ValueError('Baseline patch mismatch')
        code[pos:pos+len(before)]=before
    tvm=image.read(0x2d3b000,24576)
    if hashlib.sha256(code).hexdigest()!='4ca7cb9d4517e8319d2ba158dd02130011f56e59483d8ff43adf751938b9d4b1':raise ValueError('Original .text mismatch')
    if hashlib.sha256(tvm).hexdigest()!='8e335f3665c65447a42e970aee28e5d91fc8e927d7736eb8fe0cc6490379fde3':raise ValueError('Original TVM mismatch')
    for name,raw in [('obt27_recovered.exe',image.b),('OBT_original_code_rva_00001000.bin',code),('OBT_original_tvm_rva_0293b000.bin',tvm)]:
        path=ROOT/name
        if path.exists() and path.read_bytes()!=raw:raise ValueError('Different input exists: '+name)
        path.write_bytes(raw)
    print('PINNED_BUILD_INPUTS_RECOVERED')

if __name__=='__main__':main()
