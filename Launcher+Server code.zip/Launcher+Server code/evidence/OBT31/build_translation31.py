"""Reproducible offline translation/resource updates; original PAKs untouched."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).parent/'work_obt31/Reactivate_TFOL_OBT30_v23'
SERVER=ROOT/'Release/Server';BUNDLE=ROOT/'Release/ClientLanguages'
sys.path.insert(0,str(SERVER))
from build_localization import UI
from build_client_resources import build

def main():
    old=json.loads((BUNDLE/'manifest.json').read_text())
    previous=dict(paks=sorted(set(old.get('previous_pak_sha256',[]))|{v['pak_sha256'] for v in old['languages'].values()}),tables={})
    for name,row in old['tables'].items():previous['tables'][name]=sorted(set(row.get('previous_sha256',[]))|set(row['languages'].values()))
    (SERVER/'fixtures/client30_hashes.json').write_text(json.dumps(previous,indent=2)+'\n')
    dictionary=json.loads((BUNDLE/'ui_dictionary.json').read_text())
    for source,(ru,en) in UI.items():dictionary['entries'].setdefault(source,dict(ru=ru,en=en))
    (BUNDLE/'ui_dictionary.json').write_text(json.dumps(dictionary,ensure_ascii=False,indent=2)+'\n')
    catalog=ROOT/'LocalizationSource/localization_catalog.json';data=json.loads(catalog.read_text())
    translations={
      '追命导弹':('Самонав.','Homing'),
      '变形发射三枚具有跟踪效果的导弹':('Трансформируется и выпускает три самонаводящиеся ракеты.','Transforms and fires three homing missiles.'),
      '冲刺':('Рывок','Dash'),
      '快速冲刺一段距离':('Быстрый рывок вперёд.','Dashes forward a short distance.'),
      '喷射跳跃':('Прыжок','Jet jump'),
      '利用喷射的反作用力进行跳跃':('Прыжок с помощью реактивной тяги.','Uses jet thrust to jump.'),
      '末日震击':('Удар','Smash'),
      '挥舞链锤向选定方向猛击地面':('Ударяет цепным молотом по земле в выбранном направлении.','Slams the ground in the selected direction with his chain hammer.'),
      '威震天是狂派的领袖，心狠手辣的首领。他称得上是狂派中最为优秀的统帅和战士，多名博派领袖均死在其枪下，在他的领导下狂派维持了对塞伯坦长达千万年的极端统治':(
          'Мегатрон — безжалостный вождь десептиконов, один из их лучших полководцев и воинов. От его руки пали многие лидеры автоботов. Под его началом десептиконы жестоко правили Кибертроном десять миллионов лет.',
          'Megatron is the ruthless leader of the Decepticons and one of their finest commanders and warriors. Many Autobot leaders have fallen to him. Under his command, the Decepticons ruled Cybertron with an iron fist for ten million years.'),
      '盖亚链锤':('Молот Геи','Gaia hammer'),
      '【左键】：末日挥砍-三连击':('【ЛКМ】: тройной удар','【LMB】: triple strike'),
      '冰冷霸道的武器，代表着绝对的力量\n\n【左键】：<LightGreen>末日挥砍</>\n伤害：<TaskAct>★★★★</>\n攻击速度：<TaskAct>★★★</>\n攻击范围：<TaskAct>★★★★★</>':(
          'Грозное оружие, воплощающее абсолютную мощь.\n\n【ЛКМ】: <LightGreen>Роковой удар</>\nУрон: <TaskAct>★★★★</>\nСкорость: <TaskAct>★★★</>\nДальность: <TaskAct>★★★★★</>',
          'A fearsome weapon embodying absolute power.\n\n【LMB】: <LightGreen>Doom strike</>\nDamage: <TaskAct>★★★★</>\nSpeed: <TaskAct>★★★</>\nReach: <TaskAct>★★★★★</>')
    }
    counts=dict(ru=0,en=0)
    for row in data['entries'].values():
        if row['original'] not in translations:continue
        row['ru'],row['en']=translations[row['original']]
        counts['ru']+=1;counts['en']+=1
    catalog.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    result=build(catalog)
    result['content_revision']=31
    result['coverage']=dict(backend='verified_MSES_fields_plus_UMG_legacy_locres',table_count=len(result['tables']),
        role_biography_offset=18484,weapon_description_offsets=[2592,3616],
        ui_dictionary_sources=len(dictionary['entries']),ui_source_scan='Selected client original PAKs; prelaunch only and cached',
        textures_translated=False,full_game_translation_verified=False)
    (BUNDLE/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(offline_additions=counts,ui_dictionary_sources=len(dictionary['entries']))))

if __name__=='__main__':main()
