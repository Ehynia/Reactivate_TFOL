"""Package OBT31 localization test, preserving OBT30 native battle client."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'work_obt31/Reactivate_TFOL_OBT30_v23'
SERVER = ROOT / 'Release/Server'
PREFIX = 'Reactivate_TFOL_OBT31_v24'
OUTPUT = BASE / 'Reactivate_TFOL_OBT31_v24_UI_LOCALE_TEST_FULL.zip'
EXPECTED_NATIVE = 'b560833e8006e9575d365dee47bbf94eca959e4e03530be0a808cb3a18b41eef'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def excluded(rel):
    if any(p == '__pycache__' or p.startswith('tmp') or p in {
        'OBT_SERVER_DATA', 'OBT_LOCAL_STATE'} for p in rel.parts):
        return True
    if rel.as_posix() in {
        'Release/obt27_recovered.exe', 'Release/obt_current_recovered.exe',
        'Release/OBT_original_code_rva_00001000.bin',
        'Release/OBT_original_tvm_rva_0293b000.bin',
        'Release/Server/TFOL_OBT_TEST_30.exe', 'Release/Server/runtime.bin'}:
        return True
    return rel.suffix in {'.o', '.elf', '.pyc'}


def main():
    service = json.loads((SERVER / 'SERVICE_VALIDATION.json').read_text())
    assert service['tests_run'] == 224 and service['passed']
    assert service['errors'] == service['failures'] == 0
    assert sha((SERVER / 'ClientUpdate/TFOL_OBT.exe').read_bytes()) == EXPECTED_NATIVE
    assert (SERVER / 'LauncherSource/ReactivateStandalone.cs').read_bytes() == (
        ROOT / 'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs').read_bytes()
    bootstrap = json.loads((ROOT / 'BOOTSTRAP_VERSION31.json').read_text())
    assert sha((ROOT / 'Release/Reactivate.exe').read_bytes()) == bootstrap['sha256']
    resources = json.loads((ROOT / 'Release/ClientLanguages/manifest.json').read_text())
    dictionary = json.loads((ROOT / 'Release/ClientLanguages/ui_dictionary.json').read_text())
    proof = json.loads((ROOT / 'UI_FORMAT_PROOF31.json').read_text())
    assert len(dictionary['entries']) == 184 and proof['native_locres_rows'] == 4801
    for language in ['ru', 'en']:
        lang = resources['languages'][language]
        assert lang['translated_fields'] == 5249 and len(lang['tables']) == 33
        pak = ROOT / 'Release/ClientLanguages' / language / 'TFOL_ReactivateClient_P.pak'
        assert sha(pak.read_bytes()) == lang['pak_sha256']
    python_files = []
    for path in sorted(ROOT.rglob('*.py')):
        rel = path.relative_to(ROOT)
        if excluded(rel):
            continue
        ast.parse(path.read_text('utf-8-sig'), filename=str(path))
        python_files.append(rel.as_posix())
    checkpoint = dict(
        release='OBT31/v24-auth1', purpose='Targeted client-side UMG localization test; not complete translation',
        baseline_archive_sha256=sha((BASE / 'Reactivate_TFOL_OBT30_v23_BATTLE_INIT_TEST_FULL.zip').read_bytes()),
        service_tests=service, bootstrap_host_cases_passed=10, python_ast_files=len(python_files),
        python_ast_passed=True, csharp_compilation_executed=False, windows_gui_executed=False,
        game_exe_changed=False, native_runtime_version=30, game_exe_sha256=EXPECTED_NATIVE,
        account_generation='20261016-obt29-fresh-accounts-v1', accounts_reset_again=False,
        databases_included=False, original_game_paks_included=False,
        localization=dict(
            translated_mses_fields_per_language=5249, tables_per_language=33,
            reviewed_ui_labels=184, original_locres_rows_verified=4801,
            original_umg_widgets_inspected=3, client_side_locres=True,
            original_ui_assets_modified=False, global_slate_hooks=False,
            scan_time_limit_seconds=12, scan_byte_limit=128 * 1024 * 1024,
            scan_prelaunch_only=True, partial_scan_resumable=True,
            launcher_network_budget_seconds=8, service_daily_character_quota=5000,
            full_game_translation_verified=False, rendered_in_game_verified=False,
            texture_text_supported=False),
        remaining=[
            'Windows RU/EN display and layout require client test',
            'Unrecognized/invariant FText and image text are not covered',
            'Service availability/quota and long-source limit leave untranslated strings',
            'Combat client unchanged from OBT30; bot teams/damage/spawn remain unverified',
            'Megatron completion/nickname-popup integration incomplete'])
    (ROOT / 'CHECKPOINT_OBT31.json').write_bytes(json_bytes(checkpoint))
    (ROOT / 'SOURCE_AUDIT31.json').write_bytes(json_bytes(dict(
        python_ast_files=python_files, passed=True, pyflakes_executed=False,
        csharp_compilation_executed=False, windows_game_executed=False)))
    payloads = {}
    for path in sorted(ROOT.rglob('*')):
        rel = path.relative_to(ROOT)
        if not path.is_file() or excluded(rel) or rel.as_posix() == 'FILE_MANIFEST.json':
            continue
        if path.suffix.lower() in {'.db', '.sqlite3', '.sqlite', '.dmp'}:
            raise ValueError('Unexpected user data: ' + str(rel))
        payloads[rel.as_posix()] = path.read_bytes()
    payloads['evidence/OBT30/FILE_MANIFEST.json'] = (ROOT / 'FILE_MANIFEST.json').read_bytes()
    for name in ['build_translation31.py', 'prepare_version31.py', 'package_obt31.py']:
        payloads['evidence/OBT31/' + name] = (BASE / name).read_bytes()
    manifest = dict(release='OBT31/v24-auth1', files={
        name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(payloads.items())})
    payloads['FILE_MANIFEST.json'] = json_bytes(manifest)
    with zipfile.ZipFile(OUTPUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, raw in sorted(payloads.items()):
            archive.writestr(PREFIX + '/' + name, raw)
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        for name, row in manifest['files'].items():
            raw = archive.read(PREFIX + '/' + name)
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        for name in [
            'Release/Reactivate.exe', 'Release/Server/python/python.exe',
            'Release/Server/ClientUpdate/TFOL_OBT.exe', 'Release/START_HERE_RU.txt',
            'Release/ClientLanguages/ui_localization.py', 'Release/ClientLanguages/ue_locres.py',
            'Release/Server/test_ui_translation31.py']:
            archive.getinfo(PREFIX + '/' + name)
    receipt = dict(file=str(OUTPUT), bytes=OUTPUT.stat().st_size,
                   sha256=sha(OUTPUT.read_bytes()), files=len(payloads), checkpoint=checkpoint)
    (BASE / 'OBT31_PACKAGE_RECEIPT.json').write_bytes(json_bytes(receipt))
    print(json.dumps({key: value for key, value in receipt.items() if key != 'checkpoint'}))


if __name__ == '__main__':
    main()
