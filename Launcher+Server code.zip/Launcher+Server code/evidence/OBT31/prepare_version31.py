"""Bump wrapper/UI versions only; retain verified native OBT30 and accounts."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).parent/'work_obt31/Reactivate_TFOL_OBT30_v23'
SERVER=ROOT/'Release/Server'
def edit(path,pairs):
    raw=path.read_bytes();bom=b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b'';text=raw.decode('utf-8-sig')
    for old,new in pairs:
        if old not in text:raise ValueError('Missing version snippet '+old+' in '+str(path))
        text=text.replace(old,new)
    path.write_bytes(bom+text.encode())
def main():
    for name in ['server.py','server_main.py','launcher_entry.py','capabilities.py','test_launcher_integration.py']:
        edit(SERVER/name,[("'OBT30'","'OBT31'")])
    edit(SERVER/'open_admin.py',[("'OBT29','OBT30'","'OBT29','OBT30','OBT31'")])
    edit(SERVER/'client_runner.py',[('OBT_LOCAL_30','OBT_LOCAL_31')])
    for path in [SERVER/'LauncherSource/ReactivateStandalone.cs',ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs']:
        edit(path,[('Reactivate v23 · OBT30','Reactivate v24 · OBT31')])
    edit(SERVER/'test_hotfix29.py',[('v23-auth1','v24-auth1'),('OBT30 / v24-auth1','OBT31 / v24-auth1'),('Reactivate v23 · OBT30','Reactivate v24 · OBT31')])
    edit(ROOT/'Reactivate/NativeDesktopBuilder/bootstrap_windows.c',[('v23-auth1','v24-auth1'),('OBT30 / v24-auth1','OBT31 / v24-auth1')])
    exe=ROOT/'Release/Reactivate.exe';before=exe.read_bytes()
    previous=json.loads((ROOT/'BOOTSTRAP_VERSION30.json').read_text())
    if hashlib.sha256(before).hexdigest()!=previous['sha256']:raise ValueError('Wrong bootstrap')
    data=before
    for old,new,count in [('v23-auth1','v24-auth1',2),('OBT30 / v24-auth1','OBT31 / v24-auth1',1)]:
        a,b=old.encode('utf-16le'),new.encode('utf-16le')
        if len(a)!=len(b) or data.count(a)!=count:raise ValueError('Unexpected bootstrap literal')
        data=data.replace(a,b)
    exe.write_bytes(data)
    (ROOT/'BOOTSTRAP_VERSION31.json').write_text(json.dumps(dict(sha256=hashlib.sha256(data).hexdigest(),
        baseline_sha256=hashlib.sha256(before).hexdigest(),method='version/cache literals only; not recompiled',
        byte_differences=sum(a!=b for a,b in zip(before,data)),windows_executed=False),indent=2)+'\n')
    print('WRAPPER31_READY; NATIVE30_AND_ACCOUNT_GENERATION_UNCHANGED')
if __name__=='__main__':main()
