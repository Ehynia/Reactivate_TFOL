"""Repack OBT31 with the original client's verified +100 PAK count bias."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT=Path(__file__).parent/'work_obt31a/Reactivate_TFOL_OBT31_v24'
SERVER=ROOT/'Release/Server'
LANG=ROOT/'Release/ClientLanguages'

def edit(path,pairs):
    raw=path.read_bytes();bom=b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b''
    text=raw.decode('utf-8-sig')
    for a,b in pairs:
        if a not in text:raise ValueError('Expected literal '+a+' in '+str(path))
        text=text.replace(a,b)
    path.write_bytes(bom+text.encode())

def main():
    spec=importlib.util.spec_from_file_location('pack31a',LANG/'ue_locres.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    manifest=json.loads((LANG/'manifest.json').read_text())
    for language in ('ru','en','zh'):
        folder=LANG/language
        row=manifest['languages'][language]
        manifest['previous_pak_sha256'].append(row['pak_sha256'])
        files={'Bytes/bytes_for_bothside/'+name:(folder/'tables'/name).read_bytes() for name in manifest['tables']}
        raw=module.build_pak(files);(folder/'TFOL_ReactivateClient_P.pak').write_bytes(raw)
        row.update(pak_sha256=hashlib.sha256(raw).hexdigest(),pak_bytes=len(raw))
    manifest['previous_pak_sha256']=sorted(set(manifest['previous_pak_sha256']))
    manifest.update(pak_index_count_bias=100,hotfix='OBT31A')
    (LANG/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    for name in ['server.py','server_main.py','launcher_entry.py','capabilities.py','test_launcher_integration.py']:
        edit(SERVER/name,[("'OBT31'","'OBT31A'")])
    edit(SERVER/'open_admin.py',[("'OBT30','OBT31'","'OBT30','OBT31','OBT31A'")])
    edit(SERVER/'client_runner.py',[('OBT_LOCAL_31','OBT_LOCAL_31A')])
    edit(SERVER/'run_tests.py',[('TEST_RESULTS_31','TEST_RESULTS_31A'),("'test_ui_translation31'","'test_ui_translation31','test_pak_hotfix31a'")])
    for path in [SERVER/'LauncherSource/ReactivateStandalone.cs',ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs']:
        edit(path,[('Reactivate v24 · OBT31','Reactivate v24.1 · OBT31A')])
    edit(SERVER/'test_hotfix29.py',[('v24-auth1','v24-auth2'),('Reactivate v24 · OBT31','Reactivate v24.1 · OBT31A')])
    edit(ROOT/'Reactivate/NativeDesktopBuilder/bootstrap_windows.c',[('v24-auth1','v24-auth2')])
    finish_bootstrap()
    print('OBT31A_REPACKED; NATIVE30_UNCHANGED')

def finish_bootstrap():
    exe=ROOT/'Release/Reactivate.exe';before=exe.read_bytes()
    assert hashlib.sha256(before).hexdigest()==json.loads((ROOT/'BOOTSTRAP_VERSION31.json').read_text())['sha256']
    old,new='v24-auth1'.encode('utf-16le'),'v24-auth2'.encode('utf-16le')
    assert before.count(old)==2 and len(old)==len(new)
    after=before.replace(old,new);exe.write_bytes(after)
    (ROOT/'BOOTSTRAP_VERSION31A.json').write_text(json.dumps(dict(sha256=hashlib.sha256(after).hexdigest(),baseline_sha256=hashlib.sha256(before).hexdigest(),method='cache version literals only; not recompiled',windows_executed=False),indent=2)+'\n')

if __name__=='__main__':
    import sys
    if sys.argv[1:]==['--finish-bootstrap']:finish_bootstrap()
    else:main()
