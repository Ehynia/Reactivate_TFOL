"""Package only the urgent OBT31 translation fix, excluding battle WIP32."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile

BASE=Path(__file__).parent
ROOT=BASE/'work_obt31a/Reactivate_TFOL_OBT31_v24'
SERVER=ROOT/'Release/Server'
OUT=BASE/'Reactivate_TFOL_OBT31A_v24_1_TRANSLATION_HOTFIX_FULL.zip'
PREFIX='Reactivate_TFOL_OBT31A_v24_1'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def excluded(rel):
    return any(p=='__pycache__' or p.startswith('tmp') or p in {'OBT_SERVER_DATA','OBT_LOCAL_STATE'} for p in rel.parts) or rel.suffix in {'.pyc','.o','.elf'}

def main():
    validation=json.loads((SERVER/'SERVICE_VALIDATION.json').read_text())
    assert validation['passed'] and validation['tests_run']==230
    assert validation['errors']==validation['failures']==0
    native=sha((SERVER/'ClientUpdate/TFOL_OBT.exe').read_bytes())
    assert native=='b560833e8006e9575d365dee47bbf94eca959e4e03530be0a808cb3a18b41eef'
    assert not (SERVER/'team_login_repair.h').exists()
    assert (SERVER/'LauncherSource/ReactivateStandalone.cs').read_bytes()==(ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs').read_bytes()
    assert sha((ROOT/'Release/Reactivate.exe').read_bytes())==json.loads((ROOT/'BOOTSTRAP_VERSION31A.json').read_text())['sha256']
    reports=[]
    for name,folder in [('OBT_LOCAL_31_REPORT_20261016_234620_256791.zip','report31_234620'),('OBT_LOCAL_31_REPORT_20261016_234731_656923.zip','report31_234731')]:
        receipt=json.loads((BASE/folder/'client_resources.json').read_text())
        reports.append(dict(sha256=sha((BASE/'upload'/name).read_bytes()),language=receipt['language'],ui=receipt['ui_translation_summary']))
    proof=dict(release='OBT31A/v24.1',cause='OBT PAK index loader unconditionally subtracts 100 from declared file count',
        instruction=dict(va='0x1e31f3c',bytes='836c241c64',meaning='sub dword ptr [esp+0x1c], 100'),
        old_ui_pack_file_count=7,old_native_count=-93,new_ui_pack_file_count=107,new_native_count=7,
        old_mses_pack_file_count=33,old_native_mses_count=-67,new_mses_pack_file_count=133,new_native_mses_count=33,
        all_three_pack_writers_corrected=True,native_game_sha256=native,battle_wip_included=False,
        reports=reports,windows_rendering_verified=False,full_translation_verified=False)
    (ROOT/'PAK_FORMAT_PROOF31A.json').write_bytes(encoded(proof))
    py=[]
    for path in sorted(ROOT.rglob('*.py')):
        if excluded(path.relative_to(ROOT)):continue
        ast.parse(path.read_text('utf-8-sig'),filename=str(path));py.append(path.relative_to(ROOT).as_posix())
    checkpoint=dict(release='OBT31A/v24.1',service_tests=validation,python_ast_files=len(py),native_game_version=30,
        native_game_sha256=native,battle_wip_included=False,account_reset_again=False,
        localization_content_unchanged=True,pak_index_count_bias=100,windows_rendering_verified=False,
        full_translation_verified=False,baseline_zip_sha256=sha((BASE/'Reactivate_TFOL_OBT31_v24_UI_LOCALE_TEST_FULL.zip').read_bytes()))
    (ROOT/'CHECKPOINT_OBT31A.json').write_bytes(encoded(checkpoint))
    (ROOT/'SOURCE_AUDIT31A.json').write_bytes(encoded(dict(python_ast_files=py,passed=True,csharp_compiled_here=False,game_executed_here=False)))
    payload={}
    for path in sorted(ROOT.rglob('*')):
        rel=path.relative_to(ROOT)
        if not path.is_file() or excluded(rel) or rel.as_posix()=='FILE_MANIFEST.json':continue
        assert rel.suffix not in {'.db','.sqlite','.sqlite3','.dmp'}
        payload[rel.as_posix()]=path.read_bytes()
    payload['evidence/OBT31/FILE_MANIFEST.json']=(ROOT/'FILE_MANIFEST.json').read_bytes()
    for name in ['hotfix_translation31a.py','package_obt31a.py']:payload['evidence/OBT31A/'+name]=(BASE/name).read_bytes()
    manifest=dict(release='OBT31A/v24.1',files={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(payload.items())})
    payload['FILE_MANIFEST.json']=encoded(manifest)
    with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,raw in sorted(payload.items()):archive.writestr(PREFIX+'/'+name,raw)
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        for name,row in manifest['files'].items():assert sha(archive.read(PREFIX+'/'+name))==row['sha256']
    receipt=dict(file=str(OUT),bytes=OUT.stat().st_size,sha256=sha(OUT.read_bytes()),files=len(payload),checkpoint=checkpoint)
    (BASE/'OBT31A_PACKAGE_RECEIPT.json').write_bytes(encoded(receipt))
    print(json.dumps({k:v for k,v in receipt.items() if k!='checkpoint'}))

if __name__=='__main__':main()
