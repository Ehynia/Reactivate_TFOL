from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,zipfile
ROOT=Path(__file__).parent;OUT=ROOT/'work34';BASE=ROOT/'merge33/result';QA=ROOT/'qa34'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def include(p):
    rel=p.relative_to(OUT)
    return not ('__pycache__' in rel.parts or p.suffix in ('.pyc','.sqlite3','.db','.o','.elf','.lock') or any(x.startswith('tmp') for x in rel.parts))
def main():
    S=OUT/'Release/Server';e=OUT/'evidence/Translation34';e.mkdir(parents=True,exist_ok=True)
    service=json.loads((S/'SERVICE_VALIDATION.json').read_text());checks=json.loads((OUT/'TRANSLATION34_SOURCE_CHECKS.json').read_text())
    assert service['passed'] and service['tests_run']==256 and not checks['csharp_syntax_errors']
    assert checks['native_image_unchanged_sha256']==json.loads((S/'base_exe_manifest.json').read_text())['exe_sha256']
    shutil.copyfile(BASE/'README_RU.md',e/'README_OBT33_v26_2.md')
    shutil.copyfile(OUT/'TRANSLATION_PRELOAD_README_RU.md',OUT/'README_RU.md')
    if (OUT/'MERGE33_FILE_CHECKS.json').exists():shutil.move(OUT/'MERGE33_FILE_CHECKS.json',e/'MERGE33_FILE_CHECKS_PREVIOUS.json')
    (OUT/'Release/START_HERE_RU.txt').write_text('REACTIVATE OBT33 / v26.3\n\nЗапуск: Release\\Reactivate.exe.\nВыберите язык и игру. После входа дождитесь окна подготовки перевода.\nИгра не откроется до завершения подготовки или явного выбора неполного перевода.\nОтмена сохраняет прогресс. Полное описание: TRANSLATION_PRELOAD_README_RU.md.\nИгровой EXE и аккаунты сохранены от OBT33/v26.2.\n',encoding='utf-8-sig')
    for name in ['update_launcher34.py','package_translation34.py']:shutil.copyfile(ROOT/name,e/name)
    for name in ['regression_final.txt','new_tests_final.txt','launcher_tests_final.txt']:
        if (QA/name).exists():shutil.copyfile(QA/name,e/name)
    builder=OUT/'Reactivate/NativeDesktopBuilder'
    binary=QA/'bootstrap34_host'
    subprocess.run(['gcc','-O1','-Wall','-Wextra',str(builder/'test_bootstrap25.c'),'-o',str(binary)],check=True,capture_output=True)
    host=subprocess.check_output([str(binary)],text=True).strip()
    boot=dict(sha256=sha(OUT/'Release/Reactivate.exe'),baseline_sha256=sha(BASE/'Release/Reactivate.exe'),
        cache='v26trans1',method='two same-length UTF-16 cache literals only; native bootstrap code unchanged',bootstrap_host=host,
        csharp_syntax_checked=True,csharp_windows_compiled=False,windows_gui_executed=False)
    raw=(BASE/'Release/Reactivate.exe').read_bytes().replace('v26merge1'.encode('utf-16le'),'v26trans1'.encode('utf-16le'))
    assert (OUT/'Release/Reactivate.exe').read_bytes()==raw
    for name in ['BOOTSTRAP_VERSION34.json','BOOTSTRAP_BUILD.json','BOOTSTRAP_VALIDATION.json']:(OUT/name).write_text(json.dumps(boot,indent=2)+'\n')
    checkpoint=dict(release='OBT33/v26.3',feature_revision='translation34',service_tests=service,source_checks=checks,bootstrap=boot,
        complete_preparation_default_in_launcher=True,overall_scan_timeout_seconds=None,overall_translation_timeout_seconds=None,
        provider_request_timeout_seconds=7,client_daily_source_characters=5000,partial_translation_requires_explicit_acceptance=True,
        all_game_text_rendering_verified=False,gameplay_changes=False,account_generation_unchanged=True)
    (OUT/'CHECKPOINT_TRANSLATION34.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
    changes=[]
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and include(p) and p.name not in ('FILE_MANIFEST.json','SOURCE_MANIFEST.json'):
            old=BASE/p.relative_to(OUT)
            if not old.exists() or sha(old)!=sha(p):changes.append(dict(file=str(p.relative_to(OUT)),sha256=sha(p),bytes=p.stat().st_size))
    (e/'CHANGES.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=changes),ensure_ascii=False,indent=2)+'\n')
    files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and include(p) and p.name not in ('FILE_MANIFEST.json','SOURCE_MANIFEST.json')]
    index={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
    (OUT/'FILE_MANIFEST.json').write_text(json.dumps(dict(release='OBT33/v26.3',files=index),indent=2)+'\n')
    sources={k:v for k,v in index.items() if Path(k).suffix in ('.py','.cs','.c','.h','.ld','.bat','.cmd')}
    (OUT/'SOURCE_MANIFEST.json').write_text(json.dumps(dict(release='OBT33/v26.3',files=sources),indent=2)+'\n')
    files += [OUT/'FILE_MANIFEST.json',OUT/'SOURCE_MANIFEST.json']
    path=ROOT/'Reactivate_TFOL_OBT33_v26_3_TRANSLATION_PRELOAD_FULL.zip';prefix='Reactivate_TFOL_OBT33_v26_3'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,prefix+'/'+str(p.relative_to(OUT)))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for name,meta in index.items():assert hashlib.sha256(z.read(prefix+'/'+name)).hexdigest()==meta['sha256']
        assert not any(n.endswith(('.sqlite3','.db','.lock')) for n in z.namelist())
    result=dict(file=str(path),bytes=path.stat().st_size,sha256=sha(path),files=len(files),tests=256,crc_and_all_hashes_verified=True)
    (QA/'PACKAGE_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
