"""Integrate progress UI and complete language preparation into the shipped single C# source."""
from pathlib import Path
import json
ROOT=Path(__file__).parent/'work34'
P=ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs'
def q(s):return json.dumps(s,ensure_ascii=False)
def ui(ru,en,zh):return 'Ui('+','.join(map(q,(ru,en,zh)))+')'
def main():
    t=P.read_text('utf-8-sig')
    part=(ROOT/'Release/Server/LauncherSource/TranslationProgress.cs.part').read_text()
    needle='        private async void LaunchGameClient()'
    assert needle in t;t=t.replace(needle,part+'\n'+needle)
    t=t.replace('Reactivate v26.2 · OBT33','Reactivate v26.3 · OBT33')
    t=t.replace('AccountKey = _accountKey, AuthAction = _authAction, Language = _currentLang,','AccountKey = _accountKey, AuthAction = _authAction, Language = _currentLang, TranslationMode = "complete",')
    t=t.replace('            [DataMember(Name = "language")] public string Language;', '            [DataMember(Name = "language")] public string Language;\n            [DataMember(Name = "translation_mode")] public string TranslationMode;')
    t=t.replace('            [DataMember(Name = "event")] public string Kind;', '''            [DataMember(Name = "event")] public string Kind;
            [DataMember(Name = "stage")] public string Stage;
            [DataMember(Name = "status")] public string Status;
            [DataMember(Name = "done")] public int Done;
            [DataMember(Name = "total")] public int Total;
            [DataMember(Name = "remaining")] public int Remaining;''')
    t=t.replace('                if (_authAction != "register") _bridgeProcess.StandardInput.Close();','                // Keep the control pipe open for preparation cancellation/retry/partial acceptance.')
    # Only the registration acknowledgement in the launch loop stays open; discovery's stdin still closes.
    t=t.replace('                        _bridgeProcess.StandardInput.Close();\n                        _authAction = "login";', '                        _authAction = "login";')
    t=t.replace('                    if (state.Kind == "client_preparing")', '''                    if (state.Kind == "translation_progress" || state.Kind == "translation_blocked") ShowTranslationProgress(state);
                    if (state.Kind == "translation_complete" || state.Kind == "launch_cancelled") CloseTranslationProgress();
                    if (state.Kind == "client_preparing")''')
    t=t.replace('                        _gameRunning = true;', '                        CloseTranslationProgress();\n                        _bridgeProcess.StandardInput.Close();\n                        _gameRunning = true;')
    t=t.replace('                if (_bridgeProcess != null) { _bridgeProcess.Dispose(); _bridgeProcess = null; }','                CloseTranslationProgress();\n                if (_bridgeProcess != null) { _bridgeProcess.Dispose(); _bridgeProcess = null; }')
    # Persistent settings/card labels use the existing recursive i18n system.
    triples={
      'resolution':('Разрешение','Resolution','分辨率'),
      'windowmode':('Режим окна','Window mode','窗口模式'),
      'graphicsapi':('Графика','Graphics API','图形接口'),
      'prepare_note':('Игра запускается после подготовки перевода. Ход работы виден в отдельном окне.','The game starts after translation preparation. A separate window shows progress.','翻译准备完成后才会启动游戏，可在独立窗口查看进度。'),
      'location_note':('Игра может находиться на любом диске. Выбранный путь сохраняется.','The game can be on any drive. Your chosen location is saved.','游戏可位于任意磁盘，所选位置将保存。'),
      'openfolder':('Открыть папку игры','Open game folder','打开游戏文件夹'),
      'playhub':('ИГРОВОЙ ЦЕНТР','PLAY HUB','游戏中心'),
      'community':('ПРОЕКТ СООБЩЕСТВА','COMMUNITY RESTORATION','社区重启计划')}
    extension='        private void ExtendLauncherTranslations()\n        {\n'
    for key,values in triples.items():
        for lang,value in zip(('ru','en','zh'),values):extension+='            _i18n['+q(lang)+']['+q(key)+'] = '+q(value)+';\n'
    extension+='        }\n\n'
    t=t.replace('        private void SetLanguage(string lang)',extension+'        private void SetLanguage(string lang)')
    t=t.replace('            LoadAssets();\n            BuildLayout();','            LoadAssets();\n            ExtendLauncherTranslations();\n            BuildLayout();')
    t=t.replace('            UpdateSettingsTranslations();','            UpdateSettingsTranslations();\n            UpdateTranslationTree(this);\n            _winModeCombo.Refresh(); _dxCombo.Refresh();')
    t=t.replace('Text = "PLAY HUB",','Text = "PLAY HUB", Tag = "i18n:playhub",').replace('Text = "COMMUNITY RESTORATION",','Text = "COMMUNITY RESTORATION", Tag = "i18n:community",')
    t=t.replace('Text = "Resolution:",','Text = "Resolution:", Tag = "i18n:resolution",').replace('Text = "Window Mode:",','Text = "Window Mode:", Tag = "i18n:windowmode",').replace('Text = "Graphics API:",','Text = "Graphics API:", Tag = "i18n:graphicsapi",')
    t=t.replace('card.Controls.Add(CardLabel("Сервер и клиент подготавливаются автоматически при запуске.", 26, 282, 670, 36, 10f));','card.Controls.Add(Translate(CardLabel("", 26, 282, 670, 36, 10f), "prepare_note"));')
    t=t.replace('card.Controls.Add(CardLabel("Игра может находиться на любом диске. Выбранный путь сохраняется.", 26, 325, 670, 48, 9f));','card.Controls.Add(Translate(CardLabel("", 26, 325, 670, 48, 9f), "location_note"));')
    t=t.replace('var openGame = CardButton("Открыть папку игры", 26, 394, 250, 37, false);','var openGame = Translate(CardButton("", 26, 394, 250, 37, false), "openfolder");')
    t=t.replace('            _dxCombo.Items.AddRange', '''            _winModeCombo.FormattingEnabled = true;
            _winModeCombo.Format += (s, e) => {
                string mode = e.ListItem as string;
                e.Value = mode == "fullscreen" ? Ui("Во весь экран", "Fullscreen", "全屏") :
                    mode == "borderless" ? Ui("Без рамки", "Borderless", "无边框") : Ui("В окне", "Windowed", "窗口");
            };
            _dxCombo.FormattingEnabled = true;
            _dxCombo.Format += (s, e) => {
                string value = e.ListItem as string;
                e.Value = value != null && value.StartsWith("dx12") ? Ui("DirectX 12 (экспер.)", "DirectX 12 (experimental)", "DirectX 12（实验）") :
                    value != null && value.StartsWith("dx9") ? "DirectX 9" : "DirectX 11";
            };
            _dxCombo.Items.AddRange''')
    # Modal and runtime messages are evaluated in the current launcher language.
    replacements=[
      ('Где установлена игра?','Where is the game installed?','游戏安装在哪里？'),
      ('Укажите EXE игры или папку, в которой её нужно найти.','Select the game EXE or the folder to search.','选择游戏程序或要搜索的文件夹。'),
      ('Выбрать EXE…','Choose EXE…','选择程序…'),('Найти в папке…','Search folder…','搜索文件夹…'),
      ('Выберите EXE игры','Select the game EXE','选择游戏程序'),('Исполняемые файлы (*.exe)|*.exe','Executable files (*.exe)|*.exe','可执行文件 (*.exe)|*.exe'),
      ('Выберите папку с распакованной игрой. Поиск выполняется только внутри неё.','Select the extracted game folder. Only this folder will be searched.','选择已解压的游戏文件夹，仅搜索所选文件夹。'),
      ('Распакуйте обновление целиком: рядом с Reactivate.exe нужна папка Server.','Extract the whole update: Reactivate.exe needs the Server folder beside it.','请完整解压更新，Reactivate.exe 旁需要有 Server 文件夹。'),
      ('Поиск игры','Finding the game','查找游戏'),('Ищу Binaries/Win32, Content/Paks и Engine…\r\n','Looking for Binaries/Win32, Content/Paks and Engine…\r\n','正在查找 Binaries/Win32、Content/Paks 和 Engine…\r\n'),
      ('Отмена','Cancel','取消'),('Выбрать','Select','选择'),
      ('Поиск ограничен — выберите найденный клиент','Search limit reached — select a found client','搜索已达上限，请选择已找到的客户端'),('Выберите клиент OBT','Select the OBT client','选择 OBT 客户端'),
      ('Не удалось прочитать результат поиска. ','Could not read the discovery result. ','无法读取搜索结果。'),
      ('Клиент OBT не найден. Выберите EXE из Binaries/Win32 или папку распакованной игры с Engine и Content/Paks.','OBT client not found. Select an EXE in Binaries/Win32 or the extracted game folder with Engine and Content/Paks.','未找到 OBT 客户端。请选择 Binaries/Win32 中的程序或包含 Engine 和 Content/Paks 的游戏文件夹。'),
      (' Поиск ограничен: выберите папку ближе к игре.',' Search limit reached: choose a folder closer to the game.',' 搜索已达上限，请选择更接近游戏的文件夹。'),
      ('Игра выбрана · готов к запуску','Game selected · ready to launch','已选择游戏，可以启动'),
      ('Нет папки Server с локальным сервером. Распакуйте обновление Reactivate целиком.','The Server folder is missing. Extract the whole Reactivate update.','缺少 Server 文件夹，请完整解压 Reactivate 更新。'),
      ('Подготовка локального сервера…','Preparing the local server…','正在准备本地服务器…'),('Подготовка клиента…','Preparing the client…','正在准备客户端…'),
      ('Локальный сервер готов','Local server ready','本地服务器已就绪'),('Игра запущена','Game started','游戏已启动'),
      ('\r\n\r\nОтчёт: ','\r\n\r\nReport: ','\r\n\r\n报告：'),('Игра завершена','Game closed','游戏已退出'),('Ошибка клиента · отчёт сохранён','Client error · report saved','客户端错误，报告已保存'),
      ('Не удалось запустить сессию. Распакуйте обновление целиком и повторно выберите игру.','Session could not start. Extract the whole update and select the game again.','无法启动会话。请完整解压更新并重新选择游戏。'),
      ('Ошибка запуска локальной сессии: ','Local session launch failed: ','本地会话启动失败：'),('Готов к запуску','Ready to launch','可以启动'),
      ('Сначала выберите игру.','Select the game first.','请先选择游戏。'),('Настройки и адреса серверов сохранены.','Settings and server addresses saved.','已保存设置和服务器地址。'),
      ('Сначала выберите и запустите игру.','Select and launch the game first.','请先选择并启动游戏。'),('Сначала запустите игру или локальный сервер.','Start the game or local server first.','请先启动游戏或本地服务器。'),
      ('Сначала запустите локальный сервер: ','Start the local server first: ','请先启动本地服务器：'),
      ('Не хватает прав на сохранение Servers.ini.','Permission denied while saving Servers.ini.','没有权限保存 Servers.ini。'),('Не удалось сохранить Servers.ini: ','Could not save Servers.ini: ','无法保存 Servers.ini：'),
      ('Игра продолжит работать с локальным сервером. Закрыть только лаунчер?','The game and local server will keep running. Close the launcher?','游戏和本地服务器将继续运行。要关闭启动器吗？'),
      ('Сначала выберите игру в настройках лаунчера или нажмите «Играть».','Select the game in launcher settings or click Play.','请在启动器设置中选择游戏，或点击开始游戏。'),
      ('Сохранён TCLS\\config\\system.ini (резервная копия .bak при наличии исходного файла).','Saved TCLS\\config\\system.ini (.bak backup created if an original exists).','已保存 TCLS\\config\\system.ini（若有原文件，则创建 .bak 备份）。'),
      ('Не удалось сохранить конфигурацию / Cannot save config:\r\n','Could not save configuration:\r\n','无法保存配置：\r\n')]
    for values in replacements:
        old=q(values[0]);new=ui(*values)
        # Avoid recursively wrapping existing three-language Ui calls and i18n dictionaries.
        lines=t.splitlines(True);output=[]
        for line in lines:
            if ('Ui(' not in line and not line.lstrip().startswith('{ "')) or 'Text = "' in line or 'MessageBox.Show("' in line or '_statusMainLabel.Text = "' in line:
                line=line.replace(old,new)
            output.append(line)
        t=''.join(output)
    t=t.replace('"Параметры игры (Game Settings)"','"Параметры игры"')
    # Display category names are UI labels, while protocol/config identifiers remain untouched.
    t=t.replace('_accountBtn.Text = "◈  " + _accountName;', '_accountBtn.Text = _accountName;')
    t=t.replace('        protected override void OnFormClosing(FormClosingEventArgs e)\n        {',
        '        protected override void OnFormClosing(FormClosingEventArgs e)\n        {\n            if (_launching && !_gameRunning && _translationWindow != null) SendTranslationCommand("translation_cancel");')
    P.write_text(t,encoding='utf-8-sig')
    (ROOT/'Release/Server/LauncherSource/ReactivateStandalone.cs').write_text(t,encoding='utf-8-sig')
    boot=ROOT/'Reactivate/NativeDesktopBuilder/bootstrap_windows.c';boot.write_text(boot.read_text().replace('v26merge1','v26trans1'))
    exe=ROOT/'Release/Reactivate.exe';raw=exe.read_bytes();old='v26merge1'.encode('utf-16le');assert raw.count(old)==2
    exe.write_bytes(raw.replace(old,'v26trans1'.encode('utf-16le')))
    print('Complete preparation IPC/progress and launcher translations integrated.')
if __name__=='__main__':main()
