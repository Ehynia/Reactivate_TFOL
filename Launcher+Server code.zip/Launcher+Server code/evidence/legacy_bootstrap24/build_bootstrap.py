"""Build the tiny PE32 Win32 bootstrap without a Windows toolchain/runtime."""
import hashlib,json,struct,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=0x400000;TEXT=0x401000;IMPORT=0x430000;RESOURCE=0x440000
APIS=['GetModuleFileNameW','GetFileAttributesW','GetWindowsDirectoryW','CreateProcessW','WaitForSingleObject',
      'GetExitCodeProcess','CloseHandle','CreateFileW','ExitProcess','MessageBoxW','GetFileAttributesExW','MoveFileExW']
def align(n,a):return (n+a-1)//a*a

def resources(ico):
    assert ico[:4]==b'\0\0\1\0'
    count=struct.unpack_from('<H',ico,4)[0]
    # Root -> RT_ICON and RT_GROUP_ICON -> ID -> language -> data entries.
    data=bytearray(16+16)
    struct.pack_into('<HH',data,12,0,2)
    directory_entries=[]
    def directory(ids):
        at=len(data);data.extend(bytes(16+8*len(ids)));struct.pack_into('<H',data,at+14,len(ids))
        return at
    icons=directory(list(range(1,count+1)));groups=directory([1])
    struct.pack_into('<IIII',data,16,3,icons|0x80000000,14,groups|0x80000000)
    for index in range(count+1):
        parent=icons if index<count else groups;slot=index if index<count else 0
        lang=directory([1033]);struct.pack_into('<II',data,parent+16+8*slot,index+1 if index<count else 1,lang|0x80000000)
        leaf=len(data);data.extend(bytes(16));struct.pack_into('<II',data,lang+16,1033,leaf)
        directory_entries.append(leaf)
    group=bytearray(struct.pack('<HHH',0,1,count));payloads=[]
    for i in range(count):
        row=ico[6+16*i:22+16*i];w,h,col,res,planes,bpp,size,offset=struct.unpack('<BBBBHHII',row)
        payload=ico[offset:offset+size];assert len(payload)==size;payloads.append(payload)
        group.extend(struct.pack('<BBBBHHIH',w,h,col,res,planes,bpp,size,i+1))
    payloads.append(bytes(group))
    for leaf,payload in zip(directory_entries,payloads):
        data.extend(bytes(align(len(data),4)-len(data)));at=len(data);data.extend(payload)
        struct.pack_into('<IIII',data,leaf,RESOURCE-BASE+at,len(payload),0,0)
    return bytes(data)

def build():
    ld='ENTRY(entry)\nSECTIONS { . = 0x401000; .code : { *(.text*) *(.rodata*) *(.data*) *(.bss*) *(COMMON) } /DISCARD/ : { *(.comment*) *(.eh_frame*) *(.note*) } }\n'
    (ROOT/'bootstrap.ld').write_text(ld)
    subprocess.run(['gcc','-m32','-march=i686','-fshort-wchar','-Os','-ffreestanding','-fno-pic','-fno-pie','-fno-stack-protector','-fno-asynchronous-unwind-tables','-fno-builtin','-mpreferred-stack-boundary=2','-mincoming-stack-boundary=2','-Wall','-Wextra','-c','bootstrap.c','-o','bootstrap.o'],cwd=ROOT,check=True)
    subprocess.run(['ld','-m','elf_i386','-T','bootstrap.ld','bootstrap.o','-o','bootstrap.elf'],cwd=ROOT,check=True)
    subprocess.run(['objcopy','-O','binary','bootstrap.elf','bootstrap.bin'],cwd=ROOT,check=True)
    code=(ROOT/'bootstrap.bin').read_bytes();assert len(code)<IMPORT-TEXT
    symbols={line.split()[2]:int(line.split()[0],16) for line in subprocess.check_output(['nm','-n','bootstrap.elf'],cwd=ROOT,text=True).splitlines() if len(line.split())==3}
    idata=bytearray(0x200)
    def add(raw):at=len(idata);idata.extend(raw);return IMPORT-BASE+at
    # Separate descriptors let index 9 still map to USER32 MessageBoxW.
    for descriptor,(dll,indices) in enumerate([('KERNEL32.dll',list(range(9))),('USER32.dll',[9]),('KERNEL32.dll',[10,11])]):
        dll_rva=add(dll.encode()+b'\0');names=[]
        for i in indices:names.append(add(b'\0\0'+APIS[i].encode()+b'\0'))
        idata.extend(bytes(align(len(idata),4)-len(idata)))
        lookup=add(b''.join(struct.pack('<I',n) for n in names)+bytes(4))
        iat=0x100+indices[0]*4
        # APIs 0..8 and 9 and 10..11 need terminators between descriptors;
        # fixed slots are therefore populated from a separate init lookup below.
        real_iat=add(b''.join(struct.pack('<I',n) for n in names)+bytes(4))
        struct.pack_into('<IIIII',idata,20*descriptor,lookup,0,0,dll_rva,real_iat)
        for i,real in zip(indices,range(real_iat,real_iat+4*len(indices),4)):
            # Replace every hard-coded API slot address in the code with its
            # true import-address-table address; no runtime resolver is needed.
            old=struct.pack('<I',IMPORT+0x100+i*4);new=struct.pack('<I',BASE+real)
            assert old in code,(i,APIS[i]);code=code.replace(old,new)
    icon=resources((ROOT.parent/'Assets/app_icon.ico').read_bytes())
    sections=[('.text',TEXT-BASE,code,0xe0000060),('.idata',IMPORT-BASE,bytes(idata),0xc0000040),('.rsrc',RESOURCE-BASE,icon,0x40000040)]
    headers=512;image=bytearray(headers);image[:2]=b'MZ';struct.pack_into('<I',image,60,0x80);image[0x80:0x84]=b'PE\0\0'
    struct.pack_into('<HHIIIHH',image,0x84,0x14c,len(sections),0,0,0,224,0x103)
    o=0x98;struct.pack_into('<HBB',image,o,0x10b,14,0)
    struct.pack_into('<III',image,o+4,align(len(code),512),align(len(idata),512)+align(len(icon),512),0)
    struct.pack_into('<IIIIII',image,o+16,symbols['entry']-BASE,0x1000,IMPORT-BASE,BASE,4096,512)
    struct.pack_into('<HHHHHH',image,o+40,6,0,0,0,6,0)
    struct.pack_into('<II',image,o+56,align(RESOURCE-BASE+len(icon),4096),headers)
    struct.pack_into('<HH',image,o+68,2,0x100)
    struct.pack_into('<IIIIII',image,o+72,0x100000,0x1000,0x100000,0x1000,0,16)
    struct.pack_into('<II',image,o+96+8,IMPORT-BASE,80)
    struct.pack_into('<II',image,o+96+16,RESOURCE-BASE,len(icon))
    # Three section headers require more than the first 512-byte header block.
    assert 0x178+40*len(sections)<=headers
    for i,(name,rva,data,flags) in enumerate(sections):
        raw=align(len(data),512);offset=len(image)
        struct.pack_into('<8sIIIIIIHHI',image,0x178+i*40,name.encode(),len(data),rva,raw,offset,0,0,0,0,flags)
        image.extend(data);image.extend(bytes(raw-len(data)))
    output=ROOT.parents[1]/'Release/Reactivate.exe';output.write_bytes(image)
    result=dict(file=str(output),bytes=len(image),sha256=hashlib.sha256(image).hexdigest(),imports=APIS,entry=hex(symbols['entry']),
                type='Win32 bootstrap; compiles supplied WinForms source using installed Windows compiler on first launch',windows_execution_verified=False)
    (ROOT.parents[1]/'BOOTSTRAP_BUILD.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':build()
