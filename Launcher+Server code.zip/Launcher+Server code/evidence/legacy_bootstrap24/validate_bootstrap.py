"""PE and actual C control-flow checks; never claims Windows execution."""
import hashlib,json,struct,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'Release/Server'))
from pe_read import PE
from build_bootstrap import APIS,BASE,resources

def main():
    image=PE(ROOT.parents[1]/'Release/Reactivate.exe');checks=[]
    assert image.machine==0x14c and image.base==BASE and image.b[0x80:0x84]==b'PE\0\0'
    checks.append('Native x86 Windows PE, GUI subsystem, fixed base')
    flat=[v['name'] for descriptor in image.imports() for v in descriptor['entries']]
    assert flat==APIS
    checks.append('All twelve Win32 import names and DLL descriptors verified')
    assert struct.unpack_from('<H',image.b,0x98+68)[0]==2
    entry=image.sections['.text'];assert entry['va']<=image.entry<entry['va']+entry['vsize']
    checks.append('Entry point is inside the executable section')
    expected=resources((ROOT.parent/'Assets/app_icon.ico').read_bytes())
    assert image.read(BASE+image.directories[2][0],len(expected))==expected
    checks.append('Original icon images and group icon embedded exactly')
    prior=0
    for section in image.sections.values():
        assert section['rawptr']%512==0 and section['rawptr']+section['rawsize']<=len(image.b)
        assert section['va']>=prior;prior=section['va']+((max(section['vsize'],section['rawsize'])+4095)//4096)*4096
    checks.append('PE section bounds and virtual ranges do not overlap')
    with tempfile.TemporaryDirectory(dir=ROOT) as t:
        output=Path(t)/'bootstrap_host_test'
        subprocess.run(['gcc','-fshort-wchar','-O1','-Wno-pointer-to-int-cast','-Wno-int-to-pointer-cast','test_bootstrap.c','-o',str(output)],cwd=ROOT,check=True,capture_output=True)
        test=subprocess.run([str(output)],capture_output=True,text=True,timeout=5)
        assert test.returncode==0,(test.returncode,test.stdout,test.stderr)
        checks.append(test.stdout.strip())
    report=dict(passed=len(checks),checks=checks,bootstrap_sha256=hashlib.sha256(image.b).hexdigest(),
                compiler_executed_on_host=False,windows_executed=False,original_winforms_gui_executed=False,
                limitation='Bootstrap is built; the C# UI is built by Windows csc.exe on its first launch.')
    (ROOT.parents[1]/'BOOTSTRAP_VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
