"""Isolated reproductions against the unmodified attachment; no real profiles."""
import json,sys,tempfile,threading,concurrent.futures
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'gemini21_review/Release/Server'))
import server,game_protocol,economy,obt_extensions,obt_handlers
from tdr_codec import packet

result={}
with tempfile.TemporaryDirectory(dir=ROOT) as folder:
    app=server.App(folder,0,0)
    try:
        s=app.state.create_session('ReviewPlayer');uid=s['user_id'];db=app.state.database
        now=[1700000000.];app.state.simulation.clock=lambda:now[0]
        app.state.simulation.start(uid,'http',1010,kills=30,mobs=80,waves=4)
        now[0]+=6;app.state.simulation.poll(uid)
        with db.connect() as c:real=c.execute('SELECT count(*) FROM match_results').fetchone()[0]
        result['client_claimed_combat_without_battle']=dict(credits=db.profile(uid)['credits'],real_match_results=real)
        uid2=app.state.create_session('WavePlayer')['user_id']
        body=packet(277,'PveDefendAccBattleInfoReq',dict(Name='WavePlayer',Wave=50))
        for stamp in [1700000001.,1700000002.]:
            with patch('obt_handlers.time.time',return_value=stamp):
                game_protocol.handle(db,uid2,body,context={'logged_in':True})
        with db.connect() as c:
            result['same_pve_wave_twice']=dict(credits=economy.balance(c,uid2,3),tickets=economy.balance(c,uid2,6),energy=economy.balance(c,uid2,9),real_match_results=c.execute('SELECT count(*) FROM match_results WHERE uid=?',(uid2,)).fetchone()[0])
        uid3=app.state.create_session('RacePlayer')['user_id']
        with db.connect() as c:economy.adjust(c,uid3,5,30)
        barrier=threading.Barrier(2);original=obt_extensions.setting
        def racing_setting(db,uid,key,default=None):
            value=original(db,uid,key,default)
            if key=='active_claimed_1':barrier.wait(timeout=5)
            return value
        req=packet(153,'ActiveRewardReq',dict(Id=1,ActiveType=1))
        with patch.object(obt_extensions,'setting',side_effect=racing_setting):
            with concurrent.futures.ThreadPoolExecutor(2) as pool:
                list(pool.map(lambda _:game_protocol.handle(db,uid3,req,context={'logged_in':True}),range(2)))
        result['parallel_same_chest']=dict(credits=db.profile(uid3)['credits'],expected_one_claim_credits=35)
    finally:app.close()
(ROOT/'GEMINI21_REPRODUCTIONS.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
