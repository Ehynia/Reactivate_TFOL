"""Verified portable checkpoint, excluding every account, token and test temp."""
from pathlib import Path
import hashlib,json,re,zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE if HERE.name=='Reactivate_TFOL_OBT28_v21' else HERE/'Reactivate_TFOL_OBT28_v21'
OUT=ROOT.parent.parent/'Reactivate_TFOL_OBT28_v21_AUTH_CHECKPOINT.zip'
S=ROOT/'Release/Server'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text('utf-8'))
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

service=read(S/'SERVICE_VALIDATION.json');boot=read(ROOT/'BOOTSTRAP_VALIDATION.json')
assert service['passed'] and service['tests_run']>=193,service
native=sha(S/'ClientUpdate/TFOL_OBT.exe')
assert native=='5451365a90b80d22b37fd9aa5791bcc124de83b48ccd74b160149b694763a29b'
assert read(S/'NATIVE_VALIDATION.json')['exe_sha256']==native
assert boot['passed']==6 and boot['bootstrap_sha256']==sha(ROOT/'Release/Reactivate.exe')
audit=read(ROOT/'SOURCE_AUDIT28.json');cs=read(ROOT/'CSHARP_SYNTAX_CHECK.json')
assert not audit['syntax_errors'] and not audit['undefined_names'] and cs['identical_mirrors']
assert not any(row['syntax_has_error'] for row in cs['files'])
assert cs['files'][0]['sha256']==sha(ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs')
assert sha(ROOT/'evidence/initial_nickname_reference.png')=='a88747c47ecb18713a2d081cfbe276c1eb3de602e1da113179d3183717ff25b1'
mission=read(ROOT/'MISSION_MEGATRON_FINDINGS.json')
for row in mission['assets']:assert sha(ROOT/'evidence/mission_original'/row['path'])==row['sha256']

checkpoint=dict(release='OBT28',launcher='v21-auth1',baseline='OBT27/v20-room1 preserved separately on Drive',
 baseline_zip_sha256='6ec118eaeab8bfbd5f0ba2956ef086024dd238d26e0aeb3e52c6eeac5e9fb30f',
 native_changed=False,native_sha256=native,private_protocol='OB27',native_patch_count=9,
 account_generation='20261015-clean-profiles-v1',database_schema=10,automatic_existing_account_reset=False,
 authentication=['Play -> Login/Register','Login only registration -> random password','One-time saved-password acknowledgement before launch',
                 'scrypt hashes only; no passwords in INI, command line or logs','Private permanent login independent of game nickname',
                 'No guest takeover through public game name','SQLite pre-migration backups','Explicit offline legacy/lost-password recovery'],
 original_initial_name_commands=[5,6],paid_rename_commands=[226,227],paid_rename_implemented=False,
 first_name_gate_implemented=True,first_name_after_tutorial_flow_complete=False,
 tutorial_victory_capture_implemented=False,original_initial_name_popup_activated=False,
 onboarding_status=read(ROOT/'ONBOARDING_STATUS28.json'),service_tests=service,bootstrap_checks=boot,
 csharp_syntax=cs,python_audit=audit,windows_executed_here=False,managed_ui_compiled_here=False,
 gameplay_verified=False,new_hero_ui_windows_verified=False,teams_and_damage_verified=False,pve_waves_verified=False,
 online_human_queue_or_replication_implemented=False,
 backup_contains_account_database=False,backup_contains_admin_tokens=False,
 previous_battle_checkpoint='CHECKPOINT_OBT27.json',
 pending=['Verified native Megatron victory and automatic first-name popup','Windows launcher/auth/modal tests',
          'OBT27 confirmation/hero selection/team damage tests','Actual PvE waves/AI results','Shared multiplayer/real battle statistics',
          'Full cooked UMG/font/texture localization'])
write(ROOT/'CHECKPOINT_OBT28.json',checkpoint);write(ROOT/'CONTINUATION_21.json',checkpoint)
import sys
sys.path.insert(0,str(S));import capabilities
write(S/'API_CAPABILITIES.json',capabilities.describe())

def include(p):
    rel=p.relative_to(ROOT)
    if any(x=='__pycache__' or re.fullmatch(r'tmp[a-z0-9_]{8}',x) for x in rel.parts):return False
    if p.name in {'FILE_MANIFEST.json','SOURCE_MANIFEST.json','obt_TFOL.exe','obt23_recovered.exe','obt25_recovered.exe','OBT_original_code_rva_00001000.bin','OBT_original_tvm_rva_0293b000.bin','python-3.13.16-embed-amd64.zip'}:return False
    if p.suffix.lower() in {'.pyc','.o','.elf','.s','.dmp','.log','.sqlite3','.db','.wal','.lock'}:return False
    if p.name in {'runtime.bin','bootstrap.bin','host_engine_test','host_transport_test','bootstrap_test','admin.token'}:return False
    if re.fullmatch(r'TFOL_OBT_TEST_.*\.exe',p.name) or re.match(r'cc[a-zA-Z0-9]+\.',p.name):return False
    return True

files=sorted(p for p in ROOT.rglob('*') if p.is_file() and include(p))
assert not any('tmp'==part[:3] for p in files for part in p.relative_to(ROOT).parts)
assert not any(p.name in {'server.sqlite3','admin.token','players.json','account-generation.json','server.ready.json'} for p in files)
source={p.relative_to(ROOT).as_posix():sha(p) for p in files if p.suffix in {'.py','.c','.h','.cs','.cmd','.bat','.ld','.js','.html','.css'}}
write(ROOT/'SOURCE_MANIFEST.json',dict(release='OBT28/v21-auth1',files=source));files.append(ROOT/'SOURCE_MANIFEST.json')
manifest={p.relative_to(ROOT).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
write(ROOT/'FILE_MANIFEST.json',dict(release='OBT28/v21-auth1',files=manifest));files.append(ROOT/'FILE_MANIFEST.json')
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in sorted(files):archive.write(p,'Reactivate_TFOL_OBT28_v21/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for name,row in manifest.items():
        raw=archive.read('Reactivate_TFOL_OBT28_v21/'+name)
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
result=dict(path=str(OUT),bytes=OUT.stat().st_size,sha256=sha(OUT),members=len(files),service_tests=service)
assert result['bytes']<50*1024*1024
write(ROOT.parent/'OBT28_DELIVERY.json',result);print(json.dumps(result,indent=2))
