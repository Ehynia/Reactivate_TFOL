﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reactivate
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new ReactivateMainWindow());
        }
    }

    public sealed class ReactivateMainWindow : Form
    {
[DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("winmm.dll", CharSet = CharSet.Auto)]
        private static extern int mciSendString(string command, StringBuilder buffer, int bufferSize, IntPtr hwndCallback);

        // Standard Windows drop shadow for a borderless window (depends on OS composition).
        private const int CsDropShadow = 0x00020000;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                parameters.ClassStyle |= CsDropShadow;
                return parameters;
            }
        }

        private readonly string _baseDir = AppDomain.CurrentDomain.BaseDirectory;
        private const string GameExecutableName = "TFOL_OBT.exe";
        private Image _backgroundVignette;
        private Image _bgSharp;
        private Image _bgBlur;
        private Image _logoUniv;
        private Image _logoZh;
        private bool _useBlurBg = false;
        private bool _soundEnabled = true;
                private bool _isReady;
        private string _gameResolution = "1920X1080";
        private string _gameWindowMode = "fullscreen";
        private string _gameGraphicsApi = "dx11";
        private string _currentLang = "ru";
        private string _currentTab = "home";
        private string _currentRegion = "eu1";
        private string _accountName = "Optimus";
        private const string ClientVersion = "TFOL_1.0.0.59";
        private readonly string[] _serverCodes = { "eu1", "eu2", "asia1", "pts" };
        private readonly Dictionary<string, string> _serverIps = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> _serverPorts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, TextBox> _serverIpEdits = new Dictionary<string, TextBox>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, NumericUpDown> _serverPortEdits = new Dictionary<string, NumericUpDown>(StringComparer.OrdinalIgnoreCase);
        private string _serverIniPath;
        private ThemePanel _settingsOverlay;
        private Button _settingsBack;
        private Button _settingsAppTab;
        private Button _settingsGameTab;
        private Label _settingsPageTitle;
        private Label _serverStatusLabel;

        // UI Controls
        private ThemePanel _titleBar;
        private ThemePanel _sideBar;
        private ThemePanel _mainStage;
        private ComboBox _regionCombo;
        private Label _pingLabel;
        private Button _accountBtn;
        private Button[] _langBtns;
        private Button[] _navBtns;

        // Home Page Controls
        private ThemePanel _homePage;
        private Label _newsHeaderLabel;
        private Label[] _newsItemLabels;
        private Label _statusMainLabel;
        private Label _statusVerLabel;
        private Button _startGameBtn;

        // SubPage Controls
        private ThemePanel _subPage;
        private ThemePanel _gameSettingsCard;
        private ThemePanel _appSettingsCard;
        private TextBox _pathBox;
                        private Label _pythonStatus;
        private CheckBox _blurCheckbox;
        private CheckBox _soundCheckbox;
        private Label _subTitleLabel;
        private Label _subDescLabel;
        private ComboBox _resCombo;
        private ComboBox _winModeCombo;
        private ComboBox _dxCombo;

        // C# 5.0 compatible Dictionary collection initializer (for system csc.exe v4.0.30319)
        private readonly Dictionary<string, Dictionary<string, string>> _i18n = new Dictionary<string, Dictionary<string, string>>
        {
            {
                "ru", new Dictionary<string, string>
                {
                    { "back", "← На главную" },
                    { "settingsapp", "Лаунчер" },
                    { "settingsgame", "Игра" },
                    { "serverhead", "АДРЕСА СЕРВЕРОВ  •  SERVERS.INI" },
                    { "serverhelp", "Настройте IP и порт каждого сервера. Незаполненные адреса разрешены." },
                    { "servernote", "Адреса хранятся в отдельном Servers.ini. Без настоящих IP лаунчер не может подключиться." },
                    { "srv_eu1", "Восточный сектор #1 (EU/CIS)" },
                    { "srv_eu2", "Западный сектор #2 (EU)" },
                    { "srv_asia1", "Азиатский сектор #1 (CN/ASIA)" },
                    { "srv_pts", "Тестовый узел (PTS 2016)" },
                    { "nav_home", "⌂  Главная" },
                    { "nav_gamesettings", "◈  Параметры игры" },
                    { "nav_appsettings", "⚙  Настройки" },
                    { "sub_badge", "REACTIVATE • СЕРВЕР 2016 ГОДА" },
                    { "news_hdr", "ПРИМЕР НОВОСТЕЙ  •  ДЕМО-ДАННЫЕ" },
                    { "n1", "[15.10] Информация о работе сервера Transformers Online: Reactivate" },
                    { "n2", "[12.10] Reactivate: прямой запуск TFOL_OBT.exe" },
                    { "n3", "[09.10] Ротация классических карт 2016 года: Плотина Гувера и Иакон" },
                    { "n4", "[04.10] Пакет локализации интерфейса (ZH / EN / RU) TFOL_1.0.0.59" },
                    { "st_ver", "Версия: TFOL_1.0.0.59" },
                    { "btn_start", "▶  Запустить игру" },
                    { "gs_t", "Параметры игры (Game Settings)" },
                    { "gs_d", "Настройка TCLS/config/system.ini без замены файлов клиента" },
                    { "as_t", "Настройки лаунчера Reactivate" },
                    { "as_d", "Фон, звуки, расположение клиента и Python Portable" },
                    { "look", "ВНЕШНИЙ ВИД" },
                    { "blur", "Размытый фон" },
                    { "sound", "Звуки интерфейса" },
                    { "gamepath", "РАСПОЛОЖЕНИЕ КЛИЕНТА" },
                    { "pathhelp", "Путь к игре фиксирован: TFOL_OBT.exe рядом с Reactivate.exe." },
                    { "pythonhead", "PYTHON PORTABLE 3.12 (x64)" },
                    { "install", "Установить Python" },
                    { "pycheck", "Проверить Python" },
                    { "pynote", "Python Portable не требуется для запуска игры." },
                    { "save", "Сохранить настройки" },
                    { "syshead", "Конфигурация клиента [system] (TCLS/config/system.ini):" },
                    { "gamesave", "✔ Сохранить параметры игры" },
                    { "gameinfo", "Файл TCLS/config/system.ini сохраняется только по команде.\r\nЗапуск открывает TFOL_OBT.exe без аргументов." },
                }
            },
            {
                "en", new Dictionary<string, string>
                {
                    { "back", "← Home" },
                    { "settingsapp", "Launcher" },
                    { "settingsgame", "Game" },
                    { "serverhead", "SERVER ADDRESSES  •  SERVERS.INI" },
                    { "serverhelp", "Set real server IPs and ports. Empty entries are allowed." },
                    { "servernote", "Addresses are stored in a separate Servers.ini. Actual IPs are required for connectivity." },
                    { "srv_eu1", "Eastern Sector #1 (EU/CIS)" },
                    { "srv_eu2", "Western Sector #2 (EU)" },
                    { "srv_asia1", "Asia Pacific #1 (CN/ASIA)" },
                    { "srv_pts", "Test Node (PTS 2016)" },
                    { "nav_home", "⌂  Home" },
                    { "nav_gamesettings", "◈  Game Settings" },
                    { "nav_appsettings", "⚙  App Settings" },
                    { "sub_badge", "REACTIVATE • 2016 REVIVAL SERVER" },
                    { "news_hdr", "DEMO NOTICES  •  EXAMPLE CONTENT" },
                    { "n1", "[15.10] Transformers Online: Reactivate Server Overview & Fair Play" },
                    { "n2", "[12.10] Reactivate: direct TFOL_OBT.exe launch" },
                    { "n3", "[09.10] Weekend Classic Map Rotation: Hoover Dam & Iacon" },
                    { "n4", "[04.10] Multi-language localization pack (ZH / EN / RU) TFOL_1.0.0.59" },
                    { "st_ver", "Version: TFOL_1.0.0.59" },
                    { "btn_start", "▶  Start Game" },
                    { "gs_t", "Game Settings" },
                    { "gs_d", "Update TCLS/config/system.ini while preserving other game files" },
                    { "as_t", "Reactivate Settings" },
                    { "as_d", "Background, sounds, game location, and Python Portable" },
                    { "look", "APPEARANCE" },
                    { "blur", "Blurred background" },
                    { "sound", "Interface sounds" },
                    { "gamepath", "GAME LOCATION" },
                    { "pathhelp", "Fixed game path: TFOL_OBT.exe next to Reactivate.exe." },
                    { "pythonhead", "PYTHON PORTABLE 3.12 (x64)" },
                    { "install", "Install Python" },
                    { "pycheck", "Check Python" },
                    { "pynote", "Python Portable is not needed to launch the game." },
                    { "save", "Save settings" },
                    { "syshead", "Client configuration [system] (TCLS/config/system.ini):" },
                    { "gamesave", "✔ Save game settings" },
                    { "gameinfo", "TCLS/config/system.ini is saved only on demand.\r\nLaunch starts TFOL_OBT.exe without arguments." },
                }
            },
            {
                "zh", new Dictionary<string, string>
                {
                    { "back", "← 返回主页" },
                    { "settingsapp", "启动器" },
                    { "settingsgame", "游戏" },
                    { "serverhead", "服务器地址  •  SERVERS.INI" },
                    { "serverhelp", "输入实际服务器 IP 与端口，未填写的地址可以留空。" },
                    { "servernote", "服务器地址单独保存在 Servers.ini，未配置真实 IP 时无法连接。" },
                    { "srv_eu1", "欧洲与独联体 #1 (EU/CIS)" },
                    { "srv_eu2", "欧洲西部 #2 (EU)" },
                    { "srv_asia1", "亚太区节点 #1 (CN/ASIA)" },
                    { "srv_pts", "测试服务器 (PTS 2016)" },
                    { "nav_home", "⌂  主页" },
                    { "nav_gamesettings", "◈  游戏设置" },
                    { "nav_appsettings", "⚙  启动器设置" },
                    { "sub_badge", "REACTIVATE • 2016 怀旧服务器" },
                    { "news_hdr", "演示公告  •  示例内容" },
                    { "n1", "[15.10] Transformers Online: Reactivate 怀旧服务器运行说明" },
                    { "n2", "[12.10] Reactivate：直接启动 TFOL_OBT.exe" },
                    { "n3", "[09.10] 周末经典地图轮换：胡佛水坝与铁堡中心" },
                    { "n4", "[04.10] 客户端三语言字体与本地化资源包 (TFOL_1.0.0.59) 现已就绪" },
                    { "st_ver", "版本: TFOL_1.0.0.59" },
                    { "btn_start", "▶  启动游戏" },
                    { "gs_t", "游戏设置 (Game Settings)" },
                    { "gs_d", "保存到 TCLS/config/system.ini，不修改其他游戏文件" },
                    { "as_t", "Reactivate 启动器设置" },
                    { "as_d", "背景、声音、游戏目录及便携式 Python" },
                    { "look", "外观" },
                    { "blur", "模糊背景" },
                    { "sound", "界面音效" },
                    { "gamepath", "游戏客户端目录" },
                    { "pathhelp", "固定游戏路径：TFOL_OBT.exe 位于 Reactivate.exe 所在文件夹下。" },
                    { "pythonhead", "便携 Python 3.12 (x64)" },
                    { "install", "安装 Python" },
                    { "pycheck", "检测 Python" },
                    { "pynote", "启动游戏不需要 Python Portable。" },
                    { "save", "保存设置" },
                    { "syshead", "客户端配置 [system] (TCLS/config/system.ini)：" },
                    { "gamesave", "✔ 保存游戏设置" },
                    { "gameinfo", "仅点击保存时写入 TCLS/config/system.ini。\r\n启动 TFOL_OBT.exe 不带命令行参数。" },
                }
            }
        };

        public ReactivateMainWindow()
        {
            Text = "Reactivate — Transformers Online";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1280, 720);
            BackColor = Color.FromArgb(17, 20, 26);
            ForeColor = Color.FromArgb(242, 245, 248);
            Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;
            MinimumSize = new Size(1100, 690);
            Resize += (sender, args) => UpdateWindowShape();
            UpdateWindowShape();

            MigrateLegacySettings();
            LoadSettings();
            LoadServerConfig();
            LoadAssets();
            BuildLayout();
            SetLanguage(_currentLang);
            _isReady = true;
            UpdatePythonStatus();
        }

        private static void MigrateLegacySettings()
        {
            try
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string oldDir = Path.Combine(appData, "CollapseLauncher");
                if (!Directory.Exists(oldDir)) return;
                string newDir = Path.Combine(appData, "Reactivate");
                foreach (string fileName in new[] { "LauncherSettings.ini", "Servers.ini" })
                {
                    string from = Path.Combine(oldDir, fileName);
                    string to = Path.Combine(newDir, fileName);
                    if (File.Exists(from) && !File.Exists(to))
                    {
                        Directory.CreateDirectory(newDir);
                        File.Copy(from, to, false);
                    }
                }
            }
            catch (IOException) { /* Old settings are optional and must not prevent startup. */ }
            catch (UnauthorizedAccessException) { /* Read-only profile: use fresh settings. */ }
        }

        private void LoadAssets()
        {
            string assetsDir = Path.Combine(_baseDir, "Assets");
            if (!Directory.Exists(assetsDir))
                assetsDir = Path.Combine(_baseDir, "..", "Reactivate", "Assets");

            string icoPath = Path.Combine(assetsDir, "app_icon.ico");
            if (File.Exists(icoPath)) Icon = new Icon(icoPath);

            string vignettePath = Path.Combine(assetsDir, "background_vignette.png");
            if (File.Exists(vignettePath)) _backgroundVignette = Image.FromFile(vignettePath);
            string sharpPath = Path.Combine(assetsDir, "bg_sharp.png");
            string blurPath = Path.Combine(assetsDir, "bg_blur.png");
            string univPath = Path.Combine(assetsDir, "logo_universal.png");
            string zhPath = Path.Combine(assetsDir, "logo_zh.png");

            if (File.Exists(sharpPath)) _bgSharp = Image.FromFile(sharpPath);
            if (File.Exists(blurPath)) _bgBlur = Image.FromFile(blurPath);
            if (File.Exists(univPath)) _logoUniv = Image.FromFile(univPath);
            if (File.Exists(zhPath)) _logoZh = Image.FromFile(zhPath);
        }

        private void PlayUiSound()
        {
            if (!_soundEnabled) return;
            try
            {
                string mp3 = Path.Combine(_baseDir, "Assets", "startgame_01.mp3");
                if (File.Exists(mp3))
                {
                    mciSendString("close uisnd", null, 0, IntPtr.Zero);
                    mciSendString("open \"" + mp3 + "\" type mpegvideo alias uisnd", null, 0, IntPtr.Zero);
                    mciSendString("play uisnd", null, 0, IntPtr.Zero);
                }
            }
            catch { }
        }

        // One-pass compositing: draw a cropped scene, then a mild tint once.
        // Never redraw sibling controls or labels (previous versions duplicated text).
        internal void DrawSurface(Graphics g, Control panel, Color tint, bool solid, int radius)
        {
            DrawScene(g, ClientOrigin(panel), panel.ClientSize);
            if (solid)
            {
                using (var fill = new SolidBrush(tint))
                    g.FillRectangle(fill, panel.ClientRectangle);
            }
        }

        internal static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int d = Math.Max(2, Math.Min(radius * 2, Math.Min(r.Width, r.Height)));
            if (radius <= 0) { path.AddRectangle(r); return path; }
            path.AddArc(r.Left, r.Top, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Gentle, curved silhouette inspired by the SWF outline. The sharp side spikes
        // of the original mask have been removed. No polygons with acute angles.
        private GraphicsPath MakeWindowOutline(float inset)
        {
            float w = Math.Max(100, ClientSize.Width - 1 - 2 * inset);
            float h = Math.Max(100, ClientSize.Height - 1 - 2 * inset);
            float x = inset, y = inset;
            float r = 24f;
            float side = 11f;
            var p = new GraphicsPath();
            p.StartFigure();
            p.AddLine(x + r, y, x + w - r, y);
            p.AddBezier(x + w - r, y, x + w - 8, y, x + w, y + 8, x + w, y + r);
            p.AddLine(x + w, y + r, x + w, y + 94);
            p.AddBezier(x + w, y + 94, x + w, y + 111, x + w - side, y + 116, x + w - side, y + 143);
            p.AddLine(x + w - side, y + 143, x + w - side, y + h - 143);
            p.AddBezier(x + w - side, y + h - 143, x + w - side, y + h - 116, x + w, y + h - 111, x + w, y + h - 94);
            p.AddLine(x + w, y + h - 94, x + w, y + h - r);
            p.AddBezier(x + w, y + h - r, x + w, y + h - 7, x + w - 8, y + h, x + w - r, y + h);
            p.AddLine(x + w - r, y + h, x + r, y + h);
            p.AddBezier(x + r, y + h, x + 8, y + h, x, y + h - 8, x, y + h - r);
            p.AddLine(x, y + h - r, x, y + h - 94);
            p.AddBezier(x, y + h - 94, x, y + h - 111, x + side, y + h - 116, x + side, y + h - 143);
            p.AddLine(x + side, y + h - 143, x + side, y + 143);
            p.AddBezier(x + side, y + 143, x + side, y + 116, x, y + 111, x, y + 94);
            p.AddLine(x, y + 94, x, y + r);
            p.AddBezier(x, y + r, x, y + 8, x + 8, y, x + r, y);
            p.CloseFigure();
            return p;
        }

        private void UpdateWindowShape()
        {
            if (ClientSize.Width < 100 || ClientSize.Height < 100) return;
            using (GraphicsPath outline = MakeWindowOutline(0f))
            {
                Region old = Region;
                Region = new Region(outline);
                if (old != null) old.Dispose();
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            // Sub-pixel smoothing along the *inside* of the Win32 window region.
            // WinForms Form.Region itself remains pixel-clipped on Windows.
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            using (GraphicsPath edge = MakeWindowOutline(1.5f))
            using (var soft = new Pen(Color.FromArgb(86, 102, 129, 159), 2.5f))
                e.Graphics.DrawPath(soft, edge);
        }

        private Point ClientOrigin(Control control)
        {
            int x = 0, y = 0;
            while (control != null && control != this)
            {
                x += control.Left;
                y += control.Top;
                control = control.Parent;
            }
            return new Point(x, y);
        }

        private void DrawScene(Graphics g, Point origin, Size viewport)
        {
            var currentBg = (_useBlurBg ? _bgBlur : _bgSharp) ?? _bgSharp ?? _bgBlur;
            if (currentBg == null)
            {
                g.Clear(Color.FromArgb(28, 39, 56));
            }
            else
            {
                g.Clear(Color.FromArgb(14, 19, 29));
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                var sceneRect = new Rectangle(-origin.X, -origin.Y, ClientSize.Width, ClientSize.Height);
                g.DrawImage(currentBg, sceneRect);
                // The vignette is a transparent gradient; it only darkens the image near its edges.
                // Every panel uses the same full-window coordinates, so there are no dark seams.
                if (_backgroundVignette != null)
                    g.DrawImage(_backgroundVignette, sceneRect);
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Original SWF background + subtle dark edge falloff; no blur/glass.
            DrawScene(e.Graphics, Point.Empty, ClientSize);
        }

        private void RefreshBackground()
        {
            Invalidate(true);
        }

        private void BuildLayout()
        {
            // 1. Borderless draggable title bar with a solid background
            _titleBar = new ThemePanel(this, Color.FromArgb(236, 16, 31, 51), true, 18)
            {
                Location = new Point(244, 14),
                Size = new Size(1020, 52)
            };
            _titleBar.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    ReleaseCapture();
                    SendMessage(Handle, 0xA1, 0x2, 0);
                }
            };

            var brandLbl = new Label
            {
                Text = "Reactivate   " + ClientVersion,
                Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(242, 245, 248),
                AutoSize = true,
                Location = new Point(18, 17)
            };
            _titleBar.Controls.Add(brandLbl);

            _regionCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(26, 32, 44),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(252, 13),
                Width = 222
            };
            _regionCombo.SelectedIndexChanged += (s, e) =>
            {
                int idx = _regionCombo.SelectedIndex;
                string[] codes = { "eu1", "eu2", "asia1", "pts" };
                // Show the configured IP only, not fabricated latency.
                if (idx >= 0 && idx < codes.Length)
                {
                    _currentRegion = codes[idx];
                    UpdateServerInfoLabel();
                    if (_isReady) SaveSettings();
                }
            };
            _titleBar.Controls.Add(_regionCombo);

            _pingLabel = new Label
            {
                Text = "● IP: —",
                ForeColor = Color.FromArgb(178, 198, 215),
                AutoSize = false,
                Location = new Point(486, 18),
                Size = new Size(116, 24),
                AutoEllipsis = true
            };
            _titleBar.Controls.Add(_pingLabel);

            _accountBtn = new Button
            {
                Text = "◈ " + _accountName,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(28, 35, 48),
                ForeColor = Color.White,
                Location = new Point(606, 11),
                Size = new Size(132, 30),
                Cursor = Cursors.Hand
            };
            _accountBtn.FlatAppearance.BorderColor = Color.FromArgb(50, 255, 255, 255);
            _accountBtn.Click += (s, e) => PromptAccountDialog();
            _titleBar.Controls.Add(_accountBtn);

            string[] langs = { "zh", "en", "ru" };
            string[] langLabels = { "中文", "EN", "RU" };
            _langBtns = new Button[langs.Length];
            for (int i = 0; i < langs.Length; i++)
            {
                string lc = langs[i];
                var b = new Button
                {
                    Text = langLabels[i],
                    Tag = lc,
                    FlatStyle = FlatStyle.Flat,
                    Size = new Size(40, 30),
                    Location = new Point(748 + i * 44, 11),
                    Cursor = Cursors.Hand,
                    Font = new Font("Segoe UI", 8.5f, FontStyle.Bold)
                };
                b.FlatAppearance.BorderSize = 0;
                b.FlatAppearance.MouseOverBackColor = Color.FromArgb(61, 79, 102);
                b.Click += (s, e) => { PlayUiSound(); SetLanguage(lc); };
                _langBtns[i] = b;
                _titleBar.Controls.Add(b);
                var langTip = new ToolTip();
                langTip.SetToolTip(b, lc == "ru" ? "Русский язык" :
                    lc == "en" ? "English" : "中文");
            }

            var minBtn = new Button
            {
                Text = "—",
                FlatStyle = FlatStyle.Flat,
                Size = new Size(36, 30),
                Location = new Point(940, 11),
                ForeColor = Color.LightGray,
                BackColor = Color.FromArgb(16, 31, 51)
            };
            minBtn.FlatAppearance.BorderSize = 0;
            minBtn.Click += (s, e) => WindowState = FormWindowState.Minimized;
            _titleBar.Controls.Add(minBtn);

            var closeBtn = new Button
            {
                Text = "✕",
                FlatStyle = FlatStyle.Flat,
                Size = new Size(36, 30),
                Location = new Point(984, 11),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(196, 43, 28)
            };
            closeBtn.FlatAppearance.BorderSize = 0;
            closeBtn.Click += (s, e) => Close();
            _titleBar.Controls.Add(closeBtn);

            Controls.Add(_titleBar);

            // 2. Left NavigationView Sidebar
            _sideBar = new ThemePanel(this, Color.Transparent, false, 0)
            {
                Location = new Point(22, 82),
                Size = new Size(208, 210)
            };
            string[] navKeys = { "home", "gamesettings", "appsettings" };
            _navBtns = new Button[navKeys.Length];
            for (int i = 0; i < navKeys.Length; i++)
            {
                string nk = navKeys[i];
                var nb = new Button
                {
                    Tag = nk,
                    FlatStyle = FlatStyle.Flat,
                    TextAlign = ContentAlignment.MiddleLeft,
                    Padding = new Padding(14, 0, 0, 0),
                    Size = new Size(190, 44),
                    Location = new Point(10, 14 + i * 58),
                    Cursor = Cursors.Hand,
                    Font = new Font("Segoe UI Semibold", 9.5f)
                };
                nb.FlatAppearance.BorderSize = 0;
                nb.Click += (s, e) => { PlayUiSound(); SwitchTab(nk); };
                _navBtns[i] = nb;
                _sideBar.Controls.Add(nb);
            }
            Controls.Add(_sideBar);

            // 3. Image backdrop is continuous under all empty content areas.
            _mainStage = new ThemePanel(this, Color.Transparent, false, 0)
            {
                Location = new Point(238, 66),
                Size = new Size(1042, 654)
            };
            Controls.Add(_mainStage);
            _sideBar.BringToFront();
            _titleBar.BringToFront();

            BuildHomePage();
            BuildSubPage();
            BuildSettingsOverlay();
            SwitchTab("home");
        }

        private void BuildHomePage()
        {
            _homePage = new ThemePanel(this, Color.Transparent, false, 0)
            {
                Dock = DockStyle.Fill
            };

            // Background image already contains all scene art; do not overlay a logo or subtitle.

            // News card over the original background.
            var newsCard = new ThemePanel(this, Color.FromArgb(226, 17, 29, 49), true, 18)
            {
                Location = new Point(28, 452),
                Size = new Size(480, 176)
            };
            _newsHeaderLabel = new Label
            {
                Location = new Point(16, 12),
                AutoSize = true,
                ForeColor = Color.FromArgb(224, 123, 57),
                Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold)
            };
            newsCard.Controls.Add(_newsHeaderLabel);

            _newsItemLabels = new Label[4];
            for (int i = 0; i < 4; i++)
            {
                var nl = new Label
                {
                    Location = new Point(16, 42 + i * 30),
                    Size = new Size(448, 24),
                    ForeColor = Color.FromArgb(215, 225, 236),
                    Font = new Font("Segoe UI", 9f),
                    Cursor = Cursors.Hand
                };
                _newsItemLabels[i] = nl;
                newsCard.Controls.Add(nl);
            }
            _homePage.Controls.Add(newsCard);

            // Launch-only status: no file scans, progress bars, hashes, or repair prompts.
            var launchInfo = new ThemePanel(this, Color.FromArgb(206, 17, 29, 49), true, 16)
            {
                Location = new Point(682, 488),
                Size = new Size(350, 76)
            };
            _statusMainLabel = new Label
            {
                Location = new Point(18, 14), Size = new Size(310, 25),
                ForeColor = Color.FromArgb(228, 236, 246),
                Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold)
            };
            _statusVerLabel = new Label
            {
                Location = new Point(18, 43), Size = new Size(310, 22),
                ForeColor = Color.FromArgb(170, 184, 203),
                Font = new Font("Segoe UI", 9f)
            };
            launchInfo.Controls.Add(_statusMainLabel);
            launchInfo.Controls.Add(_statusVerLabel);
            _homePage.Controls.Add(launchInfo);

            _startGameBtn = new Button
            {
                Location = new Point(682, 576),
                Size = new Size(350, 50),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(224, 123, 57),
                ForeColor = Color.White,
                Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            _startGameBtn.FlatAppearance.BorderSize = 0;
            _startGameBtn.Click += (s, e) => LaunchGameClient();
            _homePage.Controls.Add(_startGameBtn);

            _mainStage.Controls.Add(_homePage);
        }

        private void BuildSubPage()
        {
            _subPage = new ThemePanel(this, Color.FromArgb(232, 12, 24, 42), true, 0)
            {
                Dock = DockStyle.Fill,
                Visible = false
            };

            _subTitleLabel = new Label
            {
                Location = new Point(28, 24),
                AutoSize = true,
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI Semibold", 15f, FontStyle.Bold),
                ForeColor = Color.White
            };
            _subDescLabel = new Label
            {
                Location = new Point(28, 56),
                Size = new Size(700, 24),
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.FromArgb(162, 176, 194)
            };
            _subPage.Controls.Add(_subTitleLabel);
            _subDescLabel.Visible = false;

            // Game Settings Card ([system] config writer)
            _gameSettingsCard = new ThemePanel(this, Color.FromArgb(234, 16, 30, 48), true, 19)
            {
                Location = new Point(28, 130),
                Size = new Size(1000, 245)
            };
            var gsCard = _gameSettingsCard;
            var gsHeader = new Label
            {
                Text = "Конфигурация клиента [system] (TCLS/config/system.ini):",
                Location = new Point(18, 16),
                AutoSize = true,
                Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(224, 123, 57)
            };
            gsHeader.Tag = "i18n:syshead";
            gsCard.Controls.Add(gsHeader);

            var lblRes = new Label { Text = "Resolution:", Location = new Point(18, 56), AutoSize = true, ForeColor = Color.LightGray };
            _resCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(130, 52),
                Width = 180,
                BackColor = Color.FromArgb(30, 37, 50),
                ForeColor = Color.White
            };
            _resCombo.Items.AddRange(new object[] { "1920X1080", "2560X1440", "1440X850", "1280X720" });
            _resCombo.SelectedIndex = Math.Max(0, _resCombo.Items.IndexOf(_gameResolution));

            var lblWm = new Label { Text = "Window Mode:", Location = new Point(340, 56), AutoSize = true, ForeColor = Color.LightGray };
            _winModeCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(450, 52),
                Width = 160,
                BackColor = Color.FromArgb(30, 37, 50),
                ForeColor = Color.White
            };
            _winModeCombo.Items.AddRange(new object[] { "fullscreen", "borderless", "windowed" });
            _winModeCombo.SelectedIndex = Math.Max(0, _winModeCombo.Items.IndexOf(_gameWindowMode));

            var lblDx = new Label { Text = "Graphics API:", Location = new Point(640, 56), AutoSize = true, ForeColor = Color.LightGray };
            _dxCombo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new Point(745, 52),
                Width = 220,
                BackColor = Color.FromArgb(30, 37, 50),
                ForeColor = Color.White
            };
            _dxCombo.Items.AddRange(new object[] { "dx11 (DirectX 11 FL 11.0)", "dx9 (2016 Native)", "dx12 (Experimental)" });
            _dxCombo.SelectedIndex = _gameGraphicsApi == "dx9" ? 1 : (_gameGraphicsApi == "dx12" ? 2 : 0);

            var saveCfgBtn = new Button
            {
                Text = "✔ Сохранить параметры игры",
                Location = new Point(18, 105),
                Size = new Size(235, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(45, 135, 75),
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            saveCfgBtn.Tag = "i18n:gamesave";
            saveCfgBtn.FlatAppearance.BorderSize = 0;
            RoundControl(saveCfgBtn, 9);
            saveCfgBtn.Click += (s, e) =>
            {
                if (WriteGameConfigFiles())
                    MessageBox.Show("Сохранён TCLS\\config\\system.ini (резервная копия .bak при наличии исходного файла).",
                        "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            var infoBox = new Label
            {
                Location = new Point(18, 155),
                Size = new Size(950, 60),
                ForeColor = Color.FromArgb(150, 165, 185),
                Text = "Параметры игры сохраняются вручную в TCLS\\config\\system.ini.\r\n" +
                       "При запуске открывается только TFOL_OBT.exe без аргументов."
            };

            _resCombo.SelectedIndexChanged += (sender, args) => { if (_isReady) SaveSettings(); };
            _winModeCombo.SelectedIndexChanged += (sender, args) => { if (_isReady) SaveSettings(); };
            _dxCombo.SelectedIndexChanged += (sender, args) => { if (_isReady) SaveSettings(); };
            infoBox.Tag = "i18n:gameinfo";
            gsCard.Controls.AddRange(new Control[] { lblRes, _resCombo, lblWm, _winModeCombo, lblDx, _dxCombo, saveCfgBtn, infoBox });
            _subPage.Controls.Add(gsCard);
            BuildAppSettingsCard();

            _mainStage.Controls.Add(_subPage);
        }

        private static Label CardLabel(string text, int x, int y, int width, int height, float fontSize)
        {
            return new Label
            {
                Text = text, Location = new Point(x, y), Size = new Size(width, height),
                BackColor = Color.Transparent, ForeColor = Color.FromArgb(222, 231, 243),
                Font = new Font("Segoe UI", fontSize)
            };
        }

        private static void RoundControl(Control control, int radius)
        {
            // Intentionally empty. Only the outer Form has the original SWF shape.
            // Applying a Region to child controls caused repaint artifacts.
        }

        private static Button CardButton(string text, int x, int y, int width, int height, bool accent)
        {
            var b = new Button
            {
                Text = text, Location = new Point(x, y), Size = new Size(width, height),
                BackColor = accent ? Color.FromArgb(223, 118, 48) : Color.FromArgb(50, 70, 95),
                ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand,
                Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold)
            };
            b.FlatAppearance.BorderSize = 0;
            RoundControl(b, 9);
            return b;
        }

        private T Translate<T>(T control, string key) where T : Control
        {
            control.Tag = "i18n:" + key;
            return control;
        }

        private void UpdateSettingsTranslations()
        {
            if (_appSettingsCard != null) UpdateTranslationTree(_appSettingsCard);
            if (_gameSettingsCard != null) UpdateTranslationTree(_gameSettingsCard);
        }

        private void UpdateTranslationTree(Control root)
        {
            var d = _i18n[_currentLang];
            foreach (Control control in root.Controls)
            {
                string tag = control.Tag as string;
                if (tag != null && tag.StartsWith("i18n:", StringComparison.Ordinal))
                {
                    string key = tag.Substring(5);
                    if (d.ContainsKey(key)) control.Text = d[key];
                }
                if (control.HasChildren) UpdateTranslationTree(control);
            }
        }

        private void BuildAppSettingsCard()
        {
            _appSettingsCard = new ThemePanel(this, Color.FromArgb(229, 12, 25, 43), true, 0)
            {
                Location = new Point(22, 100), Size = new Size(1198, 512)
            };
            var card = _appSettingsCard;
            card.Controls.Add(Translate(CardLabel("ВНЕШНИЙ ВИД", 26, 22, 670, 30, 11f), "look"));
            _blurCheckbox = new CheckBox
            {
                Text = "Размытый фон", Tag = "i18n:blur", Checked = _useBlurBg,
                Location = new Point(26, 62), Size = new Size(240, 32),
                ForeColor = Color.White, BackColor = Color.Transparent
            };
            _blurCheckbox.CheckedChanged += (sender, args) =>
            {
                _useBlurBg = _blurCheckbox.Checked;
                RefreshBackground();
                if (_isReady) SaveSettings();
            };
            _soundCheckbox = new CheckBox
            {
                Text = "Звуки интерфейса", Tag = "i18n:sound", Checked = _soundEnabled,
                Location = new Point(294, 62), Size = new Size(240, 32),
                ForeColor = Color.White, BackColor = Color.Transparent
            };
            _soundCheckbox.CheckedChanged += (sender, args) =>
            {
                _soundEnabled = _soundCheckbox.Checked;
                if (_isReady) SaveSettings();
            };
            card.Controls.Add(_blurCheckbox);
            card.Controls.Add(_soundCheckbox);

            card.Controls.Add(Translate(CardLabel("РАСПОЛОЖЕНИЕ КЛИЕНТА", 26, 125, 680, 28, 11f), "gamepath"));
            card.Controls.Add(Translate(CardLabel("Путь к игре (рядом с лаунчером):", 26, 156, 690, 26, 9f), "pathhelp"));
            _pathBox = new TextBox
            {
                Text = ResolveGameExecutable(),
                Location = new Point(26, 190), Size = new Size(670, 28),
                BackColor = Color.FromArgb(32, 43, 60), ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle, ReadOnly = true
            };
            card.Controls.Add(_pathBox);

            card.Controls.Add(Translate(CardLabel("PYTHON PORTABLE 3.12 (x64)", 26, 256, 650, 30, 11f), "pythonhead"));
            _pythonStatus = CardLabel("", 26, 294, 680, 36, 9f);
            card.Controls.Add(_pythonStatus);
            var install = CardButton("Установить Python", 26, 345, 205, 38, true);
            install.Tag = "i18n:install";
            install.Click += (sender, args) => LaunchPythonInstaller();
            card.Controls.Add(install);
            var check = CardButton("Проверить Python", 240, 345, 198, 38, false);
            check.Tag = "i18n:pycheck";
            check.Click += (sender, args) => UpdatePythonStatus();
            card.Controls.Add(check);
            card.Controls.Add(Translate(CardLabel("Python используется только для диагностики; игра работает без него.",
                26, 404, 680, 46, 9f), "pynote"));

            card.Controls.Add(Translate(CardLabel("СЕРВЕРЫ — SERVERS.INI", 735, 22, 410, 31, 11f), "serverhead"));
            card.Controls.Add(Translate(CardLabel("Укажи настоящий IP и порт. Пустые поля допустимы.",
                735, 55, 435, 52, 9f), "serverhelp"));
            string[] serverNames = { "EU/CIS #1", "EU #2", "CN/ASIA #1", "PTS 2016" };
            for (int i = 0; i < _serverCodes.Length; i++)
            {
                string code = _serverCodes[i];
                int y = 115 + 47 * i;
                card.Controls.Add(CardLabel(serverNames[i], 735, y + 5, 116, 31, 9.5f));
                var ip = new TextBox
                {
                    Text = _serverIps[code], Location = new Point(860, y), Width = 213,
                    BackColor = Color.FromArgb(32, 43, 60), ForeColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 10f)
                };
                var port = new NumericUpDown
                {
                    Minimum = 0, Maximum = 65535, Value = _serverPorts[code],
                    Location = new Point(1080, y), Width = 91,
                    BackColor = Color.FromArgb(32, 43, 60), ForeColor = Color.White,
                    Font = new Font("Consolas", 10f)
                };
                _serverIpEdits[code] = ip;
                _serverPortEdits[code] = port;
                card.Controls.Add(ip);
                card.Controls.Add(port);
            }
            _serverStatusLabel = Translate(CardLabel("Адреса записываются отдельно в Servers.ini рядом с EXE.",
                735, 320, 437, 57, 9f), "servernote");
            card.Controls.Add(_serverStatusLabel);

            var saveButton = CardButton("Сохранить настройки", 935, 451, 236, 40, true);
            saveButton.Tag = "i18n:save";
            saveButton.Click += (sender, args) =>
            {
                if (!SaveServerConfig(true)) return;
                SaveSettings();
                MessageBox.Show("Настройки и адреса серверов сохранены.", "Reactivate",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            card.Controls.Add(saveButton);
            _subPage.Controls.Add(card);
        }

        private void SwitchTab(string tabKey)
        {
            _currentTab = tabKey;
            bool settings = tabKey == "appsettings" || tabKey == "gamesettings";
            _sideBar.Visible = !settings;
            _mainStage.Visible = !settings;
            _settingsOverlay.Visible = settings;
            _homePage.Visible = tabKey == "home";
            _subPage.Visible = false;
            _gameSettingsCard.Visible = tabKey == "gamesettings";
            _appSettingsCard.Visible = tabKey == "appsettings";
            foreach (Button b in _navBtns)
            {
                bool active = (b.Tag as string) == tabKey;
                b.BackColor = active ? Color.FromArgb(224, 123, 57) : Color.FromArgb(38, 59, 82);
                b.ForeColor = active ? Color.White : Color.FromArgb(205, 218, 232);
                b.FlatAppearance.MouseOverBackColor = Color.FromArgb(58, 78, 102);
            }
            if (_settingsAppTab != null)
            {
                _settingsAppTab.BackColor = tabKey == "appsettings" ? Color.FromArgb(224, 123, 57) : Color.FromArgb(44, 64, 87);
                _settingsGameTab.BackColor = tabKey == "gamesettings" ? Color.FromArgb(224, 123, 57) : Color.FromArgb(44, 64, 87);
            }
            _titleBar.BringToFront();
            if (settings) { _settingsOverlay.BringToFront(); _titleBar.BringToFront(); }
            UpdateSubPageText();
            RefreshBackground();
        }

        private void BuildSettingsOverlay()
        {
            _settingsOverlay = new ThemePanel(this, Color.FromArgb(234, 11, 24, 41), true, 0)
            {
                Location = new Point(19, 81),
                Size = new Size(1242, 622),
                Visible = false
            };
            _settingsBack = CardButton("← Назад", 22, 19, 138, 40, false);
            _settingsBack.Click += (s, e) => { if (SaveServerConfig(true)) SwitchTab("home"); };
            _settingsOverlay.Controls.Add(_settingsBack);
            _settingsAppTab = CardButton("Лаунчер", 178, 19, 185, 40, false);
            _settingsAppTab.Click += (s, e) => SwitchTab("appsettings");
            _settingsOverlay.Controls.Add(_settingsAppTab);
            _settingsGameTab = CardButton("Игра", 373, 19, 185, 40, false);
            _settingsGameTab.Click += (s, e) => { if (SaveServerConfig(true)) SwitchTab("gamesettings"); };
            _settingsOverlay.Controls.Add(_settingsGameTab);
            _settingsPageTitle = new Label
            {
                Location = new Point(575, 21), Size = new Size(600, 36),
                TextAlign = ContentAlignment.MiddleRight, BackColor = Color.Transparent,
                ForeColor = Color.FromArgb(223, 235, 248),
                Font = new Font("Segoe UI Semibold", 15f, FontStyle.Bold)
            };
            _settingsOverlay.Controls.Add(_settingsPageTitle);
            // Parent transfer is deliberate: settings replace the full interior,
            // not a card squeezed beside the navigation bar.
            _gameSettingsCard.Location = new Point(22, 84);
            _gameSettingsCard.Size = new Size(1198, 512);
            _appSettingsCard.Location = new Point(22, 84);
            _appSettingsCard.Size = new Size(1198, 512);
            _settingsOverlay.Controls.Add(_gameSettingsCard);
            _settingsOverlay.Controls.Add(_appSettingsCard);
            Controls.Add(_settingsOverlay);
        }

        private void SetLanguage(string lang)
        {
            if (!_i18n.ContainsKey(lang)) lang = "ru";
            _currentLang = lang;
            var d = _i18n[lang];

            string[] codes = { "eu1", "eu2", "asia1", "pts" };
            int selReg = Array.IndexOf(codes, _currentRegion);
            _regionCombo.Items.Clear();
            _regionCombo.Items.AddRange(new object[] { d["srv_eu1"], d["srv_eu2"], d["srv_asia1"], d["srv_pts"] });
            _regionCombo.SelectedIndex = Math.Max(0, selReg);
            UpdateServerInfoLabel();

            string[] navKeys = { "nav_home", "nav_gamesettings", "nav_appsettings" };
            for (int i = 0; i < _navBtns.Length; i++)
                _navBtns[i].Text = d[navKeys[i]];

            foreach (Button lb in _langBtns)
            {
                bool active = (lb.Tag as string) == lang;
                lb.BackColor = active ? Color.FromArgb(224, 123, 57) : Color.FromArgb(42, 63, 85);
                lb.ForeColor = Color.White;
                lb.FlatAppearance.MouseOverBackColor = Color.FromArgb(58, 78, 102);
                lb.Invalidate();
            }

            _newsHeaderLabel.Text = d["news_hdr"];
            for (int i = 0; i < 4; i++) _newsItemLabels[i].Text = d["n" + (i + 1)];
            _statusMainLabel.Text = _currentLang == "en" ? "Launch: TFOL_OBT.exe" :
                (_currentLang == "zh" ? "启动: TFOL_OBT.exe" : "Запуск: TFOL_OBT.exe");
            _statusVerLabel.Text = d["st_ver"];
            _startGameBtn.Text = d["btn_start"];
            UpdateSubPageText();
            UpdateSettingsTranslations();
            if (_settingsAppTab != null)
            {
                _settingsBack.Text = d["back"];
                _settingsAppTab.Text = d["settingsapp"];
                _settingsGameTab.Text = d["settingsgame"];
                _settingsPageTitle.Text = _currentTab == "gamesettings" ? d["gs_t"] : d["as_t"];
            }
            if (_isReady) SaveSettings();
            RefreshBackground();
        }


        private void UpdateSubPageText()
        {
            var d = _i18n[_currentLang];
            if (_settingsPageTitle != null && _currentTab == "appsettings") _settingsPageTitle.Text = d["as_t"];
            else if (_settingsPageTitle != null && _currentTab == "gamesettings") _settingsPageTitle.Text = d["gs_t"];
            if (_currentTab == "gamesettings") { _subTitleLabel.Text = d["gs_t"]; _subDescLabel.Text = d["gs_d"]; }
            else if (_currentTab == "appsettings") { _subTitleLabel.Text = d["as_t"]; _subDescLabel.Text = d["as_d"]; }
        }

        private bool WriteGameConfigFiles()
        {
            string gameRoot = GetGameDirectory(true);
            if (gameRoot == null) return false;
            try
            {
                SaveSettings();
                string cfgDir = Path.Combine(gameRoot, "TCLS", "config");
                Directory.CreateDirectory(cfgDir);
                string path = Path.Combine(cfgDir, "system.ini");
                var changes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                changes["resolution"] = _gameResolution;
                changes["windowmode"] = _gameWindowMode;
                changes["graphicsapi"] = _gameGraphicsApi;
                changes["region"] = _currentRegion;
                changes["lang"] = _currentLang;
                List<string> lines = File.Exists(path) ? new List<string>(File.ReadAllLines(path)) : new List<string>();
                if (File.Exists(path) && !File.Exists(path + ".bak")) File.Copy(path, path + ".bak");
                int sectionStart = -1, sectionEnd = lines.Count;
                for (int i = 0; i < lines.Count; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Equals("[system]", StringComparison.OrdinalIgnoreCase))
                    { sectionStart = i; continue; }
                    if (sectionStart >= 0 && line.StartsWith("[") && line.EndsWith("]"))
                    { sectionEnd = i; break; }
                }
                if (sectionStart < 0)
                {
                    if (lines.Count > 0) lines.Add("");
                    sectionStart = lines.Count;
                    lines.Add("[system]");
                    sectionEnd = lines.Count;
                }
                for (int i = sectionStart + 1; i < sectionEnd; i++)
                {
                    string trimmed = lines[i].Trim();
                    if (trimmed.StartsWith("#") || trimmed.StartsWith(";")) continue;
                    int equals = lines[i].IndexOf('=');
                    if (equals < 0) continue;
                    string key = lines[i].Substring(0, equals).Trim();
                    if (changes.ContainsKey(key))
                    {
                        lines[i] = key + "=" + changes[key];
                        changes.Remove(key);
                    }
                }
                foreach (var pair in changes)
                    lines.Insert(sectionEnd++, pair.Key + "=" + pair.Value);
                File.WriteAllLines(path, lines, new UTF8Encoding(false));
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить конфигурацию: " + ex.Message, "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        private void PromptAccountDialog()
        {
            PlayUiSound();
            using (var dlg = new Form())
            {
                dlg.Text = "Account Sign-In — Reactivate";
                dlg.Size = new Size(360, 190);
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false;
                dlg.MinimizeBox = false;
                dlg.BackColor = Color.FromArgb(24, 30, 42);
                dlg.ForeColor = Color.White;

                var lbl = new Label { Text = "Account / Callsign:", Location = new Point(20, 20), AutoSize = true };
                var box = new TextBox { Text = _accountName, Location = new Point(20, 46), Width = 300 };
                var ok = new Button
                {
                    Text = "Save",
                    Location = new Point(220, 96),
                    Size = new Size(100, 32),
                    BackColor = Color.FromArgb(224, 123, 57),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat
                };
                ok.Click += (s, e) =>
                {
                    if (!string.IsNullOrWhiteSpace(box.Text))
                    {
                        _accountName = box.Text.Trim();
                        _accountBtn.Text = "◈ " + _accountName;
                        SaveSettings();
                    }
                    dlg.Close();
                };
                dlg.Controls.AddRange(new Control[] { lbl, box, ok });
                dlg.ShowDialog(this);
            }
        }

        private string ResolveGameExecutable()
        {
            string literalTilde = Path.Combine(_baseDir, "~TFOL", "TFOL", "Binaries", "Win32", GameExecutableName);
            string normalFolder = Path.Combine(_baseDir, "TFOL", "TFOL", "Binaries", "Win32", GameExecutableName);
            // Use precisely this executable, in the launcher's own directory tree.
            // The ~TFOL spelling is supported literally; TFOL is supported as a folder name too.
            if (File.Exists(literalTilde)) return literalTilde;
            if (File.Exists(normalFolder)) return normalFolder;
            return literalTilde;
        }

        private void LaunchGameClient()
        {
            string exe = ResolveGameExecutable();
            if (!File.Exists(exe))
            {
                MessageBox.Show("Не найден TFOL_OBT.exe рядом с Reactivate.exe.\r\n\r\n" +
                    "Ожидаемый путь:\r\n" + exe + "\r\n\r\n" +
                    "Также поддерживается папка TFOL\\TFOL\\Binaries\\Win32.",
                    "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            PlayUiSound();
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = exe,
                    WorkingDirectory = Path.GetDirectoryName(exe),
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось запустить TFOL_OBT.exe: " + ex.Message,
                    "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string ServerFile
        {
            get
            {
                string local = Path.Combine(_baseDir, "Servers.ini");
                string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "Servers.ini");
                if (File.Exists(local)) return local;
                return File.Exists(fallback) ? fallback : local;
            }
        }

        private void UpdateServerInfoLabel()
        {
            if (_pingLabel == null) return;
            string ip;
            if (_serverIps.TryGetValue(_currentRegion, out ip) && !string.IsNullOrWhiteSpace(ip))
            {
                _pingLabel.Text = "● " + ip;
            }
            else _pingLabel.Text = _currentLang == "en" ? "● IP not set" :
                (_currentLang == "zh" ? "● 未设置 IP" : "● IP не задан");
        }

        private void LoadServerConfig()
        {
            foreach (string code in _serverCodes) { _serverIps[code] = ""; _serverPorts[code] = 0; }
            _serverIniPath = ServerFile;
            // Create at first run; no made-up IPs. On protected media fall back to LocalAppData.
            try
            {
                if (!File.Exists(_serverIniPath))
                {
                    try { WriteDefaultServerConfig(_serverIniPath); }
                    catch (UnauthorizedAccessException)
                    {
                        _serverIniPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "Reactivate", "Servers.ini");
                        if (!File.Exists(_serverIniPath)) WriteDefaultServerConfig(_serverIniPath);
                    }
                }
                bool inServers = false;
                foreach (string line in File.ReadAllLines(_serverIniPath))
                {
                    string trimmed = line.Trim();
                    if (trimmed.StartsWith("[") && trimmed.EndsWith("]"))
                    {
                        inServers = trimmed.Equals("[servers]", StringComparison.OrdinalIgnoreCase);
                        continue;
                    }
                    if (!inServers || trimmed.StartsWith(";") || trimmed.StartsWith("#")) continue;
                    int equal = trimmed.IndexOf('=');
                    if (equal < 1) continue;
                    string key = trimmed.Substring(0, equal).Trim().ToLowerInvariant();
                    string value = trimmed.Substring(equal + 1).Trim();
                    foreach (string code in _serverCodes)
                    {
                        if (key == code + "_ip")
                        {
                            IPAddress parsed;
                            if (value.Length == 0 || IPAddress.TryParse(value, out parsed)) _serverIps[code] = value;
                        }
                        else if (key == code + "_port")
                        {
                            int port;
                            if (int.TryParse(value, out port) && port >= 0 && port <= 65535)
                                _serverPorts[code] = port;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Do not break the launcher on read-only drives / invalid user INI.
                Debug.WriteLine("Cannot read Servers.ini: " + ex.Message);
            }
        }

        private void WriteDefaultServerConfig(string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var lines = new List<string>();
            lines.Add("; TFOL_1.0.0.59 - Server endpoints. Add real IP addresses and ports.");
            lines.Add("; Empty IP and port=0 mean unconfigured; no addresses are assumed.");
            lines.Add("[servers]");
            foreach (string code in _serverCodes)
            {
                lines.Add(code + "_ip=");
                lines.Add(code + "_port=0");
            }
            File.WriteAllLines(path, lines, new UTF8Encoding(false));
        }

        private bool SaveServerConfig(bool showErrors)
        {
            var newIps = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var newPorts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string code in _serverCodes)
            {
                string ip = _serverIpEdits.ContainsKey(code) ? _serverIpEdits[code].Text.Trim() : _serverIps[code];
                int port = _serverPortEdits.ContainsKey(code) ? (int)_serverPortEdits[code].Value : _serverPorts[code];
                IPAddress parsed;
                if ((ip.Length > 0 && !IPAddress.TryParse(ip, out parsed)) || (ip.Length > 0 && port == 0))
                {
                    if (showErrors) MessageBox.Show("Для " + code + " введите настоящий IP и порт (1–65535), либо оставьте IP пустым.",
                        "Servers.ini", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                newIps[code] = ip;
                newPorts[code] = ip.Length == 0 ? 0 : port;
                if (ip.Length == 0 && _serverPortEdits.ContainsKey(code)) _serverPortEdits[code].Value = 0;
            }
            try
            {
                // Update only our section. Preserve comments, unrelated keys and sections.
                List<string> lines = File.Exists(_serverIniPath) ?
                    new List<string>(File.ReadAllLines(_serverIniPath)) : new List<string>();
                int section = -1, end = lines.Count;
                for (int i = 0; i < lines.Count; i++)
                {
                    string t = lines[i].Trim();
                    if (t.Equals("[servers]", StringComparison.OrdinalIgnoreCase)) section = i;
                    else if (section >= 0 && t.StartsWith("[") && t.EndsWith("]")) { end = i; break; }
                }
                if (section < 0) { if (lines.Count > 0) lines.Add(""); section = lines.Count; lines.Add("[servers]"); end = lines.Count; }
                var updates = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string code in _serverCodes)
                {
                    updates[code + "_ip"] = newIps[code];
                    updates[code + "_port"] = newPorts[code].ToString();
                }
                for (int i = section + 1; i < end; i++)
                {
                    int equal = lines[i].IndexOf('=');
                    if (equal < 0) continue;
                    string key = lines[i].Substring(0, equal).Trim();
                    if (updates.ContainsKey(key)) { lines[i] = key + "=" + updates[key]; updates.Remove(key); }
                }
                foreach (KeyValuePair<string, string> pair in updates) lines.Insert(end++, pair.Key + "=" + pair.Value);
                Directory.CreateDirectory(Path.GetDirectoryName(_serverIniPath));
                File.WriteAllLines(_serverIniPath, lines, new UTF8Encoding(false));
                foreach (string code in _serverCodes) { _serverIps[code] = newIps[code]; _serverPorts[code] = newPorts[code]; }
                UpdateServerInfoLabel();
                return true;
            }
            catch (UnauthorizedAccessException)
            {
                string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "Servers.ini");
                if (string.Equals(_serverIniPath, fallback, StringComparison.OrdinalIgnoreCase))
                {
                    if (showErrors) MessageBox.Show("Не хватает прав на сохранение Servers.ini.",
                        "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                _serverIniPath = fallback;
                return SaveServerConfig(showErrors);
            }
            catch (Exception ex)
            {
                if (showErrors) MessageBox.Show("Не удалось сохранить Servers.ini: " + ex.Message,
                    "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private string SettingsFile
        {
            get
            {
                string local = Path.Combine(_baseDir, "LauncherSettings.ini");
                string fallback = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Reactivate", "LauncherSettings.ini");
                if (!File.Exists(local)) return File.Exists(fallback) ? fallback : local;
                if (File.Exists(fallback) && File.GetLastWriteTimeUtc(fallback) > File.GetLastWriteTimeUtc(local))
                    return fallback;
                return local;
            }
        }

        private void LoadSettings()
        {
            try
            {
                string file = SettingsFile;
                if (File.Exists(file))
                {
                    foreach (string row in File.ReadAllLines(file))
                    {
                        int index = row.IndexOf('=');
                        if (index < 1) continue;
                        string key = row.Substring(0, index).Trim();
                        string val = row.Substring(index + 1).Trim();
                        switch (key.ToLowerInvariant())
                        {
                            case "blur": _useBlurBg = val == "1"; break;
                            case "sound": _soundEnabled = val != "0"; break;
                            case "lang": if (_i18n.ContainsKey(val)) _currentLang = val; break;
                            case "region": if (new[] { "eu1", "eu2", "asia1", "pts" }.Contains(val)) _currentRegion = val; break;
                            case "user": _accountName = val; break;
                            case "resolution": _gameResolution = val; break;
                            case "windowmode": _gameWindowMode = val; break;
                            case "graphicsapi": _gameGraphicsApi = val; break;
                        }
                    }
                }
            }
            catch { /* Invalid or read-only setting files must not block the launcher. */ }
        }

        private static string FlatValue(string value)
        {
            return (value ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
        }

        private void SaveSettings()
        {
            if (!_isReady) return;
            if (_resCombo != null && _resCombo.SelectedItem != null) _gameResolution = _resCombo.SelectedItem.ToString();
            if (_winModeCombo != null && _winModeCombo.SelectedItem != null) _gameWindowMode = _winModeCombo.SelectedItem.ToString();
            if (_dxCombo != null && _dxCombo.SelectedItem != null) _gameGraphicsApi = _dxCombo.SelectedItem.ToString().Split(' ')[0];
            string[] rows = {
                "blur=" + (_useBlurBg ? "1" : "0"),
                "sound=" + (_soundEnabled ? "1" : "0"), "lang=" + _currentLang,
                "region=" + _currentRegion, "user=" + FlatValue(_accountName),
                "resolution=" + FlatValue(_gameResolution),
                "windowmode=" + FlatValue(_gameWindowMode), "graphicsapi=" + FlatValue(_gameGraphicsApi)
            };
            try
            {
                string path = SettingsFile;
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    File.WriteAllLines(path, rows, new UTF8Encoding(false));
                }
                catch (UnauthorizedAccessException)
                {
                    path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "Reactivate", "LauncherSettings.ini");
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    File.WriteAllLines(path, rows, new UTF8Encoding(false));
                }
            }
            catch { /* Launcher should keep working when portable media is read-only. */ }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            SaveServerConfig(false);
            SaveSettings();
            base.OnFormClosing(e);
        }

        private string GetGameDirectory(bool showError)
        {
            // Game settings are saved beside the exact TFOL_OBT executable, not to an arbitrary folder.
            string exe = ResolveGameExecutable();
            if (File.Exists(exe))
            {
                string binariesDir = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(exe)));
                return binariesDir;
            }
            if (showError)
                MessageBox.Show("Не найден TFOL_OBT.exe рядом с лаунчером:\r\n" + exe,
                    "Reactivate", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return null;
        }

        private string PortablePythonPath
        {
            get { return Path.Combine(_baseDir, "PythonPortable", "python.exe"); }
        }

        private void UpdatePythonStatus()
        {
            if (_pythonStatus == null) return;
            if (!File.Exists(PortablePythonPath))
            {
                _pythonStatus.Text = "Не установлен. Нажмите «Установить Python» — скачивание с python.org (один раз).";
                return;
            }
            try
            {
                using (var process = new Process())
                {
                    process.StartInfo = new ProcessStartInfo
                    {
                        FileName = PortablePythonPath, Arguments = "-I --version",
                        UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
                        RedirectStandardError = true
                    };
                    process.Start();
                    if (!process.WaitForExit(3000))
                    {
                        process.Kill();
                        throw new InvalidOperationException("Истекло время ожидания запуска.");
                    }
                    string output = process.StandardOutput.ReadToEnd().Trim();
                    if (string.IsNullOrEmpty(output)) output = process.StandardError.ReadToEnd().Trim();
                    if (process.ExitCode != 0) throw new InvalidOperationException(output);
                    _pythonStatus.Text = "Готов: " + output + "  •  " + PortablePythonPath;
                }
            }
            catch (Exception ex) { _pythonStatus.Text = "Ошибка Python: " + ex.Message; }
        }

        private void LaunchPythonInstaller()
        {
            string installer = Path.Combine(_baseDir, "Install_Portable_Python.bat");
            if (!File.Exists(installer))
            {
                MessageBox.Show("Нет файла Install_Portable_Python.bat рядом с лаунчером.");
                return;
            }
            if (MessageBox.Show("Скачать и распаковать официальный Python 3.12.10 (x64, ~11 МБ)\n" +
                "в PythonPortable рядом с лаунчером?", "Python Portable",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try { Process.Start(new ProcessStartInfo { FileName = installer, WorkingDirectory = _baseDir, UseShellExecute = true }); }
            catch (Exception ex) { MessageBox.Show("Ошибка запуска установщика: " + ex.Message); }
        }

        private static string QuoteArg(string arg)
        {
            // Windows CreateProcess quoting rules, including spaces and embedded quotes.
            var builder = new StringBuilder("\"");
            int slashes = 0;
            foreach (char c in arg ?? "")
            {
                if (c == '\\') { slashes++; continue; }
                if (c == '"')
                {
                    builder.Append('\\', slashes * 2 + 1);
                    builder.Append('"');
                    slashes = 0;
                    continue;
                }
                builder.Append('\\', slashes);
                slashes = 0;
                builder.Append(c);
            }
            builder.Append('\\', slashes * 2);
            builder.Append('"');
            return builder.ToString();
        }
    }

    // Opaque parent panels are safe in WinForms. Their background is either
    // a solid color or a correctly cropped portion of the single SWF backdrop.
    // The only shaped control in this process is the Form itself.
    internal sealed class ThemePanel : Panel
    {
        private readonly ReactivateMainWindow _window;
        private readonly Color _tint;
        private readonly bool _solid;
        private readonly int _radius;

        public ThemePanel(ReactivateMainWindow window, Color tint, bool solid, int radius)
        {
            _window = window;
            _tint = tint;
            _solid = solid;
            _radius = radius;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            SetStyle(ControlStyles.SupportsTransparentBackColor, false);
            BackColor = tint.A == 0 ? Color.FromArgb(14, 19, 29) : Color.FromArgb(tint.R, tint.G, tint.B);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            _window.DrawSurface(e.Graphics, this, _tint, _solid, _radius);
        }
    }
}
