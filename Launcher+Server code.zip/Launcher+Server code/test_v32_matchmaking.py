"""Deterministic match-coordinator checks; NOT a two-computer UE4 network test."""
import sys,unittest,tempfile
from pathlib import Path
ROOT=Path(__file__).parent/'Release'/'Server'
sys.path.insert(0,str(ROOT))
import matchmaking
from server import App
from tdr_codec import packets,decode_all
class MultiQueue32(unittest.TestCase):
 def test_two_humans_get_same_registered_room_and_original_packet(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as temp:
   app=App(temp,0,0,config={'reddit_news_enabled':False})
   try:
    a=app.state.create_session('GroupA')['user_id'];b=app.state.create_session('GroupB')['user_id']
    q=app.state.matchmaking
    q.join(a,'a',1001,0);q.join(b,'b',1001,0)
    room=dict(RoomId=101,RoomSeq=77,RoomName='Players',MapID=101,MaxPlayerCount=12,DsDomain='127.0.0.1:7777',AllowTransform=1,Status='ready')
    q.register_worker('worker32',room,1001,0)
    first=q.poll(a,'a');second=q.poll(b,'b')
    self.assertEqual((first['state'],second['state']),(matchmaking.HUMANS,matchmaking.HUMANS))
    self.assertEqual(first['session_id'],second['session_id'])
    self.assertEqual(first['players'],[a,b]);self.assertEqual(second['players'],[a,b])
    for uid,decision in ((a,first),(b,second)):
     wire=matchmaking.poll_response(app.state.database,decision,uid)[matchmaking.POLL_HEADER.size:]
     values=decode_all('SyncMatchResult',packets(wire)[0][1]);self.assertEqual(values['TeamCount'],2)
   finally:app.close()
 def test_two_players_not_assigned_when_no_actual_host(self):
  now=[0]
  q=matchmaking.Queue(clock=lambda:now[0],wait_seconds=1,peer_enabled=False)
  q.join(1,'a',1010,0);q.join(2,'b',1010,0)
  self.assertEqual(q.poll(1,'a')['state'],matchmaking.WAITING_FOR_WORKER)
  now[0]=2
  d1=q.poll(1,'a');d2=q.poll(2,'b')
  self.assertEqual((d1['reason'],d2['reason']),('no_game_host','no_game_host'))
if __name__=='__main__':unittest.main()
