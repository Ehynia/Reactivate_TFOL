import sys,unittest
from pathlib import Path
ROOT=Path(__file__).parent / 'Release' / 'Server'
sys.path.insert(0,str(ROOT))
import client_runner,launcher_entry
class DiagnosticsOptIn32(unittest.TestCase):
 def test_launcher_contract_default_off(self):
  inp=dict(protocol=2,launcher_root='C:/Reactivate',game_path='C:/TFOL',nickname='Tester',server_code='pts',server_ip='',server_port=0,language='ru',auth_action='login',account_key='test')
  from unittest.mock import patch
  with patch.object(launcher_entry,'selected_game',return_value=dict(executable='C:/TFOL/TFOL_OBT_LOCAL.exe')):
   self.assertTrue(str(launcher_entry.request(inp)).endswith('TFOL_OBT_LOCAL.exe'))
   inp['collect_diagnostics']=True
   launcher_entry.request(inp)
   inp['collect_diagnostics']='false'
   with self.assertRaisesRegex(ValueError,'diagnostics'):launcher_entry.request(inp)
 def test_runner_opt_in_branch(self):
  src=(ROOT/'client_runner.py').read_text('utf-8')
  self.assertIn('if collect_diagnostics:out.mkdir()',src)
  self.assertIn('if collect_diagnostics:event[\'report_directory\']',src)
  self.assertIn('archive=None\n    if collect_diagnostics:',src)
 def test_csharp_switch_and_cache(self):
  root=Path(__file__).parent
  src=(root/'Release/Server/LauncherSource/ReactivateStandalone.cs').read_text('utf-8')
  self.assertIn('"diagnostics=" + (_collectDiagnostics ? "1" : "0")',src)
  self.assertIn('[DataMember(Name = "collect_diagnostics")]',src)
  self.assertIn('CollectDiagnostics = _collectDiagnostics',src)
  binary=(root/'Release/Reactivate.exe').read_bytes()
  self.assertIn('Reactivate.UI.v32'.encode('utf-16le'),binary)
  self.assertNotIn('Reactivate.UI.v31'.encode('utf-16le'),binary)
if __name__=='__main__':unittest.main()
