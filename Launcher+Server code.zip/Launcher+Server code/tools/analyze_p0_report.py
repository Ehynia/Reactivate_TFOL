#!/usr/bin/env python3
"""Read-only OBT33 post-match timeline audit; never uploads logs or creates ZIPs."""
import argparse
import collections
import json
import re
import zipfile
from pathlib import Path

MAX_FILE = 20 * 1024 * 1024
MAX_TOTAL = 40 * 1024 * 1024
EVENT_NAMES = (
    'OnBattleResultDataTimeout', 'WaitingPostMatch',
    'Match State Changed', 'BattleRLTManager', 'ingameResult_camerashake',
)
TIME_RE = re.compile(r'^\[([^]]+)\]')


def analyze(path):
    with zipfile.ZipFile(path, 'r') as archive:
        listing = {item.filename: item for item in archive.infolist()}
        wanted = ('TFOL.log', 'server.jsonl')
        if not all(name in listing for name in wanted):
            raise ValueError('Missing TFOL.log or server.jsonl')
        if any(listing[name].file_size > MAX_FILE for name in wanted) or sum(listing[name].file_size for name in wanted) > MAX_TOTAL:
            raise ValueError('Log size limit exceeded')
        game = archive.read('TFOL.log').decode('utf-8', 'replace').splitlines()
        events = []
        command_counts = collections.Counter()
        event_counts = collections.Counter()
        native_result_rejected = 0
        for line in archive.read('server.jsonl').decode('utf-8', 'replace').splitlines():
            try:
                entry = json.loads(line)
            except (json.JSONDecodeError, TypeError):
                continue
            kind = entry.get('event', '')
            event_counts[kind] += 1
            if kind == 'game_application_payload':
                command_counts[str(entry.get('command'))] += 1
            if kind == 'native_result_rejected': native_result_rejected += 1
        for line in game:
            if any(key in line for key in EVENT_NAMES):
                t = TIME_RE.search(line)
                marker = next(key for key in EVENT_NAMES if key in line)
                events.append({'time':t.group(1) if t else None, 'event': marker})
        missing = sum(1 for event in events if event['event']=='OnBattleResultDataTimeout')
        outcome = {
            'report': Path(path).name,
            'engine_postmatch_seen': any(event['event']=='WaitingPostMatch' for event in events),
            'engine_result_timeouts': missing,
            'native_result_persisted': event_counts['native_result_persisted'],
            'native_result_rejected': native_result_rejected,
            'application_exit_post_game_requests': command_counts['165'],
            'application_tutorial_completion_requests': command_counts['176'],
            'travel_status_reports': event_counts['native_engine_travel_status'],
            'result_handshake_seen': event_counts['native_result_persisted'] > 0 and missing == 0,
            'gameplay_verified': False,  # result persistence cannot prove UE4 replication/combat
            'events': events[-30:],
            'interpretation': ('UE4 post-match awaited unavailable result data; do not invent victory or awards'
                               if missing else 'No result timeout observed; result delivery still requires native proof')
        }
        return outcome


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reports', type=Path, nargs='+')
    args = parser.parse_args()
    for path in args.reports:
        print(json.dumps(analyze(path), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
