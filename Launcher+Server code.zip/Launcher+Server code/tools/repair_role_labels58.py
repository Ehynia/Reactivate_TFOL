"""Restore the pinned four-character class labels without changing other fields."""
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'Release/Server'))
sys.path.insert(0,str(ROOT/'Release/ClientLanguages'))
import build_client_resources
import ue_pak_reader


def sha(raw):return hashlib.sha256(raw).hexdigest()


def main():
    bundle=ROOT/'Release/ClientLanguages'
    path=bundle/'manifest.json'
    manifest=json.loads(path.read_text('utf-8'))
    row=manifest['tables']['RoleTable.bytes']
    source=(bundle/'zh/tables/RoleTable.bytes').read_bytes()
    if sha(source)!=row['languages']['zh']:raise ValueError('Original role table hash mismatch')
    width,count=struct.unpack_from('<II',source,8)
    if len(source)!=140+width*count or width<1040:raise ValueError('Original role layout changed')
    for side,language in enumerate(('ru','en')):
        table=bundle/language/'tables/RoleTable.bytes'
        raw=table.read_bytes()
        if sha(raw)!=row['languages'][language] or len(raw)!=len(source):raise ValueError('Translated role table mismatch')
        data=bytearray(raw)
        for i in range(count):
            offset=140+i*width+528
            label=source[offset:offset+512].split(b'\0',1)[0].decode('utf-8')
            translated=build_client_resources.CLASS_LABELS[label][side].encode('utf-8')
            data[offset:offset+512]=translated+bytes(512-len(translated))
        pak=bundle/language/'TFOL_ReactivateClient_P.pak'
        old_pak=pak.read_bytes()
        if sha(old_pak)!=manifest['languages'][language]['pak_sha256']:raise ValueError('Client PAK hash mismatch')
        _,entries,_=ue_pak_reader.index(pak)
        files={entry['name']:ue_pak_reader.asset(pak,entry) for entry in entries}
        key='Bytes/bytes_for_bothside/RoleTable.bytes'
        if files[key]!=raw:raise ValueError('Loose and packed role tables differ')
        files[key]=bytes(data)
        rebuilt=build_client_resources.build_pak(files)
        previous=row.setdefault('previous_sha256',[])
        if sha(raw)!=sha(data) and sha(raw) not in previous:previous.append(sha(raw))
        previous_paks=manifest.setdefault('previous_pak_sha256',[])
        if sha(old_pak)!=sha(rebuilt) and sha(old_pak) not in previous_paks:previous_paks.append(sha(old_pak))
        table.write_bytes(data)
        pak.write_bytes(rebuilt)
        row['languages'][language]=sha(data)
        manifest['languages'][language]['pak_sha256']=sha(rebuilt)
    path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Role labels restored; previous installed hashes remain accepted.')


if __name__=='__main__':main()
