"""Read-only, privacy-minimizing OBT report ZIP triage. No raw log exporting."""
from __future__ import annotations
import collections
import json
import re
import sys
import zipfile
from pathlib import Path

# Recognize ONLY fixed messages from native logs. No player names or addresses.
WARNINGS = {
    'empty_monthly_days': 'array astMonthDaySignDayList of length 0',
    'empty_monthly_accumulated': 'array astMonthAccSignList of length 0',
    'empty_monthly_history': 'array astMonthHistoryAccSignList of length 0',
    'empty_little_items': 'array littleItemDatas of length 0',
    'missing_skill_vehicle_icon': 'vehicle icon is NULL',
    'failed_skill_spawn': 'SkillManager InitSkillSystem Spawn Skill Failed',
    'missing_movement_animation': 'from array MovementAnim_',
    'failed_network_send': 'LogDSNET: SendPackFail:',
    'postmatch_result_timeout': 'OnBattleResultDataTimeout',
    'missing_result_camerashake': 'ingameResult_camerashake',
    'missing_CHS_font': "Failed to load font data from 'CHS'",
    'missing_ICU_resource': 'Internationalization/icudt53l/',
    'invulnerable_hit': '###########Invincible!!!!',
    'invalid_room_player': 'RoomPlayer',
}
MAX_FILE_BYTES=24*1024*1024

def _read_zip(z,name):
    entry=z.getinfo(name)
    if entry.file_size>MAX_FILE_BYTES:
        raise ValueError('report file exceeds allowed size')
    return z.read(name)

def summarize(path):
    path=Path(path)
    with zipfile.ZipFile(path) as archive:
        if not {'TFOL.log','server.jsonl','result.json'} <= set(archive.namelist()):
            raise ValueError('not an OBT diagnostic report')
        status=json.loads(_read_zip(archive,'result.json'))
        log=_read_zip(archive,'TFOL.log').decode('utf-8','replace')
        events=collections.Counter();commands=collections.Counter();unsupported=collections.Counter()
        for line in _read_zip(archive,'server.jsonl').decode('utf-8','replace').splitlines():
            try:row=json.loads(line)
            except ValueError:continue
            event=row.get('event','')
            if event in ('native_result_persisted','native_result_rejected','native_result_capture_aborted','native_engine_travel_status'):
                events[event]+=1
            if event=='game_application_payload':
                cmd=row.get('command')
                if type(cmd)==int:
                    commands[cmd]+=1
                    if row.get('handler_implemented') is False:unsupported[cmd]+=1
        matches=re.findall(r'^.*?LoadMap: [^\r\n]+$',log,re.MULTILINE)
        return {
            'report':path.name,
            'version':status.get('version'),
            'gameplay_verified':bool(status.get('gameplay_verified')),
            'matched_game_map_transitions':len(status.get('battle_init_options') or []),
            'room_player_lookup_errors':status.get('room_player_lookup_errors',None),
            'missing_animation_array_count':status.get('missing_animation_array_count',None),
            'warnings':{key:log.count(token) for key,token in WARNINGS.items() if token in log},
            'native_events':dict(events),
            'unhandled_protocol_commands':{str(k):v for k,v in sorted(unsupported.items())},
            'protocol_commands_seen':sorted(commands),
            'language':status.get('client_language'),
            'untranslated_ui_sources':(status.get('ui_translation_summary') or {}).get('remaining_sources'),
            'note':'Counts are log occurrences, not proofs of causation or successful gameplay.',
        }

if __name__=='__main__':
    if not sys.argv[1:]:raise SystemExit('Usage: report_audit38.py OBT_LOCAL_*_REPORT.zip ...')
    print(json.dumps([summarize(p) for p in sys.argv[1:]],ensure_ascii=False,indent=2))
