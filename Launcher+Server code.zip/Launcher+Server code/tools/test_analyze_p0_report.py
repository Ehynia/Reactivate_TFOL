import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from analyze_p0_report import analyze

class ReportInspector(unittest.TestCase):
    def create(self,dir,lines,events):
        fn=Path(dir)/'test_report.zip'
        with zipfile.ZipFile(fn,'w') as z:
            z.writestr('TFOL.log','\n'.join(lines))
            z.writestr('server.jsonl','\n'.join(json.dumps(e) for e in events))
        return fn
    def test_detects_timeout_without_fabricating_awards(self):
        with tempfile.TemporaryDirectory() as td:
            fn=self.create(td,['[2026.10.17-00.00.00] WaitingPostMatch','[2026.10.17-00.00.05] OnBattleResultDataTimeout'],
                           [{'event':'native_engine_travel_status'},{'event':'game_application_payload','command':65}])
            result=analyze(fn)
            self.assertTrue(result['engine_postmatch_seen'])
            self.assertEqual(result['engine_result_timeouts'],1)
            self.assertEqual(result['native_result_persisted'],0)
            self.assertFalse(result['gameplay_verified'])
    def test_handles_absent_result_timeout(self):
        with tempfile.TemporaryDirectory() as td:
            fn=self.create(td,[],[{'event':'native_result_persisted'}]);self.assertTrue(analyze(fn)['result_handshake_seen']);self.assertFalse(analyze(fn)['gameplay_verified'])
    def test_rejects_oversized_log(self):
        with tempfile.TemporaryDirectory() as td:
            fn=Path(td)/'oversized.zip'
            with zipfile.ZipFile(fn,'w',compression=zipfile.ZIP_DEFLATED) as z:
                z.writestr('TFOL.log','x'*(20*1024*1024+1))
                z.writestr('server.jsonl','{}')
            with self.assertRaisesRegex(ValueError,'size limit'):analyze(fn)
    def test_requires_both_logs(self):
        with tempfile.TemporaryDirectory() as td:
            fn=Path(td)/'empty.zip'
            with zipfile.ZipFile(fn,'w') as z:z.writestr('TFOL.log','log')
            with self.assertRaisesRegex(ValueError,'Missing'):analyze(fn)

if __name__=='__main__':unittest.main()
