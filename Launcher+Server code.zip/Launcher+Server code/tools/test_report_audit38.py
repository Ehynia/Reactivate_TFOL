"""Unit tests for privacy-safe report triage; uses only synthetic logs."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from report_audit38 import summarize

class ReportAudit38(unittest.TestCase):
    def test_summarizes_events_without_leaking_identifiers(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'sample.zip'
            lines=[dict(event='game_application_payload',command=117,handler_implemented=False,uid=100001,token='DO_NOT_COPY'),
                   dict(event='game_application_payload',command=196,handler_implemented=False,uid=100001),
                   dict(event='native_result_capture_aborted',uid=100001)]
            with zipfile.ZipFile(target,'w') as z:
                z.writestr('result.json',json.dumps(dict(version='OBT_LOCAL_33',gameplay_verified=False)))
                z.writestr('server.jsonl','\n'.join(json.dumps(row) for row in lines))
                z.writestr('TFOL.log','OnBattleResultDataTimeout\n'+"LogClient:Error: SkillUIListID 0 is Not Good! vehicle icon is NULL\n"+'player SECRET_USERNAME token DO_NOT_COPY')
            report=summarize(target)
            self.assertEqual(report['unhandled_protocol_commands'],{'117':1,'196':1})
            self.assertEqual(report['warnings']['postmatch_result_timeout'],1)
            self.assertEqual(report['warnings']['missing_skill_vehicle_icon'],1)
            text=json.dumps(report)
            self.assertNotIn('SECRET_USERNAME',text)
            self.assertNotIn('DO_NOT_COPY',text)
            self.assertNotIn('100001',text)

    def test_rejects_nonreport_archives(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'invalid.zip'
            with zipfile.ZipFile(target,'w') as z:z.writestr('README.txt','no logs')
            with self.assertRaisesRegex(ValueError,'not an OBT diagnostic report'):
                summarize(target)

if __name__=='__main__':unittest.main()
