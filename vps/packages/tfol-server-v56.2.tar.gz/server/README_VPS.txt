Reactivate TFOL OBT33 v56.2 — hosted-preparation server package.
No UE4 game EXE, DLL, PAK or personal account data included.
This is NOT a publicly playable dedicated UE4 server.
The HTTP and TCP services intentionally bind 127.0.0.1 only.
Use Linux Python 3.11+ and systemd; run installer with SHA-256 verification.
Original TFOL asset rights belong to their respective owners.
