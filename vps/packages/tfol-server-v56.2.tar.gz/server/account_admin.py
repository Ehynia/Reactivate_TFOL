"""Explicit offline recovery for an existing local account; never auto-run."""
import argparse,json
from pathlib import Path
import accounts
from database import Database
from instance_lock import InstanceLock

def issue_existing(data,login,rotate=False):
    folder=Path(data).resolve();path=folder/'server.sqlite3'
    if not path.is_file():raise ValueError('No existing account database at '+str(path))
    login=accounts.account_login(login)
    ownership=InstanceLock(folder);database=None
    try:
        database=Database(path)
        with database.connect() as c:
            if not c.execute('SELECT 1 FROM account_identity WHERE login=?',(login,)).fetchone():raise ValueError('Unknown permanent account login; no new account was created')
        uid,password=accounts.issue(database,login,rotate=rotate)
        return dict(user_id=uid,login=login,password=password,password_shown_once=True)
    finally:
        if database:database.close()
        ownership.close()

def main():
    parser=argparse.ArgumentParser(description='Close the local server first. Display a generated password once for an existing account only.')
    parser.add_argument('--data',type=Path,required=True);parser.add_argument('--login',required=True)
    parser.add_argument('--rotate',action='store_true',help='Explicitly replace a lost issued password and revoke old sessions')
    args=parser.parse_args()
    try:result=issue_existing(args.data,args.login,args.rotate)
    except (OSError,ValueError) as error:parser.exit(1,str(error)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
