"""Account logins are private, permanent and independent of in-game names."""
import hashlib,hmac,secrets,time,unicodedata

MIGRATION='''
CREATE TABLE account_identity(uid INTEGER PRIMARY KEY REFERENCES players(uid),login TEXT NOT NULL UNIQUE,
 created_at REAL NOT NULL,tutorial_required INTEGER NOT NULL DEFAULT 0 CHECK(tutorial_required IN(0,1)),
 tutorial_completed_at REAL,nickname_set INTEGER NOT NULL DEFAULT 1 CHECK(nickname_set IN(0,1)));
INSERT INTO account_identity(uid,login,created_at) SELECT uid,nickname,created_at FROM players;
'''

class AuthenticationError(ValueError):pass
class RegistrationError(ValueError):pass

def account_login(value):
    value=nickname(value)
    if unicodedata.normalize('NFC',value)!=value or any(unicodedata.category(c).startswith('C') for c in value):
        raise ValueError('Use a normalized login without invisible characters')
    return value

def register(database,login_name):
    """Atomic creation, not an upgrade/takeover of a legacy guest identity."""
    login_name=account_login(login_name)
    password=secrets.token_urlsafe(32);salt=secrets.token_bytes(16)
    hashed=key_hash(password,salt);now=time.time()
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        # Protect both permanent login reservations and still-visible old names.
        if c.execute('SELECT 1 FROM account_identity WHERE login=?',(login_name,)).fetchone() or c.execute('SELECT 1 FROM players WHERE nickname=?',(login_name,)).fetchone():
            raise RegistrationError('Логин занят / Login already exists. Use sign-in; existing accounts are not replaced.')
        temporary='R_'+secrets.token_hex(12)
        uid=c.execute('INSERT INTO players(nickname,created_at) VALUES(?,?)',(temporary,now)).lastrowid
        public='Recruit_'+str(uid)
        if c.execute('SELECT 1 FROM players WHERE nickname=?',(public,)).fetchone():public+='_'+secrets.token_hex(4)
        c.execute('UPDATE players SET nickname=? WHERE uid=?',(public,uid))
        c.execute('INSERT INTO account_identity(uid,login,created_at,tutorial_required,nickname_set) VALUES(?,?,?,1,0)',(uid,login_name,now))
        c.execute('INSERT INTO account_keys VALUES(?,?,?,?)',(uid,salt,hashed,now))
        database.audit(c,uid,'account_registered',dict(tutorial_required=True))
    return dict(user_id=uid,login=login_name,password=password,password_shown_once=True,tutorial_required=True,
                nickname_policy='in_game_on_first_login')

def identity(database,uid):
    with database.connect() as c:
        row=c.execute('SELECT login,tutorial_required,tutorial_completed_at,nickname_set FROM account_identity WHERE uid=?',(uid,)).fetchone()
    if row is None:raise ValueError('Unknown account identity')
    return dict(row)

def rename_in_game(database,uid,name):
    name=account_login(name)
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute('SELECT tutorial_required,tutorial_completed_at,nickname_set FROM account_identity WHERE uid=?',(uid,)).fetchone()
        if not row:raise ValueError('unknown_identity')
        # Nickname is a one-time character-creation action on first login.
        # Tutorial completion remains separate for gameplay unlocks.
        # Only the first free choice belongs to this onboarding flow. Paid
        # subsequent rename-card consumption is not implemented; fail closed.
        if row['nickname_set']:raise ValueError('nickname_already_set')
        if c.execute('SELECT 1 FROM players WHERE nickname=? AND uid!=?',(name,uid)).fetchone():raise ValueError('name_exists')
        reserved=c.execute('SELECT uid FROM account_identity WHERE login=?',(name,)).fetchone()
        if reserved and reserved['uid']!=uid:raise ValueError('name_exists')
        c.execute('UPDATE players SET nickname=? WHERE uid=?',(name,uid))
        c.execute('UPDATE account_identity SET nickname_set=1 WHERE uid=?',(uid,))
        database.audit(c,uid,'first_game_nickname_set',{})
    return name

def use_rename_card(database,uid,name):
    """Atomic native rename request; consume one original 601 card only on success."""
    name=account_login(name)
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        ident=c.execute('SELECT nickname_set FROM account_identity WHERE uid=?',(uid,)).fetchone()
        if not ident or not ident['nickname_set']:raise ValueError('first_nickname_required')
        row=c.execute('SELECT nickname FROM players WHERE uid=?',(uid,)).fetchone()
        if not row:raise ValueError('account_missing')
        if row['nickname']==name:raise ValueError('same_name')
        if c.execute('SELECT 1 FROM players WHERE nickname=? AND uid!=?',(name,uid)).fetchone():raise ValueError('name_exists')
        if c.execute('SELECT 1 FROM account_identity WHERE login=? AND uid!=?',(name,uid)).fetchone():raise ValueError('name_exists')
        card=c.execute('SELECT amount FROM account_cards WHERE uid=?',(uid,)).fetchone()
        if not card or card['amount']<=0:raise ValueError('rename_card_missing')
        c.execute('UPDATE account_cards SET amount=amount-1 WHERE uid=? AND amount>0',(uid,))
        c.execute('UPDATE players SET nickname=? WHERE uid=?',(name,uid))
        database.audit(c,uid,'nickname_renamed_with_card',dict(cards_left=card['amount']-1))
    return name

def confirm_tutorial(database,uid,event_id,mission):
    """Trusted worker/admin verification only; never called from client packet 176.

    The OBT mission-completion hook is not yet verified. Until it is, a client
    tutorial summary, UI step or elapsed timer cannot mark the mission complete.
    """
    if mission!='Megatron_Tutorial_1009' or not isinstance(event_id,str) or not 1<=len(event_id)<=120:raise ValueError('Invalid tutorial evidence')
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        changed=c.execute('UPDATE account_identity SET tutorial_completed_at=? WHERE uid=? AND tutorial_required=1 AND tutorial_completed_at IS NULL',(time.time(),uid)).rowcount
        if changed:database.audit(c,uid,'megatron_tutorial_verified',dict(event_id=event_id,mission=mission))
    return bool(changed)

def complete_tutorial_for_funded_account(database,uid):
    """One-way local policy: a positive persisted money balance finishes onboarding.

    Called after authentication and before native LoginDataRes; never trusts
    packet values, character XP, a tutorial banner, or a client-side balance.
    """
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        current=c.execute('SELECT tutorial_required,tutorial_completed_at FROM account_identity WHERE uid=?',(uid,)).fetchone()
        if current is None:raise ValueError('unknown_identity')
        if current['tutorial_completed_at'] is not None or not current['tutorial_required']:return False
        row=c.execute('SELECT credits FROM players WHERE uid=?',(uid,)).fetchone()
        if row is None:raise ValueError('unknown_player')
        funded=row['credits']>0
        if not funded:
            funded=bool(c.execute('SELECT 1 FROM wallet WHERE uid=? AND amount>0 LIMIT 1',(uid,)).fetchone())
        if not funded:
            funded=bool(c.execute('SELECT 1 FROM obt_currency WHERE uid=? AND amount>0 LIMIT 1',(uid,)).fetchone())
        if not funded:return False
        changed=c.execute('''UPDATE account_identity SET tutorial_required=0,tutorial_completed_at=?
                             WHERE uid=? AND tutorial_required=1 AND tutorial_completed_at IS NULL''',(time.time(),uid)).rowcount
        if changed:
            database.audit(c,uid,'tutorial_auto_completed_positive_balance',dict(policy='v56_local_money_gt_zero'))
        return bool(changed)

def nickname(value):
    if not isinstance(value,str):raise ValueError('Nickname must be text')
    value=value.strip()
    if any(c in value for c in '?&#=\\/') or not 1<=len(value)<=32 or len(value.encode('utf-8'))>=32 or any(ord(c)<32 for c in value):raise ValueError('Nickname must fit the client 32-byte UTF-8 field')
    return value
def key_hash(key,salt):
    return hashlib.scrypt(key.encode('utf-8'),salt=salt,n=16384,r=8,p=1,dklen=32)
def issue(database,nick,key=None,rotate=False):
    nick=nickname(nick);key=key if key is not None else secrets.token_urlsafe(32)
    if not isinstance(key,str) or not 20<=len(key)<=256:raise ValueError('Account key must contain 20..256 characters')
    salt=secrets.token_bytes(16);hashed=key_hash(key,salt)
    with database.connect() as c:
        row=c.execute('SELECT uid FROM account_identity WHERE login=?',(nick,)).fetchone()
    uid=row['uid'] if row else database.player(nick)
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        exists=c.execute('SELECT 1 FROM account_keys WHERE uid=?',(uid,)).fetchone()
        if exists and not rotate:raise ValueError('Account already has a key; use explicit rotation')
        c.execute('INSERT INTO account_keys VALUES(?,?,?,?) ON CONFLICT(uid) DO UPDATE SET salt=excluded.salt,key_hash=excluded.key_hash,issued_at=excluded.issued_at',(uid,salt,hashed,time.time()))
        c.execute('UPDATE sessions SET revoked=1 WHERE uid=?',(uid,))
        database.audit(c,uid,'account_key_rotated' if exists else 'account_key_issued',{})
    return uid,key
def login(database,nick,key,require_keys):
    with database.connect() as c:
        row=c.execute('SELECT a.uid,k.salt,k.key_hash FROM account_identity a LEFT JOIN account_keys k USING(uid) WHERE a.login=?',(nick,)).fetchone()
        # Guest diagnostics must not acquire an authenticated account by its
        # public Recruit_* or newly chosen in-game nickname.
        public_name=c.execute('SELECT 1 FROM players WHERE nickname=?',(nick,)).fetchone() if row is None else None
    if public_name:raise AuthenticationError('Use the permanent account login')
    registered=row is not None and row['key_hash'] is not None
    if registered or require_keys or key:
        bounded=isinstance(key,str) and 0<len(key)<=256
        candidate=key_hash(key if bounded else '',row['salt'] if registered else bytes(16))
        expected=row['key_hash'] if registered else bytes(32)
        if not bounded or not registered or not hmac.compare_digest(candidate,expected):raise AuthenticationError('Invalid nickname or account key')
        return row['uid'],False
    return (row['uid'] if row else database.player(nick)),True

class LoginLimiter:
    def __init__(self,clock=time.time):self.clock=clock;self.failures={}
    def allowed(self,address):
        now=self.clock();self.failures={k:[t for t in v if now-t<60] for k,v in self.failures.items() if any(now-t<60 for t in v)}
        return len(self.failures.get(address,[]))<5 and (address in self.failures or len(self.failures)<1024)
    def fail(self,address):self.failures.setdefault(address,[]).append(self.clock())
    def success(self,address):self.failures.pop(address,None)
