"""Read-only audit of original 32-row AIStrenthTable.bytes.

No unverified mapping of the five unknown coefficients to aim/hit chance.
"""
import hashlib, struct
from pathlib import Path
EXPECTED='5cc01a66e3027acb4a5ee8cc62c32b6c59517f2fb37c8a7df1b50cb0f665e57a'

def read_profiles(path=None):
    path=Path(path) if path else Path(__file__).parent/'resources'/'AIStrenthTable.bytes'
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=EXPECTED:raise ValueError('Unverified AI table')
    if raw[:4]!=b'MSES' or struct.unpack_from('<II',raw,8)!=(24,32) or len(raw)!=140+24*32:
        raise ValueError('Invalid original AI strength layout')
    result=[]
    for i in range(32):
        ident,*fields=struct.unpack_from('<I5f',raw,140+i*24)
        if ident!=i+1 or not all(0<=v<=1 for v in fields):raise ValueError('Unexpected AI strength row')
        result.append({'id':ident,'unknown_coefficients':fields})
    return result

if __name__=='__main__':
    import json
    print(json.dumps(read_profiles(),ensure_ascii=False,indent=2))
