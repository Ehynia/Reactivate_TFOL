"""Inspect supplied TFOL report offline; summarize only nonpersonal protocol signals."""
import argparse, collections, json, re, zipfile

def analyze(path):
    with zipfile.ZipFile(path) as z:
        events=[json.loads(line) for line in z.read('server.jsonl').decode('utf-8').splitlines() if line.strip()]
        runtime=z.read('TFOL.log').decode('utf-8','replace')
    cmds=collections.Counter((e.get('command'),e.get('schema')) for e in events if e.get('event')=='game_application_payload')
    round_end=[e for e in events if e.get('event')=='native_ui_round_end_observed']
    scores=[e for e in events if e.get('event')=='native_result_persisted']
    errors=[e for e in events if e.get('event')=='native_result_rejected']
    return dict(round_end_observed=len(round_end),round_end_outcomes=sorted({e.get('observed_ui_banner') for e in round_end if e.get('observed_ui_banner')}),
                local_participation_awards=sum(e.get('settlement')=='awarded' for e in round_end),
                accepted_OB15=len(scores),rejected_OB15=len(errors),client_result_timeouts=runtime.count('OnBattleResultDataTimeout'),
                cosmetic_equip_requests=cmds[(40,'EquipItemReq')],cosmetic_unequip_requests=cmds[(287,'UnEquipItemReq')],
                room_role_select_requests=cmds[(13,'SetRoleDataReq')],inventory_moves=cmds[(47,'MoveItemReq')],
                missing_animation_errors=len(re.findall('MovementAnim_',runtime)),
                network_send_failures=runtime.count('SendPackFail'))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('report');args=parser.parse_args()
    print(json.dumps(analyze(args.report),ensure_ascii=False,indent=2))
