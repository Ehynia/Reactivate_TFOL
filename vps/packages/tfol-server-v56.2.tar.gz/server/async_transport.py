"""Event driven sockets with bounded workers; idle clients consume no workers."""
import asyncio
import concurrent.futures
import socket
import threading
from bridge_session import BridgeSession


class TCP:
    def __init__(self, address, handler=None):
        self.socket = socket.socket()
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(address)
        self.socket.listen(128)
        self.socket.setblocking(False)
        self.server_address = self.socket.getsockname()
        self.started = threading.Event()
        self.loop = None

    def serve_forever(self):
        asyncio.run(self.run())

    async def run(self):
        self.loop = asyncio.get_running_loop()
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=self.state.config['worker_threads'], thread_name_prefix='obt-service')
        self.gate = asyncio.Semaphore(self.state.config['worker_threads']*4)
        self.stopping = asyncio.Event()
        self.tasks, self.writers = set(), set()
        self.listener = await asyncio.start_server(self.handle, sock=self.socket, limit=65543)
        self.started.set()
        await self.stopping.wait()
        self.listener.close()
        await self.listener.wait_closed()
        for writer in list(self.writers):
            writer.close()
        # Let in-flight mutations finish before taking the shutdown backup.
        if self.tasks:
            await asyncio.gather(*list(self.tasks), return_exceptions=True)
        self.pool.shutdown(wait=True)

    async def service(self, method, *args):
        async with self.gate:
            return await self.loop.run_in_executor(self.pool, method, *args)

    async def read_frame(self, reader, timeout):
        from server import HEADER, MAGIC, VERSION
        async def read():
            magic, version, kind, size = HEADER.unpack(await reader.readexactly(8))
            if magic != MAGIC or version != VERSION:
                raise ValueError('Unknown transport')
            return kind, await reader.readexactly(size)
        return await asyncio.wait_for(read(), timeout)

    async def handle(self, reader, writer):
        from server import frame
        task = asyncio.current_task()
        if len(self.tasks) >= self.state.config['max_connections']:
            self.state.metrics.record('connections_rejected_limit')
            writer.close()
            await writer.wait_closed()
            return
        self.tasks.add(task)
        self.writers.add(writer)
        session = BridgeSession(self.state)
        reason = 'peer_closed'
        try:
            writer.get_extra_info('socket').setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            kind, body = await self.read_frame(reader, self.handshake_timeout)
            result, response, closing = await self.service(session.accept, kind, body)
            writer.write(frame(result, response))
            await asyncio.wait_for(writer.drain(), 10)
            while not closing and not self.stopping.is_set():
                remaining = session.auth['expires']-self.state.clock()
                if remaining <= 0:
                    reason = 'session_expired'
                    break
                kind, body = await self.read_frame(reader, min(self.idle_timeout, remaining))
                result, response, closing = await self.service(session.process, kind, body)
                writer.write(frame(result, response))
                await asyncio.wait_for(writer.drain(), 10)
        except asyncio.IncompleteReadError:
            pass
        except (OSError, TimeoutError, ValueError) as error:
            reason = type(error).__name__
            self.state.metrics.record('transport_errors')
        except Exception as error:
            reason = type(error).__name__
            self.state.metrics.record('transport_internal_errors')
            self.state.event('transport_internal_error', connection_id=session.id, error=reason)
        finally:
            await self.service(session.close, reason)
            writer.close()
            try:
                await writer.wait_closed()
            except OSError:
                pass
            self.tasks.discard(task)
            self.writers.discard(writer)

    def shutdown(self):
        if self.started.wait(5) and self.loop and not self.loop.is_closed():
            self.loop.call_soon_threadsafe(self.stopping.set)

    def server_close(self):
        if not self.started.is_set():
            self.socket.close()
