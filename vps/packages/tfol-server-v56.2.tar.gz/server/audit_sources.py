"""Static source/ABI evidence. Requires pyflakes and tree-sitter-c-sharp.

Run after recovering the pinned original code with recover_build_inputs.py.
This audit does not execute Windows, Unreal Engine or a battle.
"""
import ast,hashlib,io,json,struct
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SERVER=Path(__file__).resolve().parent

def write(name,value):
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    from pyflakes.api import check
    from pyflakes.reporter import Reporter
    from tree_sitter import Language,Parser
    import tree_sitter_c_sharp
    files=sorted(p for p in ROOT.rglob('*.py') if not any(part.startswith('tmp') or part=='__pycache__' for part in p.relative_to(ROOT).parts))
    syntax=[];undefined=[];messages=[]
    for p in files:
        code=p.read_text('utf-8-sig');rel=p.relative_to(ROOT).as_posix()
        try:ast.parse(code,filename=rel)
        except SyntaxError as e:syntax.append(dict(file=rel,line=e.lineno,message=e.msg))
        stream=io.StringIO();check(code,rel,Reporter(stream,stream))
        for line in stream.getvalue().splitlines():
            messages.append(line)
            if 'undefined name' in line or 'referenced before assignment' in line:undefined.append(line)
    audit=dict(python_files=len(files),syntax_errors=syntax,undefined_names=undefined,
               other_lint_messages=len(messages)-len(undefined),files=[p.relative_to(ROOT).as_posix() for p in files])
    write('SOURCE_AUDIT28.json',audit)
    parser=Parser(Language(tree_sitter_c_sharp.language()));cs=[]
    for p in (ROOT/'Reactivate/NativeDesktopBuilder/ReactivateStandalone.cs',SERVER/'LauncherSource/ReactivateStandalone.cs'):
        raw=p.read_bytes();tree=parser.parse(raw)
        cs.append(dict(file=p.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),syntax_has_error=tree.root_node.has_error))
    write('CSHARP_SYNTAX_CHECK.json',dict(files=cs,identical_mirrors=cs[0]['sha256']==cs[1]['sha256'],managed_compilation_executed=False,windows_executed=False))
    code=(SERVER.parent/'OBT_original_code_rva_00001000.bin').read_bytes()
    digest=hashlib.sha256(code).hexdigest()
    if digest!='4ca7cb9d4517e8319d2ba158dd02130011f56e59483d8ff43adf751938b9d4b1':raise ValueError('Original code proof hash mismatch')
    evidence=[]
    for address,signature,meaning in (
        (0x7063d0,'83ec0c568b742414','Original ChangeAI entry, cdecl stack arguments'),
        (0x70640e,'8bb6d4020000','Read APawn.Controller at +0x2d4'),
        (0x1b8f824,'8b01ff904c030000','Original execSpawnDefaultController calls vtable +0x34c')):
        raw=bytes.fromhex(signature);offset=address-0x401000
        if code[offset:offset+len(raw)]!=raw:raise ValueError('ABI signature mismatch')
        evidence.append(dict(va=hex(address),bytes=signature,meaning=meaning))
    weapon=(SERVER/'resources/WeaponTable.bytes').read_bytes();width,count=struct.unpack_from('<II',weapon,8)
    ids=[struct.unpack_from('<I',weapon,140+i*width)[0] for i in range(count)]
    if 20101 not in ids:raise ValueError('Expected original weapon missing')
    write('AI_PORT_PROOF27.json',dict(original_code_sha256=digest,evidence=evidence,
        scope='Own started battle, game thread, enable=true, readable pawn, null controller, no re-entry',
        repair='Invoke original pawn virtual SpawnDefaultController before original ChangeAI; no fabricated controller or health',
        weapon_table_sha256=hashlib.sha256(weapon).hexdigest(),weapon_20101_exists=True,weapon_rows=count,
        runtime_ai_behavior_verified=False,pve_wave_behavior_verified=False,
        limitations=['Configured AIControllerClass may still be absent','Brain/behavior setup and native enemy waves require full Windows-client testing']))
    for address,signature in ((0x7cc8c6,'68e6000000'),(0x7ce35a,'8d88e00b0000'),(0x7ce387,'8d88ec0b0000'),(0x7c99d5,'e8265dffff')):
        raw=bytes.fromhex(signature);offset=address-0x401000
        if code[offset:offset+len(raw)]!=raw:raise ValueError('Original matching-confirmation proof mismatch')
    passed=not syntax and not undefined and not any(row['syntax_has_error'] for row in cs) and cs[0]['sha256']==cs[1]['sha256']
    print(json.dumps(dict(passed=passed,python_files=len(files),csharp_files=len(cs),abi_signatures=len(evidence),windows_executed=False)))
    if not passed:raise SystemExit(1)

if __name__=='__main__':main()
