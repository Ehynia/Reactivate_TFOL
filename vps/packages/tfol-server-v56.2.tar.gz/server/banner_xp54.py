"""Small, opt-in XP for the original UE4 results banner in offline Test Node.

This is a reward for locally observed match completion, NOT authoritative
victory/kills. Only OB15 may persist combat stats or trigger kill payouts.
Escrow is idempotent and the reward is deducted from a later real OB15's XP.
"""
import time
import progression

BASE_COMPLETION_XP = 25
UI_VICTORY_BONUS_XP = 40
MIN_DURATION = 45
MAX_DURATION = 14400
SOURCE = 'local-ue4-ui-observed-v54'

def event_id(round_id):
    if not isinstance(round_id, str) or not 16 <= len(round_id) <= 80:
        raise ValueError('Invalid native round identity')
    return 'ui54-'+round_id

def previously_credited(c, uid, round_id):
    """Only the reserved local banner credit for *this* native round."""
    row = c.execute('SELECT experience FROM match_rewards WHERE event_id=? AND uid=? AND source=?',
                    (event_id(round_id), uid, SOURCE)).fetchone()
    return row[0] if row else 0

def award(database, uid, context, outcome, *, now=None):
    if not (context.get('local_banner_reward54') and context.get('allow_local_rewards') and
            context.get('local_ui_recovery52') and context.get('native_bots') and
            context.get('logged_in') and database.progression_enabled):
        return dict(applied=False,experience=0,reason='disabled')
    match=context.get('engine_match') or {}
    if (match.get('state')!='travel_dispatched' or match.get('action') not in (1,3) or
            not isinstance(match.get('sequence'),int) or match['sequence']<=0 or
            outcome not in (0,1,2)):
        return dict(applied=False,experience=0,reason='invalid_native_round')
    round_id=match.get('round_id')
    # Only round_end45.consume sets both markers after a validated TF15/16
    # engine callback. Generic application commands cannot claim bonus XP.
    if context.get('ui_round_end45')!=round_id or context.get('ui_round_end_status45')!=outcome:
        return dict(applied=False,experience=0,reason='no_native_banner_confirmation')
    event=event_id(round_id)
    now=time.time() if now is None else now
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute('SELECT uid,mode_id,started_at FROM round_attempts WHERE round_id=?',(round_id,)).fetchone()
        if (row is None or row['uid']!=uid or row['mode_id']!=match.get('mode') or
                not MIN_DURATION <= now-row['started_at'] <= MAX_DURATION):
            return dict(applied=False,experience=0,reason='unverified_round_duration')
        # Never pay a second 'UI' bonus if the actual OB15 was already paid.
        # A late banner must not increase the award for a verified round.
        if context.get('native_result_verified52')==round_id:
            return dict(applied=False,experience=0,reason='genuine_result_already_paid')
        native_ids=['combat-native-'+round_id]
        pending=context.get('completion_pending') or {}
        if pending.get('round_id')==round_id and pending.get('event_id'):
            native_ids.append(pending['event_id'])
        if any(c.execute('SELECT 1 FROM combat_rewards WHERE event_id=?',(eid,)).fetchone() for eid in native_ids):
            return dict(applied=False,experience=0,reason='genuine_result_already_paid')
        # The only supported basis for an award without OB15 is a native HUD
        # transition observed on the engine game thread; never an APP_DATA claim.
        value=BASE_COMPLETION_XP+(UI_VICTORY_BONUS_XP if outcome==0 else 0)
        result=progression.reward_in(database,c,uid,event,value,SOURCE,now=now)
        return dict(applied=result['applied'],experience=result['awarded_experience'],
                    unlocked=result.get('unlocked',[]),reason='native_ui_completion',
                    winner_verified=False,kills_verified=False)
