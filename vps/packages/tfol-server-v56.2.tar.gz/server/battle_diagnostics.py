"""Non-authoritative battle startup observations; never assert actual playability."""
import re

def observations(text):
    launches=[]
    for line in text.splitlines():
        if 'LoadMap: ' not in line:continue
        url=line.split('LoadMap: ',1)[1].strip()
        pieces=url.split('?');options={}
        for piece in pieces[1:]:
            key,sep,value=piece.partition('=')
            if sep:options[key.lower()]=value
        alias=options.get('game','')
        if alias not in {'TDM','TRW','TE','CTF','PVE','PVEDEFEND'}:continue
        # Deliberately exclude Name, account identifiers and arbitrary URL values.
        row=dict(game=alias)
        for key in ('mapid','submode','botfill','maxplayers','startpawnid'):
            value=options.get(key,'')
            row[key]=int(value) if re.fullmatch(r'[0-9]{1,6}',value) else None
        row['missing_mapid']=not row['mapid']
        launches.append(row)
    return dict(battle_init_options=launches,
                missing_battle_map_id_count=sum(row['missing_mapid'] for row in launches),
                ds_send_failure_count=text.count('LogDSNET: SendPackFail:'),
                missing_animation_array_count=sum('MovementAnim_' in line and 'of length 0' in line for line in text.splitlines()),
                team_membership_verified=False,spawn_position_verified=False)
