"""Persist actual native offline results; expose the game's existing statistics."""
import json,math,struct,time

MIGRATION='''
ALTER TABLE match_rewards ADD COLUMN silver_coin INTEGER NOT NULL DEFAULT 0;
CREATE TABLE match_results(event_id TEXT PRIMARY KEY REFERENCES match_rewards(event_id),uid INTEGER NOT NULL REFERENCES players(uid),created_at REAL NOT NULL,character_id INTEGER NOT NULL,won INTEGER NOT NULL CHECK(won IN(0,1)),kills INTEGER NOT NULL,deaths INTEGER NOT NULL,headshots INTEGER NOT NULL,mvp INTEGER NOT NULL,stop_info TEXT NOT NULL,participants TEXT NOT NULL);
CREATE INDEX results_owner ON match_results(uid,created_at);
'''

def native_size(schema):
    from tdr_codec import SCHEMAS
    return max((f['native_offset']+(f['capacity'] if f['kind']==21 else f['width']*f['count']) for f in SCHEMAS[schema]['fields']),default=0)

def decode_native(schema,raw):
    from tdr_codec import SCHEMAS,PRIMITIVES,BY_OFFSET
    if len(raw)!=native_size(schema):raise ValueError('Wrong OBT native structure size')
    values={}
    for f in SCHEMAS[schema]['fields']:
        offset=f['native_offset'];n=values[f['count_field']] if f['count_field'] else f['count']
        if type(n)!=int or not 0<=n<=f['count']:raise ValueError('Invalid native count')
        if f['kind']==21:
            field=raw[offset:offset+f['capacity']]
            if b'\0' not in field:raise ValueError('Native string lacks terminator')
            value=field.split(b'\0',1)[0].decode('utf-8')
        else:
            items=[]
            for i in range(n):
                start=offset+i*f['width']
                if f['kind']==1:value=decode_native(BY_OFFSET[f['child']],raw[start:start+f['width']])
                else:
                    value=struct.unpack_from('<'+PRIMITIVES[f['kind']],raw,start)[0]
                    if isinstance(value,float) and not math.isfinite(value):raise ValueError('Invalid native float')
                items.append(value)
            value=items[0] if f['count']==1 else items
        values[f['name']]=value
    return values

def decode_snapshot(raw):
    if len(raw)<8:raise ValueError('Missing OBT result header')
    magic,version,count=struct.unpack_from('<4sHH',raw)
    stop_size=native_size('GameStopInfo');row_size=native_size('AccBattleInfo')
    if magic!=b'OB15' or version!=2 or not 1<=count<=16 or len(raw)!=8+stop_size+row_size*count:raise ValueError('Unsupported OBT snapshot; CBT R28B is incompatible')
    stop=decode_native('GameStopInfo',raw[8:8+stop_size])
    if stop['WinTeamId'] not in (0,1,255,-1) or stop['TimeConsume']>86400:raise ValueError('Invalid match outcome')
    rows=[decode_native('AccBattleInfo',raw[8+stop_size+i*row_size:8+stop_size+(i+1)*row_size]) for i in range(count)]
    if len({r['Name'] for r in rows})!=count:raise ValueError('Duplicate participants')
    for row in rows:
        if not row['Name'] or row['TeamId'] not in (0,1,255,-1):raise ValueError('Invalid participant')
        for key in ['Kill','Dead','HeadShot','Assists','Score']:
            if row[key]>1000000:raise ValueError('Invalid match statistic')
    return stop,rows

def record(database,uid,event_id,stop,rows):
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        event=c.execute('SELECT uid,created_at FROM match_rewards WHERE event_id=?',(event_id,)).fetchone()
        if not event or event['uid']!=uid or time.time()-event['created_at']>120:raise ValueError('No recent authenticated completion')
        if c.execute('SELECT 1 FROM match_results WHERE event_id=?',(event_id,)).fetchone():return False
        name=c.execute('SELECT nickname FROM players WHERE uid=?',(uid,)).fetchone()[0]
        mine=[r for r in rows if r['Name']==name]
        if len(mine)!=1:raise ValueError('Local player missing from native result')
        row=mine[0]
        if not c.execute('SELECT 1 FROM characters WHERE uid=? AND resource_id=?',(uid,row['JijiaId'])).fetchone():raise ValueError('Result character not owned')
        won=int(stop['WinTeamId'] in (0,1) and row['TeamId']==stop['WinTeamId'])
        c.execute('INSERT INTO match_results VALUES(?,?,?,?,?,?,?,?,?,?,?)',
          (event_id,uid,time.time(),row['JijiaId'],won,row['Kill'],row['Dead'],row['HeadShot'],int(bool(row['Mvp'])),json.dumps(stop),json.dumps(rows,ensure_ascii=False)))
        database.audit(c,uid,'native_match_result',dict(event_id=event_id,participants=len(rows),character_id=row['JijiaId']))
    return True

def player_info(database,uid):
    with database.connect() as c:
        player=c.execute('SELECT nickname FROM players WHERE uid=?',(uid,)).fetchone()
        stats=c.execute('SELECT count(*) Battle,coalesce(sum(won),0) Win,coalesce(sum(kills),0) Kill,coalesce(sum(deaths),0) Dead,coalesce(sum(headshots),0) HeadShot,coalesce(sum(mvp),0) Mvp FROM match_results WHERE uid=?',(uid,)).fetchone()
    setup=__import__('obt_extensions').setting(database,uid,'setup',[])
    with database.connect() as c:
        history=c.execute('SELECT participants FROM match_results WHERE uid=? ORDER BY created_at',(uid,)).fetchall()
    mine=[row for event in history for row in json.loads(event[0]) if row['Name']==player['nickname']]
    extended={key:min(0xffffffff,sum(row.get(key,0) for row in mine)) for key in ['Assists','Cure','WeaponDamage','MeleeDamage','Injure','Damage']}
    from tdr_codec import SCHEMAS
    for field in SCHEMAS['PlayerInfo']['fields']:
        key=field['name']
        if key.startswith('GunAccuracy'):
            source=next(f['name'] for f in SCHEMAS['AccBattleInfo']['fields'] if f['name'].startswith('GunAccuracy') and ('inner' in f['name'].lower())==('inner' in key.lower()))
            extended[key]=sum(row.get(source,0.) for row in mine)/len(mine) if mine else 0.
    counts={}
    for row in mine:counts[row['JijiaId']]=counts.get(row['JijiaId'],0)+1
    if counts:
        favorite=max(counts,key=lambda ident:(counts[ident],-ident));extended.update(CommonUseJijia=favorite,CommonUseJijiaBattle=counts[favorite])
    return dict(Name=player['nickname'],SetupLen=len(setup),Setup=setup,**{k:min(v,0xffffffff) for k,v in dict(stats).items()},**extended)

def characters(database,uid):
    with database.connect() as c:
        return [dict(r) for r in c.execute('SELECT ch.resource_id JijiaId,count(m.event_id) Battle,coalesce(sum(m.won),0) Win,coalesce(sum(m.kills),0) Kill,0 WeaponIdx FROM characters ch LEFT JOIN match_results m ON m.uid=ch.uid AND m.character_id=ch.resource_id WHERE ch.uid=? GROUP BY ch.resource_id ORDER BY ch.resource_id',(uid,))]

def daily(database,uid):
    # The native logout summary is a calendar-day summary, in server UTC.
    midnight=int(time.time())//86400*86400
    with database.connect() as c:
        row=c.execute('SELECT count(*) Battle,coalesce(sum(won),0) Win,coalesce(sum(mvp),0) Mvp,coalesce(sum(kills),0) Kill,coalesce(sum(deaths),0) Dead FROM match_results WHERE uid=? AND created_at>=?',(uid,midnight)).fetchone()
        xp,silver=c.execute('SELECT coalesce(sum(experience),0),coalesce(sum(silver_coin),0) FROM match_rewards WHERE uid=? AND created_at>=?',(uid,midnight)).fetchone()
    return dict(**dict(row),Exp=xp,MaxExp=0,SilverCoin=silver,MaxSilverCoin=0)

def _recover_native_round_completion(database,uid,stop,rows,context):
    """Authorize a *received* native scoreboard when OBT omits TutorialBattleReq.

    The 2016 client did not send MSG_TUTORIAL_BATTLE_REQ in captured real
    postmatches. Production authority stays with the UE4 listen-host, not the
    coordinator. Restrict this compatibility path to the local bridge after
    acknowledged map travel and a persisted minimum-duration round ledger.
    IMPORTANT: TCP kind=7 itself is not cryptographically proof of UE4 state;
    this compatibility path MUST NOT be enabled on public hosted services.
    """
    import round_drops
    match=context.get('engine_match') or {}
    if not (context.get('deferred_combat') and context.get('native_bots') and
            context.get('allow_local_rewards') and
            match.get('state')=='travel_dispatched' and match.get('round_id')):
        raise ValueError('Unverified native result source')
    rid=match['round_id']
    with database.connect() as c:
        row=c.execute('SELECT uid,mode_id,started_at FROM round_attempts WHERE round_id=?',(rid,)).fetchone()
    age=time.time()-row['started_at'] if row else 0
    if not row or row['uid']!=uid or row['mode_id']!=match.get('mode') or not 45<=age<=14400:
        raise ValueError('No eligible completed local round')
    if stop['TimeConsume']>age+30:
        raise ValueError('Native result time exceeds observed round lifetime')
    # A deterministic ID persists across duplicate frames/reconnects. A raw
    # client claim never reaches this point unless the bridge sent OB15 bytes.
    context['completion_pending']=dict(event_id='combat-native-'+rid,round_id=rid,created_at=time.time(),
        mode='PVEDEFEND' if match['mode']==3001 else 'TDM',source='local-native-OB15',
        room_seq=match.get('sequence',0))

def handle_snapshot(database,uid,raw,context,local=True):
    if not local:raise ValueError('Offline results are disabled on hosted servers')
    from postmatch_lifecycle53 import check_late_result
    check_late_result(context)
    pending=context.get('completion_pending')
    # FIX: a completion left over from the PREVIOUS round must never be reused.
    # Otherwise match N+1 is paid as a duplicate of match N (applied=False, no
    # rewards) or is rejected with 'Result completion expired' after 120 s.
    current_round=(context.get('engine_match') or {}).get('round_id')
    if pending and current_round and pending.get('round_id')!=current_round:
        context.pop('completion_pending',None);pending=None
    # Import/parse the actual native snapshot before mutating state. No source
    # outcome -> no scoreboard and no victory currency. The bridge's kind=7
    # frame is necessary; engine travel alone is not proof of a finished match.
    if not pending and not context.get('completion_event'):
        stop,rows=decode_snapshot(raw)
        _recover_native_round_completion(database,uid,stop,rows,context)
        pending=context['completion_pending']
    else:
        stop,rows=decode_snapshot(raw)
    from game_protocol import packet
    from postmatch_wire35 import result_notice
    match=context.get('engine_match') or {}
    seq=(pending or {}).get('room_seq',match.get('sequence',0))
    # Native packet 60 is what BattleRLTManager is waiting for. Earlier builds
    # only sent TutorialBattleRes/SyncPlayerInfo/JijiaBattleInfoRes, leaving
    # OnBattleResultDataTimeout even if a trusted OB15 had been persisted.
    # Send it first, before profile/wallet traffic.
    result=result_notice(stop,rows,seq if type(seq)==int else 0)
    if pending:
        if time.time()-pending['created_at']>120:raise ValueError('Result completion expired')
        import economy,garage
        applied,awards=economy.complete(database,uid,pending['event_id'],stop,rows,round_id=match.get('round_id'))
        response=result+packet(177,'TutorialBattleRes',dict(Exp=awards['4'],SilverCoin=awards['3'],Result='ok'))
        if applied:
            for number in [2,1,5]:
                for item in garage.bag(database,uid,number):response+=packet(39,'SyncItemData',dict(Item=item))
        for item in garage.currency_bag(database,uid):
            response+=packet(39,'SyncItemData',dict(Item=item))
        chars=characters(database,uid)
        response+=packet(62,'SyncPlayerInfo',dict(PlayerInfo=player_info(database,uid)))
        response+=packet(116,'JijiaBattleInfoRes',dict(Count=len(chars),JijiaBattleInfoList=chars,Result='ok'))
        context['native_result_verified52']=match.get('round_id')
        return response,dict(applied=applied,participants=len(rows),awards=awards,
                             sync_battle_info=True,battle_info_message_id=60,room_seq=seq)
    event=context['completion_event']
    applied=record(database,uid,event,stop,rows)
    chars=characters(database,uid)
    response=result+packet(62,'SyncPlayerInfo',dict(PlayerInfo=player_info(database,uid)))
    response+=packet(116,'JijiaBattleInfoRes',dict(Count=len(chars),JijiaBattleInfoList=chars,Result='ok'))
    context['native_result_verified52']=match.get('round_id')
    return response,dict(applied=applied,participants=len(rows),
                         sync_battle_info=True,battle_info_message_id=60,room_seq=seq)
