"""Reproducible localhost benchmark; reports measurements, not engine capacity."""
import argparse
import concurrent.futures
import json
from pathlib import Path
import platform
import socket
import struct
import tempfile
import threading
import time
from server import App,frame,read_frame
from tdr_codec import packet

ROOT=Path(__file__).parent

def measure(backend,clients,requests):
    with tempfile.TemporaryDirectory(dir=ROOT) as folder:
        app=App(folder,0,0,config=dict(network_backend=backend,capture_packets=False)).start()
        session=app.state.create_session('Benchmark')
        auth=struct.pack('<II',session['user_id'],1)+bytes.fromhex(session['token_hex']+session['login_key_hex'])
        start=threading.Barrier(clients)
        request=frame(5,packet(1,'QueryServerReq',{}))
        def worker(_):
            with socket.create_connection(('127.0.0.1',app.state.tcp_port),timeout=20) as sock:
                sock.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
                sock.sendall(frame(1,auth))
                if read_frame(sock)[0]!=2:raise AssertionError('Auth failed')
                start.wait(timeout=10)
                latencies=[]
                for _ in range(requests):
                    t=time.perf_counter();sock.sendall(request)
                    if read_frame(sock)[0]!=6:raise AssertionError('Response failed')
                    latencies.append((time.perf_counter()-t)*1000)
                return latencies
        try:
            t=time.perf_counter()
            with concurrent.futures.ThreadPoolExecutor(max_workers=clients) as pool:
                samples=[v for result in pool.map(worker,range(clients)) for v in result]
            seconds=time.perf_counter()-t;samples.sort()
            return dict(backend=backend,clients=clients,requests=len(samples),seconds=round(seconds,3),
                        requests_per_second=round(len(samples)/seconds,1),
                        roundtrip_p50_ms=round(samples[len(samples)//2],3),
                        roundtrip_p95_ms=round(samples[int(len(samples)*.95)],3),
                        metrics=app.state.metrics.snapshot())
        finally:app.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--clients',type=int,default=8);p.add_argument('--requests',type=int,default=100)
    p.add_argument('--output',type=Path,default=ROOT/'BENCHMARK.json');a=p.parse_args()
    result=dict(platform=platform.platform(),python=platform.python_version(),scope='Localhost QueryServerReq; packet capture off. Not Windows or Unreal gameplay benchmark.',
                runs=[measure(b,a.clients,a.requests) for b in ['threaded','asyncio']])
    a.output.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
