"""OBT34 experimental *listen-host side* aim-planning reference.

This is NOT attached to the recovered UE4 AIController yet; exporting a
validated aim solution cannot fire a gun or set an engine focus by itself.
It may only be connected later from the authoritative player's listen-host,
never the central matchmaking/economy service.

The 32 rows in original AIStrenthTable.bytes have five floats whose meaning
is currently unknown. This code deliberately does NOT patch those fields.
"""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class AimPolicy:
    # Values describe a *planning* model, NOT verified UE4 AI internals.
    reaction_seconds: float
    max_turn_deg_per_s: float
    max_lead_seconds: float
    max_range: float
    error_deg: float

POLICIES = {
    'easy': AimPolicy(0.32, 95.0, 0.7, 2200.0, 2.8),
    'normal': AimPolicy(0.20, 145.0, 1.25, 3000.0, 1.5),
    'hard': AimPolicy(0.11, 220.0, 1.8, 3700.0, 0.8),
}


def _vec(p):
    if len(p) != 3 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in p):
        raise ValueError('Expected a finite 3D vector')
    return tuple(float(v) for v in p)


def _dot(a, b): return sum(x*y for x,y in zip(a,b))

def _length(a): return math.sqrt(_dot(a,a))

def _unit(a):
    n = _length(a)
    return tuple(v/n for v in a) if n > 1e-8 else (1.0, 0.0, 0.0)


def intercept_seconds(origin, target, velocity, projectile_speed, max_seconds):
    """First positive root of |target+v*t-origin|=speed*t; bounded.

    Hit calculation is only a hint: cover, collision and real projectile
    physics MUST be checked by authoritative UE4 code.
    """
    origin, target, velocity = map(_vec, (origin,target,velocity))
    if not math.isfinite(projectile_speed) or projectile_speed <= 0:
        raise ValueError('Invalid projectile speed')
    if not math.isfinite(max_seconds) or max_seconds < 0:
        raise ValueError('Invalid lead bound')
    r = tuple(t-o for t,o in zip(target,origin))
    a = _dot(velocity,velocity)-projectile_speed*projectile_speed
    b = 2*_dot(r,velocity)
    c = _dot(r,r)
    if c < 1e-10:return 0.0
    if abs(a)<1e-10:
        roots = [-c/b] if abs(b)>1e-10 else []
    else:
        d=b*b-4*a*c
        roots=[] if d<0 else [(-b-math.sqrt(d))/(2*a),(-b+math.sqrt(d))/(2*a)]
    roots=[t for t in roots if t >= 0 and math.isfinite(t)]
    if not roots: return None
    t=min(roots)
    return t if t<=max_seconds else None


def plan(origin, target, velocity, projectile_speed, policy='normal', *,
         line_of_sight, friendly_in_line=False, current_direction=(1.,0.,0.),
         dt=0.05, visibility_seconds=10., bot_id=1, encounter_id=1):
    """Aim *suggestion* only. Never overrides UE4 firing / team validation.

    Requires explicit LOS from the UE4 physics trace, rejects obstructed shots
    and friendly targets, bounds rotation per frame, uses predictable but
    encounter-varying deterministic error (no hidden RNG/world writes).
    """
    if policy not in POLICIES:raise ValueError('Unknown difficulty')
    if not isinstance(line_of_sight,bool) or not isinstance(friendly_in_line,bool):
        raise ValueError('Expected explicit sight and ally flags')
    cfg=POLICIES[policy]
    origin,target,velocity,current_direction=map(_vec,(origin,target,velocity,current_direction))
    if not (0 < dt <= 0.5) or not math.isfinite(dt) or not math.isfinite(visibility_seconds):
        raise ValueError('Invalid timing')
    if line_of_sight is False or friendly_in_line:
        return dict(fire=False,reason='blocked_or_friendly',direction=_unit(current_direction),lead_s=None)
    d=tuple(t-o for t,o in zip(target,origin))
    if _length(d)>cfg.max_range:
        return dict(fire=False,reason='out_of_range',direction=_unit(current_direction),lead_s=None)
    if visibility_seconds<cfg.reaction_seconds:
        return dict(fire=False,reason='reaction',direction=_unit(current_direction),lead_s=None)
    t=intercept_seconds(origin,target,velocity,projectile_speed,cfg.max_lead_seconds)
    if t is None:
        # Fast evasive targets cannot be predicted in the weapon's envelope.
        return dict(fire=False,reason='no_intercept',direction=_unit(current_direction),lead_s=None)
    candidate=_unit(tuple(v+t*dv for v,dv in zip(d,velocity)))
    # Deterministic aim inaccuracy: bounded, reproducible per bot/encounter.
    # A real implementation should derive the basis from the UE4 controller.
    if type(bot_id)!=int or type(encounter_id)!=int:raise ValueError('Invalid stable IDs')
    noise=((bot_id*1009+encounter_id*9176)%1009)/504.-1.
    noise_angle=math.radians(cfg.error_deg*noise)
    reference=(0.,0.,1.) if abs(candidate[2])<.95 else (0.,1.,0.)
    tangent=_unit((reference[1]*candidate[2]-reference[2]*candidate[1],
                   reference[2]*candidate[0]-reference[0]*candidate[2],
                   reference[0]*candidate[1]-reference[1]*candidate[0]))
    candidate=_unit(tuple(math.cos(noise_angle)*v+math.sin(noise_angle)*w
                          for v,w in zip(candidate,tangent)))
    facing=_unit(current_direction)
    angle=math.acos(max(-1.,min(1.,_dot(candidate,facing))))
    turn=math.radians(cfg.max_turn_deg_per_s)*dt
    if angle>turn:
        f=turn/angle
        candidate=_unit(tuple((1-f)*v+f*w for v,w in zip(facing,candidate)))
        return dict(fire=False,reason='turning',direction=candidate,lead_s=t)
    return dict(fire=True,reason='on_target',direction=candidate,lead_s=t)
