"""Original OBT mode/map catalog. Bot practice is never a ranked result."""
import hashlib,re,struct
from pathlib import Path
ROOT=Path(__file__).parent
HASHES={'MapTable.bytes':'f9c4287dfa580cbe5facb14afb25bf2a2c36ae02e08c5fe395011ba730d2077d',
        'MatchingModeTable.bytes':'5789c79a1999391efb9eccf971abb9ec6248bf58416b4547f13625f4e8bb8b5b',
        'TeamDeathMatchModeConf.bytes':'69cb550e5a076e30a31b3b050c1c9325095149b04e8051a7fa76d991b1e99bc5',
        'ResourceWarModeConf.bytes':'a61e8bc33df44f69eb88c6e0f6f978d5b39e4872097173168d6447fdc916b9be',
        'EscortModeConf.bytes':'651532e0e5964dca1d0f61753d39c6555406fefaf8f8b8edc28a0d70da5b821e',
        'CaptureTheFlagModeConf.bytes':'353bced4329b6ad86355f461f80275f135665371ffe8417c5cc1134f90329b79',
        'PVEDefendTable.bytes':'477cd4fb1b59fd726d11b3dbb54f9296164d954eba047e69b778b81b6d719a29'}
RULE_TABLES={'TDM':'TeamDeathMatchModeConf.bytes','TRW':'ResourceWarModeConf.bytes',
             'TE':'EscortModeConf.bytes','CTF':'CaptureTheFlagModeConf.bytes','PVEDEFEND':'PVEDefendTable.bytes'}
def records(name):
    raw=(ROOT/'resources'/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=HASHES[name]:raise ValueError('Unverified original mode resource: '+name)
    width,count=struct.unpack_from('<II',raw,8)
    if len(raw)!=140+width*count:raise ValueError('Invalid mode layout')
    return [raw[140+i*width:140+(i+1)*width] for i in range(count)]
def text(record,at):return record[at:].split(b'\0',1)[0].decode('utf-8')
MAPS={}
for row in records('MapTable.bytes'):
    key=struct.unpack_from('<i',row)[0];alias=text(row,516);path=text(row,3616)
    if not path.startswith('/Game/Maps/') or not re.fullmatch(r'[A-Z]+',alias):raise ValueError('Unsafe original map path/alias')
    MAPS[key]=dict(map_id=key,path=path,alias=alias,submode=struct.unpack_from('<I',row,1032)[0])
MODES={}
for row in records('MatchingModeTable.bytes'):
    key=struct.unpack_from('<I',row)[0];maps=[int(v) for v in text(row,3628).split(';')]
    MODES[key]=dict(mode=key,maps=maps,players=5 if key==3001 else (6 if key in (1013,1014) else 2*int(text(row,2084))),label=text(row,1548))
PUBLIC_MODES=tuple(k for k in MODES if k != 3001)
BASE_MODE={'TDM':1002,'TRW':1003,'TE':1004,'CTF':1005}
for alias,table in RULE_TABLES.items():
    keys={struct.unpack_from('<I',row)[0] for row in records(table)}
    for row in MAPS.values():
        if row['map_id']>0 and row['alias']==alias and row['submode'] not in keys:
            raise ValueError('Map references missing engine rules: '+str(row['map_id']))
def resolve(mode,sequence):
    if mode not in MODES:raise ValueError('Unknown original mode')
    selected=mode
    if mode==1001:selected=(1002,1003,1004,1005)[(sequence-1)%4]
    maps=MODES[selected]['maps'];map_id=maps[(sequence-1)%len(maps)]
    if mode==2001:selected=BASE_MODE[MAPS[map_id]['alias']]
    players=MODES[mode]['players']
    return dict(mode=selected,requested_mode=mode,map=map_id,submode=MAPS[map_id]['submode'],action=3 if mode==3001 else 1,
                bots=0 if mode==3001 else players-1,players=players,ranked_practice=mode==2001)
def native_header():
    lines=['/* Generated from pinned OBT tables by bot_modes.native_header(). */',
           'typedef struct {U id,submode;const char*path,*alias;} BotMap;',
           'static const BotMap bot_maps[]={']
    for key,row in MAPS.items():
        if key>0:lines.append('{%du,%du,"%s","%s"},'%(key,row['submode'],row['path'],row['alias']))
    lines+=['};','static const BotMap*bot_map(U id){for(U i=0;i<sizeof(bot_maps)/sizeof(bot_maps[0]);i++)if(bot_maps[i].id==id)return bot_maps+i;return 0;}',
            'static U bot_route_valid(U mode,U map){switch(mode){']
    for key,row in MODES.items():
        if key in (1001,2001):continue  # resolved before entering the engine
        lines.append('case %du:return '%key+'||'.join('map==%du'%n for n in row['maps'])+';')
    lines+=['default:return 0;}}']
    return '\n'.join(lines)+'\n'
