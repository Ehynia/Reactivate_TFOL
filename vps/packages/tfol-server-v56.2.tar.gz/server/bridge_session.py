"""OBT frame service independent of sockets; one ordered stream per session."""
import hashlib
import secrets
import struct
import time
import battle_statistics
import matchmaking
from game_protocol import handle as handle_game, packet


class BridgeSession:
    def __init__(self, state):
        self.state = state
        self.uid = None
        self.auth = None
        self.auth_body = b''
        self.id = secrets.token_hex(8)
        self.sequence = 0
        self.context = dict(matchmaking=state.matchmaking, connection_id=self.id,allow_local_rewards=state.config['mode']=='local',local_banner_reward54=(state.config['mode']=='local' and state.config.get('enable_local_banner_xp',False)))
        if state.simulation.enabled:self.context['local_simulation']=state.simulation

    def accept(self, kind, body):
        self.auth_body = body
        self.auth = self.state.authenticate(body) if kind == 1 else None
        if not self.auth:
            self.state.event('transport_auth_rejected', connection_id=self.id)
            return 127, struct.pack('<I', 1), True
        self.uid = self.auth['uid']
        with self.state.lock:
            self.state.connections += 1
        self.state.event('transport_authenticated', uid=self.uid, connection_id=self.id, phase='awaiting_game_payload')
        return 2, self.auth['state']+self.auth['key'], False

    def process(self, kind, body):
        state = self.state
        if not state.authenticate(self.auth_body):
            return 127, struct.pack('<I', 1), True
        if self.auth['expires']-state.clock() < 900:
            self.auth['expires'] = state.renew_active(self.auth_body)
        if kind == 3 and not body:
            state.metrics.record('pings')
            job=__import__('native_bots').poll(state.database,self.uid,self.context) if self.context.get('native_bots') and self.context.get('logged_in') else b''
            return 4, job, False
        if kind == 5:
            return self.application(body)
        if kind==12:
            try:details=__import__('native_bots').status(self.context,body)
            except ValueError:return 127,struct.pack('<I',2),False
            if details['travel_dispatched'] and self.context.get('allow_local_rewards') and not self.context.get('engine_match',{}).get('tutorial_original'):
                import round_drops
                round_drops.track_started(state.database,self.uid,self.context)
            if self.context.get('engine_match',{}).get('tutorial_original'):
                state.event('original_megatron_tutorial_travel',uid=self.uid,**details)
            state.event('native_engine_travel_status',uid=self.uid,**details)
            response=b'' if details['travel_dispatched'] else packet(66,'RoomMatchRes',dict(PredictedTime=0,Result='server_unavailable'))
            return 6,response,False
        if kind == 10 and body == b'OB27':
            self.context['native_bots']=True
            # Only local sessions negotiated via the actual Win32 bridge
            # receive the zero-reward exit compatibility path.
            self.context['local_ui_recovery52']=state.config['mode']=='local'
            return 6,b'',False
        if kind == 10 and body == b'OB15':
            # Protocol capability is not proof that native EndMatch sends a
            # snapshot. Report the missing producer explicitly for diagnostics.
            self.context.update(deferred_combat=True, peer_capable=False,
                                native_result_emitter_verified=False)
            state.event('native_result_capture_capability_only',uid=self.uid,
                        native_result_emitter_verified=False)
            return 6, b'', False
        if kind == 10 and body == b'R32P':
            if state.config['mode'] != 'local':return 127,struct.pack('<I',2),False
            self.context['peer_capable']=True
            return 6,b'',False
        if kind == 13:
            if not self.context.get('peer_capable') or len(body)!=14:
                return 127,struct.pack('<I',2),False
            magic,ident,port=struct.unpack('<4sQH',body)
            try:
                with state.matchmaking.lock:
                    if magic==b'R31B':
                        state.matchmaking.peers.bound(self.uid,self.id,ident,port)
                    elif magic==b'R31D':
                        room=state.matchmaking.peers.get(self.uid,self.id)
                        if room.id!=ident or room.port!=port:raise ValueError('Wrong assignment')
                        state.matchmaking.cancel(self.uid,self.id)
                    else:raise ValueError('Unsupported peer acknowledgment')
            except ValueError:return 127,struct.pack('<I',2),False
            return 6,b'',False
        if kind in (14,15):
            if not self.context.get('peer_capable'):return 127,struct.pack('<I',2),False
            try:
                if kind==14:
                    if len(body)<21 or body[:4]!=b'R32S':raise ValueError('Invalid snapshot frame')
                    room_id,epoch,sequence=struct.unpack_from('<QII',body,4)
                    with state.matchmaking.lock:
                        state.matchmaking.peers.publish_snapshot(self.uid,self.id,room_id,epoch,sequence,body[20:])
                    return 6,b'',False
                if len(body)!=16 or body[:4]!=b'R32R':raise ValueError('Invalid restore frame')
                room_id,epoch=struct.unpack_from('<QI',body,4)
                with state.matchmaking.lock:
                    sequence,payload=state.matchmaking.peers.migration_checkpoint(self.uid,self.id,room_id,epoch)
                return 6,b'R32R'+struct.pack('<QII',room_id,epoch,sequence)+payload,False
            except ValueError:
                return 127,struct.pack('<I',2),False
        if kind == 8 and body in (b'', b'\1'):
            if body:
                state.matchmaking.cancel(self.uid, self.id)
            decision = state.matchmaking.poll(self.uid, self.id)
            return 9, matchmaking.poll_response(state.database, decision, self.uid), False
        if kind == 11 and body == b'R30A':
            pending = self.context.pop('completion_pending', None)
            state.event('native_result_capture_aborted', uid=self.uid,
                        reason='native_snapshot_not_received', completion_pending=bool(pending),
                        battle_verified=False)
            return 6, packet(177, 'TutorialBattleRes', dict(Exp=0, SilverCoin=0, Result='ok')) if pending else b'', False
        if kind == 16:
            try:
                from round_end45 import consume
                response, details=consume(state.database,self.uid,self.context,body)
            except (ValueError, KeyError, struct.error):
                state.event('native_ui_round_end_rejected',uid=self.uid,reason='invalid_or_unmatched_banner')
                return 127,struct.pack('<I',2),False
            state.event(details['event'],uid=self.uid,**{k:v for k,v in details.items() if k!='event'})
            return 6,response,False
        if kind == 7:
            try:
                response, details = battle_statistics.handle_snapshot(state.database, self.uid, body, self.context, local=state.config['mode']=='local')
            except (ValueError, KeyError, UnicodeError, struct.error):
                state.event('native_result_rejected', uid=self.uid, reason='missing_or_invalid_OB15_snapshot',
                            completion_pending=bool(self.context.get('completion_pending')),
                            battle_verified=False)
                if self.context.pop('completion_pending', None):
                    return 6, packet(177, 'TutorialBattleRes', dict(Exp=0, SilverCoin=0, Result='ok')), False
                return 127, struct.pack('<I', 2), False
            state.event('native_result_persisted', uid=self.uid, **details)
            return 6, response, False
        return 127, struct.pack('<I', 3), True

    def application(self, body):
        state = self.state
        self.sequence += 1
        target = state.folder/'captures'/self.id/f'{self.sequence:06d}.bin'
        capture_enabled = state.config['capture_packets']
        if capture_enabled:
            with state.lock:
                capture_enabled = state.capture_bytes+len(body) < state.config['capture_limit_mb']*1024*1024
                if capture_enabled:
                    state.capture_bytes += len(body)
            if capture_enabled:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(body)
            else:
                state.metrics.record('captures_skipped_limit')
        with state.lock:
            state.application_payloads += 1
        started = time.perf_counter()
        try:
            response, details = handle_game(state.database, self.uid, body, lobby_port=state.tcp_port,
                                           local_rewards=state.config['mode']=='local', context=self.context)
            if response is not None and self.context.get('native_bots') and self.context.get('logged_in') and details.get('command') not in (19,21):
                response+=__import__('native_bots').poll(state.database,self.uid,self.context)
        except Exception as error:
            # An individual bad packet must not silently tear down the stream.
            details = dict(handler_implemented=False, transport_accepted=False, error=type(error).__name__)
            state.event('handler_error', uid=self.uid, connection_id=self.id, sequence=self.sequence, error=type(error).__name__)
            response = None
        if response is not None and len(response) > 65535:
            response = None
            details = dict(handler_implemented=False, transport_accepted=False, error='reply_bundle_too_large')
        duration = time.perf_counter()-started
        state.metrics.record('application_requests', latency=duration)
        if response is None:
            state.metrics.record('application_rejections')
        state.event('game_application_payload', uid=self.uid, connection_id=self.id, sequence=self.sequence,
                    capture=str(target.relative_to(state.folder)) if capture_enabled else None,
                    bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
                    hex=body[:4096].hex() if capture_enabled else None,
                    full_payload_logged=capture_enabled and len(body)<=4096,
                    handler_ms=round(duration*1000, 3), **details)
        if response is None:
            return 127, struct.pack('<I', 2), False
        if response:
            reply_target = None
            with state.lock:
                save_reply = capture_enabled and state.capture_bytes+len(response) < state.config['capture_limit_mb']*1024*1024
                if save_reply:
                    state.capture_bytes += len(response)
            if save_reply:
                reply_target = target.with_suffix('.reply.bin')
                reply_target.write_bytes(response)
            state.event('game_application_reply', uid=self.uid, connection_id=self.id, sequence=self.sequence,
                        command=details.get('command'), capture=str(reply_target.relative_to(state.folder)) if reply_target else None,
                        bytes=len(response), sha256=hashlib.sha256(response).hexdigest())
        return 6, response, False

    def close(self, reason):
        if self.uid is not None:
            if self.context.get('allow_local_rewards'):
                import round_drops
                round_drops.settle_context(self.state.database,self.uid,self.context,reason='disconnect')
            if self.state.simulation.enabled:self.state.simulation.cancel(self.uid)
            self.state.matchmaking.cancel(self.uid, self.id)
            with self.state.lock:
                self.state.connections -= 1
        self.state.event('transport_closed', uid=self.uid, connection_id=self.id, reason=reason, application_payloads=self.sequence)
