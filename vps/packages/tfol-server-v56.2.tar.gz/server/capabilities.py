"""Machine-readable launcher contract and honest implementation boundaries."""
import game_protocol,obt_handlers,json
from pathlib import Path
def describe():
    # Advertise the actual rebuilt image, never the older pinned template.
    manifest=Path(__file__).parent/'build_manifest.json'
    native=json.loads((manifest if manifest.exists() else Path(__file__).parent/'base_exe_manifest.json').read_text())
    return dict(api_version=1,release='OBT33',transport='TF15',bind_host='127.0.0.1',
        supported_commands=sorted(set(game_protocol.REQUESTS)|set(obt_handlers.REQUESTS)),
        features=dict(guest_sessions=True,account_keys=True,self_registration_local=True,server_generated_passwords=True,separate_account_login=True,
            launcher_auth_before_play=True,first_name_server_gate=True,initial_create_role_handler=True,megatron_completion_hook_verified=False,original_first_name_screen_windows_verified=False,
            persistent_database=True,inventory=True,
            equipment=True,shop=True,progression=True,statistics=True,settings=True,
            webadmin=True,admin_audit=True,online_backups=True,portable_windows_runtime=True,event_driven_transport=True,
            spark_default_schemes=True,native_transport_rejection_drain=True,native_async_network_worker=True,shop_request_pagination=True,native_bot_travel=True,native_ftext_localization=False,presentation_only_localization=False,client_resource_localization=True,match_team_mode_selection=True,solo_bot_party=True,login_mode_snapshot=True,native_bot_battle_verified=False,all_original_mode_bot_routes=True,pve_bot_travel_experimental=True,scoped_spawn_default_controller_repair=True,prelaunch_free_translation=True,
            reactivate_launcher_handoff=True,game_folder_discovery=True,game_executable_picker=True,automatic_local_image_preparation=True,argument_free_launcher_profile=True,
            reactivate_native_bootstrap=True,reactivate_managed_ui_compiled_here=False,
            skin_shop_panel=True,player_skin_shop_api=True,reddit_rss_cache=True,reddit_news_background_service=True,reddit_news_launcher=True,combat_only_economy=False,manual_translation_export=True,test_node_only_launcher=True,local_lobby_simulation=True,first_login_quest=True,onboarding_replay=True,one_time_clean_accounts=True,matchmaking_backend=True,ready_worker_assignment=True,windows_lobby_verified=False,baseline_obt13_windows_lobby_verified=True,
            all_game_functions_verified=False,obt_native_peer_bridge=False,obt_native_result_capture=False,
            engine_worker_bundled=False,social_features=False,event_rewards=False,advanced_pve_modules=False,special_type4_weapons=False),
        runtime=dict(executable='TFOL_OBT_TEST_33.exe',sha256=native['exe_sha256'],
                     tdr_sha256='1f500fc7fa9ff0691d1fe3d126355fa035665e8fe7270b52e13c7464eee6b663',
                     forced_runtime_limit_seconds=0),
        notes=['Legacy test sessions use lobby simulation; the native bridge requests a local bot-map transition, unverified on Windows.',
               'Native R24-R31 CBT offsets are not copied to OBT.',
               'All original mode routes and a scoped original SpawnDefaultController call are implemented; actual AI, waves and map behavior still require Windows engine validation.',
               'Bot practice waits 20 seconds, uses original 82/230/231/232 confirmation and owned-hero/ready messages before local travel; new Windows UX remains unverified.',
               'Local bot practice does not implement shared human matchmaking, native multiplayer replication, ranked results or native battle-result capture.',
               'No credits are awarded from a client completion notification without validated match results.'])
