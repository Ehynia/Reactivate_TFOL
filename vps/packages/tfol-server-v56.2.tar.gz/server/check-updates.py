#!/usr/bin/env python3
"""Read-only update check against official GitHub Releases; never execute downloads."""
import json
import os
from pathlib import Path
import re
import ssl
import urllib.error
import urllib.request

REPOSITORY='Ehynia/Reactivate_TFOL'
API=f'https://api.github.com/repos/{REPOSITORY}/releases/latest'
ASSET='tfol-server-v56.2.tar.gz'

def main():
    headers={'User-Agent':'Reactivate-TFOL-VPS-Updater/1.0', 'Accept':'application/vnd.github+json'}
    request=urllib.request.Request(API,headers=headers)
    try:
        # Standard OS trust store; never skip hostname/certificate verification.
        with urllib.request.urlopen(request,timeout=20,context=ssl.create_default_context()) as resp:
            release=json.load(resp)
    except urllib.error.HTTPError as err:
        if err.code==404:
            print('No stable GitHub Release yet; server stays unchanged.')
            return 0
        raise
    tag=release.get('tag_name','')
    if not re.fullmatch(r'v[0-9][0-9A-Za-z._-]*',tag) or release.get('draft') or release.get('prerelease'):
        raise SystemExit('Invalid or nonstable release')
    assets={a.get('name'):a.get('browser_download_url') for a in release.get('assets',[]) if isinstance(a,dict)}
    if ASSET not in assets or ASSET+'.sha256' not in assets:
        print(f'Latest release {tag} has no signed-off server asset pair; no update.')
        return 0
    installed=Path('/opt/reactivate-tfol/installed_tag')
    current=installed.read_text('utf-8').strip() if installed.exists() else '(local-install)'
    if current==tag:
        print('Up to date:',tag)
    else:
        print(f'New verified asset pair advertised: {tag} (installed {current}).')
        print('Review release and run: sudo bash install.sh --tag '+tag)
    return 0

if __name__=='__main__': raise SystemExit(main())
