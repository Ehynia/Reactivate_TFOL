"""Read original TFOL PAK *indices* and locate assets referenced by failing UI/mesh.

No writes to the installed game; no source game files uploaded.
"""
from pathlib import Path
import sys,json,argparse
CLIENT=Path(__file__).resolve().parent.parent/'ClientLanguages'
sys.path.insert(0,str(CLIENT))
import ue_pak_reader as pak
TARGETS={
 'MeleeWeapon_DestroyGemini':('MeleeWeapon_DestroyGemini',),
 'SelectRoleBarList_animation':('MechRoom_BP','SelectRoleBarList'),
 'default_UMG_font_assets':('/Fonts/','/Font/','FontFace','font_'),
}

def scan(game):
 root=Path(game)
 if (root/'TFOL/Content/Paks').is_dir():root=root/'TFOL'
 paks=sorted((root/'Content/Paks').glob('TFOL-WindowsNoEditor_*.pak'))
 counts={k:[] for k in TARGETS};failed=[]
 for f in paks:
  try:mount,rows,_=pak.index(f)
  except (OSError,ValueError,UnicodeError) as e:failed.append(dict(pak=f.name,error=type(e).__name__));continue
  for row in rows:
   full=mount+row['name']
   for key,parts in TARGETS.items():
    if any(part.casefold() in full.casefold() for part in parts):
     if len(counts[key])<120:counts[key].append(dict(pak=f.name,asset=full))
 return dict(paks_seen=len(paks),problems=dict(
   missing_DestroyGemini_not_found=not counts['MeleeWeapon_DestroyGemini'],
   warning_MechRoom_assets=bool(counts['SelectRoleBarList_animation']),
   font_assets_seen=len(counts['default_UMG_font_assets'])),assets=counts,read_errors=failed,
   note='PAK index presence alone does not validate cooked blueprint dependencies, animation or runtime material initialization.')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('game_path');ap.add_argument('--output',default='TFOL_v48_asset_report.json');a=ap.parse_args()
 result=scan(a.game_path);Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
 print(json.dumps({k:len(v) for k,v in result['assets'].items()},ensure_ascii=False))
