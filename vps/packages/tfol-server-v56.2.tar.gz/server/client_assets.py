"""Read-only OBT pak-index checks; never loads or edits client assets."""
import hashlib,json,struct
from pathlib import Path

class Reader:
    def __init__(self,data):self.data=data;self.pos=0
    def take(self,size):
        if size<0 or self.pos+size>len(self.data):raise ValueError('Truncated pak index')
        value=self.data[self.pos:self.pos+size];self.pos+=size;return value
    def unpack(self,fmt):return struct.unpack(fmt,self.take(struct.calcsize(fmt)))
    def string(self):
        size=self.unpack('<i')[0]
        if not 1<=abs(size)<=65536:raise ValueError('Invalid pak name')
        raw=self.take(size if size>0 else -size*2)
        if raw[-(1 if size>0 else 2):]!=bytes(1 if size>0 else 2):raise ValueError('Pak name lacks terminator')
        return raw[:-1].decode('utf-8') if size>0 else raw[:-2].decode('utf-16le')

def parse_index(data,declared_sha):
    if hashlib.sha1(data).digest()!=declared_sha:raise ValueError('Pak index SHA-1 mismatch')
    r=Reader(data);mount=r.string();declared=r.unpack('<i')[0]
    if not 0<=declared<=1000000:raise ValueError('Invalid entry count')
    names=[]
    while r.pos<len(data):
        name=r.string();offset,size,uncompressed,compression=r.unpack('<qqqI');r.take(20)
        if min(offset,size,uncompressed)<0:raise ValueError('Invalid pak entry bounds')
        if compression:
            blocks=r.unpack('<i')[0]
            if not 0<=blocks<=65536:raise ValueError('Invalid compression blocks')
            r.take(16*blocks)
        r.take(5)
        names.append(name.replace('\\','/'))
        if len(names)>declared:raise ValueError('Too many serialized pak entries')
    adjustment=declared-len(names)
    # CRC/SHA-verified original OBT pak1: 405 declared, 305 serialized.
    # Accept this exact observed quirk, not arbitrary truncated indexes.
    if adjustment not in (0,100):raise ValueError('Unexpected OBT pak count discrepancy')
    return mount,names,adjustment

def scan(game_dir):
    game_dir=Path(game_dir)
    folder=game_dir.parent.parent/'Content'/'Paks'
    files=sorted(folder.glob('*.pak'));names=set();errors=[];adjustments=0
    if not files:raise ValueError('No client pak files')
    for path in files:
        try:
            total=path.stat().st_size
            with path.open('rb') as f:
                f.seek(-44,2);magic,version,offset,size,sha=struct.unpack('<IIqq20s',f.read(44))
                if magic!=0x5a6f12e1 or version!=3:raise ValueError('Unsupported pak footer')
                if offset<0 or not 0<size<=128*1024*1024 or offset+size>total-44:raise ValueError('Invalid pak index bounds')
                f.seek(offset);data=f.read(size)
            mount,entries,adjustment=parse_index(data,sha);names.update(entries);adjustments+=bool(adjustment)
        except (OSError,ValueError,UnicodeError,struct.error) as e:errors.append(dict(file=path.name,error=str(e)))
    resources=json.loads((Path(__file__).parent/'resource_catalog.json').read_text('utf-8'))
    found=[r['map_id'] for r in resources['maps'] if r['package'].removeprefix('/Game/')+'.umap' in names]
    return dict(pak_files=len(files),asset_names=len(names),verified_map_ids=found,index_count_adjustments=adjustments,errors=errors,
                validation='Index SHA-1 and entry paths only; full asset bodies and engine replication are not verified.')

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('game_dir');a=p.parse_args();print(json.dumps(scan(a.game_dir),ensure_ascii=False,indent=2))
