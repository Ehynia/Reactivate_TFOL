"""Canonical launcher context layout derived from the supplied x86 binaries.

Reads data only. Never loads a game DLL, creates a process or authenticates.
Canonical checks are deliberately stricter than TenProxy's unchecked pointers.
"""
import json
import struct
from pathlib import Path

MAP_BYTES = 0x80000
DATA_BEGIN = 0x104
SERVER_TABLE_WORDS = 16
INIT_FIELDS = {
    15: ('utf16', 0x410, 'launcher_window_title', 0x10006227),
    2: ('dword', 4, 'qq_id', 0x10006246),
    6: ('dword', 4, 'launch_type', 0x10006286),
    14: ('utf16', 0x410, 'launcher_executable', 0x100062d6),
    5: ('bytes_fixed', 16, 'login_key', 0x1000634c),
    3: ('byte', 1, 'qq_signature_length', 0x100063c4),
    4: ('bytes', 128, 'qq_signature', 0x1000642b),
    26: ('byte', 1, 'additional_bytes_length', 0x100064d4),
    27: ('bytes', 112, 'additional_bytes', 0x1000653b),
    16: ('utf16', 40, 'pass_parameter', 0x10006608),
}
LOGIN_FIELDS = {
    1: ('dword', 4, 'opaque_id_1', 0x10006aec),
    7: ('bytes', 512, 'opaque_login_bytes', 0x10006c45),
    17: ('dword', 4, 'server_count', 0x10006d42),
    18: ('dword', 4, 'selected_server_one_based', 0x10006d7a),
    19: ('utf16', 0x208, 'server_selection_text', 0x10006dcb),
}
MAIN_FIELDS = dict(INIT_FIELDS)
MAIN_FIELDS.update(LOGIN_FIELDS)
SERVER_FIELDS = {
    2: ('utf16', 128, 'server_text_2', 0x10006e88),
    4: ('utf16', 128, 'server_text_4', 0x10006ee4),
    3: ('dword', 4, 'server_number_3', 0x10006f35),
    5: ('dword', 4, 'server_number_5', 0x10006f86),
    6: ('dword', 4, 'server_number_6', 0x10006fd7),
    7: ('dword', 4, 'server_payload_length', 0x10007028),
    8: ('bytes', 256, 'server_payload', 0x10007084),
}

def u32(blob, offset):
    if not 0 <= offset <= len(blob) - 4:
        raise ValueError('DWORD outside mapping')
    return struct.unpack_from('<I', blob, offset)[0]

def record(blob, table, ident, kind, capacity):
    offset = u32(blob, table + (ident - 1) * 4)
    if not DATA_BEGIN <= offset <= len(blob) - 4:
        raise ValueError(f'Field {ident}: absent/invalid offset')
    size = u32(blob, offset)
    if size > capacity or offset + 4 + size > len(blob):
        raise ValueError(f'Field {ident}: invalid length')
    data = blob[offset + 4:offset + 4 + size]
    if kind in ('dword', 'byte', 'bytes_fixed') and size != capacity:
        raise ValueError(f'Field {ident}: fixed width mismatch')
    if kind == 'utf16':
        if size < 2 or size % 2 or data[-2:] != b'\0\0' or b'\0\0' in [data[i:i+2] for i in range(0, size-2, 2)]:
            raise ValueError(f'Field {ident}: invalid UTF-16 terminator')
        data.decode('utf-16le', errors='strict')
    return offset, size, data

def inspect_blob(blob):
    if len(blob) != MAP_BYTES:
        raise ValueError('Canonical image must be exactly 512 KiB')
    if u32(blob, 0) != 0x40:
        raise ValueError('Only the inspected 0x40 header is supported')
    ranges = [(0, DATA_BEGIN, 'main_offset_table')]
    rows = []
    values = {}
    for ident, (kind, cap, purpose, va) in MAIN_FIELDS.items():
        off, size, data = record(blob, 4, ident, kind, cap)
        ranges.append((off, off+4+size, f'main_{ident}'))
        values[ident] = data
        rows.append(dict(id=ident, kind=kind, bytes=size, offset=off,
                         purpose=purpose, consumer_call_va=hex(va)))
    for length_id, payload_id in ((3, 4), (26, 27)):
        if values[length_id][0] > len(values[payload_id]):
            raise ValueError(f'Field {length_id}: length exceeds payload')
    count, = struct.unpack('<I', values[17])
    selected, = struct.unpack('<I', values[18])
    if count > 128 or (count and not 1 <= selected <= count) or (not count and selected):
        raise ValueError('Invalid canonical server count/selection')
    index = u32(blob, 4+19*4)
    if not DATA_BEGIN <= index <= len(blob)-4*count:
        raise ValueError('Server index outside mapping')
    if count:
        ranges.append((index, index+4*count, 'server_index'))
    servers = []
    for ordinal in range(1, count+1):
        table = u32(blob, index+(ordinal-1)*4)
        if not DATA_BEGIN <= table <= len(blob)-SERVER_TABLE_WORDS*4:
            raise ValueError('Server offset table outside mapping')
        ranges.append((table, table+SERVER_TABLE_WORDS*4, f'server_{ordinal}_table'))
        server_rows, server_values = [], {}
        for ident, (kind, cap, purpose, va) in SERVER_FIELDS.items():
            off, size, data = record(blob, table, ident, kind, cap)
            ranges.append((off, off+4+size, f'server_{ordinal}_{ident}'))
            server_values[ident] = data
            server_rows.append(dict(id=ident, kind=kind, bytes=size, offset=off,
                                    purpose=purpose, consumer_call_va=hex(va)))
        if struct.unpack('<I', server_values[7])[0] > len(server_values[8]):
            raise ValueError('Server payload length exceeds record')
        servers.append(dict(ordinal=ordinal, table_offset=table, fields=server_rows))
    # Inspect all populated offset slots, including producer-only fields.
    for table, count_words, prefix, known in [(4, 64, 'main', set(MAIN_FIELDS)|{20})] + [
        (s['table_offset'], SERVER_TABLE_WORDS, f"server_{s['ordinal']}", set(SERVER_FIELDS)) for s in servers
    ]:
        for ident in range(1, count_words+1):
            off = u32(blob, table+(ident-1)*4)
            if not off or ident in known:
                continue
            if not DATA_BEGIN <= off <= len(blob)-4:
                raise ValueError('Additional record outside mapping')
            size = u32(blob, off)
            if off+4+size > len(blob):
                raise ValueError('Additional record length outside mapping')
            ranges.append((off, off+4+size, f'{prefix}_{ident}'))
    ordered = sorted(ranges)
    for before, after in zip(ordered, ordered[1:]):
        if before[1] > after[0]:
            raise ValueError(f'Overlapping {before[2]} and {after[2]}')
    return dict(header=0x40, mapping_bytes=len(blob), fields=rows,
                server_count=count, servers=servers,
                runtime_accepted_by_original_tenproxy=False,
                authentication_or_gameplay_verified=False)

def synthetic_fixture(window_title='TFOL_CONTEXT_R10_SYNTHETIC', launcher_path='CONTEXT_TEST_ONLY', server_count=1):
    """Test values only; these are not a real game session or login ticket."""
    if not 0 <= server_count <= 128:
        raise ValueError('Unsupported synthetic server count')
    utf = lambda text: (text+'\0').encode('utf-16le')
    dw = lambda value: struct.pack('<I', value)
    values = {15:utf(window_title), 2:dw(0), 6:dw(0), 14:utf(launcher_path),
              5:bytes(range(1,17)), 3:b'\x04', 4:b'TEST', 26:b'\x04', 27:b'FAKE',
              16:utf('PASS:LOCAL_TEST'), 1:dw(0), 7:b'SYNTHETIC_CONTEXT_ONLY',
              17:dw(server_count), 18:dw(1 if server_count else 0), 19:utf('LOCAL_TEST')}
    blob = bytearray(MAP_BYTES)
    struct.pack_into('<I', blob, 0, 0x40)
    cursor = DATA_BEGIN
    def add(table, ident, data):
        nonlocal cursor
        struct.pack_into('<I', blob, table+(ident-1)*4, cursor)
        struct.pack_into('<I', blob, cursor, len(data))
        blob[cursor+4:cursor+4+len(data)] = data
        cursor += 4+len(data)
    for ident, data in values.items():
        add(4, ident, data)
    index = cursor
    struct.pack_into('<I', blob, 4+19*4, index)
    cursor += server_count*4
    for ordinal in range(1, server_count+1):
        table = cursor
        struct.pack_into('<I', blob, index+(ordinal-1)*4, table)
        cursor += SERVER_TABLE_WORDS*4
        # Fields 1 and 9 are written by TCLS; this TenProxy GetLoginInfo does not read them.
        server = {1:utf('SYNTHETIC_SERVER'), 2:utf('127.0.0.1'), 3:dw(103),
                  4:utf('LOCAL_TEST'), 5:dw(105), 6:dw(106), 7:dw(4), 8:b'TEST', 9:utf('')}
        for ident, data in server.items():
            add(table, ident, data)
    return bytes(blob)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('blob', nargs='?', type=Path)
    parser.add_argument('--synthetic-self-test', action='store_true')
    args = parser.parse_args()
    if not args.blob and not args.synthetic_self_test:
        parser.error('Supply a saved image or --synthetic-self-test')
    image = synthetic_fixture() if args.synthetic_self_test else args.blob.read_bytes()
    print(json.dumps(inspect_blob(image), indent=2))
