"""Persistent local player state. Resource IDs must come from a sourced catalog."""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3
import time
import threading

SCHEMA=11
SLOTS={'main':'main_weapon','sub':'sub_weapon','melee':'melee_weapon'}
SQL='''
CREATE TABLE players(uid INTEGER PRIMARY KEY AUTOINCREMENT, nickname TEXT NOT NULL UNIQUE,
 level INTEGER NOT NULL DEFAULT 1 CHECK(level>=1), experience INTEGER NOT NULL DEFAULT 0 CHECK(experience>=0),
 credits INTEGER NOT NULL DEFAULT 0 CHECK(credits>=0), created_at REAL NOT NULL);
CREATE TABLE catalog(resource_id INTEGER PRIMARY KEY CHECK(resource_id>0), kind TEXT NOT NULL
 CHECK(kind IN ('character','main_weapon','sub_weapon','melee_weapon')), name TEXT NOT NULL, source TEXT NOT NULL);
CREATE TABLE characters(uid INTEGER NOT NULL REFERENCES players(uid), resource_id INTEGER NOT NULL REFERENCES catalog(resource_id),
 PRIMARY KEY(uid,resource_id));
CREATE TABLE inventory(item_id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER NOT NULL REFERENCES players(uid),
 resource_id INTEGER NOT NULL REFERENCES catalog(resource_id), acquired_at REAL NOT NULL);
CREATE TABLE loadouts(uid INTEGER NOT NULL, character_id INTEGER NOT NULL, slot TEXT NOT NULL CHECK(slot IN ('main','sub','melee')),
 item_id INTEGER NOT NULL REFERENCES inventory(item_id), PRIMARY KEY(uid,character_id,slot),
 FOREIGN KEY(uid,character_id) REFERENCES characters(uid,resource_id));
CREATE TABLE sessions(token_hash TEXT PRIMARY KEY, uid INTEGER NOT NULL REFERENCES players(uid), key_hash TEXT NOT NULL,
 expires_at REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN (0,1)));
CREATE TABLE audit(id INTEGER PRIMARY KEY, created_at REAL NOT NULL, uid INTEGER REFERENCES players(uid), action TEXT NOT NULL, data TEXT NOT NULL);
CREATE INDEX inventory_owner ON inventory(uid);
CREATE INDEX session_expiry ON sessions(expires_at);
CREATE TRIGGER character_kind BEFORE INSERT ON characters
 WHEN (SELECT kind FROM catalog WHERE resource_id=NEW.resource_id) != 'character'
 BEGIN SELECT RAISE(ABORT,'resource is not a character'); END;
CREATE TRIGGER loadout_owner BEFORE INSERT ON loadouts
 WHEN NOT EXISTS(SELECT 1 FROM inventory i JOIN catalog c ON c.resource_id=i.resource_id
 WHERE i.item_id=NEW.item_id AND i.uid=NEW.uid AND c.kind=CASE NEW.slot WHEN 'main' THEN 'main_weapon'
 WHEN 'sub' THEN 'sub_weapon' ELSE 'melee_weapon' END)
 BEGIN SELECT RAISE(ABORT,'ownership or slot mismatch'); END;
CREATE TRIGGER loadout_owner_update BEFORE UPDATE ON loadouts
 WHEN NOT EXISTS(SELECT 1 FROM inventory i JOIN catalog c ON c.resource_id=i.resource_id
 WHERE i.item_id=NEW.item_id AND i.uid=NEW.uid AND c.kind=CASE NEW.slot WHEN 'main' THEN 'main_weapon'
 WHEN 'sub' THEN 'sub_weapon' ELSE 'melee_weapon' END)
 BEGIN SELECT RAISE(ABORT,'ownership or slot mismatch'); END;
'''

def digest(raw):return hashlib.sha256(raw).hexdigest()

class Database:
 def __init__(self,path,legacy=None,progression_enabled=False):
  self.progression_enabled=progression_enabled
  self.local=threading.local();self.connection_lock=threading.Lock();self.cached_connections=set()
  self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
  with self.connect() as c:
   c.execute('PRAGMA journal_mode=WAL')
   version=c.execute('PRAGMA user_version').fetchone()[0]
   if version>SCHEMA:raise ValueError('Database is newer than this server')
   if 0<version<SCHEMA:
    # Snapshot the committed old schema before any migration writes. A failed
    # migration must leave both the original database and this backup usable.
    target=self.path.with_name(f'{self.path.stem}.before-schema-{SCHEMA}-from-{version}-{time.time_ns()}.sqlite3')
    with target.open('xb'):pass
    dest=sqlite3.connect(target)
    try:
     c.backup(dest)
     if dest.execute('PRAGMA quick_check').fetchone()[0]!='ok':raise ValueError('Migration backup failed integrity check')
    except Exception:
     dest.close();target.unlink();raise
    finally:dest.close()
   if not version:
    c.executescript('BEGIN IMMEDIATE;'+SQL+'PRAGMA user_version=1; COMMIT;')
   if legacy and Path(legacy).exists() and not c.execute('SELECT 1 FROM players LIMIT 1').fetchone():
    aliases=json.loads(Path(legacy).read_text(encoding='utf-8'))
    if not isinstance(aliases,dict):raise ValueError('Invalid legacy players file')
    for name,uid in aliases.items():
     if not isinstance(name,str) or not name.strip() or type(uid)!=int or uid<10001:raise ValueError('Invalid legacy identity')
     c.execute('INSERT INTO players(uid,nickname,created_at) VALUES(?,?,?)',(uid,name,time.time()))
   if not c.execute("SELECT 1 FROM sqlite_sequence WHERE name='players'").fetchone():
    c.execute("INSERT INTO sqlite_sequence(name,seq) VALUES('players',100000)")
   c.execute("UPDATE sqlite_sequence SET seq=max(seq,100000) WHERE name='players'")
   migrations=''
   if version<2:
    migrations+="""
CREATE TABLE IF NOT EXISTS news(id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, published_at REAL NOT NULL, visible INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS selected_characters(uid INTEGER PRIMARY KEY, resource_id INTEGER NOT NULL, FOREIGN KEY(uid,resource_id) REFERENCES characters(uid,resource_id));
"""
   if version<3:
    from garage import MIGRATION
    migrations+=MIGRATION
   if version<4:
    from progression import MIGRATION as PROGRESSION_MIGRATION
    migrations+=PROGRESSION_MIGRATION
   if version<5:
    from battle_statistics import MIGRATION as BATTLE_MIGRATION
    from progression import POLICY
    migrations+=BATTLE_MIGRATION
    # Preserve earned XP; correct only the cached level to the client table.
    cases=' '.join(f'WHEN experience>={exp} THEN {level}' for level,exp in reversed(list(enumerate(POLICY['level_entry_experience'],1))))
    migrations+='UPDATE players SET level=CASE '+cases+' ELSE 1 END;'
   if version<6:
    from economy import MIGRATION as ECONOMY_MIGRATION
    migrations+=ECONOMY_MIGRATION
   if version<7:
    from obt_extensions import MIGRATION as OBT_MIGRATION
    migrations+=OBT_MIGRATION
   if version<8:
    migrations+='CREATE TABLE IF NOT EXISTS admin_bans(uid INTEGER PRIMARY KEY REFERENCES players(uid),reason TEXT NOT NULL,created_at REAL NOT NULL);'
    migrations+='CREATE TABLE IF NOT EXISTS admin_commands(request_id TEXT PRIMARY KEY,name TEXT NOT NULL,arguments TEXT NOT NULL,result TEXT NOT NULL,created_at REAL NOT NULL);'
   if version<9:
    from local_simulation import MIGRATION as LOCAL_MIGRATION
    migrations+=LOCAL_MIGRATION
   if version<10:
    from accounts import MIGRATION as ACCOUNT_MIGRATION
    migrations+=ACCOUNT_MIGRATION
   if version<11:
    from round_drops import MIGRATION as DROP_MIGRATION
    migrations+=DROP_MIGRATION
   if migrations:c.executescript('BEGIN IMMEDIATE;'+migrations+f'PRAGMA user_version={SCHEMA}; COMMIT;')
   if 0<version<SCHEMA:self.audit(c,None,'database_migrated',{'from_schema':version,'to_schema':SCHEMA,'backup_file':target.name})
   c.execute('INSERT OR IGNORE INTO news(slug,title,body,published_at) VALUES(?,?,?,?)',('offline-bots','Локальный сервер OBT','Вход в лобби подтверждён. Переносим инвентарь, экономику и серверные функции; сетевые бои требуют готового игрового узла.',1791892800))
 @contextmanager
 def connect(self):
  cached=threading.current_thread().name.startswith('obt-service') and not getattr(self.local,'busy',False)
  c=getattr(self.local,'connection',None) if cached else None
  if c is None:
   try:c=sqlite3.connect(self.path,timeout=10,check_same_thread=not cached)
   except sqlite3.OperationalError as error:raise self._path_error(error) from error
   c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON')
   if cached:
    self.local.connection=c
    with self.connection_lock:self.cached_connections.add(c)
  if cached:self.local.busy=True
  try:
   yield c;c.commit()
  except sqlite3.OperationalError as error:
   c.rollback();raise self._path_error(error) from error
  except Exception:
   c.rollback();raise
  finally:
   if cached:self.local.busy=False
   else:c.close()
 def _path_error(self,error):
  # Diagnose account DB permissions; never chmod, reset or replace player data.
  wrapped=sqlite3.OperationalError(str(error)+'\nDatabase / База: '+str(self.path.absolute()))
  for name in ('sqlite_errorcode','sqlite_errorname'):
   if hasattr(error,name):setattr(wrapped,name,getattr(error,name))
  return wrapped
 def close(self):
  with self.connection_lock:
   for c in self.cached_connections:c.close()
   self.cached_connections.clear()
 def audit(self,c,uid,action,data):c.execute('INSERT INTO audit(created_at,uid,action,data) VALUES(?,?,?,?)',(time.time(),uid,action,json.dumps(data)))
 def aliases(self):
  with self.connect() as c:return {r['nickname']:r['uid'] for r in c.execute('SELECT uid,nickname FROM players')}
 def player(self,nickname):
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   row=c.execute('SELECT uid FROM players WHERE nickname=?',(nickname,)).fetchone()
   if row:return row['uid']
   uid=c.execute('INSERT INTO players(nickname,created_at) VALUES(?,?)',(nickname,time.time())).lastrowid
   c.execute('INSERT INTO account_identity(uid,login,created_at) VALUES(?,?,?)',(uid,nickname,time.time()))
   self.audit(c,uid,'player_created',{});return uid
 def add_session(self,token,key,uid,expires):
  with self.connect() as c:c.execute('INSERT INTO sessions(token_hash,key_hash,uid,expires_at) VALUES(?,?,?,?)',(digest(token),digest(key),uid,expires))
 def session(self,token,now,key=None):
  with self.connect() as c:
   row=c.execute('SELECT uid,expires_at,key_hash FROM sessions WHERE token_hash=? AND revoked=0 AND expires_at>?',(digest(token),now)).fetchone()
   if not row or (key is not None and row['key_hash']!=digest(key)):return None
   return dict(row)
 def revoke(self,token):
  with self.connect() as c:c.execute('UPDATE sessions SET revoked=1 WHERE token_hash=?',(digest(token),))
 def profile(self,uid):
  with self.connect() as c:
   p=c.execute('SELECT uid,nickname,level,experience,credits FROM players WHERE uid=?',(uid,)).fetchone()
   if not p:raise ValueError('Unknown player')
   result=dict(p)
   account=c.execute('SELECT tutorial_required,tutorial_completed_at,nickname_set FROM account_identity WHERE uid=?',(uid,)).fetchone()
   result['onboarding']=dict(account) if account else None
   result['characters']=[dict(r) for r in c.execute('SELECT resource_id FROM characters WHERE uid=? ORDER BY resource_id',(uid,))]
   result['inventory']=[dict(r) for r in c.execute('SELECT i.item_id,i.resource_id,c.kind,c.name FROM inventory i JOIN catalog c USING(resource_id) WHERE uid=? ORDER BY item_id',(uid,))]
   result['loadouts']=[dict(r) for r in c.execute('SELECT character_id,slot,item_id FROM loadouts WHERE uid=? ORDER BY character_id,slot',(uid,))]
   selected=c.execute('SELECT resource_id FROM selected_characters WHERE uid=?',(uid,)).fetchone()
   result['selected_character_id']=selected['resource_id'] if selected else None
   selected_map=c.execute('SELECT map_id FROM selected_maps WHERE uid=?',(uid,)).fetchone()
   result['selected_map_id']=selected_map['map_id'] if selected_map else None
   result['client_wire_verified']=False
   return result
 def catalog(self):
  with self.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM catalog ORDER BY resource_id')]
 def import_catalog(self,rows):
  if not isinstance(rows,list):raise ValueError('Expected list')
  with self.connect() as c:
   for r in rows:
    if not isinstance(r,dict) or type(r.get('resource_id'))!=int or r['resource_id']<=0 or r.get('kind') not in {'character',*SLOTS.values()} or not isinstance(r.get('name'),str) or not r['name'] or not isinstance(r.get('source'),str) or not r['source'].strip():raise ValueError('Each resource requires positive ID, kind, name and source')
    existing=c.execute('SELECT * FROM catalog WHERE resource_id=?',(r['resource_id'],)).fetchone()
    if existing and any(existing[k]!=r[k] for k in ['kind','name','source']):raise ValueError('Conflicting catalog ID')
    c.execute('INSERT OR IGNORE INTO catalog(resource_id,kind,name,source) VALUES(?,?,?,?)',(r['resource_id'],r['kind'],r['name'],r['source']))
   self.audit(c,None,'catalog_import',{'count':len(rows)})
 def grant(self,uid,resource_id):
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   row=c.execute('SELECT kind FROM catalog WHERE resource_id=?',(resource_id,)).fetchone()
   if not row:raise ValueError('Resource is absent from sourced catalog')
   category=1 if row['kind']=='character' else 2
   if category==1:
    c.execute('INSERT OR IGNORE INTO characters(uid,resource_id) VALUES(?,?)',(uid,resource_id))
    existing=c.execute('SELECT item_id FROM inventory WHERE uid=? AND resource_id=? AND category=1',(uid,resource_id)).fetchone()
   else:existing=None
   if existing:item=existing['item_id']
   else:
    pos=c.execute('SELECT coalesce(max(pos),-1)+1 FROM inventory WHERE uid=? AND bag=?',(uid,category)).fetchone()[0]
    item=c.execute('INSERT INTO inventory(uid,resource_id,acquired_at,category,bag,pos) VALUES(?,?,?,?,?,?)',(uid,resource_id,time.time(),category,category,pos)).lastrowid
   self.audit(c,uid,'grant',{'resource_id':resource_id,'item_id':item});return item
 def equip(self,uid,character,slot,item):
  if slot not in SLOTS or any(type(v)!=int or v<=0 for v in [character,item]):raise ValueError('Invalid equipment selection')
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   c.execute('INSERT INTO loadouts(uid,character_id,slot,item_id) VALUES(?,?,?,?) ON CONFLICT(uid,character_id,slot) DO UPDATE SET item_id=excluded.item_id',(uid,character,slot,item))
   self.audit(c,uid,'equip',{'character':character,'slot':slot,'item_id':item})
 def select_character(self,uid,resource):
  if type(resource)!=int or resource<=0:raise ValueError('Invalid character ID')
  with self.connect() as c:
   row=c.execute('SELECT item_id FROM inventory WHERE uid=? AND resource_id=? AND category=1',(uid,resource)).fetchone()
  if not row:raise ValueError('Character is not owned')
  from garage import move
  move(self,uid,row['item_id'],1,0)
 def news(self):
  with self.connect() as c:return [dict(r) for r in c.execute('SELECT id,slug,title,body,published_at FROM news WHERE visible=1 ORDER BY published_at DESC,id DESC')]
 def publish_news(self,slug,title,body):
  if not all(isinstance(v,str) and v.strip() for v in [slug,title,body]) or len(slug)>80 or len(title)>120 or len(body)>8000:raise ValueError('Invalid news content')
  with self.connect() as c:
   c.execute('INSERT INTO news(slug,title,body,published_at) VALUES(?,?,?,?) ON CONFLICT(slug) DO UPDATE SET title=excluded.title,body=excluded.body,published_at=excluded.published_at',(slug,title,body,time.time()))
 def status(self):
  with self.connect() as c:
   return dict(schema_version=c.execute('PRAGMA user_version').fetchone()[0],integrity=c.execute('PRAGMA quick_check').fetchone()[0],
    **{t:c.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['players','characters','inventory','loadouts','catalog','sessions']})
 def backup(self,target):
  target=Path(target)
  if target.resolve()==self.path.resolve() or target.exists():raise ValueError('Backup destination must be a new file')
  target.parent.mkdir(parents=True,exist_ok=True)
  with self.connect() as c:
   dest=sqlite3.connect(target)
   try:c.backup(dest)
   finally:dest.close()
