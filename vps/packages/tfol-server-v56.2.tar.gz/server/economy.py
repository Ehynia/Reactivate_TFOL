"""Local combat economy. Prices/rewards are our policy, item IDs are client IDs."""
import json,time
from pathlib import Path
import garage,progression

POLICY=json.loads((Path(__file__).parent/'economy_policy.json').read_text(encoding='utf-8'))
MIGRATION='''
CREATE TABLE wallet(uid INTEGER NOT NULL REFERENCES players(uid),currency INTEGER NOT NULL CHECK(currency IN(1,2,5)),amount INTEGER NOT NULL DEFAULT 0 CHECK(amount BETWEEN 0 AND 2000000000),PRIMARY KEY(uid,currency));
CREATE TABLE combat_rewards(event_id TEXT PRIMARY KEY REFERENCES match_rewards(event_id),awards TEXT NOT NULL);
CREATE TABLE combat_counters(uid INTEGER PRIMARY KEY REFERENCES players(uid),coupon_kills INTEGER NOT NULL DEFAULT 0 CHECK(coupon_kills>=0));
CREATE TABLE shop_purchases(uid INTEGER NOT NULL REFERENCES players(uid),category INTEGER NOT NULL CHECK(category IN(1,2)),resource_id INTEGER NOT NULL REFERENCES catalog(resource_id),goods_id INTEGER NOT NULL,currency INTEGER NOT NULL,price INTEGER NOT NULL,item_id INTEGER NOT NULL REFERENCES inventory(item_id),created_at REAL NOT NULL,PRIMARY KEY(uid,category,resource_id));
'''

def balance(c,uid,currency):
    if currency==3:return c.execute('SELECT credits FROM players WHERE uid=?',(uid,)).fetchone()[0]
    if currency in (1,2,5):
        row=c.execute('SELECT amount FROM wallet WHERE uid=? AND currency=?',(uid,currency)).fetchone()
    elif currency==6:
        row=c.execute('SELECT amount FROM obt_currency WHERE uid=? AND currency=6',(uid,)).fetchone()
    else:raise ValueError('Unsupported currency')
    return row[0] if row else 0

def adjust(c,uid,currency,amount):
    if currency==3:c.execute('UPDATE players SET credits=credits+? WHERE uid=?',(amount,uid))
    elif currency in (1,2,5):
        c.execute('INSERT OR IGNORE INTO wallet(uid,currency) VALUES(?,?)',(uid,currency))
        c.execute('UPDATE wallet SET amount=amount+? WHERE uid=? AND currency=?',(amount,uid,currency))
    elif currency==6:
        c.execute('INSERT OR IGNORE INTO obt_currency(uid,currency,amount) VALUES(?,6,0)',(uid,))
        c.execute('UPDATE obt_currency SET amount=amount+? WHERE uid=? AND currency=6',(amount,uid))
    else:raise ValueError('Currency cannot be spent')

def complete(database,uid,event_id,stop,rows,*,round_id=None):
    """Validate, persist result, credit wallet and unlock heroes in one transaction."""
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT awards FROM combat_rewards WHERE event_id=?',(event_id,)).fetchone()
        if old:
            owner=c.execute('SELECT uid FROM match_rewards WHERE event_id=?',(event_id,)).fetchone()[0]
            if owner!=uid:raise ValueError('Result belongs to another player')
            return False,json.loads(old[0])
        player=c.execute('SELECT nickname,experience FROM players WHERE uid=?',(uid,)).fetchone()
        mine=[r for r in rows if r['Name']==player['nickname']]
        if len(mine)!=1:raise ValueError('Local player missing from native result')
        row=mine[0]
        if not c.execute('SELECT 1 FROM characters WHERE uid=? AND resource_id=?',(uid,row['JijiaId'])).fetchone():raise ValueError('Result character not owned')
        won=int(stop['WinTeamId'] in (0,1) and row['TeamId']==stop['WinTeamId'])
        # Draws and mission failures still have authentic combat statistics.
        # Only a verified OB15 result can reach this function.  Never convert
        # a draw (255 / -1) into a victory or pretend a zero-time match ended.
        if stop['WinTeamId'] not in (0,1,255,-1) or not 1<=stop['TimeConsume']<=86400:
            raise ValueError('Match has no valid native duration/outcome')
        # Some original PvE snapshots report monster kills separately from
        # Kill. Use the larger counter, never their SUM (which double-counts
        # a kill when both fields track the same enemy).
        kills=min(max(0,row.get('Kill',0),row.get('KillMonster',0)),POLICY['max_kills'])
        assists=min(max(0,row.get('Assists',0)),POLICY['max_assists'])
        if stop['WinTeamId'] in (255,-1) and stop['TimeConsume']<45:
            raise ValueError('Too-short result without confirmed winner')
        heads=min(row['HeadShot'],kills);flags=min(row['CaptureFlagCount'],POLICY['max_objectives'])
        c.execute('INSERT OR IGNORE INTO combat_counters(uid) VALUES(?)',(uid,))
        prior=c.execute('SELECT coupon_kills FROM combat_counters WHERE uid=?',(uid,)).fetchone()[0]
        coupons,remainder=divmod(prior+kills,POLICY['coupon_kills'])
        p=POLICY
        awards={str(currency):base+kills*kill+assists*assist+won*win+heads*head+flags*objective
                for currency,(base,kill,assist,win,head,objective) in p['awards'].items()}
        # Reward a small amount of currency #1 for each verified battle;
        # kills add milestone bonuses. No award without a native result.
        awards['1']=p.get('coupon_completion',0)+kills*p.get('coupon_per_kill',0)+coupons
        # Skin tickets are earned by *verified* native battles only.  Opening
        # the shop, browsing the lobby or clicking Ready never credits money.
        awards['6']=p['skin_ticket_completion']+kills*p['skin_ticket_per_kill']
        # Previously a global 60-second throttle silently zeroed *valid*
        # back-to-back matches, including earned kill currency. A unique
        # result_id is already the durable exactly-once transaction key.
        # Hosted coordinator never accepts arbitrary native OB15 snapshots.
        now=time.time()
        payable=bool(database.progression_enabled)
        if not payable:awards={str(k):0 for k in (1,2,3,4,5,6)};remainder=prior
        # Saturating additions must record the actual credited amount.
        # If the native UI already granted a small local completion XP for
        # this same round, pay only the difference after OB15 proves the score.
        # Kill currency and true win statistics remain based on OB15 alone.
        if round_id is not None:
            import banner_xp54
            awards['4']=max(0,awards['4']-banner_xp54.previously_credited(c,uid,round_id))
        awards['4']=min(awards['4'],2_000_000_000-player['experience'])
        for k in (1,2,3,5,6):awards[str(k)]=min(awards[str(k)],2_000_000_000-balance(c,uid,k))
        total=player['experience']+awards['4']
        c.execute('UPDATE players SET experience=?,level=? WHERE uid=?',(total,progression.level_for(total),uid))
        for k in (1,2,3,5,6):adjust(c,uid,k,awards[str(k)])
        c.execute('UPDATE combat_counters SET coupon_kills=? WHERE uid=?',(remainder,uid))
        c.execute('INSERT INTO match_rewards VALUES(?,?,?,?,?,?)',(event_id,uid,awards['4'],now,'local-client' if payable else 'local-no-reward',awards['3']))
        c.execute('INSERT INTO combat_rewards VALUES(?,?)',(event_id,json.dumps(awards)))
        c.execute('INSERT INTO match_results VALUES(?,?,?,?,?,?,?,?,?,?,?)',(event_id,uid,now,row['JijiaId'],won,row['Kill'],row['Dead'],row['HeadShot'],int(bool(row['Mvp'])),json.dumps(stop),json.dumps(rows,ensure_ascii=False)))
        unlocked=garage.grant_eligible(database,c,uid)
        database.audit(c,uid,'combat_reward',dict(event_id=event_id,awards=awards,unlocked=unlocked))
    return True,awards

def goods():
    # Native GoodsRes has room for 50 entries. Hero ownership comes from
    # account levels; weapons are permanent, one owned copy per resource.
    result=[]
    for r in garage.RESOURCES['catalog']:
        if r['kind']=='character':continue
        index=len(result);currency=2 if index%2==0 else 1
        result.append(dict(Id=100000+r['resource_id'],SortId=index,Category=2,Index=r['resource_id'],Count=1,
            Discount=100,PaymentOne=3,PriceOne=POLICY['weapon_silver'],PaymentTwo=currency,
            PriceTwo=POLICY['weapon_gold'] if currency==2 else POLICY['weapon_coupons'],Tab=3,Leaf=0,Len=0,PicUrl=[]))
    # The extracted skin table contains *orphan* skins whose base hero or
    # weapon is absent from our verified catalog.  Advertising those offers
    # made the genuine ShoppingReq fail with invalidItemId, even when the
    # player owned every available base item and could afford the skin.
    # Never assign an orphan to a guessed base: that would yield a broken
    # equip and potentially make an unrelated character use its blueprint.
    sources={r['resource_id']:r['kind'] for r in garage.RESOURCES['catalog']}
    for skin in garage.RESOURCES['skins']:
        expected=('character' if skin['category']==10 else ('main_weapon','melee_weapon'))
        actual=sources.get(skin['base_id'])
        if actual not in ((expected,) if isinstance(expected,str) else expected):
            continue
        result.append(dict(Id=200000000+skin['category']*10000000+skin['resource_id'],SortId=len(result),Category=skin['category'],Index=skin['resource_id'],Count=1,Discount=100,PaymentOne=3,PriceOne=POLICY['skin_silver'],PaymentTwo=6,PriceTwo=POLICY['skin_tickets'],Tab=3,Leaf=0))
    return result

class PurchaseError(ValueError):pass

def _matches_offer_item(requested,offer):
    # Original TDR ItemInfo contains four fields, including Id (uint64).
    # The client sends Id even when not yet owning the goods, so comparing
    # the decoded object to a THREE-field dict rejected every native request.
    # Id is a hint, NOT permission to purchase an already-owned foreign item.
    return (isinstance(requested,dict) and
            requested.get('Category')==offer['Category'] and
            requested.get('Index')==offer['Index'] and
            requested.get('Count')==1 and
            type(requested.get('Id',0)) is int and
            0<=requested.get('Id',0)<2**64)

def buy(database,uid,values):
    if values.get('Id',0)>=200000000:return buy_skin(database,uid,values)
    offer=next((g for g in goods() if g['Id']==values['Id']),None)
    if not offer:raise PurchaseError('invalid_goods')
    info=values['ItemInfo'];currency=values['Payment'];price=values['Price']
    prices={offer['PaymentOne']:offer['PriceOne'],offer['PaymentTwo']:offer['PriceTwo']}
    if not _matches_offer_item(info,offer):raise PurchaseError('invalid_item')
    if currency not in prices or price!=prices[currency]:raise PurchaseError('invalid_price')
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        # Permanent ownership is the retry key: an identical purchase can
        # never debit twice, even after reconnect/restart or parallel requests.
        owned=c.execute('SELECT * FROM inventory WHERE uid=? AND category=? AND resource_id=? ORDER BY item_id LIMIT 1',(uid,offer['Category'],offer['Index'])).fetchone()
        if owned:return garage.native_item(c,uid,owned),False
        if balance(c,uid,currency)<price:raise PurchaseError('not_enough_money')
        used=c.execute('SELECT count(*) FROM inventory WHERE uid=? AND bag=2',(uid,)).fetchone()[0]
        if used>=250:raise PurchaseError('bag_full')
        pos=c.execute('SELECT coalesce(max(pos),-1)+1 FROM inventory WHERE uid=? AND bag=2',(uid,)).fetchone()[0]
        if pos>=250:raise PurchaseError('bag_full')
        adjust(c,uid,currency,-price)
        item=c.execute('INSERT INTO inventory(uid,resource_id,acquired_at,category,bag,pos) VALUES(?,?,?,2,2,?)',(uid,offer['Index'],time.time(),pos)).lastrowid
        c.execute('INSERT INTO shop_purchases VALUES(?,?,?,?,?,?,?,?)',(uid,2,offer['Index'],offer['Id'],currency,price,item,time.time()))
        database.audit(c,uid,'shop_purchase',dict(goods_id=offer['Id'],currency=currency,price=price,item_id=item))
        __import__('obt_extensions').ensure_skin(c,uid,2,offer['Index'])
        row=c.execute('SELECT * FROM inventory WHERE item_id=?',(item,)).fetchone()
        return garage.native_item(c,uid,row),True


def buy_skin_in(database,c,uid,values):
    import obt_extensions
    offer=next((g for g in goods() if g['Id']==values['Id']),None)
    if not offer:raise PurchaseError('invalid_goods')
    prices={offer['PaymentOne']:offer['PriceOne'],offer['PaymentTwo']:offer['PriceTwo']}
    if not _matches_offer_item(values['ItemInfo'],offer):raise PurchaseError('invalid_item')
    currency=values['Payment'];price=values['Price']
    if currency not in prices or price!=prices[currency]:raise PurchaseError('invalid_price')
    skin=next(s for s in garage.RESOURCES['skins'] if s['category']==offer['Category'] and s['resource_id']==offer['Index'])
    old=c.execute('SELECT item_id FROM obt_skins WHERE uid=? AND category=? AND resource_id=?',(uid,skin['category'],skin['resource_id'])).fetchone()
    if old:item_id=old[0];applied=False
    else:
        category=1 if skin['category']==10 else 2
        if not c.execute('SELECT 1 FROM inventory WHERE uid=? AND category=? AND resource_id=?',(uid,category,skin['base_id'])).fetchone():raise PurchaseError('not_owned')
        if balance(c,uid,currency)<price:raise PurchaseError('not_enough_money')
        adjust(c,uid,currency,-price)
        item_id=obt_extensions.ensure_skin(c,uid,category,skin['base_id'],skin['resource_id']);applied=True
        database.audit(c,uid,'skin_purchase',dict(goods_id=values['Id'],currency=currency,price=price,item_id=item_id))
    return item_id,applied

def buy_skin(database,uid,values):
    import obt_extensions
    with database.connect() as c:
        c.execute("BEGIN IMMEDIATE")
        item_id,applied=buy_skin_in(database,c,uid,values)
    offer=next(g for g in goods() if g["Id"]==values["Id"])
    item=next(r for r in obt_extensions.skin_items(database,uid,offer["Category"]) if r["Id"]==item_id)
    return item,applied
