"""Single writer, bounded queue, rotating JSONL. Flush before collecting reports."""
import datetime
import json
from pathlib import Path
import queue
import threading


class Journal:
    def __init__(self, folder, metrics, max_bytes=8*1024*1024):
        self.path = Path(folder)/'server.jsonl'
        self.metrics, self.max_bytes = metrics, max_bytes
        self.queue = queue.Queue(8192)
        self.error = None
        self.thread = threading.Thread(target=self.run, name='obt-journal', daemon=True)
        self.thread.start()

    def write(self, event, **fields):
        item = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), event=event, **fields)
        try:
            self.queue.put_nowait(item)
        except queue.Full:
            self.metrics.record('journal_dropped')

    def run(self):
        while True:
            value = self.queue.get()
            try:
                if value is None:
                    return
                if self.path.exists() and self.path.stat().st_size >= self.max_bytes:
                    for n in range(3, 0, -1):
                        old = self.path.with_name('server.jsonl.'+str(n))
                        if n == 3:
                            old.unlink(missing_ok=True)
                        elif old.exists():
                            old.replace(self.path.with_name('server.jsonl.'+str(n+1)))
                    self.path.replace(self.path.with_name('server.jsonl.1'))
                with self.path.open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps(value, ensure_ascii=False)+'\n')
            except OSError as error:
                self.error = str(error)
                self.metrics.record('journal_io_errors')
            finally:
                self.queue.task_done()

    def flush(self):
        self.queue.join()

    def close(self):
        self.queue.put(None)
        self.thread.join(timeout=10)
