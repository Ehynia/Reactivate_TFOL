"""Read-only, bounded search inside a user-selected location; no disk-wide scan."""
import argparse
import json
import os
from pathlib import Path
import sys

MANAGED_NAME='TFOL_OBT_LOCAL.exe'
PREFERRED=(MANAGED_NAME,'TFOL_OBT.exe','TFOL_OBT_TEST_19.exe','TFOL_OBT_TEST_16.exe','TFOL.exe','TFOL-Win32-Shipping.exe')
SKIP={'engine','content','saved','obt_server_data','.git','server','node_modules'}

def layout(win32, selected=None):
    folder=Path(win32).resolve()
    if folder.name.lower()!='win32' or folder.parent.name.lower()!='binaries':return None
    project=folder.parent.parent
    # The recovered UE client resolves ../../../TFOL from Win32.
    if project.name.casefold()!='tfol':return None
    paks=project/'Content'/'Paks'
    if not folder.is_dir() or not paks.is_dir() or not (project.parent/'Engine').is_dir():return None
    # Empty Content/Paks folders cannot launch a cooked OBT client.
    if not any(p.is_file() and p.name.lower().startswith('tfol-') and p.suffix.lower()=='.pak' for p in paks.iterdir()):return None
    files={p.name.lower():p for p in folder.iterdir() if p.is_file() and p.suffix.lower()=='.exe'}
    chosen=Path(selected).resolve() if selected else None
    if not chosen or chosen.parent!=folder or not chosen.is_file():
        chosen=next((files[n.lower()] for n in PREFERRED if n.lower() in files),None)
    if chosen is None:chosen=next(iter(sorted(files.values())),folder/MANAGED_NAME)
    return dict(executable=str(chosen),win32=str(folder),project=str(project),installation=str(project.parent))

def from_executable(value):
    selected=Path(value).expanduser().resolve()
    if not selected.is_file() or selected.suffix.lower()!='.exe':raise ValueError('Выберите существующий EXE игры.')
    direct=layout(selected.parent,selected)
    if direct:return [direct]
    # A game bootstrap EXE may be at the installation root. Examine its own
    # folder and project children only; never expand to a parent drive.
    roots=[selected.parent]
    result={}
    for root in roots:
        candidates=[root/'Binaries'/'Win32']
        candidates.extend(p/'Binaries'/'Win32' for p in root.iterdir() if p.is_dir() and not p.is_symlink())
        for folder in candidates:
            item=layout(folder)
            if item:result[item['win32']]=item
    return sorted(result.values(),key=lambda g:g['win32'].casefold())

def discover(value,max_dirs=12000,max_depth=10,cancelled=lambda:False):
    selected=Path(value).expanduser().resolve()
    if selected.is_file():return dict(games=from_executable(selected),truncated=False,skipped=0,visited=0)
    if not selected.is_dir():raise ValueError('Папка игры не найдена. Выберите EXE или папку с клиентом.')
    pending=[(selected,0)];seen=set();found={};visited=0;skipped=0;truncated=False
    while pending:
        if cancelled():return dict(games=[],cancelled=True,truncated=False,skipped=skipped,visited=visited)
        if visited>=max_dirs:truncated=True;break
        folder,depth=pending.pop();key=os.path.normcase(str(folder))
        if key in seen:continue
        seen.add(key);visited+=1
        try:
            item=layout(folder)
            if item:found[item['win32']]=item;continue
            if depth>=max_depth:truncated=True;continue
            with os.scandir(folder) as entries:
                for entry in entries:
                    # Windows junctions and symlinks must not escape the selected tree.
                    if entry.name.casefold() in SKIP or entry.is_symlink():continue
                    if hasattr(entry,'is_junction') and entry.is_junction():continue
                    if entry.is_dir(follow_symlinks=False):pending.append((Path(entry.path),depth+1))
        except (OSError,ValueError):skipped+=1
    return dict(games=sorted(found.values(),key=lambda g:g['win32'].casefold()),truncated=truncated,skipped=skipped,visited=visited)

def selected_game(value):
    result=discover(value)
    if not result['games']:raise ValueError('Клиент OBT не найден. Нужны Binaries/Win32, Content/Paks с PAK-файлами и Engine. Выберите папку с распакованной игрой или её EXE.')
    if len(result['games'])!=1:raise ValueError('Найдено несколько клиентов. Выберите EXE нужной игры.')
    return result['games'][0]

def main():
    if sys.argv[1:]!=['--json-stdin']:raise ValueError('Expected --json-stdin')
    raw=sys.stdin.buffer.read(8193)
    if len(raw)>8192:raise ValueError('Discovery request is too large')
    value=json.loads(raw.decode('utf-8-sig'))
    if not isinstance(value,dict) or set(value)!={'path'} or not isinstance(value['path'],str):raise ValueError('Invalid discovery request')
    return discover(value['path'])

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');sys.stderr.reconfigure(encoding='utf-8')
    try:print(json.dumps(main(),ensure_ascii=False),flush=True)
    except Exception as error:
        print(json.dumps(dict(error=str(error)),ensure_ascii=False),flush=True);raise SystemExit(1)
