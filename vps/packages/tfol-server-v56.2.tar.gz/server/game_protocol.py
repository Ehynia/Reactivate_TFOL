"""TDR-derived big-endian messages. Selected handlers; no fabricated inventory."""
import json
from pathlib import Path
import struct
import time
import garage
import sqlite3
import battle_statistics
import economy
from tdr_codec import SCHEMAS,PRIMITIVES,BY_OFFSET,HEAD,encode,decode,packet,decode_all,packets
from query_protocol import inspect_packet
CLIENT_PROTOCOL_VERSION=1
class Codec:
 def encode(self,name,values,depth=0):return encode(name,values,depth)
 def decode(self,name,data,depth=0):return decode(name,data,depth)
CODEC=Codec()
REQUESTS={1:'QueryServerReq',3:'LoginDataReq',37:'QueryBagData',40:'EquipItemReq',47:'MoveItemReq',65:'RoomMatchReq',67:'LobbyItemReq',72:'CancelRoomMatchReq',80:'StartGameCancelReq',83:'CreateMatchTeamReq',95:'ShoppingReq',115:'JijiaBattleInfoReq',159:'LogoutInfoReq',165:'ExitPostGameReq',169:'GoodsReq',176:'TutorialBattleReq'}
REQUESTS.update({13:'SetRoleDataReq',17:'GetTeamListDataReq',19:'StartGameDataReq',21:'GameReadyDataReq',23:'LoadMapDataReq',33:'GetRoleListDataReq',70:'StartGameReadyReq'})

REQUESTS.update({87:'LeaveMatchTeamReq',132:'MatchTeamSelectModeReq'})
REQUESTS.update({230:'MatchConfirmReq'})
REQUESTS.update({226:'RenameReq'})
REQUESTS.update({5:'CreateRoleDataReq'})
REQUESTS.update({196:'LogoutReq'})

def queue_team(database,uid,rows):
 return packet(18,'GetTeamListDataRes',dict(TeamCount=len(rows),TeamList=rows,BlueTeamCount=1,BlueTeamSeat=[0],RedTeamCount=0,RedTeamSeat=[],Result='ok'))

def room_message(database,uid,command,values,context):
 if context and context.get('native_bots') and context.get('engine_match'):
  from native_bots import room_reply
  native=room_reply(database,uid,context,command,values)
  if native is not None:return native
 if not context or 'matchmaking' not in context:raise ValueError('Authenticated room required')
 import matchmaking,peer_rooms
 queue=context['matchmaking']
 with queue.lock:
  try:room=queue.peers.get(uid,context['connection_id'])
  except ValueError:
   profile=database.profile(uid)
   rows=peer_rooms.roster(database,dict(players=[uid],host_uid=uid))
   if command==13:
    try:database.select_character(uid,values['RoleId']);result='ok'
    except ValueError:result='not_owned'
    return packet(14,'SetRoleDataRes',dict(Name=profile['nickname'],RoleId=values['RoleId'],Result=result))
   if command==17:return queue_team(database,uid,rows)
   if command==33:return packet(34,'GetRoleListDataRes',dict(TeamListCount=1,TeamList=rows,Result='ok'))
   if command==19:return packet(20,'StartGameDataRes',dict(Result='server_unavailable'))
   if command in (21,70):return packet(22 if command==21 else 71,'GameReadyDataRes' if command==21 else 'StartGameReadyRes',dict(Name=profile['nickname'],Result='server_unavailable'))
   if command==23:return packet(24,'LoadMapDataRes',dict(Result='server_unavailable'))
   raise

  decision=dict(players=[e.uid for e in room.members],host_uid=room.host,seats=room.seats,roles=room.roles,mode=room.match_id)
  if command==13:
   try:database.select_character(uid,values['RoleId']);result='ok';room.roles[uid]=values['RoleId'];room.revision+=1
   except ValueError:result='not_owned'
   return packet(14,'SetRoleDataRes',dict(Name=database.profile(uid)['nickname'],RoleId=values['RoleId'],Result=result))
  rows=peer_rooms.roster(database,decision)
  if command==17:return matchmaking.team_packet(database,decision)
  if command==33:return packet(34,'GetRoleListDataRes',dict(TeamListCount=len(rows),TeamList=rows,Result='ok'))
  if command==19:return packet(20,'StartGameDataRes',dict(Result='ok'))
  if command in (21,70):
   room.ready.add(uid)
   # All assigned members clicked Battle. Engine connection readiness is a
   # separate stage; the guest is held until the host's actual UDP bind.
   return b''.join(packet(22 if command==21 else 71,'GameReadyDataRes' if command==21 else 'StartGameReadyRes',dict(Name=r['Name'],Result='ok',**(__import__('obt_extensions').ready_info(database,player,room.roles.get(player,database.profile(player)['selected_character_id'])) if command==21 else {}))) for player,r in zip(decision['players'],rows))
  if command==23:
   if uid!=room.host and not room.bound:raise ValueError('Host not listening')
   return packet(24,'LoadMapDataRes',dict(IP='127.0.0.1',Port=room.port,Key='',Token=uid,Result='ok',LoginDsTimeout=30,DSRelayTimeout=30))
 raise ValueError('Unsupported room message')

def handle_legacy(database,uid,data,lobby_port=28080,local_rewards=True,context=None):
 command,body=inspect_packet(data)
 schema=REQUESTS.get(command)
 if schema:
  values,n=CODEC.decode(schema,body)
  if n!=len(body):raise ValueError('Trailing request data')
 else:values={}
 if command==17 and context.get('local_simulation') and context.get('party_created') and not context.get('native_bots'):
  reply=context['local_simulation'].party_packet(uid)
 elif command in (13,17,19,21,23,33,70):reply=room_message(database,uid,command,values,context)
 elif command==1:
  if type(lobby_port)!=int or not 1<=lobby_port<=65535:raise ValueError('Invalid local lobby port')
  # TDR documents Timeout in seconds. Url routes the next lobby connection;
  # the client does not reuse the launcher's gate address for that connection.
  # Its native handler strips through Find("//")+2 before splitting host:port.
  # Without a scheme, Find returns -1 and the first address character is lost.
  reply=packet(2,'QueryServerRes',dict(Timeout=30,ProtocolVersion=CLIENT_PROTOCOL_VERSION,Url=f'tcp://127.0.0.1:{lobby_port}',Res='OK'))
 elif command==3:
  # The original ONCE-ONLY tutorial must be started by the native login
  # response handler, BEFORE UE4 constructs the lobby HUD.  v36/v40 waited
  # eight seconds and dispatched OB27 after lobby entry, which overlaid the
  # entire menu on top of the Megatron tutorial scene.
  import tutorial_mission36
  first_login=tutorial_mission36.login_state(database,uid,context)
  info=dict(battle_statistics.player_info(database,uid))
  if first_login:info['Name']=''
  reply=packet(4,'LoginDataRes',dict(PlayerInfo=info,**__import__('obt_extensions').spark_login(database,uid),
      Time=int(time.time()),Result='badName' if first_login else 'ok'))
 elif command==37:
  numbers=[10,11,2,5,1]+[n for n in garage.RESOURCES['bags'] if n not in (1,2,5,10,11)] if values['BagIndex']==0 else [10,11,2,5,1] if values['BagIndex']==1 else [values['BagIndex']]
  reply=b''
  for number in numbers:
   items=garage.bag(database,uid,number)
   reply+=packet(38,'SyncBagData',dict(BagIndex=number,Count=len(items),Items=items))
 elif command==47:
  changed=[]
  try:changed=garage.move(database,uid,values['Item'],values['Bag'],values['Pos']);result='ok'
  except (ValueError,sqlite3.IntegrityError):result='not_owned'
  reply=packet(48,'MoveItemRes',dict(**values,Result=result))+b''.join(packet(39,'SyncItemData',dict(Item=item)) for item in changed)
 elif command==40:
  # UI may address the cosmetic by ItemData.Id or original resource Index,
  # and weapon skins may be attached through the selected character holder.
  # Always resolve against actual purchased ownership on this account.
  try:affected=garage.equip(database,uid,values['EquipItem'],values['HolderItem'],values['SlotIndex']);result='ok'
  except (ValueError,sqlite3.IntegrityError):affected=None;result='invalid_equipment'
  reply=packet(41,'EquipItemRes',dict(**values,Result=result))
  if result=='ok':
   # Send the affected BASE object, not the client-supplied holder hint.
   # Re-sync cosmetic bags so UE4 garage sees the new equipment immediately.
   with database.connect() as c:
    holder=c.execute('SELECT * FROM inventory WHERE uid=? AND item_id=?',(uid,affected)).fetchone()
    if holder:
     reply+=packet(39,'SyncItemData',dict(Item=garage.native_item(c,uid,holder)))
     category=10 if holder['category']==1 else 11
     if values['EquipItem']==0 or __import__('obt_extensions')._owned_skin_for_input(c,uid,values['EquipItem']) is not None:
      skins=garage.bag(database,uid,category)
      reply+=packet(38,'SyncBagData',dict(BagIndex=category,Count=len(skins),Items=skins))
 elif command==67:
  try:item=garage.lobby_item(database,uid,values['Category']);result='ok'
  except ValueError:item={};result='not_owned'
  reply=packet(68,'LobbyItemRes',dict(Item=item,Result=result))
 elif command==115:
  chars=battle_statistics.characters(database,uid)
  reply=packet(116,'JijiaBattleInfoRes',dict(Count=len(chars),JijiaBattleInfoList=chars,Result='ok'))
 elif command==169:
  # Native 0x7818ae tests End; zero sends one more GoodsReq at 0x78198f.
  # Pad is filler, not a page index. Cursor belongs to this connection.
  catalog=context.get('goods_snapshot')
  if catalog is None:
   catalog=economy.goods();context['goods_snapshot']=catalog;context['goods_cursor']=0
  cursor=context['goods_cursor'];part=catalog[cursor:cursor+50]
  ended=cursor+len(part)>=len(catalog)
  reply=packet(170,'GoodsRes',dict(Count=len(part),Goods=part,Result='ok',End=int(ended)))
  if ended:
   context.pop('goods_snapshot',None);context.pop('goods_cursor',None)
  else:context['goods_cursor']=cursor+len(part)
 elif command==95:
  try:
   item,applied=economy.buy(database,uid,values);result='ok'
   # Send the acquired 64-bit ItemInfo.Id: the original client uses it to
   # bind the purchased item to the garage without waiting for a relog.
   infos=[dict(Category=item['Category'],Index=item['Index'],Count=1,Id=item['Id'])]
  except economy.PurchaseError as error:
   item=None;infos=[];result=str(error)
  reply=packet(96,'ShoppingRes',dict(Id=values['Id'],Count=len(infos),ItemInfo=infos,Result=result))
  if item:
   for category in (10,11):
    skins=garage.bag(database,uid,category);reply+=packet(38,'SyncBagData',dict(BagIndex=category,Count=len(skins),Items=skins))
   reply+=packet(39,'SyncItemData',dict(Item=item))
   for money in garage.currency_bag(database,uid):reply+=packet(39,'SyncItemData',dict(Item=money))
 elif command==65:
  if values['MatchId']==3001:
   return packet(66,'RoomMatchRes',dict(PredictedTime=0,Result='server_unavailable')),dict(command=command,schema=schema,handler_implemented=True,application_processed=True,pve_temporarily_disabled=True)
  if context.get('native_bots') and values['MatchId'] in __import__('bot_modes').MODES:
   import native_bots
   match=native_bots.start(database,uid,context,values['MatchId'])
   return packet(66,'RoomMatchRes',dict(PredictedTime=native_bots.WAIT_SECONDS,Result='ok')),dict(command=command,schema=schema,handler_implemented=True,transport_accepted=True,application_processed=True,native_engine_travel=True,simulation=False)
  # Non-native sessions require a real listen-host/worker for online PvP.
  # The local bridge currently negotiates peer_capable=False, therefore we
  # must not pretend that its network multiplayer works already.
  # Native PvP must not be acknowledged as a completed simulation.
  simulation=(context.get('local_simulation') if not context.get('native_bots') else None) if context else None
  if simulation:
   match=simulation.start(uid,context['connection_id'],values['MatchId'])
   context['test_match_id']=match['id']
   return packet(66,'RoomMatchRes',dict(PredictedTime=6,Result='ok')),dict(command=command,schema=schema,handler_implemented=True,transport_accepted=True,application_processed=True,simulation=True)
  if context is None or 'matchmaking' not in context:raise ValueError('Authenticated matchmaking connection required')
  context.pop('completion_pending',None)
  if context.get('peer_capable'):
   import peer_rooms
   peer_rooms.safe_name(database.profile(uid)['nickname'])
  remaining=context['matchmaking'].join(uid,context['connection_id'],values['MatchId'],values['Competition'],peer=context.get('peer_capable',False))
  reply=packet(66,'RoomMatchRes',dict(PredictedTime=remaining,Result='ok'))
 elif command==230:
  if context.get('native_bots') and context.get('engine_match'):
   from native_bots import room_reply
   reply=room_reply(database,uid,context,230,values)
   if reply is None:reply=packet(231,'MatchConfirmRes',dict(Result='server_unavailable',Name=database.profile(uid)['nickname']))
  else:reply=packet(231,'MatchConfirmRes',dict(Result='server_unavailable',Name=database.profile(uid)['nickname']))
 elif command==80:
  __import__('native_bots').cancel(context)
  if context.get('local_simulation'):context['local_simulation'].cancel(uid)
  if context and 'matchmaking' in context:context['matchmaking'].cancel(uid,context['connection_id'])
  reply=packet(81,'StartGameCancelRes',dict(Name=database.profile(uid)['nickname'],Result='ok'))
 elif command==72:
  __import__('native_bots').cancel(context)
  if context.get('local_simulation'):context['local_simulation'].cancel(uid)
  if context and 'matchmaking' in context:context['matchmaking'].cancel(uid,context['connection_id'])
  reply=packet(73,'CancelRoomMatchRes',dict(Name=database.profile(uid)['nickname'],Result='ok'))
 elif command==83:
  import match_team
  reply=match_team.create(database,uid,context)
 elif command==132:
  import match_team
  reply=match_team.select(database,uid,context,values['ModeId'])
 elif command==87:
  import round_drops
  drop_result=round_drops.settle_context(database,uid,context,reason='leave_team')
  import match_team
  if context.get('local_simulation'):context['local_simulation'].cancel(uid)
  reply=match_team.leave(database,uid,context)
  if drop_result.get('state')=='awarded':
   new_items=garage.bag(database,uid,3)
   reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(new_items),Items=new_items))
   for money in garage.currency_bag(database,uid):reply+=packet(39,'SyncItemData',dict(Item=money))
 elif command==196:
  # Original account sign-out (distinct from LogoutInfoReq=159) was
  # previously silently discarded. Close only this session; never reset
  # persistent accounts or create a second award on repeated sign-outs.
  import round_drops
  round_drops.settle_context(database,uid,context,reason='account_logout')
  __import__('native_bots').cancel(context)
  if context.get('local_simulation'):context['local_simulation'].cancel(uid)
  if context.get('matchmaking'):context['matchmaking'].cancel(uid,context.get('connection_id'))
  context['logged_in']=False
  reply=packet(197,'LogoutRes',dict(nothing=values['nothing']))
 elif command==159:
  import round_drops
  settled=round_drops.settle_context(database,uid,context,reason='logout')
  __import__('native_bots').cancel(context)
  reply=packet(160,'LogoutInfoRes',dict(DailyBattleInfo=battle_statistics.daily(database,uid)))
  if settled.get('state')=='awarded':
   items=garage.bag(database,uid,3)
   reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(items),Items=items))
   for money in garage.currency_bag(database,uid):reply+=packet(39,'SyncItemData',dict(Item=money))
 elif command==165:
  import round_drops
  # Result-less post-match exits are normal in the damaged OBT client.  A
  # verified, sufficiently long round can still yield a consolation item.
  # Sending ExitPostGameRes alone left the client with a stale bag even when
  # the SQLite transaction had already committed the drop.
  settled=round_drops.settle_context(database,uid,context,reason='exit_post_game')
  # The real UE4 scoreboard can arrive after the original 165 request.
  # Preserve this exact native round for 120s only after authenticated R45E.
  from postmatch_lifecycle53 import retain_after_exit
  late_result_window=retain_after_exit(database,uid,context) if context else False
  if not late_result_window:
   __import__('native_bots').cancel(context)
  reply=packet(166,'ExitPostGameRes',dict(Result='ok'))
  if settled.get('state')=='awarded':
   items=garage.bag(database,uid,3)
   reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(items),Items=items))
   for money in garage.currency_bag(database,uid):reply+=packet(39,'SyncItemData',dict(Item=money))
 elif command==5:
  import accounts
  try:accounts.rename_in_game(database,uid,values['Name']);code='ok'
  except ValueError as error:code=str(error)
  reply=packet(6,'CreateRoleDataRes',dict(PlayerInfo=battle_statistics.player_info(database,uid),Result=code))
  if code=='ok':
   reply+=packet(62,'SyncPlayerInfo',dict(PlayerInfo=battle_statistics.player_info(database,uid)))
   if context.get('original_tutorial_login41'):
    # The original nickname/avatar UI is opened by the UE4 onboarding
    # handler.  A submitted name ends the one-time login gate.  It is NOT
    # evidence that Megatron was killed; no unverified tutorial completion
    # or victory reward is created here.
    context.pop('original_tutorial_login41',None)
    import obt_handlers
    reply+=obt_handlers.initial(database,uid,context)
 elif command==226:
  import accounts,round_drops
  try:accounts.use_rename_card(database,uid,values['Name']);code='ok'
  except ValueError as error:code=str(error)
  reply=packet(227,'RenameRes',dict(Code=code))
  if code=='ok':
   # Bag refresh drops spent cards when the count reaches zero.
   cards=round_drops.bag_cards(database,uid)
   reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(cards),Items=cards))
   reply+=packet(62,'SyncPlayerInfo',dict(PlayerInfo=battle_statistics.player_info(database,uid)))
 elif command==176:
  # PvE uses the native PVEDEFEND route (mode 3001, map 2001).  Older
  # versions cleared engine_match before checking which mode completed,
  # which meant even a legitimate PVE result could never enter OB15 escrow.
  # A client-declared mode alone is NOT enough evidence of a completed battle.
  native_match=context.get('engine_match',{}) if context else {}
  pve_report=values['Mode'] in ('PVE','PVEDEFEND')
  pve_travel=(native_match.get('mode')==3001 and
              native_match.get('state')=='travel_dispatched' and
              bool(native_match.get('round_id')))
  eligible_mode=(values['Mode']=='TDM' or (pve_report and pve_travel))
  # The UI may time out waiting for OB15 and never send ExitPostGameReq.
  # Settle already-verified participation independently of victory awards.
  # This is limited by round_drops' persisted clock/identity/caps and does
  # not invent a battle result, or modify UE4's WaitingPostMatch UI.
  if pve_travel and local_rewards:
   import round_drops
   round_drops.settle_context(database,uid,context,reason='reported_pve_completion')
  # The legacy x86 bridge sends OB27 and R45E, but not actual OB15.
  # If the game submits completion before a banner, unlock the local UI
  # with neutral, zero-stat message 60 after verified, >=45s map participation.
  # It is a UI-only escape, not a win or an economy.complete() event.
  if (context.get('local_ui_recovery52') and local_rewards and
      context.get('native_bots') and values['Match']==1 and eligible_mode):
   from result_recovery52 import notice
   fallback,rec=notice(database,uid,context,source='native_tutorial_completion',min_age=45)
   if fallback:
    context.pop('completion_pending',None);context.pop('completion_event',None)
    return fallback+packet(177,'TutorialBattleRes',dict(Exp=0,SilverCoin=0,Result='ok')),dict(
      command=command,schema=schema,handler_implemented=True,transport_accepted=True,
      application_processed=True,request_values_logged=False,reward_status='local_ui_only_no_verified_OB15',
      ui_recovery=rec['status'],scoreboard_verified=False)
  # Preserve the authenticated match context if we are still expecting a
  # genuine native outcome; clearing it here invalidates late OB15 capture.
  if context.get('native_bots') and not (eligible_mode and values['Match']==1 and
        (context.get('deferred_combat') or context.get('local_ui_recovery52'))):
   __import__('native_bots').cancel(context)
  import progression
  if context is not None and context.get('deferred_combat') and local_rewards and database.progression_enabled and eligible_mode and values['Match']==1:
   import uuid
   # Duplicate completion must preserve the same result transaction identity.
   if not context.get('completion_pending'):
    context['completion_pending']=dict(event_id='combat-'+uuid.uuid4().hex,round_id=native_match.get('round_id'),created_at=time.time(),
                                       mode='PVEDEFEND' if pve_report else 'TDM',room_seq=native_match.get('sequence',0))
   context.pop('completion_event',None)
   return b'',dict(command=command,schema=schema,handler_implemented=True,transport_accepted=True,application_processed=True,request_values_logged=False,reward_status='awaiting_authenticated_OB15_snapshot')
  if context is not None:context.pop('completion_pending',None)
  reward=dict(awarded_experience=0,awarded_silver_coin=0)
  reply=packet(177,'TutorialBattleRes',dict(Exp=0,SilverCoin=0,Result='ok'))
  if reward['awarded_experience']:
   # Native MSG_SYNC_ITEM_DATA=39 updates individual entries without clearing
   # the garage container. New weapons must precede their character holders.
   for number in [2,1]:
    for item in garage.bag(database,uid,number):reply+=packet(39,'SyncItemData',dict(Item=item))
   for item in garage.currency_bag(database,uid):
    if item['Index'] in (3,4):reply+=packet(39,'SyncItemData',dict(Item=item))
 else:reply=b''
 return reply,dict(command=command,schema=schema,handler_implemented=bool(reply),transport_accepted=True,
                   application_processed=bool(reply),request_values_logged=False,
                   **({'reward_status':'unverified_completion_no_reward'} if command==176 else {}))


def handle(database,uid,data,lobby_port=28080,local_rewards=True,context=None):
 import obt_handlers
 command,body=inspect_packet(data)
 context=context if context is not None else {}
 if command==196 and not context.get('logged_in'):
  # A duplicate sign-out should never restart a session or award a second drop.
  value=decode_all('LogoutReq',body)
  return packet(197,'LogoutRes',dict(nothing=value['nothing'])),dict(
      command=196,schema='LogoutReq',handler_implemented=True,
      transport_accepted=True,application_processed=True,duplicate_logout=True)
 if command not in (1,3,168) and not context.get('logged_in'):
  raise ValueError('Account request before application login')
 if command in obt_handlers.REQUESTS:
  reply=obt_handlers.handle(database,uid,command,body,context)
  if command==168:
   if context.get('native_bots'):
    import native_bots
    reply+=native_bots.poll(database,uid,context)
   if not context.get('original_tutorial_login41'):
    import news_feed
    reply+=news_feed.updates(database,context)
  # Original client sometimes returns to the lobby without sending
  # ExitPostGameReq(165). Refreshing available modes (263) is the first
  # observable lobby request after that return. Settle the *tracked native*
  # round here as well, so earned participation money is visible immediately.
  if command==263 and context.get('native_bots') and context.get('allow_local_rewards'):
   import round_drops
   settled=round_drops.settle_context(database,uid,context,reason='lobby_after_round')
   # Keep engine_match until a new match is actually requested. A native
   # end-of-round result can arrive late, after the lobby widget opens.
   # Clearing it here would make late authenticated OB15 impossible.
   if settled.get('state')=='awarded':
    cards=garage.bag(database,uid,3)
    reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(cards),Items=cards))
    for money in garage.currency_bag(database,uid):
     reply+=packet(39,'SyncItemData',dict(Item=money))
  if context.get('local_simulation'):reply+=context['local_simulation'].wire_updates(uid,context)
  return reply,dict(command=command,schema=obt_handlers.REQUESTS[command],handler_implemented=True,application_processed=True,transport_accepted=True)
 if command in REQUESTS:
  reply,details=handle_legacy(database,uid,data,lobby_port,local_rewards,context)
  if command==3:
   context.pop('goods_snapshot',None);context.pop('goods_cursor',None)
   context['logged_in']=True
   # Do not send HomePageInfo, mode availability or the lobby mail/news
   # during the tutorial login.  These packets can instantiate menu widgets
   # over the dedicated onboarding viewport before the native level ends.
   if not context.get('original_tutorial_login41'):
    reply+=obt_handlers.initial(database,uid,context)
   import news_feed
   if not context.get('original_tutorial_login41'):
    context['news_snapshot']=news_feed.native(database)
    context['news_check_at']=time.monotonic()+30
  elif context.get('local_simulation'):reply+=context['local_simulation'].wire_updates(uid,context)
  return reply,details
 return b'',dict(command=command,schema=None,handler_implemented=False,application_processed=False,transport_accepted=True)
