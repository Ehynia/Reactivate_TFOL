"""Owned native inventory and garage moves, backed by the actual client tables."""
import json
from pathlib import Path
import time
from database import SLOTS

RESOURCES=json.loads((Path(__file__).resolve().parent/'resource_catalog.json').read_text(encoding='utf-8'))

MIGRATION='''
ALTER TABLE inventory ADD COLUMN category INTEGER NOT NULL DEFAULT 2 CHECK(category IN (1,2));
ALTER TABLE inventory ADD COLUMN bag INTEGER NOT NULL DEFAULT 2;
ALTER TABLE inventory ADD COLUMN pos INTEGER NOT NULL DEFAULT 0;
UPDATE inventory SET category=CASE WHEN (SELECT kind FROM catalog WHERE resource_id=inventory.resource_id)='character' THEN 1 ELSE 2 END;
UPDATE inventory SET bag=category;
WITH ranked AS (SELECT item_id,row_number() OVER(PARTITION BY uid,bag ORDER BY item_id)-1 AS new_pos FROM inventory)
UPDATE inventory SET pos=(SELECT new_pos FROM ranked WHERE ranked.item_id=inventory.item_id);
CREATE UNIQUE INDEX inventory_bag_position ON inventory(uid,bag,pos);
CREATE UNIQUE INDEX one_character_item ON inventory(uid,resource_id) WHERE category=1;
CREATE TABLE starter_grants(uid INTEGER PRIMARY KEY REFERENCES players(uid), version INTEGER NOT NULL);
CREATE TABLE maps(map_id INTEGER PRIMARY KEY, name TEXT NOT NULL, package TEXT NOT NULL, available INTEGER NOT NULL, source TEXT NOT NULL);
CREATE TABLE selected_maps(uid INTEGER PRIMARY KEY REFERENCES players(uid), map_id INTEGER NOT NULL REFERENCES maps(map_id));
'''

def install(database):
 database.import_catalog(RESOURCES['catalog'])
 with database.connect() as c:
  for m in RESOURCES['maps']:
   c.execute('INSERT INTO maps(map_id,name,package,available,source) VALUES(?,?,?,?,?) ON CONFLICT(map_id) DO UPDATE SET name=excluded.name,package=excluded.package,available=excluded.available,source=excluded.source',(m['map_id'],m['name'],m['package'],int(m['available']),m['source']))

def grant_eligible(database,c,uid):
 import progression
 roles={r['resource_id']:r for r in RESOURCES['roles']};added=[]
 for role_id in map(int,progression.eligible(database,c,uid)):
  role=roles[role_id]
  if not c.execute('SELECT 1 FROM characters WHERE uid=? AND resource_id=?',(uid,role_id)).fetchone():
   c.execute('INSERT INTO characters(uid,resource_id) VALUES(?,?)',(uid,role_id));added.append(role_id)
  if not c.execute('SELECT 1 FROM inventory WHERE uid=? AND resource_id=? AND category=1',(uid,role_id)).fetchone():
   pos=c.execute('SELECT coalesce(max(pos),-1)+1 FROM inventory WHERE uid=? AND bag=1',(uid,)).fetchone()[0]
   c.execute('INSERT INTO inventory(uid,resource_id,acquired_at,category,bag,pos) VALUES(?,?,?,1,1,?)',(uid,role_id,time.time(),pos))
   __import__('obt_extensions').ensure_skin(c,uid,1,role_id)
  for slot,resource in [(s,role[s]) for s in SLOTS]:
   if not resource:continue
   if c.execute('SELECT 1 FROM loadouts WHERE uid=? AND character_id=? AND slot=?',(uid,role_id,slot)).fetchone():continue
   pos=c.execute('SELECT coalesce(max(pos),-1)+1 FROM inventory WHERE uid=? AND bag=2',(uid,)).fetchone()[0]
   item=c.execute('INSERT INTO inventory(uid,resource_id,acquired_at,category,bag,pos) VALUES(?,?,?,2,2,?)',(uid,resource,time.time(),pos)).lastrowid
   c.execute('INSERT INTO loadouts(uid,character_id,slot,item_id) VALUES(?,?,?,?)',(uid,role_id,slot,item))
   __import__('obt_extensions').ensure_skin(c,uid,2,resource)
 return added

def provision(database,uid):
 with database.connect() as c:
  c.execute('BEGIN IMMEDIATE');added=grant_eligible(database,c,uid)
  selected=c.execute('SELECT resource_id FROM inventory WHERE uid=? AND bag=1 ORDER BY pos,item_id LIMIT 1',(uid,)).fetchone()
  if selected:c.execute('INSERT OR IGNORE INTO selected_characters(uid,resource_id) VALUES(?,?)',(uid,selected[0]))
  c.execute('INSERT OR IGNORE INTO starter_grants(uid,version) VALUES(?,1)',(uid,))
  c.execute('INSERT OR IGNORE INTO account_cards(uid,amount) VALUES(?,3)',(uid,))
  if added:database.audit(c,uid,'starter_inventory',{'characters':len(added)})
 selected=database.profile(uid)['selected_character_id']
 if selected:database.select_character(uid,selected)
 import obt_extensions
 obt_extensions.provision(database,uid)

def native_item(c,uid,row):
 slots=[0,0,0]
 if row['category']==1:
  for load in c.execute('SELECT slot,item_id FROM loadouts WHERE uid=? AND character_id=?',(uid,row['resource_id'])):slots[list(SLOTS).index(load['slot'])]=load['item_id']
 count=max((i+1 for i,v in enumerate(slots) if v),default=0)
 return dict(Id=row['item_id'],Category=row['category'],Index=row['resource_id'],Bag=row['bag'],Pos=row['pos'],Stack=1,
             Exp=0,WeaponCount=count,WeaponSlot=slots[:count],DecorateCount=0,DecorateSlot=[],CreateTime=int(row['acquired_at']),DeadTime=0,BeginTime=0,EndTime=0,ExistType=0,Skin=__import__('obt_extensions').skin_for(c,uid,row['category'],row['resource_id'],row['item_id']))

def currency_bag(database,uid):
 import obt_extensions
 return obt_extensions.currency_items(database,uid)

def bag(database,uid,number):
 if type(number)!=int or number not in RESOURCES['bags']:raise ValueError('Invalid bag')
 if number==5:return currency_bag(database,uid)
 if number==3:
  import round_drops,spark_system50
  return round_drops.bag_cards(database,uid)+spark_system50.spark_items(database,uid)
 if number in (10,11):
  import obt_extensions
  return obt_extensions.skin_items(database,uid,number)
 with database.connect() as c:
  rows=list(c.execute('SELECT * FROM inventory WHERE uid=? AND bag=? ORDER BY pos,item_id',(uid,number)))
  if len(rows)>250:raise ValueError('Bag exceeds native capacity')
  return [native_item(c,uid,r) for r in rows]

def lobby_item(database,uid,category):
 with database.connect() as c:
  row=c.execute('SELECT * FROM inventory WHERE uid=? AND category=? ORDER BY pos,item_id LIMIT 1',(uid,category)).fetchone()
  if not row:raise ValueError('No owned item in category')
  return native_item(c,uid,row)

def move(database,uid,item,number,pos):
 if type(pos)!=int or not 0<=pos<250:raise ValueError('Invalid position')
 with database.connect() as c:
  c.execute('BEGIN IMMEDIATE')
  row=c.execute('SELECT * FROM inventory WHERE uid=? AND item_id=?',(uid,item)).fetchone()
  if not row or number!=row['category']:raise ValueError('Item ownership or bag mismatch')
  old=row['pos'];other=c.execute('SELECT item_id FROM inventory WHERE uid=? AND bag=? AND pos=?',(uid,number,pos)).fetchone()
  if old!=pos:
   temp=c.execute('SELECT max(pos)+1 FROM inventory WHERE uid=? AND bag=?',(uid,number)).fetchone()[0]
   c.execute('UPDATE inventory SET pos=? WHERE item_id=?',(temp,item))
   if other:c.execute('UPDATE inventory SET pos=? WHERE item_id=?',(old,other['item_id']))
   c.execute('UPDATE inventory SET pos=? WHERE item_id=?',(pos,item))
  if number==1:
   selected=c.execute('SELECT resource_id FROM inventory WHERE uid=? AND bag=1 AND pos=0',(uid,)).fetchone()
   if selected:c.execute('INSERT INTO selected_characters(uid,resource_id) VALUES(?,?) ON CONFLICT(uid) DO UPDATE SET resource_id=excluded.resource_id',(uid,selected['resource_id']))
  database.audit(c,uid,'garage_move',{'item_id':item,'bag':number,'position':pos})
  changed=[item]+([other['item_id']] if other and other['item_id']!=item else [])
  return [native_item(c,uid,c.execute('SELECT * FROM inventory WHERE uid=? AND item_id=?',(uid,ident)).fetchone()) for ident in changed]

def equip(database,uid,item,holder,slot):
 import obt_extensions
 # Native garage can request the original/default look with EquipItem=0.
 # Do not treat it as a new weapon: validate the owned holder and only clear
 # cosmetic state. This is idempotent for heroes who never bought any skin.
 if item==0:
  if type(holder)!=int or holder<=0:raise ValueError('Missing cosmetic holder')
  with database.connect() as c:
   row=c.execute('SELECT * FROM inventory WHERE uid=? AND item_id=?',(uid,holder)).fetchone()
   if row is None:
    # Only fall back to resource index when the exact 64-bit item ID is absent.
    # Starter item_id=1 can collide with a different character resource_id=1.
    matches=list(c.execute('SELECT * FROM inventory WHERE uid=? AND resource_id=?',(uid,holder)))
    if len(matches)!=1:raise ValueError('Unowned or ambiguous cosmetic holder')
    row=matches[0]
   real_id=row['item_id']
   c.execute('DELETE FROM obt_skin_equipment WHERE uid=? AND holder_item=?',(uid,real_id))
   database.audit(c,uid,'skin_reset_default',dict(holder_item=real_id))
  return real_id
 holder_id=obt_extensions.equip_skin(database,uid,item,holder,slot)
 if holder_id is not None:return holder_id
 if type(slot)!=int or not 0<=slot<=2:raise ValueError('Invalid weapon slot')
 with database.connect() as c:
  row=c.execute('SELECT resource_id FROM inventory WHERE uid=? AND item_id=? AND category=1',(uid,holder)).fetchone()
  if not row:raise ValueError('Holder is not owned character')
 database.equip(uid,row['resource_id'],list(SLOTS)[slot],item)
 return holder

def maps(database):
 with database.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM maps ORDER BY map_id')]

def select_map(database,uid,number):
 if type(number)!=int or number<=0:raise ValueError('Invalid map ID')
 with database.connect() as c:
  if not c.execute('SELECT 1 FROM maps WHERE map_id=? AND available=1',(number,)).fetchone():raise ValueError('Map is absent from archive')
  c.execute('INSERT INTO selected_maps(uid,map_id) VALUES(?,?) ON CONFLICT(uid) DO UPDATE SET map_id=excluded.map_id',(uid,number));database.audit(c,uid,'select_map',{'map_id':number})
