"""Read-only character references and original PAK-index search."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
from client_assets import parse_index

ROOT=Path(__file__).resolve().parent
TERMS=['starscream','star_scream','starscreem','старскрим','红蜘蛛']

def index_matches(path,terms=TERMS):
    with Path(path).open('rb') as f:
        total=f.seek(0,2)
        if total<44:raise ValueError('Truncated PAK')
        f.seek(-44,2);magic,version,offset,size,sha=struct.unpack('<IIqq20s',f.read(44))
        if magic!=0x5a6f12e1 or version!=3 or offset<0 or not 0<size<=128*1024*1024 or offset+size>total-44:
            raise ValueError('Unsupported or invalid PAK index')
        f.seek(offset);index=f.read(size)
    mount,names,adjustment=parse_index(index,sha)
    hits=[n for n in names if any(t.casefold() in n.casefold() for t in terms)]
    return dict(file=str(path),index_sha1=sha.hex(),entries=len(names),count_adjustment=adjustment,mount=mount,hits=hits)

def table_references(terms=TERMS):
    found=[]
    for path in sorted((ROOT/'resources').glob('*.bytes')):
        raw=path.read_bytes();width,count=struct.unpack_from('<II',raw,8)
        for term in terms:
            for encoding in ['utf-8','utf-16le']:
                needle=term.casefold().encode(encoding)
                offset=raw.lower().find(needle)
                if offset<140:continue
                row=(offset-140)//width
                if not 0<=row<count:continue
                ident=struct.unpack_from('<I',raw,140+row*width)[0]
                found.append(dict(file=path.name,term=term,row=row,id=ident,offset=offset,sha256=hashlib.sha256(raw).hexdigest()))
    return found

def inspect(game_dir=None):
    catalog=json.loads((ROOT/'resource_catalog.json').read_text('utf-8'))
    role_hits=[r for r in catalog['roles'] if any(t.casefold() in str(r).casefold() for t in TERMS)]
    records=[];errors=[];paths=[]
    if game_dir:
        directory=Path(game_dir)/'TFOL'/'Content'/'Paks'
        # Accept the launcher Win32 folder or the TFOL project folder as well.
        for candidate in [directory,Path(game_dir).parent.parent/'Content'/'Paks',Path(game_dir)/'Content'/'Paks']:
            if candidate.is_dir():directory=candidate;break
        paths=sorted(directory.glob('*.pak'))
        for path in paths:
            try:records.append(index_matches(path))
            except (OSError,ValueError,UnicodeError,struct.error) as error:errors.append(dict(file=str(path),error=str(error)))
    expected=json.loads((ROOT/'metadata/obt_pak_names.json').read_text())['pak_files']
    missing=sorted(set(n.casefold() for n in expected)-{p.name.casefold() for p in paths})
    return dict(character='Starscream',terms=TERMS,playable_table_roles=len(catalog['roles']),playable_role_matches=role_hits,
                table_references=table_references(),pak_files_checked=len(records),pak_errors=errors,
                original_pak_files_expected=len(expected),pak_files_seen=len(paths),missing_original_paks=missing,
                original_pak_index_set_checked=not missing and not errors,
                pak_matches=[r for r in records if r['hits']],
                conclusion=('Starscream-named assets found in checked PAK indexes. Index names alone do not establish a complete playable character; consult playable_role_matches separately.' if any(r['hits'] for r in records) else 'No Starscream-named assets found in the checked indexes. Consult original_pak_index_set_checked and playable_role_matches; names alone cannot exclude unlabelled resources.'),
                changes_made_to_game_files=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--game-dir',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();value=inspect(args.game_dir)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(report=str(args.output),pak_files_checked=value['pak_files_checked'],matching_paks=len(value['pak_matches']),errors=len(value['pak_errors'])),ensure_ascii=False))
