"""OS-held exclusive ownership of a data folder; stale PID files are harmless."""
import os
from pathlib import Path


class InstanceLock:
    def __init__(self,folder):
        path=Path(folder);path.mkdir(parents=True,exist_ok=True)
        self.stream=(path/'server.lock').open('a+b')
        if not self.stream.tell():
            self.stream.write(b'0');self.stream.flush()
        self.stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.stream.close()
            raise ValueError('Закройте игру и старый локальный сервер перед обновлением. / '
                             'This data folder is already in use by another TFOL server: '+str(path.resolve()))
        self.stream.seek(0);self.stream.truncate();self.stream.write(str(os.getpid()).encode());self.stream.flush()

    def close(self):
        self.stream.close()
