"""Bounded runtime counters shared by transport and WebAdmin."""
from collections import Counter, deque
import threading
import time


class Metrics:
    def __init__(self):
        self.lock = threading.Lock()
        self.started = time.monotonic()
        self.counts = Counter()
        self.latencies = deque(maxlen=4096)

    def record(self, name, amount=1, latency=None):
        with self.lock:
            self.counts[name] += amount
            if latency is not None:
                self.latencies.append(latency * 1000)

    def snapshot(self):
        with self.lock:
            values = sorted(self.latencies)
            return dict(uptime_seconds=round(time.monotonic()-self.started, 2),
                        counters=dict(self.counts), latency_samples=len(values),
                        handler_p50_ms=round(values[len(values)//2], 3) if values else 0,
                        handler_p95_ms=round(values[min(len(values)-1, int(len(values)*.95))], 3) if values else 0)
