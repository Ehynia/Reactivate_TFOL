"""Selected game paths and explicit native launch profiles."""
from pathlib import Path, PureWindowsPath
import subprocess
import os

NATIVE_NAMES={'TFOL_OBT_TEST_19.exe','TFOL_OBT.exe','TFOL_OBT_TEST_22.exe','TFOL_OBT_TEST_23.exe','TFOL_OBT_TEST_24.exe','TFOL_OBT_TEST_27.exe','TFOL_OBT_TEST_33.exe','TFOL_OBT_LOCAL.exe'}
DIAGNOSTIC_ARGS=['-game','-log','-windowed','-ResX=1280','-ResY=720','-d3d11','-nosplash']

def launcher_settings(root):
    """Utilities use the same saved explicit location as the GUI."""
    from game_discovery import selected_game
    settings=Path(root)/'LauncherSettings.ini'
    fallback=Path(os.environ.get('LOCALAPPDATA',str(root)))/'Reactivate/LauncherSettings.ini'
    if fallback.is_file() and (not settings.exists() or fallback.stat().st_mtime>settings.stat().st_mtime):settings=fallback
    values={}
    if settings.is_file():
        for row in settings.read_text('utf-8-sig').splitlines():
            key,separator,value=row.partition('=')
            if separator:values[key.strip().lower()]=value.strip()
    return values

def require_test_node(root):
    if launcher_settings(root).get('region')!='pts':raise ValueError('Выберите Test Node в списке серверов Reactivate перед запуском локального сервера.')

def launcher_executable(root):
    from game_discovery import selected_game
    game=launcher_settings(root).get('gamepath')
    if game:return Path(selected_game(game)['executable'])
    raise ValueError('Откройте Reactivate.exe и выберите игру кнопкой «Играть».')

def command(executable,profile):
    executable=Path(executable)
    if PureWindowsPath(str(executable)).name not in NATIVE_NAMES:raise ValueError('Unsupported native executable name')
    if profile not in {'diagnostic','launcher'}:raise ValueError('Unknown launch profile')
    # Launcher mode MUST NOT override the user's graphics/system settings.
    args=DIAGNOSTIC_ARGS if profile=='diagnostic' else []
    flags=0x14 if profile=='diagnostic' else 0x08000004
    return subprocess.list2cmdline([str(executable),*args]),flags
