"""Explicit local menu simulation; it never advertises an Unreal endpoint."""
import json
import time
import uuid
from world_policy import POLICY

MIGRATION='''
CREATE TABLE local_test_matches(id TEXT PRIMARY KEY,uid INTEGER NOT NULL REFERENCES players(uid),connection_id TEXT NOT NULL,mode_id INTEGER NOT NULL,state TEXT NOT NULL CHECK(state IN ('running','completed','cancelled')),started_at REAL NOT NULL,ends_at REAL NOT NULL,receipt TEXT);
CREATE UNIQUE INDEX local_test_one_active ON local_test_matches(uid) WHERE state='running';
CREATE TABLE first_login_progress(uid INTEGER PRIMARY KEY REFERENCES players(uid),created_at REAL NOT NULL,completed_tests INTEGER NOT NULL DEFAULT 0,quest_claimed INTEGER NOT NULL DEFAULT 0 CHECK(quest_claimed IN (0,1)),revision INTEGER NOT NULL DEFAULT 1);
'''

def ensure(c,uid):
    c.execute('INSERT OR IGNORE INTO first_login_progress(uid,created_at) VALUES(?,?)',(uid,time.time()))

def quest_in(c,uid):
    ensure(c,uid)
    row=c.execute('SELECT * FROM first_login_progress WHERE uid=?',(uid,)).fetchone()
    q=POLICY['first_quest'];progress=min(row['completed_tests'],q['target'])
    return dict(task_id=q['task_id'],group=q['group'],progress=progress,total=q['target'],state=2 if row['quest_claimed'] else 1 if progress==q['target'] else 0,
                revision=row['revision'],source=q['source'])

def quest(database,uid):
    with database.connect() as c:return quest_in(c,uid)

def claim_in(database,c,uid,group):
    from progression import reward_in
    if type(group) is not int or group!=POLICY['first_quest']['group']:raise ValueError('Unknown first quest group')
    state=quest_in(c,uid)
    if state['state']==0:raise ValueError('First quest is not complete')
    if state['state']==2:return dict(applied=False,quest=state)
    policy=POLICY['first_quest']
    receipt=reward_in(database,c,uid,'first-quest-'+str(uid),policy['experience'],'first-quest',silver_coin=policy['silver_coin'])
    c.execute('UPDATE first_login_progress SET quest_claimed=1,revision=revision+1 WHERE uid=?',(uid,))
    return dict(applied=receipt['applied'],quest=quest_in(c,uid),reward=receipt)

def claim(database,uid,group):
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE');return claim_in(database,c,uid,group)

def wire_quest(database,uid):
    from tdr_codec import packet
    q=quest(database,uid)
    return packet(112,'SyncDailyTask',dict(refreshCount=0,group=q['group'],Id=q['task_id'],Progress=q['progress'],State=q['state']))

def wire_profile(database,uid):
    import garage,battle_statistics
    from tdr_codec import packet
    # Skins before their parent character/weapon items, including new unlocks.
    reply=b''.join(packet(38,'SyncBagData',dict(BagIndex=n,Count=len(rows),Items=rows)) for n in (10,11) for rows in [garage.bag(database,uid,n)])
    for number in (2,1,5):
        reply+=b''.join(packet(39,'SyncItemData',dict(Item=item)) for item in garage.bag(database,uid,number))
    return reply+packet(62,'SyncPlayerInfo',dict(PlayerInfo=battle_statistics.player_info(database,uid)))

class Matches:
    def __init__(self,database,enabled=True,clock=time.time,event=None):
        self.database=database;self.enabled=enabled;self.clock=clock;self.event=event or (lambda *a,**k:None)
    def start_in(self,c,uid,connection,mode_id):
        if not self.enabled:raise ValueError('Local test matches are disabled')
        if type(mode_id) is not int or mode_id not in POLICY['simulation']['enabled_modes']+[0,1001]:raise ValueError('Unsupported local test mode')
        ensure(c,uid)
        row=c.execute("SELECT * FROM local_test_matches WHERE uid=? AND state='running'",(uid,)).fetchone()
        if row:return self.public(row)
        now=self.clock();ident=uuid.uuid4().hex
        c.execute('INSERT INTO local_test_matches VALUES(?,?,?,?,?,?,?,?)',(ident,uid,connection,1002 if mode_id in (0,1001) else mode_id,'running',now,now+POLICY['simulation']['duration_seconds'],None))
        return self.public(c.execute('SELECT * FROM local_test_matches WHERE id=?',(ident,)).fetchone())
    def start(self,uid,connection,mode_id):
        with self.database.connect() as c:
            c.execute('BEGIN IMMEDIATE');value=self.start_in(c,uid,connection,mode_id)
        self.event('local_test_match_started',uid=uid,match_id=value['id'],simulation=True)
        return value
    def finish_in(self,c,uid,ident):
        from progression import reward_in
        row=c.execute('SELECT * FROM local_test_matches WHERE id=? AND uid=?',(ident,uid)).fetchone()
        if not row:raise ValueError('Unknown local test match')
        if row['state']=='completed':return self.public(row)
        if row['state']!='running':raise ValueError('Local test match was cancelled')
        if self.clock()<row['ends_at']:raise ValueError('Local test match has not finished')
        policy=POLICY['simulation']
        receipt=reward_in(self.database,c,uid,'test-'+ident,policy['experience'],'local-test-simulation',now=self.clock(),silver_coin=policy['silver_coin'])
        c.execute("UPDATE local_test_matches SET state='completed',receipt=? WHERE id=?",(json.dumps(receipt),ident))
        c.execute('UPDATE first_login_progress SET completed_tests=completed_tests+1,revision=revision+1 WHERE uid=?',(uid,))
        return self.public(c.execute('SELECT * FROM local_test_matches WHERE id=?',(ident,)).fetchone())
    def poll(self,uid):
        with self.database.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT * FROM local_test_matches WHERE uid=? ORDER BY started_at DESC,rowid DESC LIMIT 1',(uid,)).fetchone()
            if not row:return None
            if row['state']=='running' and self.clock()>=row['ends_at']:return self.finish_in(c,uid,row['id'])
            return self.public(row)
    def cancel_in(self,c,uid):
        c.execute("UPDATE local_test_matches SET state='cancelled' WHERE uid=? AND state='running'",(uid,))
        return dict(cancelled=True,uid=uid,simulation=True)
    def cancel(self,uid):
        with self.database.connect() as c:
            c.execute('BEGIN IMMEDIATE');return self.cancel_in(c,uid)
    def public(self,row):
        return dict(id=row['id'],uid=row['uid'],state=row['state'],mode_id=row['mode_id'],started_at=row['started_at'],ends_at=row['ends_at'],
                    simulation=True,engine_connected=False,remaining_seconds=max(0,row['ends_at']-self.clock()),reward=json.loads(row['receipt']) if row['receipt'] else None)
    def wire_updates(self,uid,context):
        from tdr_codec import packet
        current=self.poll(uid)
        if not current or current['state']!='completed' or context.get('test_result_seen')==current['id']:return b''
        context['test_result_seen']=current['id']
        # Close the queue UI rather than send a made-up DS address. No map
        # travel/game-stop packet is fabricated for a world that never existed.
        name=self.database.profile(uid)['nickname']
        reply=packet(73,'CancelRoomMatchRes',dict(Name=name,Result='ok'))
        reply+=wire_profile(self.database,uid)+wire_quest(self.database,uid)
        return reply
    def party(self,uid):
        import garage
        p=self.database.profile(uid);rows=[dict(Name=p['nickname'],Avatar=0,RoleIndex=p['selected_character_id'],TeamId=0,SeatId=0,Level=p['level'],IsRoomMaster=1,PlayerStatus='ready')]
        roles=garage.RESOURCES['roles']
        for i in range(1,POLICY['simulation']['party_size']):
            rows.append(dict(Name='LOCAL_TEST_BOT_'+str(i),Avatar=0,RoleIndex=roles[(i-1)%len(roles)]['resource_id'],TeamId=0,SeatId=i,Level=1,IsRoomMaster=0,PlayerStatus='ready'))
        return rows
    def party_packet(self,uid):
        from tdr_codec import packet
        rows=self.party(uid)
        return packet(18,'GetTeamListDataRes',dict(TeamCount=len(rows),TeamList=rows,BlueTeamCount=len(rows),BlueTeamSeat=list(range(len(rows))),RedTeamCount=0,RedTeamSeat=[],Result='ok'))
