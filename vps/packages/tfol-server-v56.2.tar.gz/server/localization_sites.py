"""Pinned OBT presentation conversions; never replace global FText::ToString.

The text-layout marshaller receives translated text before splitting lines and
creating character ranges. Font measure and whole-string draw overloads use
the same lookup. Blueprint conversions, comparisons, names and serialization
continue to call the original 0xc19120 implementation.
"""
TEXT_TO_STRING = 0xc19120
PRESENTATION_CALLS = {
    0x7f9b40: 'rich text layout source',
    0x7fa34f: 'text layout line rebuild source',
    0x7fa649: 'text layout marshaller full rebuild',
    0x7fa6cf: 'text layout marshaller incremental source',
    0xda474e: 'Slate font measure FText overload',
    0xdb42e1: 'Slate whole-text draw overload',
    0xdb4627: 'Slate whole-text draw length',
}
