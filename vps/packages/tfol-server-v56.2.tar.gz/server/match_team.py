"""Matchmaking party protocol; map-room rosters use different messages."""
from tdr_codec import packet
from bot_modes import MODES
def snapshot(db,uid,context):
    p=db.profile(uid)
    rows=[dict(Name=p['nickname'],Avatar=0,Level=p['level'],QualifyInfo={})] if context.get('party_created') else []
    return packet(134,'SyncMatchTeam',dict(Count=len(rows),MatchingPlayerInfo=rows))
def create(db,uid,context):
    context['party_created']=True;context.setdefault('party_mode',1010)
    return packet(84,'CreateMatchTeamRes',dict(Result='ok'))+snapshot(db,uid,context)
def select(db,uid,context,mode):
    if mode==3001 or mode not in MODES:return packet(133,'MatchTeamSelectModeRes',dict(ModeId=mode,Result='server_unavailable'))
    context['party_mode']=mode
    return packet(133,'MatchTeamSelectModeRes',dict(ModeId=mode,Result='ok'))+snapshot(db,uid,context)
def leave(db,uid,context):
    import native_bots
    native_bots.cancel(context)
    if context.get('matchmaking'):context['matchmaking'].cancel(uid,context['connection_id'])
    context.pop('party_created',None);context.pop('party_mode',None)
    return packet(88,'LeaveMatchTeamRes',dict(Reason='',Result='ok'))+snapshot(db,uid,context)
