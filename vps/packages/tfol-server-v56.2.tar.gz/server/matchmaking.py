"""Authenticated matchmaking and listen-host coordination. No imaginary players."""
import math,struct,threading,time,itertools
from dataclasses import dataclass
import peer_rooms

IDLE,WAITING,BOTS,HUMANS,WAITING_FOR_WORKER=0,1,2,3,4
POLL_HEADER=struct.Struct('<4sBBHIQ')
@dataclass
class Entry:
    uid:int
    connection:str
    match_id:int
    competition:int
    started:float
    deadline:float
    peer:bool=False

class Queue:
    def __init__(self,clock=time.monotonic,wait_seconds=20,event=None,peer_enabled=False,solo_grace_seconds=2):
        self.clock=clock;self.wait_seconds=wait_seconds;self.solo_grace_seconds=solo_grace_seconds;self.event=event or (lambda *a,**kw:None)
        self.lock=threading.RLock();self.entries={};self.ready={};self.workers={};self.claimed_rooms=set();self.ids=itertools.count(1)
        self.peer_enabled=peer_enabled;self.peers=peer_rooms.Rooms(lambda:self.clock(),self.event)
    def join(self,uid,connection,match_id,competition,peer=False):
        now=self.clock()
        with self.lock:
            if (uid,connection) in self.peers.members:return 0
            for old_uid,old_connection in list(self.peers.members):
                if old_uid==uid:self.peers.cancel(uid,old_connection)
            self.peers.failures.pop((uid,connection),None)
            old=self.entries.get(uid)
            if old and old.connection==connection and (old.match_id,old.competition)==(match_id,competition):return max(0,math.ceil(old.deadline-now))
            ready=self.ready.get(uid)
            if ready and ready[0]==connection:return 0
            self.ready.pop(uid,None)
            peer_ready=bool(peer and self.peer_enabled)
            wait=min(self.wait_seconds,self.solo_grace_seconds) if peer_ready else self.wait_seconds
            self.entries[uid]=Entry(uid,connection,match_id,competition,now,now+wait,peer_ready)
            self.event('matchmaking_queued',uid=uid,wait_seconds=wait,mode=match_id,peer=peer_ready)
            return wait
    def cancel(self,uid,connection):
        with self.lock:
            self.peers.cancel(uid,connection)
            old=self.entries.get(uid)
            if old and old.connection==connection:
                del self.entries[uid];self.event('matchmaking_cancelled',uid=uid)
            ready=self.ready.get(uid)
            if ready and ready[0]==connection:self.ready.pop(uid,None)
    def register_worker(self,worker_id,room,match_id=0,competition=0):
        # Only the authenticated internal HTTP service calls this. This is an
        # already-running engine room, never an invented TCP endpoint.
        if not isinstance(worker_id,str) or not 1<=len(worker_id)<=64:raise ValueError('Invalid worker ID')
        if type(match_id)!=int or not 0<=match_id<=0xffffffff or type(competition)!=int or not 0<=competition<=65535:raise ValueError('Invalid matchmaking mode')
        if not isinstance(room,dict) or not isinstance(room.get('DsDomain'),str) or not room['DsDomain'].strip():raise ValueError('A running game endpoint is required')
        if type(room.get('MapID'))!=int or room['MapID'] not in {m['map_id'] for m in __import__('garage').RESOURCES['maps']}:raise ValueError('Unsupported TDM map')
        if type(room.get('RoomId'))!=int or room['RoomId']<=0 or type(room.get('RoomSeq'))!=int or room['RoomSeq']<=0:raise ValueError('Invalid engine room')
        if type(room.get('MaxPlayerCount'))!=int or not 2<=room['MaxPlayerCount']<=12:raise ValueError('Invalid room capacity')
        from game_protocol import CODEC
        try:CODEC.encode('RoomInfo',room)
        except (struct.error,TypeError) as e:raise ValueError('Invalid room metadata') from e
        with self.lock:
            identity=(room['DsDomain'],room['RoomId'],room['RoomSeq'])
            if identity in self.claimed_rooms:raise ValueError('Room already assigned; register a fresh room sequence')
            self.workers[worker_id]=(self.clock()+30,dict(room),match_id,competition)
    def _allocate(self):
        now=self.clock()
        for worker_id,(expires,room,match_id,competition) in list(self.workers.items()):
            if expires<=now:self.workers.pop(worker_id,None);continue
            waiting=sorted((e for e in self.entries.values() if (e.match_id,e.competition)==(match_id,competition)),key=lambda e:e.started)
            if not waiting:continue
            identity=(room['DsDomain'],room['RoomId'],room['RoomSeq'])
            if identity in self.claimed_rooms:self.workers.pop(worker_id,None);continue
            players=waiting[:room['MaxPlayerCount']];self.workers.pop(worker_id,None);self.claimed_rooms.add(identity)
            assigned=next(self.ids)
            for e in players:
                self.entries.pop(e.uid,None);self.ready[e.uid]=(e.connection,HUMANS,assigned,dict(room),[x.uid for x in players])
            self.event('matchmaking_human_room_assigned',room_id=room['RoomId'],players=[e.uid for e in players])
    def poll(self,uid,connection):
        with self.lock:
            self._allocate()
            for assigned in self.peers.allocate(list(self.entries.values())):self.entries.pop(assigned,None)
            decision=self.peers.poll(uid,connection)
            if decision is not None:return decision
            ready=self.ready.get(uid)
            if ready and ready[0]==connection:
                self.ready.pop(uid,None);return dict(state=ready[1],remaining_ms=0,session_id=ready[2],room=ready[3],players=ready[4])
            entry=self.entries.get(uid)
            if not entry or entry.connection!=connection:return dict(state=IDLE,remaining_ms=0,session_id=0)
            compatible=[e for e in self.entries.values() if e.uid!=uid and (e.match_id,e.competition)==(entry.match_id,entry.competition)]
            remaining=max(0,math.ceil((entry.deadline-self.clock())*1000))
            if not remaining:
                if self.peers.solo(entry):
                    self.entries.pop(uid,None);return self.peers.poll(uid,connection)
                self.entries.pop(uid,None);session=next(self.ids)
                # Do not mislabel unavailable UE listen-host/worker as bots.
                self.event('matchmaking_no_game_host',uid=uid,session_id=session,
                           reason='no_ready_worker' if compatible else 'solo',gameplay_verified=False)
                return dict(state=peer_rooms.PEER_FAILED,remaining_ms=0,session_id=session,reason='no_game_host')
            return dict(state=WAITING_FOR_WORKER if compatible else WAITING,remaining_ms=remaining,session_id=0)

def poll_response(database,decision,uid=None):
    header=POLL_HEADER.pack(b'R29Q',1,decision['state'],0,decision['remaining_ms'],decision['session_id'])
    from game_protocol import packet
    state=decision['state']
    if state==peer_rooms.PEER_FAILED:
        return header+packet(81,'StartGameCancelRes',dict(Name=database.profile(uid)['nickname'],Result='ok'))
    if state==peer_rooms.PEER_WAIT and decision.get('sync_roster'):
        return header+team_packet(database,decision)
    if state in (peer_rooms.HOST_START,peer_rooms.GUEST_START):header+=peer_rooms.config(database,decision,uid)
    elif state!=HUMANS:return header
    # Native matching roster and room metadata supplied by the game worker.
    roster=peer_rooms.roster(database,decision)
    room=dict(decision['room'],PlayerCount=len(roster))
    return header+packet(82,'SyncMatchResult',dict(RoomInfo=room,Result='ok',TeamCount=len(roster),TeamList=roster))

def team_packet(database,decision):
    from game_protocol import packet
    rows=peer_rooms.roster(database,decision)
    blue=[r['SeatId'] for r in rows if r['TeamId']==0];red=[r['SeatId'] for r in rows if r['TeamId']==1]
    return packet(18,'GetTeamListDataRes',dict(TeamCount=len(rows),TeamList=rows,BlueTeamCount=len(blue),BlueTeamSeat=blue,RedTeamCount=len(red),RedTeamSeat=red,Result='ok'))
