"""Local bot practice: wait, original room/hero UI, explicit ready, countdown timer, engine travel.

This is not shared multiplayer. No fictitious player accounts or DS endpoint.
"""
import struct,time
from tdr_codec import HEAD,packet
from bot_modes import MODES,resolve
WAIT_SECONDS=20
SELECTION_TIMEOUT_SECONDS=120
READY_COUNTDOWN_SECONDS=5
# Original hero-selection widget starts a 30-second counter. Readiness never skips it.
HERO_SELECTION_SECONDS=30
DISPATCH_TIMEOUT_SECONDS=20
COMMAND=65530

def clock():
    """Monotonic production clock; test fixtures can substitute virtual time."""
    return time.monotonic()

def selected(database,uid):
    profile=database.profile(uid);hero=profile['selected_character_id']
    with database.connect() as c:
        if not c.execute('SELECT 1 FROM characters WHERE uid=? AND resource_id=?',(uid,hero)).fetchone():raise ValueError('Character is not owned')
    return hero

def start(database,uid,context,mode,now=None):
    if mode not in MODES:raise ValueError('Native bot mode is not implemented')
    if mode==3001:raise ValueError('PVE temporarily disabled in v56')
    if not context.get('native_bots'):raise ValueError('OB27 bridge required')
    old=context.get('engine_match')
    if old and old['state'] in ('waiting','confirming','selecting','ready','travel_requested'):return old
    now=clock() if now is None else now
    context.pop('completion_pending',None);context.pop('completion_event',None)
    context.pop('postmatch_result_escrow53',None)
    context['engine_sequence']=context.get('engine_sequence',0)+1
    route=resolve(mode,context['engine_sequence'])
    context['engine_match']=dict(state='waiting',deadline=now+WAIT_SECONDS,sequence=context['engine_sequence'],
        hero=selected(database,uid),match_confirmed=False,selection_seen=False,explicit_ready=False,
        ready_deadline=0,last_poll_now=now,**route)
    return context['engine_match']

def cancel(context):context.pop('engine_match',None)

def roster(database,uid,context):
    import peer_rooms,obt_extensions
    rows=peer_rooms.roster(database,dict(players=[uid],host_uid=uid,roles={uid:selected(database,uid)}))
    rows[0].update(obt_extensions.ready_info(database,uid,rows[0]['RoleIndex']))
    rows[0]['PlayerStatus']='ready' if context['engine_match'].get('explicit_ready') else 'not_ready'
    return rows

def teams(database,uid,context):
    rows=roster(database,uid,context)
    return packet(18,'GetTeamListDataRes',dict(TeamCount=1,TeamList=rows,BlueTeamCount=1,BlueTeamSeat=[0],RedTeamCount=0,RedTeamSeat=[],Result='ok'))

def found(database,uid,context):
    match=context['engine_match'];rows=roster(database,uid,context)
    room=dict(RoomId=match['sequence'],RoomSeq=match['sequence'],RoomName='Test Node - Bot Practice',
        AccName=database.profile(uid)['nickname'],MapID=match['map'],FriendlyFire=0,AllowTransform=1,
        MaxPlayerCount=match['players'],PlayerCount=1,Status='waiting',DsDomain='')
    # PVEDEFEND must not have generic PvP AI opponents in its 5 ally seats.
    # Its enemy Insecticons are governed by the UE mission, not BotFill.
    # Original 0x7c9a00 copies RoomInfo and invokes NotifyMatchingSuccess.
    # Empty DS domain is intentional: local travel happens only after Ready and countdown.
    return packet(82,'SyncMatchResult',dict(RoomInfo=room,Result='ok',TeamCount=1,TeamList=rows))+teams(database,uid,context)

def room_reply(database,uid,context,command,values,now=None):
    match=context['engine_match']
    if match['state'] not in ('confirming','selecting','ready','travel_requested','travel_dispatched'):return None
    name=database.profile(uid)['nickname']
    if command==230:
        ack=packet(231,'MatchConfirmRes',dict(Name=name,Result='ok'))
        if values.get('Confirm') not in (0,1):raise ValueError('Invalid matching confirmation')
        if not values['Confirm']:
            cancel(context)
            return ack+packet(233,'SyncMatchConfirmFailed',dict(Match=0))
        if match.get('match_confirmed'):return ack
        if match['state']!='confirming':return packet(231,'MatchConfirmRes',dict(Name=name,Result='server_unavailable'))
        match.update(match_confirmed=True,state='selecting',selection_end=(clock() if now is None else now)+context.get('hero_selection_seconds',HERO_SELECTION_SECONDS))
        # Pinned native registration: 231 -> 0x7c7380; 232 -> 0x7c9970.
        # 232 calls original DoEnterMatchingRoom, which opens the hero room.
        return ack+packet(232,'SyncMatchConfirmSuccess',dict(Pad=0))+teams(database,uid,context)
    if command==13:
        if match['state'] not in ('selecting','ready'):
            return packet(14,'SetRoleDataRes',dict(Name=name,RoleId=values['RoleId'],Result='server_unavailable'))
        try:
            database.select_character(uid,values['RoleId']);result='ok'
            match.update(hero=selected(database,uid),selection_seen=True,explicit_ready=False,ready_deadline=0,state='selecting')
        except ValueError:result='not_owned'
        return packet(14,'SetRoleDataRes',dict(Name=name,RoleId=values['RoleId'],Result=result))+teams(database,uid,context)
    if command==17:return teams(database,uid,context)
    if command==33:return packet(34,'GetRoleListDataRes',dict(TeamListCount=1,TeamList=roster(database,uid,context),Result='ok'))
    if command==70:
        # Matching-success confirmation is NOT hero-ready. Do not travel here.
        return packet(71,'StartGameReadyRes',dict(Name=name,Result='ok'))
    if command in (19,21):
        if not match.get('match_confirmed'):
            return packet(20,'StartGameDataRes',dict(Result='server_unavailable')) if command==19 else packet(22,'GameReadyDataRes',dict(Name=name,Result='server_unavailable'))
        if match['state']=='selecting':
            countdown=context.get('ready_countdown_seconds',READY_COUNTDOWN_SECONDS)
            base_now=clock() if now is None else now
            match.update(hero=selected(database,uid),explicit_ready=True,state='ready',ready_deadline=max(base_now+countdown,match.get('selection_end',base_now+countdown)))
        if command==19:return packet(20,'StartGameDataRes',dict(Result='ok'))
        import obt_extensions
        return packet(22,'GameReadyDataRes',dict(Name=name,Result='ok',**obt_extensions.ready_info(database,uid,match['hero'])))
    if command==23:
        # A client request cannot shorten the server's countdown.
        if not match.get('explicit_ready'):return packet(24,'LoadMapDataRes',dict(Result='server_unavailable'))
        return b''
    return None

def poll(database,uid,context,now=None):
    match=context.get('engine_match');now=clock() if now is None else now
    import tutorial_mission36
    special=tutorial_mission36.poll(database,uid,context,now)
    if special:return special
    match=context.get('engine_match')
    if not match:return b''
    match['last_poll_now']=now
    if match['state']=='waiting':
        if now<match['deadline']:return b''
        match.update(state='confirming',selection_deadline=now+SELECTION_TIMEOUT_SECONDS)
        return found(database,uid,context)
    if match['state']=='selecting' and now>=match.get('selection_end',float('inf')):
        # The native hero picker runs a 30s countdown. Previously, a player who
        # never pressed Ready remained in `selecting` until the 120s timeout;
        # UE4 displayed -1, -2, ... instead of starting the match. At zero,
        # auto-confirm ONLY an already owned selected hero. Preserve the same
        # loadout / mode, and notify the native picker before engine travel.
        try:
            hero=selected(database,uid)
        except ValueError:
            match.update(state='failed',failure='no_owned_hero_for_auto_ready')
            return packet(81,'StartGameCancelRes',dict(Name=database.profile(uid)['nickname'],Result='ok'))
        match.update(state='ready',hero=hero,explicit_ready=True,auto_ready=True,
                     ready_deadline=now+0.25,selection_seen=True)
        import obt_extensions
        name=database.profile(uid)['nickname']
        return (packet(22,'GameReadyDataRes',dict(Name=name,Result='ok',
                **obt_extensions.ready_info(database,uid,hero)))+
                teams(database,uid,context))
    if match['state'] in ('confirming','selecting'):
        if now>=match['selection_deadline']:
            match.update(state='failed',failure='hero_selection_timeout')
            return packet(81,'StartGameCancelRes',dict(Name=database.profile(uid)['nickname'],Result='ok'))
        return b''
    if match['state']=='travel_requested' and now>=match['dispatch_deadline']:
        match.update(state='failed',failure='engine_dispatch_timeout')
        return packet(81,'StartGameCancelRes',dict(Name=database.profile(uid)['nickname'],Result='ok'))
    if match['state']!='ready' or not match.get('explicit_ready'):return b''
    if now<match.get('ready_deadline',0):return b''
    hero=selected(database,uid)
    body=struct.pack('<4s6I',b'OB27',match['sequence'],match['action'],match['map'],hero,match['bots'],match['mode'])
    match.update(state='travel_requested',dispatch_deadline=now+DISPATCH_TIMEOUT_SECONDS,hero=hero)
    return HEAD.pack(1,COMMAND,12,len(body))+body

def status(context,body):
    if len(body)!=12 or body[:4]!=b'OB27' or not context.get('native_bots'):raise ValueError('Invalid engine status')
    sequence,state=struct.unpack_from('<II',body,4);match=context.get('engine_match')
    if not match or sequence!=match['sequence'] or state not in (0,1) or match['state']!='travel_requested':raise ValueError('Unexpected engine status')
    match['state']='travel_dispatched' if state else 'failed'
    # Round ID is independent of the connection-local engine sequence.
    if state:match.setdefault('round_id',__import__('uuid').uuid4().hex)
    return dict(sequence=sequence,travel_dispatched=bool(state),battle_verified=False)
