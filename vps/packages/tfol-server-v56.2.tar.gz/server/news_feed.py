"""Bounded Reddit RSS cache + local server announcements and Home Page builder."""
import argparse,concurrent.futures,datetime,hashlib,json,threading,time,urllib.request,os,tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlsplit

SOURCES=('transformers','TransformersReactivate')
INTERVAL=900
MAX_BYTES=1024*1024
ATOM='{http://www.w3.org/2005/Atom}'

def reddit_url(value):
    if not isinstance(value,str):raise ValueError('Missing Reddit URL')
    p=urlsplit(value)
    if p.scheme!='https' or p.hostname not in {'www.reddit.com','reddit.com','old.reddit.com'} or p.username or p.password or p.port:raise ValueError('Invalid Reddit URL')
    if not p.path.startswith('/r/') or '/comments/' not in p.path:raise ValueError('Expected a Reddit post')
    return 'https://www.reddit.com'+p.path.rstrip('/')+'/'

def parse_rss(raw,community):
    if community not in SOURCES or len(raw)>MAX_BYTES:raise ValueError('Invalid feed')
    root=ET.fromstring(raw);rows=[]
    for item in root.findall(ATOM+'entry')[:25]:
        title=' '.join((item.findtext(ATOM+'title') or '').split())[:300]
        link=next((n.attrib.get('href') for n in item.findall(ATOM+'link') if n.attrib.get('rel','alternate')=='alternate'),None)
        if not title:continue
        try:
            url=reddit_url(link)
            published=datetime.datetime.fromisoformat((item.findtext(ATOM+'published') or item.findtext(ATOM+'updated') or '').replace('Z','+00:00')).timestamp()
            if not urlsplit(url).path.lower().startswith('/r/'+community.lower()+'/'):continue
            if not 0<published<time.time()+86400:continue
        except (ValueError,TypeError):continue
        rows.append(dict(id='reddit-'+hashlib.sha256(url.encode()).hexdigest()[:20],title=title,url=url,
                         subreddit=community,published_at=int(published),source='Reddit'))
    return rows

def fetch(community):
    request=urllib.request.Request('https://www.reddit.com/r/'+community+'/new/.rss',headers={'User-Agent':'TFOL-Local/0.21 (public community news RSS)','Accept':'application/atom+xml'})
    with urllib.request.urlopen(request,timeout=6) as response:
        raw=response.read(MAX_BYTES+1)
    return parse_rss(raw,community)

def load(path):
    try:
        path=Path(path)
        if path.stat().st_size>MAX_BYTES:raise ValueError('Oversized cache')
        value=json.loads(path.read_text('utf-8'))
        if not isinstance(value,dict) or not isinstance(value.get('items'),list):raise ValueError('Invalid cache')
        rows=[]
        for row in value['items'][:40]:
            row=dict(row);row['url']=reddit_url(row['url'])
            if row.get('subreddit') not in SOURCES or not isinstance(row.get('title'),str) or not row['title'] or len(row['title'])>300:continue
            if not urlsplit(row['url']).path.lower().startswith('/r/'+row['subreddit'].lower()+'/'):continue
            if type(row.get('published_at')) is not int or not 0<row['published_at']<time.time()+86400:continue
            row['id']='reddit-'+hashlib.sha256(row['url'].encode()).hexdigest()[:20]
            rows.append(row)
        for key in ('checked_at','last_success'):
            if type(value.get(key)) not in (int,float) or not 0<=value[key]<=time.time()+86400:raise ValueError('Invalid cache time')
        value['items']=rows;return value
    except (OSError,ValueError,KeyError,TypeError):return dict(items=[],last_success=0,checked_at=0,errors=[])

def refresh(path,force=False,fetcher=fetch,now=None):
    path=Path(path);now=time.time() if now is None else now;old=load(path)
    if not force and now-old.get('checked_at',0)<INTERVAL:return old
    rows=[];errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        tasks={name:pool.submit(fetcher,name) for name in SOURCES}
        for name,task in tasks.items():
            try:rows.extend(task.result())
            except Exception as e:errors.append(dict(source=name,error=type(e).__name__))
    failed={e['source'] for e in errors}
    rows.extend(r for r in old['items'] if r.get('subreddit') in failed)
    unique={r['url']:r for r in rows}
    value=dict(items=sorted(unique.values(),key=lambda r:r['published_at'],reverse=True)[:40],
               checked_at=now,last_success=now if len(failed)<len(SOURCES) else old.get('last_success',0),errors=errors)
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False)
        os.replace(temp,path)
    finally:Path(temp).unlink(missing_ok=True)
    return value

class Service:
    def __init__(self,folder,database,enabled=True):
        self.path=Path(folder)/'reddit_news_cache.json'
        self.database=database;self.enabled=enabled
        self.stop_event=threading.Event();self.thread=None
    def start(self):
        if not self.enabled or self.thread:return self
        self.thread=threading.Thread(target=self._loop,name='obt-news-rss',daemon=True)
        self.thread.start();return self
    def _loop(self):
        while not self.stop_event.is_set():
            try:
                value=refresh(self.path,fetcher=fetch)
                if self.stop_event.is_set():return
                if value['items'] or not value['errors']:
                    with self.database.connect() as c:
                        c.execute("UPDATE news SET visible=0 WHERE slug LIKE 'reddit-%'")
                        for row in value['items']:
                            c.execute('INSERT INTO news(slug,title,body,published_at,visible) VALUES(?,?,?,?,1) ON CONFLICT(slug) DO UPDATE SET title=excluded.title,body=excluded.body,published_at=excluded.published_at,visible=1',
                                      (row['id'],row['title'],json.dumps(row,ensure_ascii=False),row['published_at']))
            except Exception:pass
            self.stop_event.wait(INTERVAL)
    def close(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=15)
            if self.thread.is_alive():raise RuntimeError('News service did not stop')

def utf8_chars(text,capacity):
    raw=text.encode('utf-8')[:capacity-1]
    while True:
        try:raw.decode('utf-8');break
        except UnicodeError:raw=raw[:-1]
    return [v if v<128 else v-256 for v in raw+b'\0']

def featured_heroes():
    import garage
    from world_policy import POLICY
    roles=[r['resource_id'] for r in garage.RESOURCES['roles']]
    preferred=[r for r in POLICY.get('featured_heroes',[11,2,8,9,6]) if r in roles]
    for r in roles:
        if len(preferred)>=5:break
        if r not in preferred:preferred.append(r)
    return [dict(Category=1,Index=ident,Count=1,Id=0) for ident in preferred[:5]]

# A directory landing page is safe for an offline fallback, but not a fabricated
# Reddit post. Only the JSON metadata for actually indexed Reddit RSS entries may
# become a news article inside the game. Never emit the old local-server URL.
COMMUNITY_URL='https://www.reddit.com/r/transformers/'

def _reddit_entries(database):
    entries=[];seen=set()
    for row in database.news()[:80]:
        if not str(row.get('slug','')).startswith('reddit-'):
            continue
        try:
            value=json.loads(row['body'])
            url=reddit_url(value['url'])
            sub=value['subreddit']
            if sub not in SOURCES or not urlsplit(url).path.lower().startswith('/r/'+sub.lower()+'/'):
                continue
            title=' '.join(value['title'].split())[:240]
            published=int(value['published_at'])
            if not title or not 0<published<time.time()+86400 or url in seen:
                continue
            seen.add(url)
            entries.append(dict(slug=row['slug'],title=title,url=url,subreddit=sub,published_at=published))
        except (ValueError,KeyError,TypeError,AttributeError):
            continue
    return sorted(entries,key=lambda entry:entry['published_at'],reverse=True)[:20]

def _news_items(database):
    entries=_reddit_entries(database)
    if entries:return entries
    # Offline means 'open community', NOT fake post IDs or invented headlines.
    return [dict(slug='community-directory',title='Transformers community',
                 url=COMMUNITY_URL,subreddit='transformers',published_at=1700000000)]

def update_notice(database):
    from tdr_codec import packet
    entries=_news_items(database)
    title=utf8_chars('REDDIT / r/transformers',128)
    lines=['Transformers Reddit community: '+COMMUNITY_URL]
    for row in entries[:5]:
        lines.append(row['title']+' — '+row['url'])
    info=utf8_chars('\n'.join(lines),5939)
    return packet(282,'QueryVerUpdateInfoRes',dict(TitleLen=len(title),Title=title,
                                                  InfoLen=len(info),Info=info,Status=0))

def native(database):
    from tdr_codec import packet
    entries=_news_items(database)
    posts=[];notices=[]
    def add(row,tab):
        ident=int(hashlib.sha256((row['slug']+':'+str(tab)).encode()).hexdigest()[:8],16)
        text='r/'+row['subreddit']+': '+row['title']
        title=utf8_chars(text,100);jump=utf8_chars(row['url'],512)
        posts.append(dict(Id=ident,Tab=tab,TitleLen=len(title),Title=title,
                          SortId=len(posts),JumpType=1,JumpUrlLen=len(jump),JumpUrl=jump,
                          Top=1 if tab==1 and len(posts)==0 else 0,
                          UpdateTime=row['published_at']))
    # Original Home Page tabs are numbered 1..4 (0 is not a visible tab).
    for row in entries[:12]:add(row,1)
    for tab in (2,3,4):
        add(entries[(tab-2)%len(entries)],tab)
    for row in entries[:5]:
        content='Reddit / r/'+row['subreddit']+'\n'+row['title']+'\n'+row['url']
        content_bytes=content.encode('utf-8')
        if len(content_bytes)>=1048:
            content=content_bytes[:1030].decode('utf-8','ignore')
        ident=int(hashlib.sha256(row['slug'].encode()).hexdigest()[:8],16)
        notices.append(dict(Id=ident,BeginTime=0,EndTime=2147483647,
                            Priority=1,Cycle=1,Speed=50,Count=1,Interval=60,Content=content))
    import garage
    owned=set(garage.RESOURCES['starter_roles'])
    heroes=[dict(Category=1,Index=ident,Count=1,Id=0)
            for ident in garage.RESOURCES['starter_roles'][:5] if ident in owned]
    return (packet(186,'NoticeBoardList',dict(Count=len(notices),NoticeBoards=notices))+
            packet(188,'SyncHomePageInfo',dict(AWordNewsListLen=len(posts),WordNewsList=posts,
                                               LimitJijiaListLen=len(heroes),LimitJijiaList=heroes)))

def updates(database,context):
    if not context.get('logged_in'):return b''
    now=time.monotonic()
    if now<context.get('news_check_at',0):return b''
    context['news_check_at']=now+30
    value=native(database)
    if value==context.get('news_snapshot'):return b''
    context['news_snapshot']=value
    return value

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--cache',type=Path,required=True);parser.add_argument('--refresh',action='store_true');args=parser.parse_args()
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    try:value=refresh(args.cache,force=args.refresh)
    except Exception:value=load(args.cache)
    print(json.dumps(value,ensure_ascii=False))
