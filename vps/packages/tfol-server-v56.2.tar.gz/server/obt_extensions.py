"""OBT persistence extensions; old inventory transactions remain intact."""
import json,time
import garage

MIGRATION='''
CREATE TABLE obt_settings(uid INTEGER NOT NULL REFERENCES players(uid),name TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(uid,name));
CREATE TABLE obt_skins(item_id INTEGER PRIMARY KEY,uid INTEGER NOT NULL REFERENCES players(uid),category INTEGER NOT NULL CHECK(category IN(10,11)),resource_id INTEGER NOT NULL,base_id INTEGER NOT NULL,UNIQUE(uid,category,resource_id));
CREATE TABLE obt_currency(uid INTEGER NOT NULL REFERENCES players(uid),currency INTEGER NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 0 AND 2000000000),PRIMARY KEY(uid,currency));
CREATE TABLE obt_grants(uid INTEGER NOT NULL REFERENCES players(uid),version INTEGER NOT NULL,PRIMARY KEY(uid,version));
CREATE TABLE obt_signs(uid INTEGER NOT NULL REFERENCES players(uid),day TEXT NOT NULL,PRIMARY KEY(uid,day));
CREATE TABLE obt_skin_equipment(uid INTEGER NOT NULL REFERENCES players(uid),holder_item INTEGER NOT NULL REFERENCES inventory(item_id),skin_item INTEGER NOT NULL REFERENCES obt_skins(item_id),PRIMARY KEY(uid,holder_item));
'''

def setting(database,uid,name,default):
    with database.connect() as c:
        row=c.execute('SELECT value FROM obt_settings WHERE uid=? AND name=?',(uid,name)).fetchone()
    return json.loads(row[0]) if row else default

def save(database,uid,name,value):
    with database.connect() as c:
        c.execute('INSERT INTO obt_settings VALUES(?,?,?) ON CONFLICT(uid,name) DO UPDATE SET value=excluded.value',(uid,name,json.dumps(value)))
        database.audit(c,uid,'obt_setting_saved',dict(name=name))

def provision(database,uid):
    resources=garage.RESOURCES
    from world_policy import POLICY
    by_id={(r['category'],r['resource_id']):r for r in resources['skins']}
    roles={r['resource_id']:r for r in resources['roles']}
    weapons={r['resource_id']:r for r in resources['weapons']}
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        # The original price table contains two free scheme slots (IDs 1,2).
        # Empty equipped grids are valid; an empty scheme list breaks the UI.
        from pathlib import Path
        import struct
        raw=(Path(__file__).parent/'resources/SparkSchemePriceTable.bytes').read_bytes()
        width,count=struct.unpack_from('<II',raw,8)
        if width!=12:raise ValueError('Unexpected OBT spark price layout')
        defaults=[struct.unpack_from('<III',raw,140+width*i) for i in range(count)]
        free=[ident for ident,currency,price in defaults if price==0]
        row=c.execute("SELECT value FROM obt_settings WHERE uid=? AND name='spark_configs'",(uid,)).fetchone()
        configs=json.loads(row[0]) if row else {}
        for ident in free:configs.setdefault(str(ident),dict(name='Scheme '+str(ident),grids=[]))
        for config in configs.values():
            if 'grid' in config:
                old=config.pop('grid');config.setdefault('grids',[old] if old.get('GridId') else [])
        c.execute("INSERT INTO obt_settings VALUES(?,'spark_configs',?) ON CONFLICT(uid,name) DO UPDATE SET value=excluded.value",(uid,json.dumps(configs)))
        for item in c.execute('SELECT DISTINCT category,resource_id FROM inventory WHERE uid=? ORDER BY category,resource_id',(uid,)).fetchall():
            category=10 if item['category']==1 else 11
            descriptor=(roles if category==10 else weapons).get(item['resource_id'])
            if not descriptor:raise ValueError('Inventory resource is not in the OBT catalog')
            ident=descriptor['skin'];skin=by_id[category,ident]
            item_id=(1<<62)+(uid<<32)+(category<<28)+ident
            if not 0<uid<(1<<28) or not 0<ident<(1<<28):raise ValueError('Skin identifier range')
            c.execute('INSERT OR IGNORE INTO obt_skins VALUES(?,?,?,?,?)',(item_id,uid,category,ident,skin['base_id']))
        if not c.execute('SELECT 1 FROM obt_grants WHERE uid=? AND version=1',(uid,)).fetchone():
            for currency,amount in POLICY['initial_balances'].items():
                currency=int(currency)
                if currency in (1,2,5):c.execute('INSERT OR IGNORE INTO wallet(uid,currency,amount) VALUES(?,?,?)',(uid,currency,amount))
                elif currency==3:c.execute('UPDATE players SET credits=min(credits+?,2000000000) WHERE uid=?',(amount,uid))
                elif currency>=6:c.execute('INSERT INTO obt_currency VALUES(?,?,?) ON CONFLICT(uid,currency) DO UPDATE SET amount=min(amount+excluded.amount,2000000000)',(uid,currency,amount))
                else:raise ValueError('Unexpected initial currency table entry')
            c.execute('INSERT INTO obt_grants VALUES(?,1)',(uid,))
            database.audit(c,uid,'initial_balances',POLICY['initial_balances'])
    # Starter Sparks belong to original ItemSparkTable, in a separate bag
    # ledger so currency/cards and owned characters are not rewritten.
    import spark_system50
    spark_system50.ensure_starters(database,uid)

def spark_login(database,uid):
    # Native UMG locks the Spark grid when LoginDataRes reports zero slots.
    # Restore original level-based GridIdList; do not hardcode empty arrays.
    import spark_system50
    return spark_system50.login_snapshot(database,uid)

def skin_for(c,uid,category,resource_id,item_id=None):
    if item_id is not None:
        selected=c.execute('SELECT s.item_id FROM obt_skin_equipment e JOIN obt_skins s ON s.item_id=e.skin_item WHERE e.uid=? AND e.holder_item=? AND s.uid=?',(uid,item_id,uid)).fetchone()
        if selected:return selected[0]
    row=c.execute('SELECT item_id FROM obt_skins WHERE uid=? AND category=? AND base_id=? ORDER BY resource_id LIMIT 1',(uid,10 if category==1 else 11,resource_id)).fetchone()
    return row[0] if row else 0

def ensure_skin(c,uid,category,resource_id,skin_resource=None):
    descriptors=garage.RESOURCES['roles'] if category==1 else garage.RESOURCES['weapons']
    descriptor=next((r for r in descriptors if r['resource_id']==resource_id),None)
    if descriptor is None:raise ValueError('Unknown base resource')
    ident=descriptor['skin'] if skin_resource is None else skin_resource
    category=10 if category==1 else 11
    skin=next((s for s in garage.RESOURCES['skins'] if s['category']==category and s['resource_id']==ident and s['base_id']==resource_id),None)
    if skin is None:raise ValueError('Skin does not belong to base item')
    item_id=(1<<62)+(uid<<32)+(category<<28)+ident
    if not 0<uid<(1<<28) or not 0<ident<(1<<28):raise ValueError('Skin identifier range')
    c.execute('INSERT OR IGNORE INTO obt_skins VALUES(?,?,?,?,?)',(item_id,uid,category,ident,resource_id))
    return item_id

def _owned_skin_for_input(c,uid,skin_item):
    """Resolve owned skin by 64-bit item ID, table resource ID or shop offer ID.

    The native garage can pass a short skin resource ID instead of ItemData.Id.
    Never look up an unowned catalog entry or attach the wrong category.
    """
    row=c.execute('SELECT * FROM obt_skins WHERE uid=? AND item_id=?',(uid,skin_item)).fetchone()
    if row:return row
    found=list(c.execute('SELECT * FROM obt_skins WHERE uid=? AND (resource_id=? OR (? = 200000000+category*10000000+resource_id))',
                         (uid,skin_item,skin_item)).fetchall())
    if len(found)>1:raise ValueError('Ambiguous owned skin ID')
    return found[0] if found else None


def _skin_holder_candidates(c,uid,skin,holder_item,slot):
    """Resolve only an actually owned matching base item, never a guessed one."""
    category=1 if skin['category']==10 else 2
    base=skin['base_id']
    matches=list(c.execute('SELECT * FROM inventory WHERE uid=? AND category=? AND resource_id=?',
                           (uid,category,base)))
    candidates=[]
    for r in matches:
        if holder_item in (0,r['item_id'],r['resource_id']):candidates.append(r)
    if candidates:return candidates
    # The native Garage can send the character holding a weapon skin, not
    # the weapon's inventory ID. Resolve through the verified loadout slot.
    if skin['category']==11 and holder_item>0:
        char=c.execute('SELECT * FROM inventory WHERE uid=? AND item_id=? AND category=1',
                       (uid,holder_item)).fetchone()
        if char is None:
            char=c.execute('SELECT * FROM inventory WHERE uid=? AND resource_id=? AND category=1',
                           (uid,holder_item)).fetchone()
        if char:
            found=list(c.execute("""SELECT i.* FROM loadouts l
                    JOIN inventory i ON i.item_id=l.item_id AND i.uid=l.uid
                    WHERE l.uid=? AND l.character_id=? AND i.category=2
                      AND i.resource_id=?""",(uid,char['resource_id'],base)))
            if 0<=slot<3:
                from database import SLOTS
                named=c.execute("""SELECT i.* FROM loadouts l JOIN inventory i
                    ON i.item_id=l.item_id AND i.uid=l.uid
                    WHERE l.uid=? AND l.character_id=? AND l.slot=? AND
                        i.category=2 AND i.resource_id=?""",
                    (uid,char['resource_id'],list(SLOTS)[slot],base)).fetchone()
                if named:return [named]
            return found
    return []


def equip_skin(database,uid,skin_item,holder_item,slot=0):
    """Return actual affected inventory ItemData.Id, or None for non-skin.

    Explicitly reject unowned resource/offer IDs: they are not fallback
    requests to equip a normal weapon. Transaction remains account-scoped.
    """
    with database.connect() as c:
        skin=_owned_skin_for_input(c,uid,skin_item)
        if skin is None:
            # Inputs that look like cosmetic offer IDs must never fall
            # through into ordinary weapon slot equipping.
            if skin_item>=200000000 or any(x['resource_id']==skin_item for x in garage.RESOURCES['skins']):
                raise ValueError('Skin is not owned')
            return None
        holders=_skin_holder_candidates(c,uid,skin,holder_item,slot)
        if len(holders)!=1:raise ValueError('Skin holder mismatch or ambiguity')
        holder=holders[0]
        c.execute('INSERT INTO obt_skin_equipment VALUES(?,?,?) ON CONFLICT(uid,holder_item) DO UPDATE SET skin_item=excluded.skin_item',
                  (uid,holder['item_id'],skin['item_id']))
        database.audit(c,uid,'skin_equipped',dict(holder_item=holder['item_id'],skin_item=skin['item_id']))
        return holder['item_id']


def unequip_skin(database,uid,skin_item,holder_item):
    """Remove a previously equipped cosmetic; None if not a skin operation."""
    with database.connect() as c:
        skin=_owned_skin_for_input(c,uid,skin_item) if skin_item else None
        if skin is None and skin_item:
            return None
        if skin is not None:
            matches=list(c.execute('SELECT holder_item FROM obt_skin_equipment WHERE uid=? AND skin_item=?',(uid,skin['item_id'])))
        else:
            matches=[]
        if holder_item:
            holder=c.execute('SELECT * FROM inventory WHERE uid=? AND (item_id=? OR resource_id=?)',(uid,holder_item,holder_item)).fetchone()
            if holder is not None:
                if matches and holder['item_id']!=matches[0]['holder_item']:raise ValueError('Wrong skin holder')
                matches=list(c.execute('SELECT holder_item FROM obt_skin_equipment WHERE uid=? AND holder_item=?',(uid,holder['item_id'])))
        if not matches:return None
        if len(matches)!=1:raise ValueError('Ambiguous skin removal')
        ident=matches[0]['holder_item']
        c.execute('DELETE FROM obt_skin_equipment WHERE uid=? AND holder_item=?',(uid,ident))
        database.audit(c,uid,'skin_unequipped',{'holder_item':ident})
        return ident

def skin_items(database,uid,category):
    with database.connect() as c:
        rows=c.execute('SELECT * FROM obt_skins WHERE uid=? AND category=? ORDER BY resource_id',(uid,category)).fetchall()
    return [dict(Id=r['item_id'],Category=category,Index=r['resource_id'],Bag=category,Pos=i,Stack=1,Skin=0) for i,r in enumerate(rows)]

def currency_items(database,uid):
    with database.connect() as c:
        row=c.execute('SELECT experience,credits,created_at FROM players WHERE uid=?',(uid,)).fetchone()
        if not row:raise ValueError('Unknown player')
        amounts={r['id']:0 for r in garage.RESOURCES['currencies']}
        amounts.update({3:row['credits'],4:row['experience']})
        for table in ['wallet','obt_currency']:
            for balance in c.execute('SELECT currency,amount FROM '+table+' WHERE uid=?',(uid,)):amounts[balance['currency']]=balance['amount']
    return [dict(Id=(1<<63)|(uid<<8)|index,Category=5,Index=index,Bag=5,Pos=index-1,Stack=amounts[index],CreateTime=int(row['created_at'])) for index in sorted(amounts)]

def ready_info(database,uid,role_id):
    role=next(r for r in garage.RESOURCES['roles'] if r['resource_id']==role_id)
    with database.connect() as c:
        loadouts={r['slot']:dict(r) for r in c.execute('SELECT l.slot,i.* FROM loadouts l JOIN inventory i ON i.item_id=l.item_id WHERE l.uid=? AND l.character_id=?',(uid,role_id))}
        holder=c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=1 AND resource_id=?',(uid,role_id)).fetchone()
        def skin_id(category,resource,item_id):
            ident=skin_for(c,uid,category,resource,item_id)
            row=c.execute('SELECT resource_id FROM obt_skins WHERE uid=? AND item_id=?',(uid,ident)).fetchone()
            return row[0] if row else 0
        skin_ids=[skin_id(2,loadouts[s]['resource_id'],loadouts[s]['item_id']) if s in loadouts else 0 for s in ['main','sub','melee']]
        return dict(MainWeaponId=loadouts.get('main',{}).get('resource_id',0),MeleeWeaponId=loadouts.get('melee',{}).get('resource_id',0),
                    Skin=dict(JijiaSkinId=skin_id(1,role_id,holder[0]) if holder else role['skin'],WeaponSkinIdCount=len(skin_ids),WeaponSkinIdList=skin_ids))
