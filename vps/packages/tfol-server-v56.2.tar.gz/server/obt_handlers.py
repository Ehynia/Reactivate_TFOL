"""OBT account/UI requests and persisted settings, separate from CBT logic."""
import calendar,datetime,json,sqlite3
from tdr_codec import packet,decode_all
import obt_extensions as store
import garage

REQUESTS={113:'RefreshDailyTask',114:'CommitDailyTask',135:'SystemSetupReq',137:'SparkConfigReq',139:'SyncSparkConfigReq',141:'SelectSparkConfigReq',
151:'QueryActiveRewardReq',168:'HeartbeatNotify',179:'SevenDaySignListReq',189:'SyncNewBieStage',
200:'QueryHead',219:'QueryActivityReq',222:'QueryAasHourReq',245:'QueryJijiaSparkReq',
255:'MonthSignInfoReq',263:'MatchModeOpenInfoReq',267:'QueryPopupReq',270:'QueryModularSlotReq',
281:'QueryVerUpdateInfoReq',284:'MatrixCoreReq',287:'UnEquipItemReq',
220:'PingTest',252:'HomePageClickNotify',265:'FpsNotify',276:'ClientLogNotify',277:'PveDefendAccBattleInfoReq',106:'QueryMailData',111:'SetMailReadFlag'}

REQUESTS[74]='BrowseChannelReq'
REQUESTS[117]='QueryAchievementList'
# Spark tab: original OBT shop and information requests (previously ignored).
REQUESTS.update({147:'LotterySparkInfoReq',149:'LotterySparkReq',
                 161:'BuySparkCfgReq',163:'BuySparkGridReq'})


def owned_spark_holder(database,uid,requested_id):
    '''Resolve original UI hero references to the canonical owned ItemData.Id.

    The picker can use Id=0 for the active character, or send its resource id,
    rather than the generated uint64 inventory item id. Never trust another
    account's holder or silently grant missing characters.
    '''
    with database.connect() as c:
        if requested_id:
            item=c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=1 AND item_id=?',
                           (uid,requested_id)).fetchone()
            if item:return item['item_id']
            item=c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=1 AND resource_id=? ORDER BY item_id LIMIT 1',
                           (uid,requested_id)).fetchone()
        else:
            hero=database.profile(uid)['selected_character_id']
            item=c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=1 AND resource_id=? ORDER BY item_id LIMIT 1',
                           (uid,hero)).fetchone()
        return item['item_id'] if item else None

def mail_summary(database,uid):
    read=int(bool(store.setting(database,uid,'guide_mail_read',False)))
    return packet(105,'SyncMailSummary',dict(NewMailCount=1-read,AllMailCount=1,MailList=[1]))

def mode_availability(database,uid,context):
    from world_policy import POLICY
    modes=store.setting(database,uid,'enabled_match_modes',POLICY['simulation']['enabled_modes'])
    if context.get('native_bots'):modes=__import__('bot_modes').PUBLIC_MODES
    modes=[m for m in modes if m!=3001]
    # Original 0x7c76b0 clears all flags before applying this snapshot.
    # Open is a byte boolean (0x7c7717/setne), not an inverted lock enum.
    return packet(264,'MatchModeOpenInfoRes',dict(MatchModeOpenInfoCount=len(modes)+1,MatchModeOpenInfoList=[dict(MatchId=n,Open=1) for n in modes]+[dict(MatchId=3001,Open=0)]))

def initial(database,uid,context=None):
    import news_feed
    reply=mail_summary(database,uid)
    reply+=news_feed.native(database)
    reply+=b''.join(packet(command,schema,value) for command,schema,value in [
        (202,'SyncPcCfg',{}),(192,'SyncActivity',dict(End=1)),(193,'SyncActivityStatus',dict(End=1))])
    from local_simulation import wire_quest
    reply+=wire_quest(database,uid)
    # Populate before the first menu opens; keep request 263 refreshes too.
    reply+=mode_availability(database,uid,context or {})
    # Do not replay obsolete guided steps after the funded-account bypass.
    import accounts
    if accounts.identity(database,uid)['tutorial_completed_at'] is None:
        for ident,kind in store.setting(database,uid,'newbie_stages',{}).items():
            reply+=packet(189,'SyncNewBieStage',dict(Id=int(ident),Type=kind))
    return reply

def handle(database,uid,command,body,context):
    if command==74:return packet(75,'BrowseChannelRes',dict(Count=0,ChannelList=[]))
    value=decode_all(REQUESTS[command],body)
    if command==117:
        # No verified achievements: provide the original valid empty snapshot.
        # The old server silently discarded this request (observed in reports).
        return packet(118,'SyncAchievementList',dict(AchievementCount=0,AchievementList=[]))
    if command==106:
        if value['Id'] not in (0,1):return mail_summary(database,uid)
        return packet(107,'SyncMailData',dict(Id=1,Read=int(bool(store.setting(database,uid,'guide_mail_read',False))),Time=1792074000,
            Sender='Reactivate',Title='Бои и инвентарь',Content='Бои с ботами: Сражения → Против ИИ → сложность → В бой. Ожидание до перехода — 20 секунд. Эта сборка проверяет запуск настоящей карты; начисление наград за бой ещё требует проверки. Склад показывает полученные расходники. Герои, оружие и скины находятся на базе. Режим PVE временно отключён до восстановления результатов.',AttachmentCount=0,AttachmentList=[]))
    if command==111:
        if value['MailId']==1:store.save(database,uid,'guide_mail_read',bool(value['Read']))
        return mail_summary(database,uid)
    if command==220:return packet(220,'PingTest',dict(Time=value['Time'],Cost=value['Cost']))
    if command in (252,265,276):return b''
    if command==277:
        # This is a client summary request, not proof of a completed battle.
        # Keep the UI response valid without minting rewards on each replay.
        return packet(278,'PveDefendAccBattleInfoRes',dict(Name=value['Name'],ItemCount=0,ItemInfo=[],EnergyMatrix=0,Exp=0,Gold=0))
    if command in (113,114):
        import local_simulation
        if command==114:
            try:result=local_simulation.claim(database,uid,value['Group'])
            except ValueError:result={'applied':False}
            if result['applied']:return local_simulation.wire_profile(database,uid)+local_simulation.wire_quest(database,uid)
        return local_simulation.wire_quest(database,uid)
    if command==135:
        store.save(database,uid,'setup',value['Setup'])
        return packet(136,'SystemSetupRes',dict(Result='ok'))
    if command==189:
        if not 1<=value['Id']<=36:raise ValueError('Unknown original onboarding step')
        import accounts
        if accounts.identity(database,uid)['tutorial_completed_at'] is None:
            stages=store.setting(database,uid,'newbie_stages',{})
            stages[str(value['Id'])]=value['Type'];store.save(database,uid,'newbie_stages',stages)
        return b''
    if command==168:
        # EXE 13 has no R31 queue-poll extension. Native heartbeats can
        # deliver a real worker assignment without inventing an endpoint.
        queue=context.get('matchmaking')
        if queue:
            decision=queue.poll(uid,context['connection_id'])
            import matchmaking
            if decision['state']==matchmaking.HUMANS:
                response=matchmaking.poll_response(database,decision,uid)
                return response[matchmaking.POLL_HEADER.size:]
            if decision['state']==matchmaking.BOTS:
                context['engine_worker_required']=True
                return packet(66,'RoomMatchRes',dict(PredictedTime=0,Result='server_unavailable'))
        return b''
    if command==200:
        return packet(201,'SyncHead',dict(Name=value['Name'],Time=0,Type=0,Flag=0,Url=''))
    if command==267:return packet(268,'QueryPopupRes',dict(PopupCount=0,PopupList=[]))
    if command==281:
        import news_feed
        return news_feed.update_notice(database)
    if command==263:
        return mode_availability(database,uid,context)
    if command==222:return packet(167,'AasHourNotify',dict(Id=0))
    if command==270:
        slots=store.setting(database,uid,'modular_slots',[])
        return packet(271,'QueryModularSlotRes',dict(ModularSlotCount=len(slots),ModularSlotList=slots))
    if command==255:
        # The original monthly sign-in widgets index these arrays immediately.
        # Returning zero counts caused repeated out-of-bounds errors on every
        # menu frame. Provide calendar *slots*, not fabricated claimed rewards.
        today=datetime.datetime.now().date()
        days=calendar.monthrange(today.year,today.month)[1]
        slots=[dict(MonthDay=d,ItemCount=0,ItemInfo=[],Status=0,Redo=0,Festival=0)
               for d in range(1,days+1)]
        aggregate=[dict(AccDay=d,ItemCount=0,ItemInfo=[],Status=0)
                   for d in range(1,days+1)]
        history=[dict(AccDay=d,ItemCount=0,ItemInfo=[],Status=0,Progress=0,Id=d)
                 for d in range(1,days+1)]
        return packet(256,'MonthSignInfoRes',dict(
            Result='ok',
            MonthDaySignInfo=dict(Month=today.month,Year=today.year,Day=today.day,
                                  MonthDaySignCount=days,MonthDaySignDayList=slots),
            MonthAccSignInfo=dict(Month=today.month,MonthAccSignCount=days,MonthAccSignList=aggregate),
            MonthHistoryAccSignInfo=dict(MonthHistoryAccSignCount=days,MonthHistoryAccSignList=history)))
    if command==219:return packet(192,'SyncActivity',dict(End=1))+packet(193,'SyncActivityStatus',dict(End=1))
    if command==151:return packet(152,'QueryActiveRewardRes',dict(ActiveType=value['ActiveType']))
    if command==179:return packet(180,'SevenDaySignListRes',{})
    if command in (147,149,161,163):
        import spark_system50
        if command==147:
            return packet(148,'LotterySparkInfoRes',spark_system50.lottery_info(database,uid))
        if command==149:
            outcome,rewards,meta,applied=spark_system50.free_lottery_draw(database,uid,value['Id'])
            state=spark_system50.lottery_info(database,uid)
            reply=packet(150,'LotterySparkRes',dict(
                LotteryInfo=meta,Count=len(rewards),ItemInfo=rewards,Result=outcome,
                DayCount=state['DayCount']))
            if applied:
                # Refresh the native consumables bag and Spark lottery panel.
                items=garage.bag(database,uid,3)
                reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(items),Items=items))
            reply+=packet(148,'LotterySparkInfoRes',state)
            return reply
        result=(spark_system50.buy_scheme(database,uid,value['Id']) if command==161
                else spark_system50.buy_grid(database,uid,value['Id']))
        reply=packet(162 if command==161 else 164,
                     'BuySparkCfgRes' if command==161 else 'BuySparkGridRes',
                     dict(Id=value['Id'],Result=result))
        if result=='ok':
            for money in garage.currency_bag(database,uid):
                reply+=packet(39,'SyncItemData',dict(Item=money))
        return reply
    if command==245:
        holder=owned_spark_holder(database,uid,value['Id'])
        config=store.setting(database,uid,'jijia_spark',{}).get(str(holder),0) if holder is not None else 0
        return packet(246,'QueryJijiaSparkRes',dict(Id=value['Id'],SparkCfgId=config,
                                                       Result='ok' if holder is not None else 'not_owned'))
    if command==284:
        if value['ItemId']==0 and value['OpType']==0:
            return packet(285,'MatrixCoreRes',dict(**value,Result='ok'))+packet(286,'SyncMatrixCoreProperty',{})
        return packet(285,'MatrixCoreRes',dict(**value,Result='not_owned'))
    if command==137:
        configs=store.setting(database,uid,'spark_configs',{})
        config=configs.get(str(value['ConfigId']))
        if config is None:return packet(138,'SparkConfigRes',dict(**value,Result='not_owned'))
        grid=value['SparkGrid']
        import spark_system50
        # The server must enforce original unlocked grid, not accept forged
        # placements into unearned slots or an imaginary Spark item.
        if grid['GridId'] not in spark_system50.available_grids(database,uid):
            return packet(138,'SparkConfigRes',dict(**value,Result='not_owned'))
        # Native color classes 1/2/3 correspond to original 201xx/202xx/203xx
        # Spark series. Preserve the original layout; do not let a blue Spark
        # occupy a red slot. Type 4 has no proven prefix restriction yet.
        slot_type=spark_system50.GRID_ROWS[grid['GridId']]['type']
        if grid['ItemId'] and slot_type in (1,2,3):
            if grid['Index']//100 != 200+slot_type:
                return packet(138,'SparkConfigRes',dict(**value,Result='not_owned'))
        # Reject forged item references. Keep all other equipped grid slots.
        if grid['ItemId']:
            with database.connect() as c:
                owned=c.execute('SELECT 1 FROM inventory WHERE uid=? AND item_id=? AND resource_id=?',(uid,grid['ItemId'],grid['Index'])).fetchone()
            if not owned and not spark_system50.owns_spark(database,uid,grid['ItemId'],grid['Index']):
                return packet(138,'SparkConfigRes',dict(**value,Result='not_owned'))
        grids=[g for g in config.get('grids',[]) if g['GridId']!=grid['GridId']]
        if grid['GridId'] and grid['ItemId']:grids.append(grid)
        config.update(name=value['ConfigName'] or config['name'],grids=grids)
        store.save(database,uid,'spark_configs',configs)
        return packet(138,'SparkConfigRes',dict(**value,Result='ok'))
    if command==139:
        config=store.setting(database,uid,'spark_configs',{}).get(str(value['ConfigId']))
        grids=config.get('grids',[]) if config else []
        return packet(140,'SyncSparkConfigRes',dict(ConfigId=value['ConfigId'],ConfigName=config['name'] if config else '',Count=len(grids),SparkGridList=grids))
    if command==141:
        holder=owned_spark_holder(database,uid,value['Id'])
        exists=str(value['ConfigId']) in store.setting(database,uid,'spark_configs',{})
        result='ok' if holder is not None and exists else 'not_owned'
        if result=='ok':
            configs=store.setting(database,uid,'jijia_spark',{})
            configs[str(holder)]=value['ConfigId']
            store.save(database,uid,'jijia_spark',configs)
        return packet(142,'SelectSparkConfigRes',dict(ConfigId=value['ConfigId'],Result=result))
    if command==287:
        # Native UI may remove the current cosmetic before selecting another.
        # Handle that independently of detaching weapons from character slots.
        try: cosmetic_holder=store.unequip_skin(database,uid,value['EquipItem'],value['HolderItem'])
        except ValueError: cosmetic_holder=None
        if cosmetic_holder is not None:
            with database.connect() as c:
                base=c.execute('SELECT * FROM inventory WHERE uid=? AND item_id=?',(uid,cosmetic_holder)).fetchone()
                reply=packet(288,'UnEquipItemRes',dict(**value,Result='ok'))
                if base:
                    reply+=packet(39,'SyncItemData',dict(Item=garage.native_item(c,uid,base)))
                    skin_bag=10 if base['category']==1 else 11
                    skins=garage.bag(database,uid,skin_bag)
                    reply+=packet(38,'SyncBagData',dict(BagIndex=skin_bag,Count=len(skins),Items=skins))
                return reply
        result='not_owned'
        with database.connect() as c:
            holder=c.execute('SELECT resource_id FROM inventory WHERE uid=? AND item_id=? AND category=1',(uid,value['HolderItem'])).fetchone()
            if holder:
                removed=c.execute('DELETE FROM loadouts WHERE uid=? AND character_id=? AND item_id=?',(uid,holder[0],value['EquipItem'])).rowcount
                if removed:result='ok'
        return packet(288,'UnEquipItemRes',dict(**value,Result=result))
    raise ValueError('OBT handler not implemented')
