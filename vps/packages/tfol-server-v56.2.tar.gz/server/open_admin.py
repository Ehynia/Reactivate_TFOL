"""Open the local admin page; the token stays in the URL fragment."""
import argparse
import json
from pathlib import Path
import urllib.request
from launcher_sdk import API


def open_panel(data):
    import webbrowser
    data=Path(data)
    ready=json.loads((data/'server.ready.json').read_text('utf-8'))
    api=API(ready['api_url'])
    health=api.request('/health')
    if health.get('release') not in {'OBT16','OBT17','OBT18','OBT19','OBT22','OBT24','OBT25','OBT27','OBT28','OBT29','OBT30','OBT31','OBT31A','OBT33'}:raise ValueError('No compatible local OBT server is running')
    token=(data/'admin.token').read_text('ascii').strip()
    webbrowser.open(api.url+'/admin/#'+token)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True)
    open_panel(p.parse_args().data)
