"""Read-only x86 PE metadata and byte ranges. Never loads the supplied binary."""
from pathlib import Path
import struct

class PE:
    def __init__(self,path):
        self.path=Path(path);self.b=self.path.read_bytes()
        off=struct.unpack_from('<I',self.b,0x3c)[0]
        assert self.b[:2]==b'MZ' and self.b[off:off+4]==b'PE\0\0'
        self.machine,nsec=struct.unpack_from('<HH',self.b,off+4)
        opts=struct.unpack_from('<H',self.b,off+20)[0];op=off+24
        self.magic=struct.unpack_from('<H',self.b,op)[0];assert self.magic==0x10b
        self.base=struct.unpack_from('<I',self.b,op+28)[0]
        self.entry=self.base+struct.unpack_from('<I',self.b,op+16)[0]
        self.directories=[struct.unpack_from('<II',self.b,op+96+i*8) for i in range(16)]
        self.sections={}
        for i in range(nsec):
            pos=op+opts+i*40;name,size,rva,raw,ptr=struct.unpack_from('<8sIIII',self.b,pos)
            label=name.rstrip(b'\0').decode()
            # Protected binaries may reuse one name for several distinct sections.
            # Preserve every range rather than silently overwriting earlier ones.
            key=label if label not in self.sections else f'{label}#{i}'
            self.sections[key]=dict(va=self.base+rva,vsize=size,rawsize=raw,rawptr=ptr)
    def read(self,va,n):
        for s in self.sections.values():
            if s['va']<=va and va+n<=s['va']+max(s['rawsize'],s['vsize']):
                offset=va-s['va'];available=max(0,min(n,s['rawsize']-offset))
                p=s['rawptr']+offset;return self.b[p:p+available]+bytes(n-available)
        raise ValueError(f'Unmapped {va:#x} length {n}')
    def u32(self,va):return struct.unpack('<I',self.read(va,4))[0]
    def string(self,va,wide=False):
        data=bytearray();step=2 if wide else 1
        for i in range(4096):
            b=self.read(va+i*step,step)
            if b==bytes(step):return data.decode('utf-16le' if wide else 'ascii',errors='replace')
            data.extend(b)
        raise ValueError('Unterminated string')
    def imports(self):
        rva,size=self.directories[1]
        if not rva:return []
        rows=[]
        for i in range(256):
            d=struct.unpack('<5I',self.read(self.base+rva+i*20,20))
            if not any(d):break
            table,timestamp,chain,name,iat=d;table=table or iat;entries=[]
            for j in range(4096):
                v=self.u32(self.base+table+j*4)
                if not v:break
                label='ordinal:'+str(v&65535) if v&0x80000000 else self.string(self.base+v+2)
                entries.append(dict(name=label,iat_va=self.base+iat+j*4))
            rows.append(dict(dll=self.string(self.base+name),entries=entries))
        return rows
    def thunk(self,va):
        if self.read(va,1)==b'\xe9':return va+5+struct.unpack('<i',self.read(va+1,4))[0]
        return va

