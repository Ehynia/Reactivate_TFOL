"""Listen-host coordination for an authenticated room. All methods run under Queue.lock.

This component selects the new host and issues a new listen assignment. Actual
UE4 world state transfer, AI spawn and remote NAT traversal are NOT implemented.
"""
import itertools
import random
import socket
import struct
from dataclasses import dataclass,field

HOST_START,PEER_WAIT,GUEST_START,PEER_FAILED=5,6,7,8
CONFIG=struct.Struct('<4sHHIII32s')
MAPS=(101,102,103,104,106)
MAX_SNAPSHOT_BYTES=32768  # protocol limit, not a complete world-state format
AI_MODES=frozenset((1010,1011,1012))
PVP_MODES=frozenset((1001,1002,1003,1004,1005,1013,1014,1015,2001))
COOP_MODES=frozenset((3001,))

def room_capacity(mode):
    if mode in COOP_MODES:return 5
    if mode in (1013,1014):return 6
    if mode in AI_MODES or mode in PVP_MODES:return 12
    if mode==0:return 10  # Old same-PC test protocol.
    raise ValueError("Unsupported room mode")

def safe_name(name):
    raw=name.encode('utf-8')
    if not raw or len(raw)>31 or any(c in name for c in '?&#=\\/') or any(ord(c)<32 for c in name):
        raise ValueError('Nickname cannot be used in game travel')
    return raw

@dataclass
class Room:
    id:int
    port:int
    map_id:int
    members:list
    host:int
    deadline:float
    bot_fill:int=0
    bound:bool=False
    delivered:set=field(default_factory=set)
    ready:set=field(default_factory=set)
    roles:dict=field(default_factory=dict)
    seats:dict=field(default_factory=dict)
    revision:int=1
    seen:dict=field(default_factory=dict)
    match_id:int=0
    competition:int=0
    capacity:int=10
    epoch:int=1
    snapshot:bytes=b''
    snapshot_seq:int=0
    snapshot_epoch:int=0

class Rooms:
    def __init__(self,clock,event,capacity=10,probe=True):
        self.clock=clock;self.event=event;self.capacity=capacity;self.probe=probe
        self.rooms={};self.members={};self.failures={};self.ids=itertools.count(100000)

    def _port(self):
        used={r.port for r in self.rooms.values()}
        for port in range(7777,7977):
            if port in used:continue
            if self.probe:
                try:
                    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',port))
                except OSError:continue
            return port
        return None

    def get(self,uid,connection):
        ident=self.members.get((uid,connection))
        if ident not in self.rooms:raise ValueError('No assigned peer room')
        return self.rooms[ident]

    def _new(self,entries,bot_fill=None):
        if not entries:return False
        mode=entries[0].match_id;competition=entries[0].competition
        if any((e.match_id,e.competition)!=(mode,competition) for e in entries):raise ValueError('Mixed room modes')
        capacity=room_capacity(mode)
        if len(entries)>capacity:raise ValueError('Room capacity exceeded')
        port=self._port()
        if port is None:return False
        bots=capacity-len(entries) if bot_fill is None else bot_fill
        if not 0<=bots<=capacity-len(entries):raise ValueError('Invalid bot count')
        # Respect the original mode->map catalog: PVE must never start on a
        # random TDM map. Mode 0 preserves the legacy same-PC probe.
        from bot_modes import resolve
        new_id=next(self.ids)
        map_id=random.choice(MAPS) if mode==0 else resolve(mode,new_id)['map']
        if mode in COOP_MODES:
            # Mission scripts own Insecticon enemies; normal versus bots are
            # NOT part of the allied cooperative roster.
            bots=0
        room=Room(new_id,port,map_id,list(entries),entries[0].uid,self.clock()+60,bots,
                  match_id=mode,competition=competition,capacity=capacity)
        room.seats={e.uid:i for i,e in enumerate(entries)}
        self.rooms[room.id]=room
        for e in entries:self.members[e.uid,e.connection]=room.id
        self.event('peer_host_assigned',room_id=room.id,port=port,host=room.host,players=[e.uid for e in entries],bot_fill=bots)
        return True

    def allocate(self,entries):
        """Pool real players only with compatible modes, never fabricate player UIDs.

        Solo creation is delayed until the caller's queue deadline (see solo).
        TDM versus AI and PvP both use the original 6v6 capacity.
        """
        waiting=sorted((e for e in entries if e.peer and e.match_id in
                        (AI_MODES|PVP_MODES|COOP_MODES|{0})),key=lambda e:(e.started,e.uid))
        assigned=[]
        for r in list(self.rooms.values()):
            if not r.bound and self.clock()>=r.deadline:continue
            for e in list(waiting):
                if len(r.members)>=r.capacity:break
                if (e.match_id,e.competition)!=(r.match_id,r.competition):continue
                waiting.remove(e);r.members.append(e)
                r.seats[e.uid]=next(i for i in range(r.capacity) if i not in r.seats.values())
                self.members[e.uid,e.connection]=r.id;r.revision+=1;assigned.append(e.uid)
                r.bot_fill=0 if r.match_id in COOP_MODES else r.capacity-len(r.members)
                self.event('peer_room_member_added',room_id=r.id,uid=e.uid,bot_fill=r.bot_fill)
        while waiting:
            head=waiting[0]
            cohort=[e for e in waiting if (e.match_id,e.competition)==(head.match_id,head.competition)]
            capacity=room_capacity(head.match_id)
            # A second player can join immediately; the solo case is handled
            # after the queue deadline rather than waiting forever.
            if len(cohort)<2:
                waiting.remove(head);continue
            cohort=cohort[:capacity]
            if not self._new(cohort):break
            assigned.extend(e.uid for e in cohort)
            for e in cohort:waiting.remove(e)
        return assigned

    def solo(self,e):
        return e.peer and e.match_id in (AI_MODES|PVP_MODES|COOP_MODES|{0}) and self._new([e])

    def close(self,r,reason,skip=None):
        self.rooms.pop(r.id,None)
        for e in r.members:
            key=(e.uid,e.connection);self.members.pop(key,None)
            if key!=skip:self.failures[key]=(r.id,reason)
        self.event('peer_room_closed',room_id=r.id,reason=reason)

    def cancel(self,uid,connection):
        key=(uid,connection);self.failures.pop(key,None)
        if key not in self.members:return
        r=self.get(uid,connection)
        was_host=uid==r.host
        self.members.pop(key,None);r.members=[e for e in r.members if (e.uid,e.connection)!=key]
        r.seats.pop(uid,None);r.roles.pop(uid,None);r.delivered.discard(uid);r.ready.discard(uid);r.seen.pop(uid,None);r.revision+=1
        if not r.members:
            self.close(r,'last_player_left');return
        r.bot_fill=0 if r.match_id in COOP_MODES else r.capacity-len(r.members)
        if was_host:
            # Coordination is possible; world continuity still needs an engine
            # snapshot/checkpoint and working remote listen bind on the new host.
            previous_host=uid
            r.host=next((e.uid for e in r.members if e.uid in r.ready),r.members[0].uid)
            r.epoch+=1;r.bound=False;r.deadline=self.clock()+60
            r.delivered.clear();r.ready.clear();r.seen.clear()
            port=self._port()
            if port is None:
                self.close(r,'migration_no_available_port');return
            r.port=port
            self.event('peer_host_migration_assigned',room_id=r.id,previous_host=previous_host,
                       new_host=r.host,epoch=r.epoch,port=port,world_restored=False)
        self.event('peer_room_member_left',room_id=r.id,uid=uid,bot_fill=r.bot_fill)

    def poll(self,uid,connection):
        key=(uid,connection)
        if key in self.failures:
            ident,reason=self.failures.pop(key)
            return dict(state=PEER_FAILED,remaining_ms=0,session_id=ident,reason=reason)
        if key not in self.members:return None
        r=self.get(uid,connection)
        if not r.bound and self.clock()>=r.deadline:
            self.close(r,'host_listen_timeout');return self.poll(uid,connection)
        state=PEER_WAIT
        if uid not in r.delivered and (uid==r.host or r.bound):
            state=HOST_START if uid==r.host else GUEST_START;r.delivered.add(uid)
        sync=state==PEER_WAIT and uid in r.delivered and r.seen.get(uid)!=r.revision
        if state!=PEER_WAIT or sync:r.seen[uid]=r.revision
        info=dict(RoomId=r.id,RoomSeq=r.epoch,RoomName='TFOL Local Peer',MapID=r.map_id,MaxPlayerCount=r.capacity,
                  PlayerCount=len(r.members),AllowTransform=1,Status='ready',DsDomain=f'127.0.0.1:{r.port}')
        return dict(state=state,remaining_ms=0,session_id=r.id,room=info,players=[e.uid for e in r.members],
                    host_uid=r.host,udp_port=r.port,seats=dict(r.seats),roles=dict(r.roles),sync_roster=sync,
                    bot_fill=r.bot_fill,epoch=r.epoch,mode=r.match_id,world_restored=False)

    def bound(self,uid,connection,ident,port):
        r=self.get(uid,connection)
        if uid!=r.host or r.id!=ident or r.port!=port or uid not in r.delivered or (not r.bound and self.clock()>=r.deadline):
            raise ValueError('Host readiness does not match assignment')
        if not r.bound:self.event('peer_host_udp_bound',room_id=r.id,port=port)
        r.bound=True

    def publish_snapshot(self,uid,connection,room_id,epoch,sequence,payload):
        """Opaque authenticated host checkpoint. Not interpreted or awarded.

        Full UE4 state serialization and client restore callbacks are still
        required before this becomes real host migration.
        """
        r=self.get(uid,connection)
        if uid!=r.host or r.id!=room_id or epoch!=r.epoch or not r.bound:
            raise ValueError('Only the current listening host can publish')
        if type(sequence)!=int or sequence<=r.snapshot_seq and r.snapshot_epoch==epoch:
            raise ValueError('Non-monotonic checkpoint')
        if not isinstance(payload,bytes) or not 1<=len(payload)<=MAX_SNAPSHOT_BYTES:
            raise ValueError('Invalid checkpoint size')
        r.snapshot=payload;r.snapshot_seq=sequence;r.snapshot_epoch=r.epoch
        self.event('peer_checkpoint_saved',room_id=r.id,epoch=r.epoch,sequence=sequence,bytes=len(payload))

    def migration_checkpoint(self,uid,connection,room_id,epoch):
        r=self.get(uid,connection)
        if uid!=r.host or r.id!=room_id or epoch!=r.epoch:
            raise ValueError('Not the elected new host')
        if r.snapshot_epoch!=r.epoch-1 or not r.snapshot:
            raise ValueError('No predecessor checkpoint')
        # Never tell the client that receiving data means the world has been restored.
        return r.snapshot_seq,r.snapshot

def roster(database,decision):
    rows=[]
    for index,uid in enumerate(decision['players']):
        p=database.profile(uid);seat=decision.get('seats',{}).get(uid,index)
        # Cooperative allies and human players versus AI share team 0. PvP
        # keeps the original alternating-team seat allocation.
        cooperative=decision.get('mode',decision.get('match_id',0)) in (COOP_MODES|AI_MODES)
        rows.append(dict(Name=p['nickname'],Avatar=0,RoleIndex=decision.get('roles',{}).get(uid,p['selected_character_id']),
                         TeamId=0 if cooperative else seat%2,SeatId=seat if cooperative else seat//2,
                         Level=p['level'],IsRoomMaster=int(uid==decision.get('host_uid',decision['players'][0])),PlayerStatus='ready'))
    return rows

def config(database,decision,uid):
    p=database.profile(uid)
    return CONFIG.pack(b'R31P',1,decision['udp_port'],decision['room']['MapID'],
                       decision.get('roles',{}).get(uid,p['selected_character_id']),decision['bot_fill'],safe_name(p['nickname']))
