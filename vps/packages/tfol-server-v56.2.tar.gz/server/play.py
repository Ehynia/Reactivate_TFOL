"""One-click local server plus game; launcher GUI stays independent."""
import argparse,json,urllib.request
from pathlib import Path
from server import App
from client_runner import run_client,game_folder
import client_assets

def main():
    p=argparse.ArgumentParser();p.add_argument('--game-dir',type=Path,required=True)
    p.add_argument('--nickname');p.add_argument('--data',type=Path);p.add_argument('--max-seconds',type=int,default=0)
    p.add_argument('--no-admin',action='store_true')
    args=p.parse_args();folder=game_folder(args.game_dir)
    data=args.data or folder/'OBT_SERVER_DATA'
    legacy=folder/'OBT_LOCAL_STATE'/'player.json'
    nickname=args.nickname or (json.loads(legacy.read_text('utf-8'))['name'] if legacy.exists() else 'OBT_Player')
    app=App(data,0,0,legacy_profile=legacy).start()
    ready_path=data/'server.ready.json'
    ready_path.write_text(json.dumps(dict(api_url='http://127.0.0.1:'+str(app.api_port),tcp_port=app.state.tcp_port)),encoding='utf-8')
    try:
        if not args.no_admin:
            from open_admin import open_panel
            open_panel(data)
        session=app.state.create_session(nickname)
        try:
            assets=client_assets.scan(folder)
            (data/'client_assets.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2),encoding='utf-8')
            with app.state.database.connect() as c:
                for row in __import__('garage').RESOURCES['maps']:
                    c.execute('UPDATE maps SET available=? WHERE map_id=?',(int(row['map_id'] in assets['verified_map_ids']),row['map_id']))
            app.state.event('client_assets_checked',uid=session['user_id'],**assets)
        except (ValueError,OSError) as e:app.state.event('client_asset_check_failed',uid=session['user_id'],reason=str(e))
        print('OBT 17: close the game when finished. There is no automatic 180-second limit.',flush=True)
        def snapshot():
            app.state.journal.flush()
            (data/'last_runtime_metrics.json').write_text(json.dumps(app.state.metrics.snapshot(),indent=2),encoding='utf-8')
        run_client(folder,session,data,args.max_seconds,before_report=snapshot)
    finally:
        app.close();ready_path.unlink(missing_ok=True)

if __name__=='__main__':main()
