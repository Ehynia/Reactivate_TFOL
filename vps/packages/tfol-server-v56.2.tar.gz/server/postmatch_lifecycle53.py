"""OBT53: authenticated/local-only late-result escrow after post-game exit.

UE4's round-end HUD/event can precede the final result packet.  Keep the
matching native engine context for at most 120 seconds after 165, but never
create a result or extend the authority to a new round/reconnect.
"""
import time

WINDOW_SECONDS = 120


def retain_after_exit(database, uid, context, *, now=None):
    match=context.get('engine_match') or {}
    rid=match.get('round_id')
    if not (context.get('native_bots') and context.get('logged_in') and
            context.get('allow_local_rewards') and context.get('local_ui_recovery52') and
            rid and match.get('state')=='travel_dispatched' and
            match.get('sequence',0)>0 and context.get('ui_round_end45')==rid):
        return False
    with database.connect() as connection:
        row=connection.execute('SELECT uid,mode_id,started_at FROM round_attempts WHERE round_id=?',(rid,)).fetchone()
    now=time.time() if now is None else now
    if (row is None or row['uid']!=uid or row['mode_id']!=match.get('mode') or
            not 45 <= now-row['started_at'] <= 14400):
        return False
    context['postmatch_result_escrow53']=dict(round_id=rid,sequence=match['sequence'],
                                                 expires_at=now+WINDOW_SECONDS)
    return True


def check_late_result(context, *, now=None):
    escrow=context.get('postmatch_result_escrow53')
    if not escrow:
        return
    match=context.get('engine_match') or {}
    now=time.time() if now is None else now
    if (now>escrow['expires_at'] or match.get('round_id')!=escrow['round_id'] or
            match.get('sequence')!=escrow['sequence'] or
            context.get('ui_round_end45')!=escrow['round_id']):
        raise ValueError('Expired or mismatched post-game result escrow')
