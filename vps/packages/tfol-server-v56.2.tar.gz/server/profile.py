"""Write the validated x86 TenProxy context using OUR server's guest session."""
import struct
from context_schema import synthetic_fixture,record,u32,inspect_blob

def build_profile(session,title,launcher):
    blob=bytearray(synthetic_fixture(title,launcher,1))
    def replace(table,ident,value):
        offset,old_size,_=record(blob,table,ident,'bytes',0x410)
        if len(value)!=old_size:raise ValueError('Fixed fixture record size mismatch')
        blob[offset+4:offset+4+len(value)]=value
    replace(4,2,struct.pack('<I',session['user_id']));replace(4,1,struct.pack('<I',session['service_id']))
    replace(4,5,bytes.fromhex(session['login_key_hex']))
    # Rebuild variable-width signature record without moving offset tables.
    signature=bytes.fromhex(session['token_hex'])
    if len(signature)!=32:raise ValueError('Expected 32-byte local token')
    # Use a dedicated bounded tail region, well beyond the fixture's records.
    cursor=0x70000;struct.pack_into('<I',blob,4+3*4,cursor)
    struct.pack_into('<I',blob,cursor,32);blob[cursor+4:cursor+36]=signature
    replace(4,3,bytes([32]))
    index=u32(blob,4+19*4);table=u32(blob,index)
    if session['host']!='127.0.0.1' or not 1<=session['port']<=65535:raise ValueError('Only a loopback endpoint is supported')
    replace(table,3,struct.pack('<I',session['port']))
    inspect_blob(blob)
    return bytes(blob)
