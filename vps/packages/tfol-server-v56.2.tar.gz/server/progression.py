"""Server rewards, using the pinned client's cumulative account level table."""
import json,time,uuid
from pathlib import Path
POLICY=json.loads((Path(__file__).parent/'progression_policy.json').read_text(encoding='utf-8'))
MIGRATION='''
CREATE TABLE progression_legacy(uid INTEGER PRIMARY KEY REFERENCES players(uid));
INSERT INTO progression_legacy SELECT uid FROM players;
CREATE TABLE match_rewards(event_id TEXT PRIMARY KEY,uid INTEGER NOT NULL REFERENCES players(uid),experience INTEGER NOT NULL,created_at REAL NOT NULL,source TEXT NOT NULL);
CREATE INDEX reward_owner ON match_rewards(uid,created_at);
CREATE TABLE account_keys(uid INTEGER PRIMARY KEY REFERENCES players(uid),salt BLOB NOT NULL,key_hash BLOB NOT NULL,issued_at REAL NOT NULL);
'''
def threshold(level):
    if type(level)!=int or not 1<=level<=POLICY['max_level']:raise ValueError('Invalid level')
    return POLICY['level_entry_experience'][level-1]
def level_for(experience):
    level=1
    while level<POLICY['max_level'] and experience>=threshold(level+1):level+=1
    return level
def required_level(resource):return POLICY['character_levels'].get(str(resource),POLICY['max_level']+1)
def eligible(database,c,uid):
    if not database.progression_enabled or c.execute('SELECT 1 FROM progression_legacy WHERE uid=?',(uid,)).fetchone():return list(POLICY['character_levels'])
    level=c.execute('SELECT level FROM players WHERE uid=?',(uid,)).fetchone()[0]
    return [r for r,l in POLICY['character_levels'].items() if l<=level]
def status(database,uid):
    with database.connect() as c:
        row=c.execute('SELECT level,experience FROM players WHERE uid=?',(uid,)).fetchone()
        if not row:raise ValueError('Unknown player')
        owned={r[0] for r in c.execute('SELECT resource_id FROM characters WHERE uid=?',(uid,))}
    return dict(level=row['level'],experience=row['experience'],next_level_experience=threshold(row['level']+1) if row['level']<POLICY['max_level'] else None,
        characters=[dict(resource_id=int(r),required_level=l,unlocked=int(r) in owned) for r,l in POLICY['character_levels'].items()])
def reward_in(database,c,uid,event_id,experience,source,now=None,cooldown=0,silver_coin=0):
    if not isinstance(event_id,str) or not 1<=len(event_id)<=128 or type(experience)!=int or not 0<=experience<=10000:raise ValueError('Invalid match reward')
    if type(silver_coin)!=int or not 0<=silver_coin<=10000:raise ValueError('Invalid silver reward')
    now=time.time() if now is None else now
    old=c.execute('SELECT uid FROM match_rewards WHERE event_id=?',(event_id,)).fetchone()
    if old:
        if old['uid']!=uid:raise ValueError('Match belongs to another player')
        return dict(applied=False,awarded_experience=0,unlocked=[])
    if cooldown:
        last=c.execute('SELECT max(created_at) FROM match_rewards WHERE uid=? AND source=?',(uid,source)).fetchone()[0]
        if last is not None and now-last<cooldown:return dict(applied=False,awarded_experience=0,unlocked=[])
    row=c.execute('SELECT experience FROM players WHERE uid=?',(uid,)).fetchone()
    if not row:raise ValueError('Unknown player')
    total=min(row['experience']+experience,2_000_000_000)
    c.execute('UPDATE players SET experience=?,level=?,credits=min(credits+?,2000000000) WHERE uid=?',(total,level_for(total),silver_coin,uid))
    c.execute('INSERT INTO match_rewards(event_id,uid,experience,created_at,source,silver_coin) VALUES(?,?,?,?,?,?)',(event_id,uid,experience,now,source,silver_coin))
    import garage
    unlocked=garage.grant_eligible(database,c,uid)
    database.audit(c,uid,'match_reward',dict(event_id=event_id,experience=experience,source=source,unlocked=unlocked))
    return dict(applied=True,awarded_experience=experience,awarded_silver_coin=silver_coin,unlocked=unlocked,event_id=event_id)
def reward(database,uid,event_id,experience,source,now=None,cooldown=0,silver_coin=0):
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        return reward_in(database,c,uid,event_id,experience,source,now,cooldown,silver_coin)
def local_completion(database,uid,mode,match):
    # The observed v0047 sends TDM/1 only after its local match ends. TRA/2
    # is also sent on training exit and must never award completion XP.
    if not database.progression_enabled or mode!='TDM' or match!=1:return dict(awarded_experience=0,unlocked=[])
    now=time.time()
    return reward(database,uid,'local-'+uuid.uuid4().hex,POLICY['completion_experience'],'local-client',now,POLICY['local_reward_cooldown_seconds'],POLICY['completion_silver_coin'])
