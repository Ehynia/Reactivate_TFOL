"""First OBT application exchange, grounded in the attached OBT TDR.

The advertised application revision is a diagnostic probe. It is not the
CBT revision 58 and is not yet verified against the running OBT client.
"""
import struct

NATIVE = struct.Struct('>HHII')
ADVERTISED_PROTOCOL_VERSION = 1
APPLICATION_VERSION_VERIFIED = False

def inspect_packet(data):
    if len(data) < NATIVE.size:
        raise ValueError('native header truncated')
    version, command, head, size = NATIVE.unpack_from(data)
    if version != 1 or head != 12 or size != len(data) - head:
        raise ValueError('invalid native header')
    return command, data[head:]

def string(value, capacity):
    encoded = value.encode('utf-8') + b'\0'
    if len(encoded) > capacity or b'\0' in encoded[:-1]:
        raise ValueError('invalid TDR string')
    return struct.pack('>I', len(encoded)) + encoded

def query_response(request, port):
    command, body = inspect_packet(request)
    if command != 1:
        return b''
    if body != b'\0':
        raise ValueError('unexpected QueryServerReq body')
    if not 0 < port < 65536:
        raise ValueError('invalid local port')
    body = (struct.pack('>II', 30, ADVERTISED_PROTOCOL_VERSION)
            + string('tcp://127.0.0.1:%d' % port, 120)
            + string('OK', 50))
    return NATIVE.pack(1, 2, 12, len(body)) + body
