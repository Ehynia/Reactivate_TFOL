"""Recover pinned plaintext inputs from this release; requires the user's original EXE."""
import argparse,hashlib,json
from pathlib import Path
from pe_read import PE
ROOT=Path(__file__).parent

def recover(original,out):
    manifest=json.loads((ROOT/'base_exe_manifest.json').read_text());raw=Path(original).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=manifest['source_sha256']:raise ValueError('Wrong original OBT client')
    image=PE(ROOT/'ClientUpdate/TFOL_OBT.exe')
    if hashlib.sha256(image.b).hexdigest()!=manifest['exe_sha256']:raise ValueError('Wrong recovered image')
    code=bytearray(image.read(0x401000,32436224))
    for patch in manifest['patches']:
        at=int(patch['va'],16)-0x401000;before=bytes.fromhex(patch['before']);after=bytes.fromhex(patch['after'])
        if code[at:at+len(after)]!=after:raise ValueError('Modified code differs from manifest')
        code[at:at+len(before)]=before
    if hashlib.sha256(code).hexdigest()!=manifest['original_code_sha256']:raise ValueError('Recovered code hash mismatch')
    tvm=image.read(0x2d3b000,24576)
    if hashlib.sha256(tvm).hexdigest()!=manifest['recovered_tvm_sha256']:raise ValueError('Recovered TVM hash mismatch')
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    for name,data in [('obt_TFOL.exe',raw),('OBT_original_code_rva_00001000.bin',code),('OBT_original_tvm_rva_0293b000.bin',tvm)]:
        path=out/name
        if path.exists() and path.read_bytes()!=data:raise ValueError('Refusing to replace different build input: '+name)
        path.write_bytes(data)
    return dict(original_sha256=manifest['source_sha256'],code_sha256=manifest['original_code_sha256'],tvm_sha256=manifest['recovered_tvm_sha256'])

if __name__=='__main__':
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--original',type=Path);g.add_argument('--baseline',type=Path)
    p.add_argument('--out',type=Path,default=ROOT.parent);args=p.parse_args()
    if args.original:print(json.dumps(recover(args.original,args.out),indent=2))
    else:
        image=PE(args.baseline);pinned=hashlib.sha256(image.b).hexdigest()
        release_manifest=json.loads((ROOT/'base_exe_manifest.json').read_text())
        current_release=pinned==release_manifest['exe_sha256']
        current=pinned=='f3d284d6f7d8807dbc833563829d5edef14cbf770e717aae0c99e835d3bcd7df'
        native30=pinned=='b560833e8006e9575d365dee47bbf94eca959e4e03530be0a808cb3a18b41eef'
        native27=pinned=='5451365a90b80d22b37fd9aa5791bcc124de83b48ccd74b160149b694763a29b'
        chosen=ROOT/'base_exe_manifest.json' if current_release else ROOT/'fixtures/obt30_manifest.json' if native30 else ROOT/'fixtures/obt27_manifest.json' if native27 else ROOT/'fixtures/obt25_manifest.json' if current else ROOT/'fixtures/obt23_manifest.json'
        manifest=json.loads(chosen.read_text())
        if pinned!=manifest['exe_sha256']:raise ValueError('Expected the current release or a pinned OBT23/25/27/30 image')
        code=bytearray(image.read(0x401000,32436224))
        for patch in manifest['patches']:
            at=int(patch['va'],16)-0x401000;before=bytes.fromhex(patch['before']);after=bytes.fromhex(patch['after'])
            if code[at:at+len(after)]!=after:raise ValueError('Baseline patch mismatch')
            code[at:at+len(before)]=before
        tvm=image.read(0x2d3b000,24576)
        if hashlib.sha256(code).hexdigest()!=manifest['original_code_sha256']:raise ValueError('Original code mismatch')
        if hashlib.sha256(tvm).hexdigest()!=manifest['recovered_tvm_sha256']:raise ValueError('Original TVM mismatch')
        args.out.mkdir(parents=True,exist_ok=True)
        for name,data in [('obt_current_recovered.exe' if current_release or native30 else 'obt27_recovered.exe' if native27 else 'obt25_recovered.exe' if current else 'obt23_recovered.exe',image.b),('OBT_original_code_rva_00001000.bin',code),('OBT_original_tvm_rva_0293b000.bin',tvm)]:
            target=args.out/name
            if target.exists() and target.read_bytes()!=data:raise ValueError('Refusing to replace a different build input')
            target.write_bytes(data)
        print(json.dumps(dict(baseline_sha256=manifest['exe_sha256'],original_code_sha256=manifest['original_code_sha256'])))
