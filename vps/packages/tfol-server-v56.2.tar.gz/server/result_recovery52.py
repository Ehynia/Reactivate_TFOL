"""OBT52 LOCAL UI recovery when the original OB15 result producer is absent.

A neutral, all-zero placeholder unlocks the native results screen ONLY; it is
not a GameStopInfo/AccBattleInfo snapshot, doesn't call economy.complete(),
doesn't persist wins/kills, and never grants tutorial completion.

A valid locally negotiated OB27 connection, acknowledged map travel and a
persisted round attempt are required. Hosted servers MUST NOT opt in.
"""
import time
from tdr_codec import packet,packets,decode_all


def notice(database,uid,context,*,source,now=None,min_age=0,reward_experience=0):
    if (source not in ('native_banner','native_tutorial_completion') or
        not context.get('local_ui_recovery52') or not context.get('native_bots') or
        not context.get('allow_local_rewards')):
        return b'',dict(status='disabled')
    match=context.get('engine_match') or {}
    rid=match.get('round_id')
    if (match.get('state')!='travel_dispatched' or match.get('action') not in (1,3) or not isinstance(rid,str) or
        not 16<=len(rid)<=80 or not isinstance(match.get('sequence'),int) or
        match.get('sequence',0)<=0):
        return b'',dict(status='unverified_round')
    with database.connect() as c:
        row=c.execute('SELECT uid,mode_id,started_at FROM round_attempts WHERE round_id=?',(rid,)).fetchone()
    t=time.time() if now is None else now
    age=t-row['started_at'] if row else -1
    if (not row or row['uid']!=uid or row['mode_id']!=match.get('mode') or
        age<min_age or age<0 or age>14400):
        return b'',dict(status='unverified_duration')
    if context.get('native_result_verified52')==rid:
        return b'',dict(status='real_native_result_already_received')
    if context.get('ui_placeholder_sent52')==rid:
        return b'',dict(status='duplicate')
    profile=database.profile(uid)
    hero=profile['selected_character_id']
    if not hero:
        return b'',dict(status='no_owned_character')
    # Do not infer winner or kills from a banner. 255 means unknown / no side.
    # Report only observed wall-clock duration to make the original native UI
    # leave its waiting state. The result's stats and bonuses are all zero.
    elapsed=max(1,min(86400,int(age)))
    value=dict(RoomSeq=match['sequence'],BattleInfo=dict(WinTeamId=255,TimeConsume=elapsed),
               Count=1,AccBattleInfo=[dict(Name=profile['nickname'],TeamId=255,Level=profile['level'],
                                           JijiaId=hero,Score=0,Kill=0,Dead=0,
                                           PveExp=reward_experience if match['mode']==3001 else 0)],
               ItemCount=0,ItemInfo=[],ActivityItemCount=0,ActivityItemList=[],
               FirstWinItemCount=0,FirstWinItemList=[],FirstWinMatchId=0,
               BonusCardItemCount=0,BonusCardItemList=[],RandomItemCount=0,
               RandomItemList=[],DeltaQualifyElo=0,DeltaQualifyWarrior=0,
               DeltaQualifyStar=0,NetbarItemCount=0,NetbarItemList=[])
    wire=packet(60,'SyncBattleInfo',value)
    frames=packets(wire)
    if len(frames)!=1 or frames[0][0]!=60:raise ValueError('Invalid local UI recovery frame')
    check=decode_all('SyncBattleInfo',frames[0][1])
    if (check['Count']!=1 or check['BattleInfo']['WinTeamId']!=255 or
        check['AccBattleInfo'][0]['Kill']!=0):
        raise ValueError('Local UI recovery must contain zero/unknown stats')
    # Mark only after serialization succeeds. Does not touch the reward DB.
    context['ui_placeholder_sent52']=rid
    return wire,dict(status='ui_placeholder_emitted',round_id=rid,source=source,
                     scoreboard_verified=False,win_claimed=False,kills_claimed=0,
                     credits_granted=0,experience_granted=0)
