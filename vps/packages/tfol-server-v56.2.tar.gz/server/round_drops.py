"""Experimental local Listen-Host round participation drops, independent of result tables.

A native authenticated bridge must acknowledge map travel. No server-authoritative
combat is implied. Hosted-preparation must not distribute untrusted drops.
"""
import time,hashlib,struct

MIGRATION='''
CREATE TABLE IF NOT EXISTS account_cards(uid INTEGER PRIMARY KEY REFERENCES players(uid),amount INTEGER NOT NULL DEFAULT 3 CHECK(amount BETWEEN 0 AND 9999));
CREATE TABLE IF NOT EXISTS round_attempts(round_id TEXT PRIMARY KEY,uid INTEGER NOT NULL REFERENCES players(uid),mode_id INTEGER NOT NULL,started_at REAL NOT NULL,ended_at REAL,reason TEXT,award_item_id INTEGER,awarded INTEGER NOT NULL DEFAULT 0 CHECK(awarded IN(0,1)));
CREATE INDEX IF NOT EXISTS idx_round_attempts_user ON round_attempts(uid,started_at);
CREATE TABLE IF NOT EXISTS round_items(uid INTEGER NOT NULL REFERENCES players(uid),resource_id INTEGER NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 0 AND 9999),PRIMARY KEY(uid,resource_id));
'''
RENAME_CARD_ID=601
# IDs are original ItemBonusCardTable.bytes entries. They are not newly invented assets.
DROP_IDS=(101,201)  # Double-XP card, Double-Coins card; unactivated consumables.
MIN_SECONDS=45
MAX_DAILY=20
COOLDOWN_SECONDS=60
# Modest participation coins earned for an *acknowledged, sufficiently long*
# local UE4 round even if native OB15 never reaches the server. This is not a
# per-kill claim or a fabricated victory. Daily/interval caps still apply.
# A validated OB15 credits much larger, uncapped-by-time kill rewards.
PARTICIPATION_CURRENCY={1:1,2:2,3:75,5:2,6:2}

def _item(uid,resource_id,count):
    """Stable native inventory entry; bag 3 is the original consumables bag."""
    return dict(Id=(1<<48)+(uid<<14)+resource_id,Category=3,Index=resource_id,Bag=3,Pos=(0 if resource_id==RENAME_CARD_ID else 1+DROP_IDS.index(resource_id)),Stack=count,
                Exp=0,WeaponCount=0,WeaponSlot=[],DecorateCount=0,DecorateSlot=[],CreateTime=0,DeadTime=0,BeginTime=0,EndTime=0,ExistType=0,Skin=0)

def bag_cards(database,uid):
    with database.connect() as c:
        row=c.execute('SELECT amount FROM account_cards WHERE uid=?',(uid,)).fetchone()
        result=[_item(uid,RENAME_CARD_ID,row['amount'])] if row and row['amount'] else []
        for r in c.execute('SELECT resource_id,amount FROM round_items WHERE uid=? ORDER BY resource_id',(uid,)):
            if r['amount']:result.append(_item(uid,r['resource_id'],r['amount']))
    return result

def track_started(database,uid,context,now=None):
    match=context.get('engine_match')
    if not match or match.get('state')!='travel_dispatched' or not match.get('round_id'):
        return False
    if now is None:now=time.time()
    with database.connect() as c:
        c.execute('INSERT OR IGNORE INTO round_attempts(round_id,uid,mode_id,started_at) VALUES(?,?,?,?)',
                  (match['round_id'],uid,match['mode'],now))
    return True

def settle_context(database,uid,context,reason='leave',now=None):
    """Grant at most one consolation item for a sufficiently long round.

    NEVER grants victory XP/currency, and never uses an unauthenticated packet
    as battle-proof. The same round_id can be retried after reconnect.
    """
    if not context or not context.get('allow_local_rewards',True):return dict(state='disabled')
    match=context.get('engine_match') if context else None
    if not match or match.get('state')!='travel_dispatched':return dict(state='no_active_round')
    return settle(database,uid,match.get('round_id'),reason,now)

def settle(database,uid,round_id,reason='leave',now=None):
    if not isinstance(round_id,str) or not 16<=len(round_id)<=80:raise ValueError('Invalid round identity')
    now=time.time() if now is None else now
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        current=c.execute('SELECT * FROM round_attempts WHERE round_id=? AND uid=?',(round_id,uid)).fetchone()
        if not current:return dict(state='not_recorded')
        if current['ended_at'] is not None:return dict(state='already_settled',item=current['award_item_id'])
        if now<current['started_at']+MIN_SECONDS:return dict(state='too_short')
        # Account, interval and UTC-day caps are enforced by the persistent ledger.
        today=int(now//86400)
        total=c.execute('SELECT count(*) FROM round_attempts WHERE uid=? AND awarded=1 AND CAST(ended_at/86400 AS INTEGER)=?',(uid,today)).fetchone()[0]
        latest=c.execute('SELECT max(ended_at) FROM round_attempts WHERE uid=? AND awarded=1',(uid,)).fetchone()[0]
        eligible=total<MAX_DAILY and (latest is None or now-latest>=COOLDOWN_SECONDS)
        item=DROP_IDS[int.from_bytes(hashlib.sha256(round_id.encode()).digest()[:2],'little')%len(DROP_IDS)] if eligible else None
        c.execute('UPDATE round_attempts SET ended_at=?,reason=?,award_item_id=?,awarded=? WHERE round_id=? AND ended_at IS NULL',
                  (now,reason,item,int(eligible),round_id))
        if item is not None:
            c.execute('INSERT INTO round_items(uid,resource_id,amount) VALUES(?,?,1) ON CONFLICT(uid,resource_id) DO UPDATE SET amount=min(9999,amount+1)',(uid,item))
            database.audit(c,uid,'consolation_drop',dict(round_id=round_id,item=item,reason=reason))
        else:database.audit(c,uid,'round_settled_without_drop',dict(round_id=round_id,reason=reason))
        currency_awards={}
        if eligible and database.progression_enabled:
            # Same SQLite transaction as round_attempts.awarded. A repeated
            # postmatch/exit/logout request can NEVER mint this reward twice.
            import economy
            for kind,amount in PARTICIPATION_CURRENCY.items():
                amount=max(0,min(amount,2_000_000_000-economy.balance(c,uid,kind)))
                if amount:
                    economy.adjust(c,uid,kind,amount)
                    currency_awards[str(kind)]=amount
            database.audit(c,uid,'verified_round_participation',
                           dict(round_id=round_id,awards=currency_awards,reason=reason))
        return dict(state='awarded' if eligible else 'limited',item=item,currency=currency_awards)
