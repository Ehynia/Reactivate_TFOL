"""Native UE4 results-banner observation, NOT a verified scoreboard.

This is a locally authenticated transport hint from the game's own UI code.
Only the original actual OB15 source may supply winner, kills, XP/scoreboard.
"""
import struct,time

MAGIC=b'R45E'
FRAME=struct.Struct('<4sII')


def consume(database,uid,context,body,*,now=None):
    if not context.get('allow_local_rewards') or not context.get('native_bots'):
        raise ValueError('Only local UE4 bridge may report a banner')
    if len(body)!=FRAME.size:
        raise ValueError('Unexpected end-marker length')
    magic,sequence,outcome=FRAME.unpack(body)
    if magic!=MAGIC or outcome not in (0,1,2) or sequence==0:
        raise ValueError('Invalid UE4 banner event')
    match=context.get('engine_match') or {}
    if (match.get('state')!='travel_dispatched' or
        match.get('sequence')!=sequence or not match.get('round_id') or
        match.get('action') not in (1,3)):
        raise ValueError('No matching acknowledged UE4 round')
    rid=match['round_id']
    with database.connect() as c:
        attempt=c.execute('SELECT started_at,uid,mode_id FROM round_attempts WHERE round_id=?',(rid,)).fetchone()
    t=time.time() if now is None else now
    if not attempt or attempt['uid']!=uid or attempt['mode_id']!=match.get('mode') or not 0<=t-attempt['started_at']<=14400:
        raise ValueError('No matching native round record')
    if context.get('ui_round_end45')==rid:
        return b'',dict(event='duplicate_ui_round_end',round_id=rid,
                        banner_outcome=outcome,verified_scoreboard=False)
    context['ui_round_end45']=rid
    context['ui_round_end_status45']=outcome
    # Authenticated UE4 HUD observation: settle the modest participation
    # consolation, but do NOT synthesize game results or per-kill values.
    # A later actual native kind7 OB15 can still be processed using engine_match.
    import round_drops
    settled=round_drops.settle_context(database,uid,context,reason='native_ui_round_end',now=t)
    # Offline-only XP is a small reward for locally observed match completion,
    # NOT a persisted win or a claim of kills. A later genuine OB15 reconciles
    # this XP so one round does not receive two completion bonuses.
    import banner_xp54
    bonus=banner_xp54.award(database,uid,context,outcome,now=t)
    # Local OBT cannot emit a true OB15 scoreboard yet. The game's own
    # native results-banner event is enough for a no-reward UI exit placeholder.
    # Keep hosted paths and older unnegotiated sessions unchanged.
    from result_recovery52 import notice
    reply,recovery=notice(database,uid,context,source='native_banner',now=t,reward_experience=bonus['experience'])
    pending=context.pop('completion_pending',None) if recovery['status']=='ui_placeholder_emitted' else None
    if recovery['status']=='ui_placeholder_emitted' and (pending or bonus['applied']):
        from tdr_codec import packet
        reply+=packet(177,'TutorialBattleRes',dict(Exp=bonus['experience'],SilverCoin=0,Result='ok'))
    if bonus['applied']:
        # Refresh XP currency, and only refresh gear when a new character
        # actually unlocked. Prevent bloating every postmatch reply.
        from tdr_codec import packet
        import garage
        if bonus.get('unlocked'):
            for number in (2,1):
                for item in garage.bag(database,uid,number):
                    reply+=packet(39,'SyncItemData',dict(Item=item))
        for item in garage.currency_bag(database,uid):
            if item['Index']==4:reply+=packet(39,'SyncItemData',dict(Item=item))
    if settled.get('state')=='awarded':
        import garage
        from tdr_codec import packet
        items=garage.bag(database,uid,3)
        reply+=packet(38,'SyncBagData',dict(BagIndex=3,Count=len(items),Items=items))
        for item in garage.currency_bag(database,uid):
            reply+=packet(39,'SyncItemData',dict(Item=item))
    return reply,dict(event='native_ui_round_end_observed',round_id=rid,
                       observed_ui_banner=['victory','defeat','tie'][outcome],
                       verified_scoreboard=False,scoreboard_pending_OB15=(context.get('native_result_verified52')!=rid),
                       ui_recovery=recovery['status'],settlement=settled.get('state'),currency=settled.get('currency',{}),
                       completion_xp=bonus['experience'],completion_xp_applied=bonus['applied'])
