"""Persist exact service regression results; Windows engine is not executed."""
import io,json
from pathlib import Path
import time
import unittest
from unittest.mock import patch

root=Path(__file__).parent
suite=unittest.defaultTestLoader.loadTestsFromNames(['test_obt_server','test_kernel','test_launcher_integration','test_local_world','test_reviewed21','test_obt22','test_obt23','test_match_host24','test_obt24','test_file_access25','test_bot_modes26','test_battle_flow27','test_accounts28','test_hotfix29','test_battle_init30','test_ui_translation31','test_pak_hotfix31a','test_obt32','test_merge33','test_translation34'])
started=time.perf_counter()
stream=io.StringIO()
with patch('news_feed.fetch',side_effect=OSError('offline test fixture')):
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(root/'TEST_RESULTS_34.txt').write_text(stream.getvalue(),encoding='utf-8')
value=dict(tests_run=result.testsRun,passed=result.wasSuccessful(),errors=len(result.errors),failures=len(result.failures),
           seconds=round(time.perf_counter()-started,3),windows_game_executed=False,gui_executed=False)
(root/'SERVICE_VALIDATION.json').write_text(json.dumps(value,indent=2))
print(json.dumps(value),flush=True)
for test,trace in result.failures+result.errors:print(str(test)+'\n'+trace,flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
