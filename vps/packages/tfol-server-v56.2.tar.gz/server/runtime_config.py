"""Fail-closed hosting preparation: transports remain loopback-only."""
import json
from pathlib import Path
DEFAULTS=dict(mode='local',require_account_keys=False,capture_packets=True,api_port=28000,tcp_port=28080,data_directory='data',
              local_test_matches=True,network_backend='asyncio',worker_threads=8,max_connections=256,capture_limit_mb=256,reddit_news_enabled=True,enable_local_banner_xp=True)
def load(path=None):
    values=dict(DEFAULTS)
    if path:
        data=json.loads(Path(path).read_text(encoding='utf-8'))
        if not isinstance(data,dict) or set(data)-set(DEFAULTS):raise ValueError('Unknown server configuration fields')
        values.update(data)
    if values['mode'] not in {'local','hosted-preparation'}:raise ValueError('Unsupported server mode')
    if values['network_backend'] not in {'asyncio','threaded'}:raise ValueError('Unsupported network backend')
    for key,maximum in [('worker_threads',32),('max_connections',4096),('capture_limit_mb',4096)]:
        if type(values[key]) is not int or not 1<=values[key]<=maximum:raise ValueError('Invalid '+key)
    for k in ['require_account_keys','capture_packets','local_test_matches','reddit_news_enabled','enable_local_banner_xp']:
        if type(values[k]) is not bool:raise ValueError('Expected boolean configuration')
    for k in ['api_port','tcp_port']:
        if type(values[k]) is not int or not 0<=values[k]<=65535:raise ValueError('Invalid configured port')
    if not isinstance(values['data_directory'],str) or not values['data_directory']:raise ValueError('Invalid data directory')
    if values['mode']=='hosted-preparation' and (not values['require_account_keys'] or values['capture_packets']):raise ValueError('Hosting preparation requires account keys and disabled packet capture')
    return values
