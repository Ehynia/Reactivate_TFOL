"""Future anti-cheat boundary for TFOL; NO protection is active in R18.

Does not impersonate Tencent, scan processes, install drivers, or attest a client.
Guest-session HMAC authentication happens before this API is evaluated.
"""
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class SecurityStatus:
    api_version: int = 1
    provider: str = "TFOL_OWN_SECURITY"
    lifecycle: str = "STUB_READY"
    implementation: str = "development_placeholder"
    enforcement_active: bool = False
    driver_loaded: bool = False
    monitoring_active: bool = False
    gameplay_gate_enabled: bool = False
    authenticates_users: bool = False
    legacy_anticheat: str = "not_shipped"
    future_provider: str = "not_integrated"
    client_attestation_verified: bool = False

    def public(self):
        return asdict(self)


class DevelopmentSecurityStub:
    """Replaceable API. No real anti-cheat is installed."""
    status = SecurityStatus()

    def after_guest_authentication(self, *, verified: bool) -> bool:
        # This interface may never convert a failed guest login into success.
        return bool(verified)

    def check_client(self, *, verified_guest: bool) -> dict:
        return {
            "allowed": bool(verified_guest),
            "reason": "development_only_no_anticheat" if verified_guest else "unauthorized",
            "anticheat_verified": False,
            "enforcement_active": False,
        }
