"""TFOL local guest sessions and framed TCP transport. No Tencent services."""
import argparse
import os
import datetime
import hashlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hmac
import json
from pathlib import Path
import secrets
import socket
import socketserver
import struct
import threading
import time

from game_protocol import handle as handle_game
import garage
from database import Database
import sqlite3
import accounts
import progression
import battle_statistics
import matchmaking
import runtime_config

from security_stub import DevelopmentSecurityStub

MAGIC=b'TF15';HEADER=struct.Struct('<4sBBH');SERVICE_ID=1
HELLO,ACCEPT,PING,PONG,APP_DATA,ERROR=1,2,3,4,5,127
APP_ACCEPT=6
LOCAL_RESULT=7  # Our authenticated bridge frame, never a Tencent message ID.
LOCAL_UI_ROUND_END=16  # Our observed UE4 results banner, no scoreboard content.
COMBAT_CAPS,COMBAT_ABORT=10,11  # Own bridge negotiation / failed capture exit.
MATCH_POLL,MATCH_STATE=8,9
PEER_BOUND=13
PEER_SNAPSHOT,PEER_RESTORE=14,15
VERSION=1;MAX_BODY=65535

def import_obt14_profile(database,path):
    """Import only the user's minimal OBT-14 identity, never a CBT catalog."""
    import shutil
    path=Path(path)
    if not path.exists():return
    value=json.loads(path.read_text('utf-8'))
    if value.get('format')!=1 or type(value.get('uid')) is not int or not 10001<=value['uid']<2**28:
        raise ValueError('Unsupported OBT14 identity')
    name=accounts.nickname(value.get('name'))
    created=value.get('created_at')
    if type(created) is not int or not 0<created<=time.time()+86400:raise ValueError('Invalid identity creation date')
    with database.connect() as c:
        found=c.execute('SELECT uid,nickname FROM players WHERE uid=? OR nickname=?',(value['uid'],name)).fetchall()
        if found and any((r['uid'],r['nickname'])!=(value['uid'],name) for r in found):
            raise ValueError('OBT14 identity conflicts with existing account')
        if found:return
        backup=database.path.parent/'imported_OBT14_player.json'
        if not backup.exists():shutil.copy2(path,backup)
        c.execute('INSERT INTO players(uid,nickname,created_at) VALUES(?,?,?)',(value['uid'],name,created))
        c.execute('INSERT INTO account_identity(uid,login,created_at) VALUES(?,?,?)',(value['uid'],name,created))
        database.audit(c,value['uid'],'obt14_identity_imported',dict(format=1))

def frame(kind,body=b''):
    if len(body)>MAX_BODY:raise ValueError('Frame too large')
    return HEADER.pack(MAGIC,VERSION,kind,len(body))+body

def read_exact(sock,n):
    data=bytearray()
    while len(data)<n:
        part=sock.recv(n-len(data))
        if not part:raise EOFError()
        data.extend(part)
    return bytes(data)

def read_frame(sock):
    magic,version,kind,n=HEADER.unpack(read_exact(sock,HEADER.size))
    if magic!=MAGIC or version!=VERSION:raise ValueError('Unknown transport')
    return kind,read_exact(sock,n)

class State:
    def __init__(self,folder,tcp_port,clock=time.time,config=None,progression_enabled=True,legacy_profile=None):
        self.config=dict(runtime_config.DEFAULTS);self.config.update(config or {})
        self.login_limiter=accounts.LoginLimiter(clock)
        self.registration_limiter=accounts.LoginLimiter(clock)
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.clock=clock;self.tcp_port=tcp_port
        self.players_path=self.folder/'players.json'
        self.database=Database(self.folder/'server.sqlite3',self.players_path,progression_enabled=progression_enabled)
        garage.install(self.database)
        if legacy_profile:
            import_obt14_profile(self.database,legacy_profile)
        self.players=self.database.aliases()
        self.sessions={};self.connections=0;self.application_payloads=0;self.clients=set();self.security=DevelopmentSecurityStub()
        from kernel_metrics import Metrics
        from event_journal import Journal
        self.metrics=Metrics();self.journal=Journal(self.folder,self.metrics)
        self.capture_bytes=sum(p.stat().st_size for p in (self.folder/'captures').glob('*/*.bin'))
        self.matchmaking=matchmaking.Queue(event=self.event,peer_enabled=self.config['mode']=='local')
        from local_simulation import Matches
        self.simulation=Matches(self.database,self.config['local_test_matches'] and self.config['mode']=='local',clock=self.clock,event=self.event)
        from webadmin import Admin
        self.admin=Admin(self)
        from news_feed import Service
        self.news=Service(self.folder,self.database,enabled=self.config['reddit_news_enabled'])
    def event(self,event,**fields):
        self.journal.write(event,**fields)
    def register_account(self,login,address='local'):
        if self.config['mode']!='local':raise accounts.RegistrationError('Self-registration is local Test Node only')
        with self.lock:
            if not self.registration_limiter.allowed(address):raise accounts.AuthenticationError('Too many registration attempts; try again in one minute')
            self.registration_limiter.fail(address)
            result=accounts.register(self.database,login)
            garage.provision(self.database,result['user_id'])
            self.players=self.database.aliases()
            return result
    def create_session(self,nick,account_key=None,address='local',require_password=False):
        nick=accounts.nickname(nick)
        with self.lock:
            if not self.login_limiter.allowed(address):raise accounts.AuthenticationError('Too many attempts; try again later')
            try:uid,guest=accounts.login(self.database,nick,account_key,self.config['require_account_keys'] or require_password)
            except accounts.AuthenticationError:
                self.login_limiter.fail(address);raise
            with self.database.connect() as c:
                if c.execute('SELECT 1 FROM admin_bans WHERE uid=?',(uid,)).fetchone():raise accounts.AuthenticationError('Account is banned')
            # v56: only successful local authenticated logins may auto-complete
            # onboarding from persisted money. No client-supplied balance.
            if self.config['mode']=='local':accounts.complete_tutorial_for_funded_account(self.database,uid)
            self.login_limiter.success(address)
            game_name=self.database.profile(uid)['nickname']
            self.players[game_name]=uid
            garage.provision(self.database,uid)
            token=secrets.token_bytes(32);key=secrets.token_bytes(16)
            self.sessions[token.hex()]=dict(uid=uid,key=key,expires=self.clock()+1800,nick=nick)
            self.database.add_session(token,key,uid,self.sessions[token.hex()]['expires'])
            self.event('local_session_created',uid=uid,session_fingerprint=hashlib.sha256(token).hexdigest()[:16])
            return dict(user_id=uid,service_id=SERVICE_ID,token_hex=token.hex(),login_key_hex=key.hex(),
                expires_utc=self.sessions[token.hex()]['expires'],host='127.0.0.1',port=self.tcp_port,
                world_name='TFOL Local',protocol='TF15',guest_session=guest,gameplay_verified=False)
    def authenticate(self,body):
        if len(body)!=56:return None
        uid,service=struct.unpack_from('<II',body);token=body[8:40];key=body[40:56]
        with self.lock:
            cached=self.sessions.get(token.hex())
            if cached and cached['expires']<=self.clock():return None
            session=self.database.session(token,self.clock(),key)
            if not session or session['uid']!=uid or service!=SERVICE_ID:return None
            if not self.security.after_guest_authentication(verified=True):return None
            return dict(uid=uid,key=key,expires=session['expires_at'],state=struct.pack('<5I',uid,1,0,0,VERSION))
    def revoke(self,token):
        with self.lock:
            self.database.revoke(bytes.fromhex(str(token)))
            self.sessions.pop(str(token),None)
    def renew_active(self,body):
        now=self.clock();expires=now+1800
        token=body[8:40]
        with self.lock,self.database.connect() as c:
            changed=c.execute('UPDATE sessions SET expires_at=? WHERE token_hash=? AND revoked=0 AND expires_at>?',(expires,hashlib.sha256(token).hexdigest(),now)).rowcount
            if not changed:raise ValueError('Session cannot be renewed')
            cached=self.sessions.get(token.hex())
            if cached:cached['expires']=expires
        return expires

class TCP(socketserver.ThreadingTCPServer):
    allow_reuse_address=True;daemon_threads=True

class TCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        state=self.server.state;self.request.settimeout(self.server.handshake_timeout);uid=None;counted=False
        connection_id=secrets.token_hex(8);sequence=0;reason="peer_closed";context=dict(matchmaking=state.matchmaking,connection_id=connection_id,allow_local_rewards=state.config['mode']=='local',local_banner_reward54=(state.config['mode']=='local' and state.config.get('enable_local_banner_xp',False)))
        if state.simulation.enabled:context['local_simulation']=state.simulation
        try:
            kind,body=read_frame(self.request)
            auth_body=body
            authenticated=state.authenticate(body) if kind==HELLO else None
            if not authenticated:
                reason='auth_rejected';self.request.sendall(frame(ERROR,struct.pack('<I',1)));state.event('transport_auth_rejected');return
            uid=authenticated['uid'];self.request.sendall(frame(ACCEPT,authenticated['state']+authenticated['key']))
            with state.lock:state.connections+=1;counted=True;state.clients.add(self.request)
            state.event('transport_authenticated',uid=uid,connection_id=connection_id,phase='awaiting_game_payload')
            while True:
                remaining=authenticated['expires']-state.clock()
                if remaining<=0:reason='session_expired';break
                self.request.settimeout(min(self.server.idle_timeout,remaining))
                kind,body=read_frame(self.request)
                if not state.authenticate(auth_body):reason='session_rejected';self.request.sendall(frame(ERROR,struct.pack('<I',1)));break
                if authenticated['expires']-state.clock()<900:
                    authenticated['expires']=state.renew_active(auth_body)
                if kind==PING and not body:
                    job=__import__('native_bots').poll(state.database,uid,context) if context.get('native_bots') and context.get('logged_in') else b''
                    self.request.sendall(frame(PONG,job))
                elif kind==APP_DATA:
                    sequence+=1
                    capture=state.folder/'captures'/connection_id
                    filename=f'{sequence:06d}.bin'
                    target=capture/filename
                    if state.config['capture_packets']:
                        capture.mkdir(parents=True,exist_ok=True)
                        temporary=target.with_suffix('.tmp');temporary.write_bytes(body);temporary.replace(target)
                    with state.lock:state.application_payloads+=1
                    try:
                        response,details=handle_game(state.database,uid,body,lobby_port=state.tcp_port,local_rewards=state.config['mode']=='local',context=context)
                        if response is not None and context.get('native_bots') and context.get('logged_in'):
                            response+=__import__('native_bots').poll(state.database,uid,context)
                    except (ValueError,KeyError,UnicodeError,struct.error) as error:
                        details=dict(handler_implemented=False,transport_accepted=False,error=type(error).__name__)
                        response=None
                    if response is not None and len(response)>65535:
                        response=None;details=dict(handler_implemented=False,transport_accepted=False,error='reply_bundle_too_large')
                    state.event('game_application_payload',uid=uid,connection_id=connection_id,sequence=sequence,
                        capture=str(target.relative_to(state.folder)) if state.config['capture_packets'] else None,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),
                        hex=body[:4096].hex() if state.config['capture_packets'] else None,full_payload_logged=state.config['capture_packets'] and len(body)<=4096,**details)
                    if response is None:self.request.sendall(frame(ERROR,struct.pack('<I',2)))
                    else:
                        reply_target=None
                        if response and state.config['capture_packets']:
                            reply_target=capture/f'{sequence:06d}.reply.bin'
                            temporary=reply_target.with_suffix('.tmp');temporary.write_bytes(response);temporary.replace(reply_target)
                        self.request.sendall(frame(APP_ACCEPT,response))
                        if response:state.event('game_application_reply',uid=uid,connection_id=connection_id,sequence=sequence,command=details['command'],capture=str(reply_target.relative_to(state.folder)) if reply_target else None,bytes=len(response),sha256=hashlib.sha256(response).hexdigest())
                elif kind==12:
                    try:details=__import__('native_bots').status(context,body)
                    except ValueError:self.request.sendall(frame(ERROR,struct.pack('<I',2)))
                    else:
                        if details['travel_dispatched'] and context.get('allow_local_rewards'):
                            import round_drops
                            round_drops.track_started(state.database,uid,context)
                        state.event('native_engine_travel_status',uid=uid,**details)
                        response=b'' if details['travel_dispatched'] else __import__('tdr_codec').packet(66,'RoomMatchRes',dict(PredictedTime=0,Result='server_unavailable'))
                        self.request.sendall(frame(APP_ACCEPT,response))
                elif kind==COMBAT_CAPS and body==b'OB27':
                    context['native_bots']=True
                    context['local_ui_recovery52']=state.config['mode']=='local'
                    self.request.sendall(frame(APP_ACCEPT))
                elif kind==COMBAT_CAPS and body==b'OB15':
                    context['deferred_combat']=True
                    context['peer_capable']=False
                    self.request.sendall(frame(APP_ACCEPT))
                elif kind==PEER_BOUND:
                    try:
                        if not context.get('peer_capable') or len(body)!=14:raise ValueError('Invalid readiness')
                        magic,ident,port=struct.unpack('<4sQH',body)
                        with state.matchmaking.lock:
                            if magic==b'R31B':state.matchmaking.peers.bound(uid,connection_id,ident,port)
                            elif magic==b'R31D':
                                room=state.matchmaking.peers.get(uid,connection_id)
                                if room.id!=ident or room.port!=port:raise ValueError('Assignment mismatch')
                                state.matchmaking.cancel(uid,connection_id)
                            else:raise ValueError('Invalid readiness')
                    except ValueError:self.request.sendall(frame(ERROR,struct.pack('<I',2)))
                    else:self.request.sendall(frame(APP_ACCEPT))
                elif kind==COMBAT_CAPS and body==b'R32P':
                    if state.config['mode']!='local':self.request.sendall(frame(ERROR,struct.pack('<I',2)))
                    else:
                        context['peer_capable']=True
                        self.request.sendall(frame(APP_ACCEPT))
                elif kind in (PEER_SNAPSHOT,PEER_RESTORE):
                    try:
                        if not context.get('peer_capable'):raise ValueError('Peer capability not negotiated')
                        if kind==PEER_SNAPSHOT:
                            if len(body)<21 or body[:4]!=b'R32S':raise ValueError('Invalid checkpoint')
                            room_id,epoch,sequence=struct.unpack_from('<QII',body,4)
                            with state.matchmaking.lock:
                                state.matchmaking.peers.publish_snapshot(uid,connection_id,room_id,epoch,sequence,body[20:])
                            response=b''
                        else:
                            if len(body)!=16 or body[:4]!=b'R32R':raise ValueError('Invalid restore')
                            room_id,epoch=struct.unpack_from('<QI',body,4)
                            with state.matchmaking.lock:
                                sequence,snapshot=state.matchmaking.peers.migration_checkpoint(uid,connection_id,room_id,epoch)
                            response=b'R32R'+struct.pack('<QII',room_id,epoch,sequence)+snapshot
                    except ValueError:self.request.sendall(frame(ERROR,struct.pack('<I',2)))
                    else:self.request.sendall(frame(APP_ACCEPT,response))
                elif kind==COMBAT_ABORT and body==b'R30A':
                    pending=context.pop('completion_pending',None)
                    from game_protocol import packet
                    response=packet(177,'TutorialBattleRes',dict(Exp=0,SilverCoin=0,Result='ok')) if pending else b''
                    self.request.sendall(frame(APP_ACCEPT,response));state.event('native_result_capture_aborted',uid=uid)
                elif kind==LOCAL_UI_ROUND_END:
                    try:
                        from round_end45 import consume
                        response,details=consume(state.database,uid,context,body)
                    except (ValueError,KeyError,struct.error):
                        state.event('native_ui_round_end_rejected',uid=uid,reason='invalid_or_unmatched_banner')
                        self.request.sendall(frame(ERROR,struct.pack('<I',2)));continue
                    state.event(details['event'],uid=uid,**{k:v for k,v in details.items() if k!='event'})
                    self.request.sendall(frame(APP_ACCEPT,response))
                elif kind==LOCAL_RESULT:
                    try:
                        response,details=battle_statistics.handle_snapshot(state.database,uid,body,context,local=state.config['mode']=='local')
                    except (ValueError,KeyError,UnicodeError,struct.error):
                        if context.pop('completion_pending',None):
                            from game_protocol import packet
                            self.request.sendall(frame(APP_ACCEPT,packet(177,'TutorialBattleRes',dict(Exp=0,SilverCoin=0,Result='ok'))))
                        else:self.request.sendall(frame(ERROR,struct.pack('<I',2)))
                        state.event('native_result_rejected',uid=uid,reason='missing_or_invalid_OB15_snapshot');continue
                    self.request.sendall(frame(APP_ACCEPT,response));state.event('native_result_persisted',uid=uid,**details)
                elif kind==MATCH_POLL and body in (b'',b'\1'):
                    if body:state.matchmaking.cancel(uid,connection_id)
                    decision=state.matchmaking.poll(uid,connection_id)
                    self.request.sendall(frame(MATCH_STATE,matchmaking.poll_response(state.database,decision,uid)))
                else:reason='protocol_error';self.request.sendall(frame(ERROR,struct.pack('<I',3)));break
        except (EOFError,OSError,ValueError) as error:
            reason=('session_expired' if uid is not None and authenticated['expires']<=state.clock() else 'idle_timeout') if isinstance(error,socket.timeout) else type(error).__name__
        finally:
            if uid is not None:
                try:
                    import round_drops
                    round_drops.settle_context(state.database,uid,context,reason='disconnect')
                except (ValueError,sqlite3.Error) as error:state.event('round_drop_error',uid=uid,error=type(error).__name__)
                state.matchmaking.cancel(uid,connection_id)
            state.event('transport_closed',uid=uid,connection_id=connection_id,reason=reason,application_payloads=sequence)
            if counted:
                with state.lock:state.connections-=1;state.clients.discard(self.request)

class HTTPHandler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def send_json(self,status,data):
        raw=json.dumps(data,ensure_ascii=False).encode();self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def do_GET(self):
        state=self.server.state
        if self.path.startswith('/admin'):
            state.admin.http_get(self);return
        if self.path=='/health':self.send_json(200,dict(server='TFOL_OBT_LOCAL',release='OBT33',api_version=1,protocol='TF15',tcp_port=state.tcp_port,windows_lobby_verified=False,baseline_obt13_windows_lobby_verified=True,gameplay_verified=False))
        elif self.path in ('/capabilities','/v1/capabilities'):
            import capabilities
            self.send_json(200,capabilities.describe())
        elif self.path=='/auth/mode':self.send_json(200,dict(require_account_keys=state.config['require_account_keys'],self_registration_enabled=state.config['mode']=='local',login_is_game_nickname=False,password_generation='server_random_256_bits',nickname_after_megatron_tutorial=True,nickname_on_first_login=False,automatic_tutorial_and_first_name_flow_complete=False))
        elif self.path=='/security/status':self.send_json(200,state.security.status.public())
        elif self.path=='/status':
            with state.lock:self.send_json(200,dict(connections=state.connections,guest_sessions=len(state.sessions),players=len(state.players),application_payloads=state.application_payloads,game_application_handlers_implemented=True,all_game_functions_verified=False,implemented_commands=sorted(set(__import__('game_protocol').REQUESTS)|set(__import__('obt_handlers').REQUESTS))))
        elif self.path=='/database/status':self.send_json(200,state.database.status())
        elif self.path=='/maps':self.send_json(200,dict(maps=garage.maps(state.database)))
        elif self.path=='/news':self.send_json(200,dict(news=state.database.news()))
        elif self.path=='/skins':
            session=self.authorized_session()
            if session:
                import skin_shop
                self.send_json(200,skin_shop.catalog(state.database,session['uid']))
        elif self.path=='/catalog':self.send_json(200,dict(resources=state.database.catalog()))
        elif self.path=='/profile':
            session=self.authorized_session()
            if session:self.send_json(200,state.database.profile(session['uid']))
        elif self.path=='/progression':
            session=self.authorized_session()
            if session:self.send_json(200,progression.status(state.database,session['uid']))
        elif self.path in {'/test-match','/first-quest'}:
            session=self.authorized_session()
            if session:
                import local_simulation
                self.send_json(200,dict(match=state.simulation.poll(session['uid']),quest=local_simulation.quest(state.database,session['uid']),progression=progression.status(state.database,session['uid'])))
        elif self.path=='/worlds':self.send_json(200,dict(worlds=[dict(id=1,name='TFOL Local',host='127.0.0.1',port=state.tcp_port)],gameplay_verified=False))
        else:self.send_json(404,dict(error='not_found'))
    def authorized_session(self):
        header=self.headers.get('Authorization','')
        try:
            if not header.startswith('Bearer '):raise ValueError('Missing session')
            token=bytes.fromhex(header[7:])
            if len(token)!=32:raise ValueError('Invalid token')
            session=self.server.state.database.session(token,self.server.state.clock())
            if not session:raise ValueError('Expired or revoked session')
            return session
        except ValueError as error:self.send_json(401,dict(error=str(error)));return None
    def do_POST(self):
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=4096:raise ValueError('Invalid body size')
            data=json.loads(self.rfile.read(n))
            if not isinstance(data,dict):raise ValueError('Expected JSON object')
            if self.path.startswith('/admin'):
                self.server.state.admin.http_post(self,data);return
            if self.path in {'/session','/auth/login'}:
                if type(data.get('require_password',False)) is not bool:raise ValueError('Invalid authentication mode')
                self.send_json(201,self.server.state.create_session(data.get('login',data.get('nickname','')),data.get('password',data.get('account_key')),self.client_address[0],data.get('require_password',False)))
            elif self.path=='/auth/register':
                if set(data)!={'login'}:raise ValueError('Registration accepts only an account login; password is generated by the server')
                self.send_json(201,self.server.state.register_account(data['login'],self.client_address[0]))
            elif self.path=='/internal/tutorial/complete':
                secret=os.environ.get('TFOL_MATCH_SERVICE_TOKEN','')
                if len(secret)<32 or not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+secret):
                    self.send_json(403,dict(error='trusted_mission_verification_required'));return
                uid=data.get('user_id')
                if type(uid)!=int or uid<=0:raise ValueError('Invalid player ID')
                self.send_json(200,dict(applied=accounts.confirm_tutorial(self.server.state.database,uid,data.get('event_id'),data.get('mission'))))
            elif self.path in {'/internal/matches/complete','/internal/matchmaking/worker-ready'}:
                secret=os.environ.get('TFOL_MATCH_SERVICE_TOKEN','')
                header=self.headers.get('Authorization','')
                if len(secret)<32 or not hmac.compare_digest(header,'Bearer '+secret):
                    self.send_json(403,dict(error='trusted_match_service_required'));return
                if self.path=='/internal/matchmaking/worker-ready':
                    self.server.state.matchmaking.register_worker(data.get('worker_id'),data.get('room'),data.get('match_id',0),data.get('competition',0))
                    self.send_json(200,dict(registered=True,lease_seconds=30));return
                uid=data.get('user_id')
                if type(uid)!=int or uid<=0:raise ValueError('Invalid player ID')
                result=progression.reward(self.server.state.database,uid,data.get('event_id'),data.get('experience'),'trusted-match-service')
                self.send_json(200,dict(**result,progression=progression.status(self.server.state.database,uid)))
            elif self.path=='/client/maps-verified':
                session=self.authorized_session()
                if session:
                    ids=data.get('map_ids')
                    if not isinstance(ids,list) or any(type(i)!=int for i in ids):raise ValueError('Invalid map availability')
                    known={m['map_id'] for m in garage.RESOURCES['maps']}
                    if set(ids)-known:raise ValueError('Unknown map ID')
                    with self.server.state.database.connect() as c:
                        for ident in known:c.execute('UPDATE maps SET available=? WHERE map_id=?',(int(ident in ids),ident))
                    self.send_json(200,dict(verified=len(ids)))
            elif self.path=='/skins/buy':
                session=self.authorized_session()
                if session:
                    import skin_shop,economy
                    try:value=skin_shop.purchase(self.server.state.database,session['uid'],data.get('goods_id'),data.get('equip',True),data.get('currency',3))
                    except economy.PurchaseError as err:raise ValueError(str(err)) from err
                    self.send_json(200,value)
            elif self.path in {'/test-match/start','/test-match/cancel','/first-quest/claim'}:
                session=self.authorized_session()
                if session:
                    uid=session['uid'];state=self.server.state
                    if self.path=='/test-match/start':value=state.simulation.start(uid,'http',data.get('mode_id',1002))
                    elif self.path=='/test-match/cancel':value=state.simulation.cancel(uid)
                    else:
                        import local_simulation
                        value=local_simulation.claim(state.database,uid,data.get('group',0))
                    self.send_json(200,value)
            elif self.path=='/logout':self.server.state.revoke(data.get('token_hex',''));self.send_json(200,dict(revoked=True))
            elif self.path=='/maps/select':
                session=self.authorized_session()
                if session:
                    garage.select_map(self.server.state.database,session['uid'],data.get('map_id'))
                    self.send_json(200,dict(selected_map_id=data.get('map_id')))
            elif self.path=='/character/select':
                session=self.authorized_session()
                if session:
                    self.server.state.database.select_character(session['uid'],data.get('resource_id'))
                    self.send_json(200,self.server.state.database.profile(session['uid']))
            elif self.path=='/equipment':
                session=self.authorized_session()
                if session:
                    self.server.state.database.equip(session['uid'],data.get('character_id'),data.get('slot'),data.get('item_id'))
                    self.send_json(200,self.server.state.database.profile(session['uid']))
            else:self.send_json(404,dict(error='not_found'))
        except accounts.RegistrationError as error:self.send_json(409,dict(error=str(error)))
        except accounts.AuthenticationError:self.send_json(401,dict(error='Неверный логин/пароль или слишком много попыток / Invalid login/password or too many attempts'))
        except (ValueError,TypeError,sqlite3.IntegrityError) as error:self.send_json(400,dict(error=str(error)))

class App:
    def __init__(self,folder,api_port=28000,tcp_port=28080,handshake_timeout=30,idle_timeout=1800,config=None,progression_enabled=True,legacy_profile=None):
        if handshake_timeout<=0 or idle_timeout<=0:raise ValueError("Timeouts must be positive")
        from instance_lock import InstanceLock
        self.ownership=InstanceLock(folder)
        try:self.state=State(folder,tcp_port,config=config,progression_enabled=progression_enabled,legacy_profile=legacy_profile)
        except Exception:
            self.ownership.close();raise
        self.tcp=None;self.http=None;self.threads=[];self.closed=False
        try:
            from async_transport import TCP as AsyncTCP
            transport=AsyncTCP if self.state.config['network_backend']=='asyncio' else TCP
            self.tcp=transport(('127.0.0.1',tcp_port),TCPHandler);self.state.tcp_port=self.tcp.server_address[1];self.tcp.state=self.state
            self.tcp.handshake_timeout=handshake_timeout;self.tcp.idle_timeout=idle_timeout
            self.http=ThreadingHTTPServer(('127.0.0.1',api_port),HTTPHandler);self.http.state=self.state
        except Exception:
            if self.tcp:self.tcp.server_close()
            self.state.database.close()
            self.state.journal.close()
            self.ownership.close()
            raise
        self.api_port=self.http.server_address[1]
    def start(self):
        for server in [self.tcp,self.http]:
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();self.threads.append(thread)
        if hasattr(self.tcp,'started') and not self.tcp.started.wait(5):raise RuntimeError('Network startup failed')
        self.state.news.start()
        self.state.event('server_started',api_port=self.api_port,tcp_port=self.state.tcp_port,handshake_timeout=self.tcp.handshake_timeout,idle_timeout=self.tcp.idle_timeout)
        return self
    def close(self):
        if self.closed:return
        self.closed=True
        with self.state.lock:clients=list(self.state.clients)
        for client in clients:
            try:client.shutdown(socket.SHUT_RDWR)
            except OSError:pass
        for server in [self.http,self.tcp]:
            if self.threads:server.shutdown()
            server.server_close()
        for thread in self.threads:thread.join(timeout=30)
        if any(thread.is_alive() for thread in self.threads):raise RuntimeError('Server shutdown did not complete')
        self.state.news.close()
        self.state.database.close()
        self.state.journal.flush();self.state.journal.close()
        self.ownership.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--api-port',type=int);parser.add_argument('--tcp-port',type=int)
    parser.add_argument('--data',type=Path);parser.add_argument('--config',type=Path)
    args=parser.parse_args();config=runtime_config.load(args.config)
    folder=args.data or Path(__file__).resolve().parent/config['data_directory']
    # NEVER wipe/rotate accounts automatically when a daemon starts.
    # account_reset.py is an explicit operator-only utility.
    app=App(folder,args.api_port if args.api_port is not None else config['api_port'],args.tcp_port if args.tcp_port is not None else config['tcp_port'],config=config).start()
    print('Local API: http://127.0.0.1:'+str(app.api_port));print('Game transport: 127.0.0.1:'+str(app.state.tcp_port))
    try:threading.Event().wait()
    except KeyboardInterrupt:pass
    finally:app.close()
