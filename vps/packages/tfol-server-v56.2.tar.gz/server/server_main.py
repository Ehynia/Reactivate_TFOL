"""Stable server CLI for an independently developed launcher."""
import argparse,json,threading,sys,os
from pathlib import Path
from server import App
from client_file_access import write_text as write_managed_text

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--api-port',type=int,default=0)
    parser.add_argument('--tcp-port',type=int,default=0)
    parser.add_argument('--import-obt14-profile',type=Path)
    parser.add_argument('--ready-file',type=Path)
    parser.add_argument('--stdin-control',action='store_true')
    parser.add_argument('--config',type=Path)
    parser.add_argument('--open-admin',action='store_true')
    args=parser.parse_args()
    import runtime_config
    from account_reset import reset
    reset(args.data,args.import_obt14_profile)
    args.import_obt14_profile=None
    app=App(args.data,args.api_port,args.tcp_port,config=runtime_config.load(args.config),legacy_profile=args.import_obt14_profile).start()
    ready=dict(event='ready',pid=os.getpid(),api_version=1,release='OBT33',api_url='http://127.0.0.1:'+str(app.api_port),tcp_host='127.0.0.1',tcp_port=app.state.tcp_port,data_dir=str(args.data.resolve()))
    ready['admin_url']=ready['api_url']+'/admin/'
    args.ready_file=args.ready_file or args.data/'server.ready.json'
    if args.ready_file:
        args.ready_file.parent.mkdir(parents=True,exist_ok=True)
        write_managed_text(args.ready_file,json.dumps(ready))
    print(json.dumps(ready),flush=True)
    if args.open_admin:
        from open_admin import open_panel
        open_panel(args.data)
    stopped=threading.Event()
    if args.stdin_control:
        def control():
            for line in sys.stdin:
                try:value=json.loads(line)
                except ValueError:continue
                if value=={'command':'stop'}:stopped.set();return
                if isinstance(value,dict) and value.get('command')=='admin':
                    try:result=app.state.admin.execute(value.get('name'),value.get('arguments',{}),value.get('request_id'))
                    except (ValueError,TypeError) as error:result=dict(error=str(error))
                    print(json.dumps(dict(event='admin_result',**result)),flush=True)
            stopped.set()
        threading.Thread(target=control,daemon=True).start()
    try:stopped.wait()
    except KeyboardInterrupt:pass
    finally:
        app.close()
        args.ready_file.unlink(missing_ok=True)

if __name__=='__main__':main()
