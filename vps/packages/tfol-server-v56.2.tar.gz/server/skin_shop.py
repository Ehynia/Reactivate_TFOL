"""Player-owned skin purchases. Credits (3) or battle tickets (6) are accepted; rewards are owned by the server."""
import economy,garage

def catalog(db,uid):
    p=db.profile(uid)
    with db.connect() as c:
        owned={(r['category'],r['resource_id']) for r in c.execute('SELECT category,resource_id FROM inventory WHERE uid=?',(uid,))}
        skins={(r['category'],r['resource_id']) for r in c.execute('SELECT category,resource_id FROM obt_skins WHERE uid=?',(uid,))}
        equipped={r[0] for r in c.execute('SELECT skin_item FROM obt_skin_equipment WHERE uid=?',(uid,))}
        ids={(r['category'],r['resource_id']):r['item_id'] for r in c.execute('SELECT * FROM obt_skins WHERE uid=?',(uid,))}
        tickets=c.execute('SELECT amount FROM obt_currency WHERE uid=? AND currency=6',(uid,)).fetchone()
        tickets=tickets[0] if tickets else 0
    meta={(s['category'],s['resource_id']):s for s in garage.RESOURCES['skins']};rows=[]
    for g in economy.goods():
        if g['Category'] not in (10,11):continue
        s=meta[g['Category'],g['Index']];key=(g['Category'],g['Index'])
        rows.append(dict(goods_id=g['Id'],name=s['name'],category=s['category'],skin_id=s['resource_id'],base_id=s['base_id'],
                         base_owned=(1 if s['category']==10 else 2,s['base_id']) in owned,owned=key in skins,equipped=ids.get(key) in equipped,
                         price=g['PriceOne'],tickets=g['PriceTwo'],currency=3))
    return dict(uid=uid,nickname=p['nickname'],credits=p['credits'],tickets=tickets,skins=rows)

def purchase(db,uid,ident,equip=True,currency=3):
    if type(ident) is not int or type(equip) is not bool or type(currency) is not int or currency not in (3,6):
        raise ValueError('Invalid skin purchase')
    g=next((g for g in economy.goods() if g['Id']==ident and g['Category'] in (10,11)),None)
    if not g:raise ValueError('Unknown skin')
    price=g['PriceOne'] if currency==3 else g['PriceTwo']
    with db.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        item,applied=economy.buy_skin_in(db,c,uid,dict(Id=ident,Payment=currency,Price=price,ItemInfo=dict(Category=g['Category'],Index=g['Index'],Count=1)))
        if equip:
            s=next(s for s in garage.RESOURCES['skins'] if s['category']==g['Category'] and s['resource_id']==g['Index'])
            holder=c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=? AND resource_id=?',(uid,1 if s['category']==10 else 2,s['base_id'])).fetchone()
            if not holder:raise ValueError('Base character or weapon is not owned')
            c.execute('INSERT INTO obt_skin_equipment VALUES(?,?,?) ON CONFLICT(uid,holder_item) DO UPDATE SET skin_item=excluded.skin_item',(uid,holder[0],item))
        return dict(purchased=applied,equipped=equip,skin_item=item,currency=currency)
