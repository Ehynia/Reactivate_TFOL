"""Native OBT Spark tab recovery, using ORIGINAL SparkGridTable and scheme prices.

This module restores the server's unlock snapshot, per-owner Spark items, and
purchases.  It does not modify UE4 cooked UI and does not claim the tab is
unlocked by native code until Windows is tested.
"""
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'resources'
STARTER_GRID_IDS = (1, 10, 19)  # each original color, as in the old v26.2 build
STARTER_ITEM_IDS = (20101, 20201, 20301)


def _table(filename, width, fmt):
    blob = (ROOT / filename).read_bytes()
    record_size, count = struct.unpack_from('<II', blob, 8)
    if record_size != width or count > 250 or len(blob) < 140 + width * count:
        raise ValueError('Unexpected original Spark table layout: ' + filename)
    return [struct.unpack_from(fmt, blob, 140 + i * width) for i in range(count)]


GRID_ROWS = {
    gid: dict(id=gid, type=type_id, unlock_level=level, raw_aux=(a, b, f), price=price)
    for gid, type_id, level, a, b, f, price in _table('SparkGridTable.bytes', 28, '<7I')
}
SCHEME_ROWS = {
    ident: dict(currency=currency, price=price)
    for ident, currency, price in _table('SparkSchemePriceTable.bytes', 12, '<3I')
}
VALID_SPARKS = {row[0] for row in _table('ItemSparkTable.bytes', 2104, '<I')}
if len(GRID_ROWS) != 30 or len(SCHEME_ROWS) != 10 or not set(STARTER_GRID_IDS) <= set(GRID_ROWS):
    raise ValueError('Spark OBT resources changed; refusing unsafe assumptions')
if not set(STARTER_ITEM_IDS) <= VALID_SPARKS:
    raise ValueError('Spark starter item IDs absent from original resource table')


def _saved(c, uid, name, default):
    row = c.execute('SELECT value FROM obt_settings WHERE uid=? AND name=?', (uid, name)).fetchone()
    return json.loads(row['value']) if row else default


def _write(c, uid, name, value):
    c.execute('INSERT INTO obt_settings(uid,name,value) VALUES(?,?,?) '
              'ON CONFLICT(uid,name) DO UPDATE SET value=excluded.value',
              (uid, name, json.dumps(value, ensure_ascii=False)))


def available_grids(database, uid):
    with database.connect() as c:
        row = c.execute('SELECT level FROM players WHERE uid=?', (uid,)).fetchone()
        if row is None:
            raise ValueError('Account not found')
        purchased = _saved(c, uid, 'spark_grids', [])
    unlocked = {gid for gid, info in GRID_ROWS.items() if info['unlock_level'] <= row['level']}
    unlocked.update(STARTER_GRID_IDS)
    unlocked.update(int(x) for x in purchased if str(x).isdigit() and int(x) in GRID_ROWS)
    return sorted(unlocked)


def login_snapshot(database, uid):
    with database.connect() as c:
        configs = _saved(c, uid, 'spark_configs', {})
    valid_ids = sorted(int(x) for x in configs if str(x).isdigit() and int(x) in SCHEME_ROWS)
    grids = available_grids(database, uid)
    return dict(Count=len(grids), GridIdList=grids, CfgCount=len(valid_ids), SparkCfgIdList=valid_ids)


def _ensure_table(c):
    c.execute('CREATE TABLE IF NOT EXISTS obt_spark_items('
              'uid INTEGER NOT NULL REFERENCES players(uid),'
              'resource_id INTEGER NOT NULL,amount INTEGER NOT NULL CHECK(amount BETWEEN 0 AND 9999),'
              'PRIMARY KEY(uid,resource_id))')


def ensure_starters(database, uid):
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        _ensure_table(c)
        for ident in STARTER_ITEM_IDS:
            c.execute('INSERT OR IGNORE INTO obt_spark_items(uid,resource_id,amount) VALUES(?,?,1)',
                      (uid, ident))


def item_id(uid, resource_id):
    return (1 << 60) + (int(uid) << 20) + int(resource_id)


def spark_items(database, uid):
    with database.connect() as c:
        _ensure_table(c)
        records = c.execute('SELECT resource_id,amount FROM obt_spark_items WHERE uid=? AND amount>0 ORDER BY resource_id', (uid,)).fetchall()
    return [dict(Id=item_id(uid, row['resource_id']), Category=3, Index=row['resource_id'],
                 Bag=3, Pos=10+i, Stack=row['amount'], Exp=0, WeaponCount=0, WeaponSlot=[],
                 DecorateCount=0, DecorateSlot=[], CreateTime=0, DeadTime=0,
                 BeginTime=0, EndTime=0, ExistType=0, Skin=0)
            for i, row in enumerate(records)]


def owns_spark(database, uid, item, index):
    if not item or index not in VALID_SPARKS:
        return False
    with database.connect() as c:
        _ensure_table(c)
        row = c.execute('SELECT amount FROM obt_spark_items WHERE uid=? AND resource_id=?',
                        (uid, index)).fetchone()
    return bool(row and row['amount'] and item == item_id(uid, index))


def _buy(database, uid, ident, kind):
    table = SCHEME_ROWS if kind == 'scheme' else GRID_ROWS
    if ident not in table:
        return 'invalid_goods'
    if kind == 'grid' and ident in available_grids(database, uid):
        return 'ok'
    import economy
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        if kind == 'scheme':
            configs = _saved(c, uid, 'spark_configs', {})
            if str(ident) in configs:
                return 'ok'
            amount = SCHEME_ROWS[ident]['price']
            currency = SCHEME_ROWS[ident]['currency']
            if currency not in (1, 2, 3, 5, 6):
                return 'unsupported_currency'
        else:
            purchased = set(int(x) for x in _saved(c, uid, 'spark_grids', []) if str(x).isdigit())
            if ident in purchased:
                return 'ok'
            # The 4th-6th DWORD meanings in SparkGridTable are not verified.
            # Our local policy charges silver (3) at the original final DWORD
            # amount, never a guessed currency or a payment URL.
            amount = GRID_ROWS[ident]['price']
            currency = 3
        if amount and economy.balance(c, uid, currency) < amount:
            return 'not_enough_money'
        if amount:
            economy.adjust(c, uid, currency, -amount)
        if kind == 'scheme':
            configs[str(ident)] = dict(name='Scheme ' + str(ident), grids=[])
            _write(c, uid, 'spark_configs', configs)
        else:
            purchased.add(ident)
            _write(c, uid, 'spark_grids', sorted(purchased))
        database.audit(c, uid, 'spark_unlock', dict(kind=kind, id=ident, currency=currency, price=amount))
        return 'ok'


def buy_scheme(database, uid, ident):
    return _buy(database, uid, int(ident), 'scheme')


def buy_grid(database, uid, ident):
    return _buy(database, uid, int(ident), 'grid')


# v56.1: one *local* free Spark roll per account, not Tencent lottery odds.
# The original ItemSparkTable proves the granted IDs are real resources, but
# does not prove the original lottery probability table or prize distribution.
FREE_SPARK_PRIZES = {1: 20102, 2: 20202, 3: 20302, 4: 20102}
if not set(FREE_SPARK_PRIZES.values()) <= VALID_SPARKS:
    raise ValueError('Missing original Spark free reward resources')
FREE_SPARK_KEY = 'spark_free_roll_v56_1'


def _free_lottery_info(ident, claimed):
    # Present a free first roll on each tab until the *shared* entitlement is
    # used. The client chooses the ID; all four IDs consume the same claim.
    return dict(Id=ident, Total=int(claimed), DayFree=0 if claimed else 1,
                NextFreeTime=0, Discount=100, LoginFree=0 if claimed else 1)


def lottery_info(database, uid):
    with database.connect() as c:
        claimed = bool(_saved(c, uid, FREE_SPARK_KEY, None))
    return dict(Count=4, LotteryInfo=[_free_lottery_info(i, claimed) for i in range(1, 5)],
                DayMaxCount=1, DayCount=int(claimed))


def free_lottery_draw(database, uid, ident):
    """Consume a single local free claim and grant one real OBT Spark item.

    Entire read/modify/write is under one SQLite write transaction. No paid
    draws, guessed RNG, or purchases, and no client-provided prize identifiers.
    Returns (result, item_info, updated_info, actual_change).
    """
    if type(ident) is not int or ident not in FREE_SPARK_PRIZES:
        return 'invalid_goods', [], _free_lottery_info(1, True), False
    with database.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        _ensure_table(c)
        if c.execute('SELECT 1 FROM players WHERE uid=?', (uid,)).fetchone() is None:
            raise ValueError('Account not found')
        if _saved(c, uid, FREE_SPARK_KEY, None):
            return 'already_claimed', [], _free_lottery_info(ident, True), False
        item = FREE_SPARK_PRIZES[ident]
        c.execute('INSERT INTO obt_spark_items(uid,resource_id,amount) VALUES(?,?,1) '
                  'ON CONFLICT(uid,resource_id) DO UPDATE SET amount=amount+1', (uid, item))
        _write(c, uid, FREE_SPARK_KEY, {'id': ident, 'item': item, 'version': 1})
        database.audit(c, uid, 'spark_free_roll', {'lottery_id': ident, 'reward_id': item, 'count': 1})
        reward = dict(Category=3, Index=item, Count=1, Id=item_id(uid, item))
        return 'ok', [reward], _free_lottery_info(ident, True), True


# Keep the old API for historical callers. It now exposes the current
# entitlement rather than explicitly disabling every free Spark interaction.
def unavailable_lottery_info(database, uid):
    return lottery_info(database, uid)
