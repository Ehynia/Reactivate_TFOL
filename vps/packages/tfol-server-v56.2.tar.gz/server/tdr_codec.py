"""Bounded TDR codec using the original OBT metadata, not CBT layouts."""
import json
import math
import struct
from pathlib import Path

SCHEMAS = json.loads((Path(__file__).parent / 'obt_schema.json').read_text('utf-8'))
BY_OFFSET = {value['offset']: name for name, value in SCHEMAS.items()}
PRIMITIVES = {2: 'b', 3: 'B', 4: 'B', 5: 'h', 6: 'H', 7: 'i', 8: 'I', 11: 'q', 12: 'Q', 17: 'f'}
HEAD = struct.Struct('>HHII')
MAX_BODY = 65523

def encode(name, values, depth=0):
    if depth > 24 or not isinstance(values, dict):
        raise ValueError('invalid structure')
    fields = SCHEMAS[name]['fields']
    if set(values) - {f['name'] for f in fields}:
        raise ValueError('unknown field for ' + name)
    out = bytearray()
    for field in fields:
        count = values.get(field['count_field'], 0) if field['count_field'] else field['count']
        if type(count) is not int or not 0 <= count <= field['count']:
            raise ValueError('invalid array count')
        if field['count'] == 1:
            items = [values.get(field['name'])]
        else:
            items = values.get(field['name'], [None] * count)
            if not isinstance(items, (list, tuple)) or len(items) != count:
                raise ValueError('array length mismatch')
        for value in items:
            kind = field['kind']
            if kind == 1:
                out.extend(encode(BY_OFFSET[field['child']], {} if value is None else value, depth + 1))
            elif kind == 21:
                value = '' if value is None else value
                if not isinstance(value, str) or '\0' in value:
                    raise ValueError('invalid string')
                raw = value.encode('utf-8') + b'\0'
                if len(raw) > field['capacity']:
                    raise ValueError('string exceeds OBT capacity')
                out.extend(struct.pack('>I', len(raw)) + raw)
            elif kind in PRIMITIVES:
                value = 0 if value is None else value
                if kind == 17:
                    if not isinstance(value, (int, float)) or not math.isfinite(value):
                        raise ValueError('invalid float')
                elif type(value) is not int:
                    raise ValueError('invalid integer')
                try:
                    out.extend(struct.pack('>' + PRIMITIVES[kind], value))
                except (struct.error, OverflowError) as e:
                    raise ValueError('scalar outside OBT range') from e
            else:
                raise ValueError('unsupported TDR kind')
            if len(out) > MAX_BODY:
                raise ValueError('message too large')
    return bytes(out)

def decode(name, data, depth=0):
    if depth > 24:
        raise ValueError('schema recursion')
    pos = 0
    result = {}
    for field in SCHEMAS[name]['fields']:
        count = result[field['count_field']] if field['count_field'] else field['count']
        if type(count) is not int or not 0 <= count <= field['count']:
            raise ValueError('invalid array count')
        items = []
        for _ in range(count):
            kind = field['kind']
            if kind == 1:
                value, size = decode(BY_OFFSET[field['child']], data[pos:], depth + 1)
                pos += size
            elif kind == 21:
                if pos + 4 > len(data):
                    raise ValueError('truncated string length')
                size = struct.unpack_from('>I', data, pos)[0]
                pos += 4
                if not 1 <= size <= field['capacity'] or pos + size > len(data):
                    raise ValueError('invalid string length')
                raw = data[pos:pos + size]
                if raw[-1] != 0 or b'\0' in raw[:-1]:
                    raise ValueError('invalid string terminator')
                try:
                    value = raw[:-1].decode('utf-8')
                except UnicodeError as e:
                    raise ValueError('invalid UTF-8') from e
                pos += size
            elif kind in PRIMITIVES:
                fmt = struct.Struct('>' + PRIMITIVES[kind])
                if pos + fmt.size > len(data):
                    raise ValueError('truncated scalar')
                value = fmt.unpack_from(data, pos)[0]
                if kind == 17 and not math.isfinite(value):
                    raise ValueError('invalid float')
                pos += fmt.size
            else:
                raise ValueError('unsupported TDR kind')
            items.append(value)
        result[field['name']] = items[0] if field['count'] == 1 else items
    return result, pos

def decode_all(name, data):
    value, size = decode(name, data)
    if size != len(data):
        raise ValueError('trailing request data')
    return value

def packet(command, schema, values):
    # Native OBT dialogs use NetResultMessageTable keys, not our Python
    # exception names. Keep domain errors separate from client wire text.
    mapping={'not_owned':'invalidItemId','invalid_equipment':'invalidItemId',
             'not_enough_money':'lackOfMoney','invalid_goods':'invalidGoodsId',
             'invalid_price':'invalidGoodsId','invalid_item':'invalidItemId',
             'bag_full':'unkown','server_unavailable':'noSuitableRoom'}
    if values.get('Result') in mapping:values=dict(values,Result=mapping[values['Result']])
    body = encode(schema, values)
    return HEAD.pack(1, command, 12, len(body)) + body

def packets(data):
    """Split a response bundle into complete native packets."""
    result = []
    pos = 0
    while pos < len(data):
        if pos + 12 > len(data):
            raise ValueError('truncated native header')
        version, command, head, size = HEAD.unpack_from(data, pos)
        end = pos + head + size
        if version != 1 or head != 12 or size > MAX_BODY or end > len(data):
            raise ValueError('invalid native packet')
        result.append((command, data[pos + head:end]))
        pos = end
    return result
