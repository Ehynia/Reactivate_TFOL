"""Manual, read-only text inventory. Never invoked by game launch or exit."""
import argparse,csv,hashlib,json,re,struct,time,zlib
from pathlib import Path

FIELDS=['key','source','record','offset','original','translation','parameters','kind','source_sha256']
UTF8=re.compile(rb'[\x09\x0a\x0d\x20-\x7e\x80-\xff]{2,}')
FSTRING=re.compile(rb'(?=[\x02-\xff][\x00-\x7f]\x00\x00|[\x00-\xff][\x80-\xff]\xff\xff)')
CJK=re.compile('[\u3400-\u9fff]')
PARAMS=re.compile(r'%(?:\d+\$)?[-+#0 ]*\d*(?:\.\d+)?[a-zA-Z]|\{[^{}\r\n]+\}|</?[^<>\r\n]+>|\\[nrt]')

def human(text):
    if not text.strip() or len(text)>20000:return False
    if any(not c.isprintable() and c not in '\r\n\t' for c in text):return False
    if CJK.search(text):return True
    return bool(re.search('[A-Za-z]',text) and (' ' in text or '%' in text or '{' in text)) and not text.startswith(('/Game/','/Engine/','../../../','Class '))

def row(source,record,offset,text,kind,sha):
    return dict(key=hashlib.sha256((source+'\0'+str(record)+'\0'+str(offset)+'\0'+text).encode()).hexdigest()[:24],source=source,record=record,offset=offset,
                original=text,translation='',parameters=' '.join(PARAMS.findall(text)),kind=kind,source_sha256=sha)

def table_rows(raw,source):
    width,count=struct.unpack_from('<II',raw,8)
    if not width or len(raw)!=140+width*count:raise ValueError('MSES layout mismatch: '+source)
    sha=hashlib.sha256(raw).hexdigest();out=[]
    for i in range(count):
        record=raw[140+i*width:140+(i+1)*width]
        for m in UTF8.finditer(record):
            if m.end()>=len(record) or record[m.end()]!=0:continue
            try:text=m.group().decode('utf-8')
            except UnicodeError:continue
            if human(text):out.append(row(source,i+1,m.start(),text,'MSES UTF-8 field',sha))
    return out

class Reader:
    def __init__(self,raw):self.raw=raw;self.pos=0
    def read(self,n):
        if n<0 or self.pos+n>len(self.raw):raise ValueError('Truncated resource')
        value=self.raw[self.pos:self.pos+n];self.pos+=n;return value
    def unpack(self,fmt):return struct.unpack(fmt,self.read(struct.calcsize(fmt)))
    def string(self):
        n,=self.unpack('<i')
        if not -32768<=n<=32768:raise ValueError('Invalid FString length')
        raw=self.read(n if n>=0 else -n*2)
        if not raw:return ''
        value=raw.decode('utf-8' if n>=0 else 'utf-16le')
        if not value.endswith('\0'):raise ValueError('Missing FString terminator')
        return value[:-1]
    def entry(self):
        offset,size,usize,compression=self.unpack('<qqqI');sha=self.read(20);blocks=[]
        if compression:
            n,=self.unpack('<i')
            if not 0<=n<=65536:raise ValueError('Invalid block count')
            blocks=[self.unpack('<qq') for _ in range(n)]
        flags,blocksize=self.unpack('<BI')
        return dict(offset=offset,size=size,uncompressed=usize,compression=compression,sha1=sha,blocks=blocks,flags=flags,blocksize=blocksize)

def pak_index(path):
    with path.open('rb') as f:
        f.seek(-44,2);magic,version,offset,size,sha=struct.unpack('<IIqq20s',f.read(44))
        if magic!=0x5a6f12e1 or version!=3 or not 0<=size<=64*1024*1024:raise ValueError('Unsupported PAK footer')
        f.seek(offset);raw=f.read(size)
    if hashlib.sha1(raw).digest()!=sha:raise ValueError('PAK index hash mismatch')
    r=Reader(raw);mount=r.string();declared,=r.unpack('<i');entries=[]
    while r.pos<len(raw):
        name=r.string();entry=r.entry();entry['name']=name;entries.append(entry)
    if len(entries)-declared not in (0,-100):raise ValueError('Unexpected PAK entry count')
    return mount,entries

def pak_asset(path,entry):
    if entry['flags']&1:raise ValueError('Encrypted PAK asset')
    if not 0<=entry['uncompressed']<=256*1024*1024:raise ValueError('Asset exceeds manual export limit')
    with path.open('rb') as f:
        if entry['compression']:
            if entry['compression']!=1:raise ValueError('Unsupported asset compression')
            result=bytearray()
            for start,end in entry['blocks']:
                f.seek(start);result.extend(zlib.decompress(f.read(end-start)))
                if len(result)>entry['uncompressed']:raise ValueError('Expanded asset too large')
            result=bytes(result)
        else:
            f.seek(entry['offset']);local=Reader(f.read(53)).entry()
            if local['size']!=entry['size']:raise ValueError('PAK entry disagrees')
            result=f.read(entry['size'])
    if len(result)!=entry['uncompressed'] or hashlib.sha1(result).digest()!=entry['sha1']:raise ValueError('PAK asset hash mismatch')
    return result

def asset_rows(raw,source):
    if raw[:4]==b'MSES':return table_rows(raw,source)
    sha=hashlib.sha256(raw).hexdigest();out=[];seen=set()
    for m in FSTRING.finditer(raw):
        offset=m.start()
        try:
            reader=Reader(raw);reader.pos=offset;text=reader.string()
        except (ValueError,UnicodeError,struct.error):continue
        if human(text):out.append(row(source,'FString',offset,text,'Asset FString candidate',sha));seen.add(text)
    # Also catch unprefixed UTF-8 strings (configs and hardcoded UI text).
    for m in UTF8.finditer(raw):
        if m.end()>=len(raw) or raw[m.end()]!=0:continue
        try:text=m.group().decode('utf-8')
        except UnicodeError:continue
        if CJK.search(text) and human(text) and text not in seen:
            out.append(row(source,'UTF8',m.start(),text,'Asset UTF-8 candidate',sha));seen.add(text)
    return out

def export(game,out):
    game=Path(game).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    sources=[];rows=[];errors=[];started=time.time()
    for p in sorted((game/'TFOL/Content/Bytes').rglob('*.bytes')):
        try:rows.extend(table_rows(p.read_bytes(),p.relative_to(game).as_posix()));sources.append(p.relative_to(game).as_posix())
        except (OSError,ValueError) as e:errors.append(dict(file=str(p),error=str(e)))
    extensions={'.uasset','.umap','.locres','.ini','.txt','.json','.xml','.csv','.bytes'}
    for p in sorted((game/'TFOL/Content/Paks').glob('*.pak')):
        print('Reading '+p.name,flush=True)
        try:mount,entries=pak_index(p)
        except (OSError,ValueError,struct.error) as e:errors.append(dict(file=p.name,error=str(e)));continue
        sources.append(p.name)
        for entry in entries:
            if Path(entry['name']).suffix.lower() not in extensions:continue
            try:rows.extend(asset_rows(pak_asset(p,entry),p.name+'!'+entry['name']))
            except (OSError,ValueError,struct.error,zlib.error) as e:errors.append(dict(file=p.name+'!'+entry['name'],error=str(e)))
    if not sources:raise ValueError('No client tables or PAKs found. Select the extracted game root.')
    with (out/'TFOL_translation.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,FIELDS);writer.writeheader();writer.writerows(rows)
    manifest=dict(sources=sources,rows=len(rows),seconds=round(time.time()-started,2),errors=errors,
        coverage='All readable MSES human text and FString/UTF-8 candidates in selected local PAK assets. Image text, voice audio and unsupported/encrypted resources are not transcribed. Candidate strings require context review before binary reinsertion.')
    (out/'EXPORT_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Exported '+str(len(rows))+' rows to '+str(out/'TFOL_translation.csv'),flush=True)
    return manifest

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--game-root',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();export(args.game_root,args.out)
