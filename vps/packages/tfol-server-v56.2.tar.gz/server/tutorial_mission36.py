"""v41 original ONCE-ONLY first-login onboarding, not the practice game mode.

The native UE4 OnMSG_LOGIN_DATA_RES handler (pinned in OBT x86 at 0x7d0860)
owns the first tutorial and its UI.  Return Result=badName and blank Name before
lobby initialization, and let the client invoke StartTutorialLevel itself.

DO NOT queue the OB27 travel job here: that opens the training map *after* the
lobby/menu HUD has already been constructed.  The result is two UIs on one map.
"""
import accounts

MAP_ID=1009
PRIVATE_MODE=1004
HERO_ID=15


def tutorial_due(database, uid):
    try:
        identity=accounts.identity(database,uid)
    except ValueError:
        return False
    # nickname_set is the one-time *UI* gate.  tutorial_completed_at is
    # reserved for trusted UE4 completion and is not forged by an ordinary
    # travel, an ESC exit, or an arbitrary network request.
    return bool(identity['tutorial_required'] and not identity['nickname_set']
                and identity['tutorial_completed_at'] is None)


def login_state(database, uid, context):
    """Mark the original client-driven first-login flow before packet 4."""
    accounts.complete_tutorial_for_funded_account(database,uid)
    needed=tutorial_due(database,uid)
    if needed:
        context['original_tutorial_login41']=dict(state='native_login_pending',
            map=MAP_ID,mode=PRIVATE_MODE,hero=HERO_ID)
        # A previously scheduled deferred tutorial would re-enter the map
        # after native StartTutorialLevel.  Never leave one outstanding.
        context.pop('megatron_tutorial36',None)
        context.pop('engine_match',None)
    else:
        context.pop('original_tutorial_login41',None)
        context.pop('megatron_tutorial36',None)
    return needed


def poll(database,uid,context,now):
    """Deprecated delayed OB27 route: explicitly disabled for first login."""
    return b''
