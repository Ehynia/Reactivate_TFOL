"""Local WebAdmin and durable, idempotent typed admin commands."""
import hmac
import json
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
from urllib.parse import urlsplit, parse_qs
import garage
import obt_extensions

ROOT = Path(__file__).resolve().parent
COMMANDS = {
    'backup': [], 'grant_resource': ['uid','resource_id'],
    'grant_currency': ['uid','currency','amount'], 'ban': ['uid','reason'],
    'unban': ['uid'], 'revoke_sessions': ['uid'],
    'publish_news': ['slug','title','body'],
    'start_test_match': ['uid','mode_id'], 'cancel_test_match': ['uid'],
    'claim_first_quest': ['uid'],
    'buy_skin': ['uid','goods_id','currency'],
}


class Admin:
    def __init__(self, state):
        self.state = state
        self.lock = threading.RLock()
        self.path = state.folder/'admin.token'
        if not self.path.exists():
            with self.path.open('x', encoding='ascii') as stream:
                stream.write(secrets.token_hex(32))
            self.path.chmod(0o600)
        self.token = self.path.read_text('ascii').strip()
        if not re.fullmatch('[a-f0-9]{64}', self.token):
            raise ValueError('Invalid local admin.token')

    def authenticated(self, handler):
        origin = handler.headers.get('Origin')
        expected = 'http://127.0.0.1:'+str(handler.server.server_address[1])
        if origin and origin != expected:
            handler.send_json(403, dict(error='origin_rejected'))
            return False
        if not hmac.compare_digest(handler.headers.get('Authorization',''), 'Bearer '+self.token):
            handler.send_json(401, dict(error='admin_token_required'))
            return False
        return True

    def http_get(self, handler):
        parts = urlsplit(handler.path)
        public = {'/admin/':('index.html','text/html; charset=utf-8'),
                  '/admin/admin.js':('admin.js','text/javascript; charset=utf-8'),
                  '/admin/style.css':('style.css','text/css; charset=utf-8')}
        if parts.path in public:
            file, content_type = public[parts.path]
            raw = (ROOT/'admin'/file).read_bytes()
            handler.send_response(200)
            for k,v in {'Content-Type':content_type,'Content-Length':str(len(raw)),
                        'Cache-Control':'no-store','X-Frame-Options':'DENY',
                        'Content-Security-Policy':"default-src 'self'; frame-ancestors 'none'; object-src 'none'",
                        'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}.items():
                handler.send_header(k,v)
            handler.end_headers();handler.wfile.write(raw)
            return
        if not self.authenticated(handler):
            return
        state = self.state
        query = parse_qs(parts.query)
        try:
            if parts.path == '/admin/api/status':
                from capabilities import describe
                with state.lock:
                    counters = dict(connections=state.connections, application_payloads=state.application_payloads,
                                    capture_bytes=state.capture_bytes, network_backend=state.config['network_backend'])
                handler.send_json(200, dict(**counters, metrics=state.metrics.snapshot(), database=state.database.status(),
                                            capabilities=describe(), commands=COMMANDS, journal_error=state.journal.error,
                                            config=state.config))
            elif parts.path == '/admin/api/players':
                offset = int(query.get('offset',['0'])[0])
                if not 0 <= offset <= 10000000:
                    raise ValueError('Invalid offset')
                with state.database.connect() as c:
                    rows = [dict(r) for r in c.execute('SELECT p.uid,p.nickname,p.level,p.experience,p.credits,b.reason AS ban_reason FROM players p LEFT JOIN admin_bans b USING(uid) ORDER BY p.uid LIMIT 100 OFFSET ?', (offset,))]
                handler.send_json(200, dict(players=rows, next_offset=offset+len(rows)))
            elif parts.path == '/admin/api/profile':
                uid = int(query.get('uid',['0'])[0])
                handler.send_json(200, state.database.profile(uid))
            elif parts.path == '/admin/api/local-test':
                import local_simulation,progression
                uid=int(query.get('uid',['0'])[0])
                state.database.profile(uid)
                handler.send_json(200,dict(match=state.simulation.poll(uid),quest=local_simulation.quest(state.database,uid),progression=progression.status(state.database,uid)))
            elif parts.path == '/admin/api/skins':
                import economy
                uid=int(query.get('uid',['0'])[0]);state.database.profile(uid)
                with state.database.connect() as c:
                    owned={(r['category'],r['resource_id']) for r in c.execute('SELECT category,resource_id FROM inventory WHERE uid=?',(uid,))}
                    skins={(r['category'],r['resource_id']) for r in c.execute('SELECT category,resource_id FROM obt_skins WHERE uid=?',(uid,))}
                metadata={(s['category'],s['resource_id']):s for s in garage.RESOURCES['skins']}
                rows=[]
                for g in economy.goods():
                    if g['Category'] not in (10,11):continue
                    skin=metadata[g['Category'],g['Index']];base=(1 if g['Category']==10 else 2,skin['base_id'])
                    rows.append(dict(goods_id=g['Id'],name=skin['name'],category=g['Category'],skin_id=g['Index'],base_id=skin['base_id'],base_owned=base in owned,owned=(g['Category'],g['Index']) in skins,credits=g['PriceOne'],tickets=g['PriceTwo']))
                handler.send_json(200,dict(skins=rows,balances={str(r['Index']):r['Stack'] for r in garage.currency_bag(state.database,uid)}))
            elif parts.path == '/admin/api/audit':
                with state.database.connect() as c:
                    rows = [dict(r) for r in c.execute('SELECT id,created_at,uid,action,data FROM audit ORDER BY id DESC LIMIT 200')]
                handler.send_json(200, dict(audit=rows))
            elif parts.path == '/admin/api/errors':
                state.journal.flush()
                rows = []
                path = state.folder/'server.jsonl'
                if path.exists():
                    # Rotation bounds this read to 8 MiB; no session secrets in the journal.
                    for line in path.read_text('utf-8', errors='replace').splitlines():
                        try:
                            value = json.loads(line)
                        except ValueError:
                            continue
                        if 'error' in value or value.get('event') in {'transport_closed','transport_auth_rejected'}:
                            rows.append({k:v for k,v in value.items() if k not in {'hex'}})
                handler.send_json(200, dict(errors=rows[-200:]))
            else:
                handler.send_json(404, dict(error='not_found'))
        except (ValueError, TypeError) as error:
            handler.send_json(400, dict(error=str(error)))

    def http_post(self, handler, data):
        if not self.authenticated(handler):
            return
        if handler.path != '/admin/api/command':
            handler.send_json(404, dict(error='not_found'));return
        result = self.execute(data.get('name'), data.get('arguments',{}), data.get('request_id'))
        handler.send_json(200, result)

    def execute(self, name, arguments, request_id=None):
        if name not in COMMANDS or not isinstance(arguments,dict) or set(arguments)!=set(COMMANDS[name]):
            raise ValueError('Unknown command or invalid arguments')
        request_id = request_id or secrets.token_hex(16)
        if not isinstance(request_id,str) or not re.fullmatch('[a-zA-Z0-9_-]{16,64}',request_id):
            raise ValueError('Invalid request_id')
        encoded = json.dumps(arguments,sort_keys=True,ensure_ascii=False)
        state = self.state
        with self.lock, state.database.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            old = c.execute('SELECT * FROM admin_commands WHERE request_id=?',(request_id,)).fetchone()
            if old:
                if old['name'] != name or old['arguments'] != encoded:
                    raise ValueError('request_id is already used for a different command')
                return dict(request_id=request_id,replayed=True,result=json.loads(old['result']))
            uid = arguments.get('uid')
            if uid is not None:
                if type(uid) is not int or not c.execute('SELECT 1 FROM players WHERE uid=?',(uid,)).fetchone():
                    raise ValueError('Unknown uid')
            if name == 'backup':
                target = state.folder/'backups'/('server-'+request_id+'.sqlite3')
                # Run SQLite's online backup using a separate read connection.
                if not target.exists():
                    state.database.backup(target)
                with sqlite3.connect(target) as check:
                    if check.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                        raise ValueError('Backup integrity failure')
                result = dict(file=str(target.resolve()), integrity='ok')
            elif name in {'ban','unban','revoke_sessions'}:
                if name == 'ban':
                    reason = arguments['reason']
                    if not isinstance(reason,str) or not 1<=len(reason)<=200:
                        raise ValueError('Reason requires 1..200 characters')
                    c.execute('INSERT INTO admin_bans VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET reason=excluded.reason,created_at=excluded.created_at',(uid,reason,time.time()))
                elif name == 'unban':
                    c.execute('DELETE FROM admin_bans WHERE uid=?',(uid,))
                if name != 'unban':
                    c.execute('UPDATE sessions SET revoked=1 WHERE uid=?',(uid,))
                result = dict(uid=uid, banned=name=='ban', sessions_revoked=name!='unban')
            elif name == 'start_test_match':
                result=state.simulation.start_in(c,uid,'admin',arguments['mode_id'])
            elif name == 'cancel_test_match':
                result=state.simulation.cancel_in(c,uid)
            elif name == 'claim_first_quest':
                import local_simulation
                result=local_simulation.claim_in(state.database,c,uid,0)
            elif name == 'buy_skin':
                import economy
                ident,currency=arguments['goods_id'],arguments['currency']
                if type(ident) is not int or type(currency) is not int:raise ValueError('Invalid skin purchase')
                offer=next((g for g in economy.goods() if g['Id']==ident and g['Category'] in (10,11)),None)
                if not offer:raise ValueError('Unknown skin')
                price={3:offer['PriceOne'],6:offer['PriceTwo']}.get(currency)
                if price is None:raise ValueError('Skin currency must be 3 or 6')
                item,applied=economy.buy_skin_in(state.database,c,uid,dict(Id=ident,Payment=currency,Price=price,ItemInfo=dict(Category=offer['Category'],Index=offer['Index'],Count=1)))
                skin=next(s for s in garage.RESOURCES['skins'] if s['category']==offer['Category'] and s['resource_id']==offer['Index'])
                holder=c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=? AND resource_id=?',(uid,1 if offer['Category']==10 else 2,skin['base_id'])).fetchone()
                if not holder:raise ValueError('Base character or weapon is not owned')
                c.execute('INSERT INTO obt_skin_equipment VALUES(?,?,?) ON CONFLICT(uid,holder_item) DO UPDATE SET skin_item=excluded.skin_item',(uid,holder[0],item))
                result=dict(uid=uid,skin_item=item,goods_id=ident,purchased=applied,equipped=True)
            elif name == 'grant_currency':
                currency, amount = arguments['currency'],arguments['amount']
                if type(currency) is not int or currency not in {1,2,3,6,7,8,9} or type(amount) is not int or not 1<=amount<=1000000:
                    raise ValueError('Invalid currency or amount (1..1000000)')
                if currency == 3:
                    current = c.execute('SELECT credits FROM players WHERE uid=?',(uid,)).fetchone()[0]
                    if current+amount>2000000000:raise ValueError('Balance limit')
                    c.execute('UPDATE players SET credits=credits+? WHERE uid=?',(amount,uid))
                else:
                    table = 'obt_currency' if currency>=6 else 'wallet'
                    row = c.execute('SELECT amount FROM '+table+' WHERE uid=? AND currency=?',(uid,currency)).fetchone()
                    current = row[0] if row else 0
                    if current+amount>2000000000:raise ValueError('Balance limit')
                    c.execute('INSERT INTO '+table+' VALUES(?,?,?) ON CONFLICT(uid,currency) DO UPDATE SET amount=excluded.amount',(uid,currency,current+amount))
                result = dict(uid=uid,currency=currency,balance=current+amount)
            elif name == 'grant_resource':
                resource = arguments['resource_id']
                if type(resource) is not int:raise ValueError('Invalid resource ID')
                row = c.execute('SELECT kind FROM catalog WHERE resource_id=?',(resource,)).fetchone()
                if not row:raise ValueError('Resource absent from original OBT catalog')
                category = 1 if row[0]=='character' else 2
                old = c.execute('SELECT item_id FROM inventory WHERE uid=? AND category=? AND resource_id=?',(uid,category,resource)).fetchone()
                if old:
                    item = old[0]
                else:
                    pos = c.execute('SELECT coalesce(max(pos),-1)+1 FROM inventory WHERE uid=? AND bag=?',(uid,category)).fetchone()[0]
                    item = c.execute('INSERT INTO inventory(uid,resource_id,acquired_at,category,bag,pos) VALUES(?,?,?,?,?,?)',(uid,resource,time.time(),category,category,pos)).lastrowid
                if category==1:
                    c.execute('INSERT OR IGNORE INTO characters VALUES(?,?)',(uid,resource))
                skin = obt_extensions.ensure_skin(c,uid,category,resource)
                result = dict(uid=uid,item_id=item,resource_id=resource,skin_item=skin)
            elif name == 'publish_news':
                slug,title,body = (arguments[k] for k in ['slug','title','body'])
                if not all(isinstance(v,str) and v.strip() for v in [slug,title,body]) or len(slug)>80 or len(title)>120 or len(body)>8000:
                    raise ValueError('Invalid news content')
                c.execute('INSERT INTO news(slug,title,body,published_at) VALUES(?,?,?,?) ON CONFLICT(slug) DO UPDATE SET title=excluded.title,body=excluded.body,published_at=excluded.published_at',(slug,title,body,time.time()))
                result = dict(slug=slug,published=True)
            c.execute('INSERT INTO admin_commands VALUES(?,?,?,?,?)',(request_id,name,encoded,json.dumps(result),time.time()))
            state.database.audit(c,uid,'admin_'+name,dict(request_id=request_id,arguments=arguments,result=result))
        state.metrics.record('admin_commands')
        state.event('admin_command',name=name,uid=uid,request_id=request_id)
        return dict(request_id=request_id,replayed=False,result=result)
