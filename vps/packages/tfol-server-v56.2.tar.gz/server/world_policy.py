import json
from pathlib import Path
POLICY=json.loads((Path(__file__).parent/'world_policy.json').read_text('utf-8'))
